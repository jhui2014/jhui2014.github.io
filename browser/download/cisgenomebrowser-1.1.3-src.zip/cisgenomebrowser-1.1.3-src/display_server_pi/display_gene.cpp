#include "display_gene.h"
#include "drawCommon.h"
#include "display_genome.h"

display_gene::display_gene(http_request* r, string track_name, display_genome *g) 
             :display_track(r, track_name, g) {
	src_filename = "";
	draw_exon_num = default_draw_exon_num;
	do_caching = default_do_caching;
	annotation = default_annotation;
	max_height = default_max_height;
	gene_font_size = default_gene_font_size;
}

bool display_gene::load_from_file(string file_name)
{
	display_track::load_from_file(file_name);
	src_filename = ReadIni(file_name, name + "/src_filename", wxString(""));
	draw_exon_num = ReadIni(file_name, name + "/draw_exon_num",
		default_draw_exon_num);
	do_caching = ReadIni(file_name, name + "/do_caching", default_do_caching);
	annotation = ReadIni(file_name, name + "/annotation", default_annotation);
	max_height = ReadIni(file_name, name + "/max_height", default_max_height);
	gene_font_size = ReadIni(file_name, name + "/gene_font_size", gene_font_size);
	if (title == "")
	{
		title = get_file_name(src_filename);
	}
	return true;
}

bool display_gene::update_params()
{
	if (!display_track::update_params())
		return false;
	if (req->params_.count("update_track") > 0)
	{
		if (req->params_.count("src_filename") > 0) src_filename = req->params_["src_filename"];
		draw_exon_num = (req->params_.count("draw_exon_num") > 0);
		do_caching = (req->params_.count("do_caching") > 0);
		annotation = (req->params_.count("annotation") > 0);		
		if (is_int(req->params_["max_height"]) && str2int(req->params_["max_height"]) >= 10 && str2int(req->params_["max_height"]) <= 10000) {
			max_height = str2int(req->params_["max_height"]);
		}
		if (is_int(req->params_["gene_font_size"]) && str2int(req->params_["gene_font_size"]) >= 0 && str2int(req->params_["gene_font_size"]) <= 30) {
			gene_font_size = str2int(req->params_["gene_font_size"]);
		}
		if (title == "")
			title = get_file_name(src_filename);
	}
	else if (req->params_.count("update_tracks") > 0)
	{
	}
	else
		return false;
	return true;
}

bool display_gene::write_to_file(string file_name)
{
	display_track::write_to_file(file_name);
	WriteIni(file_name, name + "/type", "gene", true);
	WriteIni(file_name, name + "/src_filename", src_filename, src_filename
		!= "");
	WriteIni(file_name, name + "/draw_exon_num", draw_exon_num, draw_exon_num
		!= default_draw_exon_num);
	WriteIni(file_name, name + "/do_caching", do_caching, do_caching
		!= default_do_caching);
	WriteIni(file_name, name + "/annotation", annotation, annotation != default_annotation);
	WriteIni(file_name, name + "/max_height", max_height, max_height != default_max_height);
	WriteIni(file_name, name + "/gene_font_size", gene_font_size, gene_font_size != default_gene_font_size);
	return true;
}

string display_gene::get_configure_html()
{
	html_formater my_html_formater;
	my_html_formater.load_from_template_file(template_path
		+ "gene_track_config.html");
	my_html_formater.replace_keyword("$SRC_FILENAME$", src_filename);
	string result = my_html_formater.buf;
	my_html_formater.buf = display_track::get_configure_html();
	my_html_formater.replace_keyword("$TRACK_CONTENTS$", result);
	my_html_formater.replace_keyword("$TRACK_TYPE$", "gene");
	my_html_formater.replace_keyword("$DRAW_EXON_NUM$",
		draw_exon_num ? " checked" : "");
	my_html_formater.replace_keyword("$DO_CACHING$", do_caching ? " checked"
		: "");
	my_html_formater.replace_keyword("$ANNOTATION$", annotation?" checked":"");
	my_html_formater.replace_keyword("$MAX_HEIGHT$", int2str(max_height));
	my_html_formater.replace_keyword("$GENE_FONT_SIZE$", int2str(gene_font_size));

	return my_html_formater.buf;
}

bool display_gene::generate_pic_file(bool get_intervals)
{
	if (!display_track::generate_pic_file(get_intervals))
		return false;
	/*string command_line = module_path + "draw_intensity.exe " + src_filename + " " + temp_path + pic_filename + " /gene /region:" + genome->region + " /size:" + int2str(genome->pic_width) + "x100" + " /axis:";
	command_line += (genome->left_axis?"1":"0");
	command_line += (genome->right_axis?"1":"0");
	command_line += (top_axis?"1":"0");
	command_line += (bottom_axis?"1":"0");*/
	/*string command_line = string("\"") + module_path + "draw_figure.exe\" gene \"" + temp_path + pic_filename + "\" \"" + src_filename + "\" /region:" + genome->region + " /width:" + int2str(genome->pic_width) + " /axis:";
	command_line += (top_axis?"1":"0");
	command_line += (bottom_axis?"1":"0");
	command_line += (genome->left_axis?"1":"0");
	command_line += (genome->right_axis?"1":"0");
	call_external(command_line);*/
	draw_gene my_draw;
	my_draw.intervals = intervals;
	if (!parse_region(genome->region, my_draw.chr, my_draw.startpos,
		my_draw.endpos))
	{
		my_draw.error_msg = "bad region.";
	}
	if (cache_genefiles && do_caching)
	{
		genefile* tempgenefile = NULL;
		if (get_genefile_from_cache(src_filename, my_draw.error_msg,
			tempgenefile))
		{
			tempgenefile->search_by_region(my_draw.chr, my_draw.startpos,
				my_draw.endpos, my_draw.genes);
		}
		my_draw.gene_filename = "";
	}
	else
	{
		get_gene_file_name(src_filename, my_draw.gene_filename,
			my_draw.error_msg);
	}
	my_draw.draw_exon_num = draw_exon_num;
	my_draw.size.cx = genome->pic_width;
	my_draw.max_height = max_height;
	my_draw.box_margin = genome->pic_margin / 3;
	my_draw.data_margin = genome->pic_margin * 2 / 3;
	my_draw.font_size = genome->font_size;
		my_draw.gene_font_size = gene_font_size;
	my_draw.left_axis = genome->left_axis;
	my_draw.right_axis = genome->right_axis;
	if (genome->grid == "off") {
		my_draw.v_grids = false;
	} else if (genome->grid == "gray") {
		my_draw.custom_grid_color = true;
		my_draw.shaded_background = false;
	} else if (genome->grid == "gray_shaded") {
		my_draw.custom_grid_color = true;
		my_draw.shaded_background = true;
	} else if (genome->grid == "color_shaded") {
		my_draw.custom_grid_color = false;
		my_draw.shaded_background = true;
	} else if (genome->grid == "color") {
		my_draw.custom_grid_color = false;
		my_draw.shaded_background = false;
	}
	my_draw.top_axis = top_axis;
	my_draw.bottom_axis = bottom_axis;
	my_draw.fast_draw = fast_draw;
	my_draw.load_data();
	my_draw.prepare_data();
	if (get_intervals) {
		my_draw.get_intervals();
		intervals = my_draw.intervals;
	} else {
		my_draw.drawfile(temp_path + client_ip + pic_filename);
		display_track::generate_hrefs(my_draw.map_rects, my_draw.map_strings);
	}

	return true;
}

string display_gene::type()
{
	return "display_gene";
}