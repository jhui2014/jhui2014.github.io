#exp_object is a list that contains three elements:
#iso.exp is the isoform expression matrix 
#gene.exp is the gene expression matrix
#num_iso is contains the gene names and number of isoforms for each gene
#outcome is the sample tags for the groups like C(1,1...,1,2,2...,2,3,3...,3)

Multigroup=function(exp_object, outcome, nperm, seed)
{
  iso.exp=exp_object$iso.exp
  gene.exp=exp_object$gene.exp
  
  #get the name for genes and isoforms--isoform level
  gene_name=iso.exp[,1]
  isoform_name=iso.exp[,2]
  isoform_number=iso.exp[,3]
  
  #get the gene name and isoform number--gene level
  gene.name=gene.exp[,1]
  isoform.number=gene.exp[,2]
  
  n_sample=length(outcome) #total number of samples
  n_iso=nrow(iso.exp) #total number of isoforms(transcripts) in the dataframe  
  n_gene=nrow(gene.exp) #number of genes
  
  N.iso=apply(iso.exp[,4:(n_sample+3)],2,as.numeric)#this is the expression matrix for all isoforms, without the gene and isoform names
  N.gene=apply(gene.exp[,3:(n_sample+2)],2,as.numeric)
    
  #test 1: do the Kruskal-Wallis test for all isoforms, returns the KW statistics and p-values
  isoform.res=t(apply(N.iso,1,calculate.KW.test,tag=outcome))
  colnames(isoform.res)=c('KW.stat','p.value.KWtest')
  
  #calculate the FDR for all isoforms based on the KW p value
  iso.FDR=p.adjust(isoform.res[,2], method="BH")
  
  isoform.result=data.frame(gene_name,isoform_name,isoform_number,isoform.res,iso.FDR)
  isoform.result=isoform.result[order(isoform.result[,5],-isoform.result[,4],isoform.result[,1]),]
  #gene_name, isoform_name, isoform_number, KW.stat, p.value, FDR
  #sort order: p.value, -KW.stat, gene_name
  print("Isoform differential expression test done!")
  
  #test 2: Do the Kruskal-Wallis test for all genes, returns the KW statistics and p-values
  gene.DE.res=t(apply(N.gene,1,calculate.KW.test,tag=outcome))
  colnames(gene.DE.res)=c('kw.stat','p.value.kwtest')
  gene.FDR=p.adjust(gene.DE.res[,2], method="BH")
  gene.DE.result=data.frame(gene.name,gene.DE.res,gene.FDR)
  gene.DE.result=gene.DE.result[order(gene.DE.result[,3],-gene.DE.result[,2],gene.DE.result[,1]),]
  
  print("Gene differential expression test done!")
  
  #test 3: Permutation test for differential expression and splicing of genes using GDS score
   GDS.result=GDS(isoform.info=data.frame(gene_name=isoform.result[,1], isoform_number=isoform.result[,3], Tj=isoform.result[,4]),
                  iso.exp=iso.exp, type='quant', outcome=outcome, nperm=nperm, seed=seed)
   GDS_c=GDS.result[[1]]
   GDS_p=GDS.result[[2]]
   print("Permutation test based on DS done!")
  
  return(list(isoform.result=isoform.result,gene.DE.result=gene.DE.result,GDS_c.result=GDS_c, GDS_p.result=GDS_p, test=GDS.result$test))
}

#this function calculate the Kruskal-Wallis test for multiple groups, 
#data is the data vector, tag is the sample tags for the groups like C(1,1...,1,2,2...,2,3,3...,3)
#return the KW statistic and the p_value
calculate.KW.test=function(data,tag)
{
  test=kruskal.test(data, tag)
  
  kw_stat=test$statistic
  p_value=test$p.value
    
  if(is.na(p_value)){p_value=1}
  
  return(c(kw_stat, p_value))
  
}
