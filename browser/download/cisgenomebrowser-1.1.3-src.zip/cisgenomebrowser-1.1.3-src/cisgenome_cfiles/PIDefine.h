#ifndef _PIDEFINE_H_
#define _PIDEFINE_H_

#define fabs abs

#endif