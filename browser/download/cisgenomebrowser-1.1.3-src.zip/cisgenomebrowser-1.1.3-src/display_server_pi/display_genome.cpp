#include "display_genome.h"
#include "drawCommon.h"
#include "display_gene.h"
#include "display_signal.h"
#include "display_conservation.h"
#include "display_region.h"
#include "display_nucleotide.h"
#include "display_motif.h"
#include "display_data.h"
#include "display_cel.h"
#include "session.h"

display_genome::display_genome()
{

}

display_genome::display_genome(http_request* r)
{
	req = r;
	tracks.clear();
	hided_tracks.clear();
	region = default_genome;
	ucsc_genome_assembly = "";
	pic_width = default_pic_width;
	pic_margin = default_pic_margin;
	font_size = default_font_size;
	grid = default_grid;
	fold_track.clear();
	left_axis = true;
	right_axis = true;
	ucsc_browser = false;
}

display_genome::~display_genome()
{
	cleanup();
}

void display_genome::cleanup()
{
	for (int i = 0; i < (int) tracks.size(); i++)
	{
		delete tracks[i];
	}
	tracks.clear();
	for (int i = 0; i < (int) hided_tracks.size(); i++)
	{
		delete hided_tracks[i];
	}
	hided_tracks.clear();
}

display_track* display_genome::create_track(string track_type, string trackname)
{
	if (track_type == "gene")
	{
		return new display_gene(req, trackname, this);
	}
	else if (track_type == "signal")
	{
		return new display_signal(req, trackname, this);
	}
	else if (track_type == "conservation")
	{
		return new display_conservation(req, trackname, this);
	}
	else if (track_type == "region")
	{
		return new display_region(req, trackname, this);
	}
	else if (track_type == "nucleotide")
	{
		return new display_nucleotide(req, trackname, this);
	}
	else
	{
		return NULL;
	}
}

bool display_genome::load_from_file(string file_name)
{
	cleanup();
	int num_tracks = ReadIni(file_name, "genome/num_tracks", 0);
	tracks.resize(num_tracks);
	int num_hided_tracks = ReadIni(file_name, "genome/num_hided_tracks", 0);
	hided_tracks.resize(num_hided_tracks);
	region = ReadIni(file_name, "genome/region", wxS(default_genome));
	chr_region my_region(region);
	my_region.correct();
	region = my_region.get_region();
	ucsc_genome_assembly = ReadIni(file_name, "genome/ucsc_genome_assembly",
		wxString(""));
	pic_width = ReadIni(file_name, "genome/pic_width", default_pic_width);
	pic_margin = ReadIni(file_name, "genome/pic_margin", default_pic_margin);
	font_size = ReadIni(file_name, "genome/font_size", default_font_size);
	left_axis = ReadIni(file_name, "genome/left_axis", true);
	right_axis = ReadIni(file_name, "genome/right_axis", true);
	ucsc_browser = ReadIni(file_name, "genome/ucsc_browser", false);
	grid = ReadIni(file_name, "genome/grid", wxS(default_grid));
	fold_track = str2int_vec(string(ReadIni(file_name, "genome/fold", wxString(
		"")).char_str()));
	for (int i = 0; i < (int) tracks.size(); i++)
	{
		string trackname = string("track") + int2str(i + 1);
		string track_type = ReadIni(file_name, trackname + "/type", wxString("")).c_str();
		tracks[i] = create_track(track_type, trackname);
		if (NULL == tracks[i])
			return false;
		tracks[i]->load_from_file(file_name);
	}
	for (int i = 0; i < (int) hided_tracks.size(); i++)
	{
		string trackname = string("hided_track") + int2str(i + 1);
		string track_type = ReadIni(file_name, trackname + "/type", wxString("")).c_str();
		hided_tracks[i] = create_track(track_type, trackname);
		if (NULL == hided_tracks[i])
			return false;
		hided_tracks[i]->load_from_file(file_name);
	}
	return true;
}

bool display_genome::update_params()
{
	return true;
}

bool display_genome::write_to_file(string file_name)
{
	WriteIni(file_name, "genome/num_tracks", (long) tracks.size(),
		tracks.size() > 0);
	WriteIni(file_name, "genome/num_hided_tracks", (long) hided_tracks.size(),
		hided_tracks.size() > 0);
	WriteIni(file_name, "genome/region", region, region != "");
	WriteIni(file_name, "genome/ucsc_genome_assembly", ucsc_genome_assembly,
		ucsc_genome_assembly != "");
	WriteIni(file_name, "genome/pic_width", pic_width, pic_width
		!= default_pic_width);
	WriteIni(file_name, "genome/pic_margin", pic_margin, pic_margin
		!= default_pic_margin);
	WriteIni(file_name, "genome/font_size", font_size, font_size
		!= default_font_size);
	WriteIni(file_name, "genome/left_axis", left_axis, left_axis != true);
	WriteIni(file_name, "genome/right_axis", right_axis, right_axis != true);
	WriteIni(file_name, "genome/ucsc_browser", ucsc_browser, ucsc_browser
		!= false);
	WriteIni(file_name, "genome/grid", grid, grid != default_grid);
	WriteIni(file_name, "genome/fold", int_vec2str(fold_track),
		!fold_track.empty());
	for (int i = 0; i < (int) tracks.size(); i++)
	{
		tracks[i]->name = string("track") + int2str(i + 1);
		tracks[i]->write_to_file(file_name);
	}
	for (int i = 0; i < (int) hided_tracks.size(); i++)
	{
		hided_tracks[i]->name = string("hided_track") + int2str(i + 1);
		hided_tracks[i]->write_to_file(file_name);
	}
	return true;
}

string display_genome::get_html()
{
	int i;
	html_formater my_html_formater;

	bool updated = true; //always update pictures to regenerate map areas
	string old_region = region;

	s->seed--; //dangerous operations

	if (req->params_.count("region") > 0)
	{		
		region = trim_space(req->params_["region"]);
	}

	if (is_region(region))
	{
		chr_region my_region(region);
		if (req->params_.count("moveleft") > 0)
			my_region.move(-.1);
		if (req->params_.count("moveleft2") > 0)
			my_region.move(-.5);
		if (req->params_.count("moveleft3") > 0)
			my_region.move(-.9);
		if (req->params_.count("moveright") > 0)
			my_region.move(.1);
		if (req->params_.count("moveright2") > 0)
			my_region.move(.5);
		if (req->params_.count("moveright3") > 0)
			my_region.move(.9);
		if (req->params_.count("center") > 0)
			my_region.move(str2int(req->params_["center"]) - (my_region.start
			+ my_region.end) / 2);
		if (req->params_.count("zoomin1_5") > 0)
			my_region.resize(1.0 / 1.5);
		if (req->params_.count("zoomin3") > 0)
			my_region.resize(1.0 / 3);
		if (req->params_.count("zoomin10") > 0)
			my_region.resize(.1);
		if (req->params_.count("zoominbase") > 0)
			my_region.resize((double) (pic_width - 100) / 15
			/ my_region.length());
		if (req->params_.count("zoomout1_5") > 0)
			my_region.resize(1.5);
		if (req->params_.count("zoomout3") > 0)
			my_region.resize(3.0);
		if (req->params_.count("zoomout10") > 0)
			my_region.resize(10.0);
		if (req->params_.count("show10M") > 0)
			my_region.resize(10000000);
		if (req->params_.count("show1M") > 0)
			my_region.resize(1000000);
		if (req->params_.count("show100K") > 0)
			my_region.resize(100000);
		if (req->params_.count("show10K") > 0)
			my_region.resize(10000);
		if (req->params_.count("refresh") > 0)
			updated = true;
		//		if (req->params_.count("submit") > 0) ;
		//		if (req->params_.count("goto") > 0) ;

		my_region.correct();
		region = my_region.get_region();
		if (old_region != region)
			updated = true;
		if (req->params_.count("leftaxis") > 0)
		{
			left_axis = !left_axis;
			updated = true;
		}
		else if (req->params_.count("rightaxis") > 0)
		{
			right_axis = !right_axis;
			updated = true;
		}
		else if (req->params_.count("ucsc_browser") > 0)
		{
			ucsc_browser = !ucsc_browser;
		}
		else if (req->params_.count("grid") > 0)
		{
			if (grid == "gray")
				grid = "color";
			else if (grid == "color")
				grid = "gray_shaded";
			else if (grid == "gray_shaded")
				grid = "color_shaded";
			else if (grid == "color_shaded")
				grid = "off";
			else if (grid == "off")
				grid = "gray";
			updated = true;
		}

		if (req->params_.count("ucsc_genome_assembly") > 0)
		{ //should always be true
			ucsc_genome_assembly = req->params_["ucsc_genome_assembly"];
		}

		if (req->params_.count("ucsc") > 0)
		{
			if (ucsc_genome_assembly == "")
			{
				return error_html(
					"You should specify a genome assembly for UCSC genome browser first.");
			}
			else
			{
				string link = string(
					"http://genome.ucsc.edu/cgi-bin/hgTracks?db=")
					+ ucsc_genome_assembly + "&position=" + region;
				return redirect_html(link);
			}
		}

		if (req->params_.count("track_width") > 0)
		{ //should always be true
			if (!is_int(req->params_["track_width"]) || str2int(
				req->params_["track_width"]) < 40 || str2int(
				req->params_["track_width"]) > 4000)
			{
				return error_html(
					"Picture width must be integer between 40 and 4000.");
			}
			else if (pic_width != str2int(req->params_["track_width"]))
			{
				pic_width = str2int(req->params_["track_width"]);
				updated = true;
			}
		}

		if (req->params_.count("pic_margin") > 0)
		{ //should always be true
			if (!is_int(req->params_["pic_margin"]) || str2int(
				req->params_["pic_margin"]) < 4 || str2int(
				req->params_["pic_margin"]) > 40)
			{
				return error_html(
					"Picture margin must be integer between 4 and 40.");
			}
			else if (pic_margin != str2int(req->params_["pic_margin"]))
			{
				pic_margin = str2int(req->params_["pic_margin"]);
				updated = true;
			}
		}

		if (req->params_.count("font_size") > 0)
		{ //should always be true
			if (!is_int(req->params_["font_size"]) || str2int(
				req->params_["font_size"]) < 4 || str2int(
				req->params_["font_size"]) > 40)
			{
				return error_html("Font size must be integer between 4 and 40.");
			}
			else if (font_size != str2int(req->params_["font_size"]))
			{
				font_size = str2int(req->params_["font_size"]);
				updated = true;
			}
		}

		if (req->params_.count("fold_track") > 0)
		{ //should always be true
			if (int_vec2str(fold_track) != req->params_["fold_track"])
			{
				vector<int> temp = str2int_vec(req->params_["fold_track"]);
				for (int i = 0; i < (int) temp.size(); i++)
				{
					if (temp[i] < 1 || temp[i] > (int) tracks.size())
					{
						return error_html("Illegal track numbers for folding.");
					}
				}

				fold_track = str2int_vec(req->params_["fold_track"]);
				updated = true;
			}
		}

		vector<int> track_selected;
		track_selected.clear();
		for (i = 1; i <= (int) tracks.size(); i++)
		{
			if (req->params_.count(string("track_selected_") + int2str(i)) > 0)
			{
				track_selected.push_back(i);
			}
		}

		if (track_selected.empty() && (req->params_.count("trackdelete")
			+ req->params_.count("trackmoveup") + req->params_.count(
			"trackmovedown") + req->params_.count("tracktotop")
			+ req->params_.count("tracktobottom") + req->params_.count(
			"trackconfigure") > 0))
		{
			return error_html("Must select a track first.");
		}

		for (i = 0; i < (int) tracks.size(); i++)
			tracks[i]->fold = false;
		for (i = 0; i < (int) fold_track.size(); i++)
			tracks[fold_track[i] - 1]->fold = true;

		if (req->params_.count("trackdelete") > 0)
		{
			if (local_client)
			{
				s->seed++;
				for (i = (int) track_selected.size() - 1; i >= 0; i--)
				{ //must do in reverse order
					delete[] tracks[track_selected[i] - 1];
					tracks.erase(tracks.begin() + track_selected[i] - 1);
				}
			}
			else
			{
				return error_html(string("Remote user can not do this."));
			}
		}
		else if (req->params_.count("trackhide") > 0 && track_selected.size()
				> 0)
		{
			s->seed++;
			int n = (int) hided_tracks.size();
			for (i = (int) track_selected.size() - 1; i >= 0; i--)
			{ //must do in reverse order
				hided_tracks.insert(hided_tracks.begin() + n,
					tracks[track_selected[i] - 1]);
				tracks.erase(tracks.begin() + track_selected[i] - 1);
			}
		}
		else if (req->params_.count("trackmoveup") > 0)
		{
			s->seed++;
			for (i = 0; i < (int) track_selected.size(); i++)
			{ //must do in ascending order
				if (track_selected[i] > i + 1)
				{
					display_track* temp_track = tracks[track_selected[i] - 1];
					tracks[track_selected[i] - 1] = tracks[track_selected[i]
					- 2];
					tracks[track_selected[i] - 2] = temp_track;
				}
			}
		}
		else if (req->params_.count("trackmovedown") > 0)
		{
			s->seed++;
			for (i = (int) track_selected.size() - 1; i >= 0; i--)
			{ //must do in reverse order
				if (track_selected[i] < (int) tracks.size()
					- (int) track_selected.size() + i + 1)
				{
					display_track* temp_track = tracks[track_selected[i] - 1];
					tracks[track_selected[i] - 1] = tracks[track_selected[i]];
					tracks[track_selected[i]] = temp_track;
				}
			}
		}
		else if (req->params_.count("tracktotop") > 0)
		{
			s->seed++;
			for (i = 0; i < (int) track_selected.size(); i++)
			{ //must do in ascending order
				if (track_selected[i] > i + 1)
				{
					display_track* temp_track = tracks[track_selected[i] - 1];
					tracks.erase(tracks.begin() + track_selected[i] - 1);
					tracks.insert(tracks.begin() + i, temp_track);
				}
			}
		}
		else if (req->params_.count("tracktobottom") > 0)
		{
			s->seed++;
			for (i = 0; i < (int) track_selected.size(); i++)
			{ //must do in ascending order
				display_track* temp_track = tracks[track_selected[i] - 1 - i];
				tracks.erase(tracks.begin() + track_selected[i] - 1 - i);
				tracks.push_back(temp_track);
			}
		}

		fold_track.clear();
		for (i = 0; i < (int) tracks.size(); i++)
		{
			if (tracks[i]->fold)
				fold_track.push_back(i + 1);
		}

		if (req->params_.count("fold") > 0)
		{
			fold_track = track_selected;
			updated = true;
		}
		else if (req->params_.count("update_track") > 0)
		{
			int track_num = str2int(req->params_["track_num"]);
			if (track_num < 1 || track_num > (int) tracks.size() + 1)
				return error_html("Wrong track number.");
			tracks[track_num - 1]->update_params();
			updated = true;
			//tracks[track_num-1]->generate_pic_file();
		}
		else if (req->params_.count("update_tracks") > 0)
		{
			vector<int> track_nums = str2int_vec(req->params_["track_num"]);
			for (i = 0; i < (int) track_nums.size(); i++)
			{
				if (track_nums[i] < 1 || track_nums[i] > (int) tracks.size()
					+ 1)
					return error_html("Wrong track number.");
				tracks[track_nums[i] - 1]->update_params();
				updated = true;
				//tracks[track_nums[i]-1]->generate_pic_file();
			}
		}
		else if (req->params_.count("unhide_track") > 0)
		{
			s->seed++;
			int n = (int) tracks.size();
			for (i = (int) hided_tracks.size() - 1; i >= 0; i--)
			{ //must do in reverse order
				if (req->params_.count(string("unhide_track_selected_")
					+ int2str(i + 1)) > 0)
				{
					tracks.insert(tracks.begin() + n, hided_tracks[i]);
					hided_tracks.erase(hided_tracks.begin() + i);
				}
			}
		}

		if (req->params_.count("trackadd") > 0)
		{
			if (local_client)
			{
				my_html_formater.load_from_template_file(template_path
					+ "new_track.html");
				my_html_formater.replace_keyword("$TRACK_NUM$", int2str(
					(int) tracks.size() + 1));
			}
			else
			{
				return error_html(string("Remote user can not do this."));
			}
		}
		else if (req->params_.count("trackhide") > 0 && track_selected.size()
			== 0)
		{
			s->seed++;
			my_html_formater.load_from_template_file(template_path
				+ "unhide_track.html");
			if (hided_tracks.size() >= 1)
			{
				vector<vector<string> > table;
				table.resize(hided_tracks.size());
				for (i = 0; i < (int) table.size(); i++)
				{
					table[i].push_back(string("$UNHIDE_TRACK") + int2str(i + 1)
						+ "_SELECT$");
					table[i].push_back(string("$UNHIDE_TRACK") + int2str(i + 1)
						+ "_TITLE$");
				}
				my_html_formater.replace_keyword("$UNHIDE_TRACKS$", table_html(
					table, 0));
				for (i = 0; i < (int) hided_tracks.size(); i++)
				{
					my_html_formater.replace_keyword(string("$UNHIDE_TRACK")
						+ int2str(i + 1) + "_SELECT$", check_box_html(
						string("unhide_track_selected_") + int2str(i + 1)));
					my_html_formater.replace_keyword(string("$UNHIDE_TRACK")
						+ int2str(i + 1) + "_TITLE$",
						hided_tracks[i]->title);
				}
			}
			else
			{
				my_html_formater.replace_keyword("$UNHIDE_TRACKS$",
					"There is no track hided.");
			}
		}
		else if (req->params_.count("trackconfigure") > 0)
		{
			if (track_selected.size() == 1)
			{
				my_html_formater.buf
					= tracks[track_selected[0] - 1]->get_configure_html();
				my_html_formater.replace_keyword("$TRACK_NUM$", int2str(
					track_selected[0]));
			}
			else if (track_selected.size() > 1)
			{
				my_html_formater.load_from_template_file(template_path
					+ "configure_multiple_tracks.html");
				my_html_formater.replace_keyword("$TRACK_NUM$", int_vec2str(
					track_selected));
				my_html_formater.replace_keyword("$TRACK_HEIGHT$", "");
				my_html_formater.replace_keyword("$RANGE_LOW$", "");
				my_html_formater.replace_keyword("$RANGE_HIGH$", "");
				my_html_formater.replace_keyword("$SIGNAL_WIDTH$", "");
				//return error_html("Can only configure one track at one time..");
			}
			else
			{ // track_selected.size() == 0
				return error_html("Must select at least one track.");
			}
		}
		else if (req->params_.count("create_track_type") > 0)
		{
			s->seed++;
			int track_num = str2int(req->params_["track_num"]);
			if (track_num != (int) tracks.size() + 1)
				return error_html("Wrong track number.");
			string track_name = string("track") + int2str(track_num);
			string track_type = req->params_["track_type"];
			display_track* track = create_track(track_type, track_name);
			if (NULL == track)
				return error_html("Wrong track type.");
			tracks.push_back(track);
			my_html_formater.buf = tracks[track_num - 1]->get_configure_html();
			my_html_formater.replace_keyword("$TRACK_NUM$", int2str(track_num));
		}
		else
		{
			intervals.end_points.clear();
			for (i = 0; i < (int) fold_track.size(); i++)
			{
				if (fold_track[i] < 1 || fold_track[i] > (int) tracks.size())
					return error_html("bad fold tracks");
				tracks[fold_track[i] - 1]->generate_pic_file(true);
				intervals.union_with(tracks[fold_track[i] - 1]->intervals);
			}
			//			intervals.end_points.clear();
			for (i = 0; i < (int) tracks.size(); i++)
			{
				tracks[i]->intervals = intervals;
			}

			if (updated)
			{
				for (i = 0; i < (int) tracks.size(); i++)
				{
					tracks[i]->generate_pic_file();
				}
			}

			my_html_formater.load_from_template_file(template_path
				+ "genome.html");
			if (!is_region(region))
			{
				return error_html("Bad Region.");
			}
			chr_region my_region(region);
			my_html_formater.replace_keyword("$GENOME_REGION$", region);
			my_html_formater.replace_keyword("$CHR$", my_region.chr);
			my_html_formater.replace_keyword("$LEN$", int2str(
				my_region.length()));
			my_html_formater.replace_keyword("$START$",
				int2str(my_region.start));
			my_html_formater.replace_keyword("$END$", int2str(my_region.end));
			my_html_formater.replace_keyword("$UCSC_GENOME_ASSEMBLY$",
				ucsc_genome_assembly);
			my_html_formater.replace_keyword("$GENOME_REGION_LENGTH$", int2str(
				my_region.length()));
			my_html_formater.replace_keyword("$TRACK_WIDTH$",
				int2str(pic_width));
			my_html_formater.replace_keyword("$PIC_MARGIN$",
				int2str(pic_margin));
			my_html_formater.replace_keyword("$FONT_SIZE$", int2str(font_size));
			my_html_formater.replace_keyword("$LEFT_AXIS$", left_axis ? "on"
				: "off");
			my_html_formater.replace_keyword("$RIGHT_AXIS$", right_axis ? "on"
				: "off");
			if (ucsc_browser)
			{
				if (ucsc_genome_assembly == "")
				{
					ucsc_browser = false;
					return error_html(
						"You should specify a genome assembly for UCSC genome browser first.");
				}
				else
				{
					string link = string(
						"http://genome.ucsc.edu/cgi-bin/hgTracks?db=")
						+ ucsc_genome_assembly + "&position=" + region;
					string iframe = "<iframe src=\"" + link
						+ "\" width=\"100%\" height=\"100%\"></iframe>";
					my_html_formater.replace_keyword("$UCSC_BROWSER_FRAME$",
						iframe);
				}
			}
			else
			{
				my_html_formater.replace_keyword("$UCSC_BROWSER_FRAME$", "");
			}
			my_html_formater.replace_keyword("$UCSC_BROWSER$",
				ucsc_browser ? "on" : "off");
			my_html_formater.replace_keyword("$GRID$", grid);
			//my_html_formater.replace_keyword("$FOLD$", fold_track.empty()? "fold" : "unfold");
			my_html_formater.replace_keyword("$FOLD_TRACK$", int_vec2str(
				fold_track));
			if (tracks.size() > 0)
			{
				vector<vector<string> > table;
				table.resize(tracks.size() + 2);
				for (i = 0; i < (int) table.size(); i++)
				{
					table[i].push_back(string("$GENOME_TRACK") + int2str(i)
						+ "_SELECT$");
					table[i].push_back(string("$GENOME_TRACK") + int2str(i)
						+ "_TITLE$");
					table[i].push_back(string("$GENOME_TRACK") + int2str(i)
						+ "_PIC$");
				}
				my_html_formater.replace_keyword("$GENOME_TRACKS$", table_html(
					table, 0));
				for (i = 0; i < (int) tracks.size(); i++)
				{
					my_html_formater.replace_keyword(string("$GENOME_TRACK")
						+ int2str(i + 1) + "_SELECT$", check_box_html(
						string("track_selected_") + int2str(i + 1)));
					my_html_formater.replace_keyword(string("$GENOME_TRACK")
						+ int2str(i + 1) + "_TITLE$", tracks[i]->title);
					my_html_formater.replace_keyword(string("$GENOME_TRACK")
						+ int2str(i + 1) + "_PIC$", tracks[i]->get_html());
				}
				display_signal temp_track(req, "track_top_axis", this);
				temp_track.intervals = intervals;
				temp_track.top_axis = true;
				temp_track.bottom_axis = false;
				temp_track.fast_draw = true;
				temp_track.src_filenames.clear();
				temp_track.pic_filename = "top_axis.png";
				temp_track.pic_height = fold_track.empty() ? font_size + 15
					: font_size + 45;
				temp_track.generate_pic_file();
				my_html_formater.replace_keyword(string("$GENOME_TRACK")
					+ int2str(0) + "_SELECT$", "");
				my_html_formater.replace_keyword(string("$GENOME_TRACK")
					+ int2str(0) + "_TITLE$", "");
				my_html_formater.replace_keyword(string("$GENOME_TRACK")
					+ int2str(0) + "_PIC$", temp_track.get_html());
				temp_track.name = "track_bottom_axis";
				temp_track.top_axis = false;
				temp_track.bottom_axis = true;
				temp_track.fast_draw = true;
				temp_track.src_filenames.clear();
				temp_track.pic_filename = "bottom_axis.png";
				temp_track.generate_pic_file();
				my_html_formater.replace_keyword(string("$GENOME_TRACK")
					+ int2str((int) tracks.size() + 1) + "_SELECT$", "");
				my_html_formater.replace_keyword(string("$GENOME_TRACK")
					+ int2str((int) tracks.size() + 1) + "_TITLE$", "");
				my_html_formater.replace_keyword(string("$GENOME_TRACK")
					+ int2str((int) tracks.size() + 1) + "_PIC$",
					temp_track.get_html());
			}
			else
			{
				my_html_formater.replace_keyword("$GENOME_TRACKS$", "");
			}
		}
	}
	else
	{ //if is_region(region, chr, start, end)
		vector<int> track_selected;
		track_selected.clear();
		for (i = 1; i <= (int) tracks.size(); i++)
		{
			if (req->params_.count(string("track_selected_") + int2str(i)) > 0)
			{
				track_selected.push_back(i);
			}
		}

		vector<gene_struct> genes;
		genes.clear();
		if (trim_space(region) != "") {
			for (i = 0; i < (int)tracks.size(); i++) {
				if (tracks[i]->type() != "display_gene") continue;
				if (!((display_gene*)tracks[i])->annotation) continue;
				if (!track_selected.empty() && find(track_selected.begin(), track_selected.end(), i + 1) == track_selected.end()) continue;
				if (cache_genefiles && ((display_gene*)tracks[i])->do_caching) {
					genefile *mygenefile;
					string error_msg;
					if (!get_genefile_from_cache(((display_gene*)(tracks[i]))->src_filename, error_msg, mygenefile)) {
						return error_html(error_msg);
					}
					if (!mygenefile->search_by_name(region, genes)) {
						return error_html("error reading genefile.");
					}
				} else {
					genefile mygenefile;
					string genefilename, error_msg;
					if (!get_gene_file_name(((display_gene*)(tracks[i]))->src_filename, genefilename, error_msg)) {
						return error_html(error_msg);
					}
					if (!mygenefile.read_from_file_gene_name(genefilename, region, genes)) {
						return error_html("error reading genefile.");
					}
				}
			}
		}
		if (genes.size() == 0) {
			string error_message;
			if (trim_space(region) == "") error_message = "Region or gene name needed.";
			else error_message = string("Region or gene not found: ") + region;
			if (is_region(old_region)) region = old_region;
			else region = "chr1:5001000-5002000";
			return error_html(error_message);
		}
		vector<vector<string> > table;
		table.resize(genes.size());
		for (i = 0; i < (int) table.size(); i++)
		{
			string new_region = genes[i].chrom + ":"
				+ int2str(genes[i].txStart) + "-" + int2str(genes[i].txEnd);
			string url = host_name + "session?name=$SESSION_NAME$&region="
				+ new_region;
			string text = genes[i].geneName + " (" + genes[i].name + ") at "
				+ new_region;
			table[i].push_back(link_html(url, text));
		}
		my_html_formater.buf = table_html(table, 1);
	}

	my_html_formater.replace_keyword("$REGION$", region);
	return my_html_formater.buf;
}

