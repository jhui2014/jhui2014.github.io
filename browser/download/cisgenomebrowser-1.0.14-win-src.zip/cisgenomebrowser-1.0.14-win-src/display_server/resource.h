//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by display_server.rc
//
#define IDR_TRAY                        4
#define IDM_ABOUTBOX                    0x0010
#define IDR_MAINFRAME                   16
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_DISPLAY_SERVER_DIALOG       102
#define ID__SYSTRAY                     32771
#define ID__RESTORE                     32772
#define ID__EXIT                        32773
#define ID_SYSTRAY_RESTORE              32774
#define ID_SYSTRAY_BROWSE               32776
#define ID_SYSTRAY_SETTING              32777
#define ID_SYSTRAY_ABOUT                32778
#define ID_SYSTRAY_EXIT                 32780

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32781
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
