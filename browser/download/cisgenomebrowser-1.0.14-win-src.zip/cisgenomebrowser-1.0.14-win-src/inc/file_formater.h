/*
file_formater.h - Header file for generic text file formater
written by JIANG Hui, 
Institute for Computational and Mathematical Engineering, Stanford University
May, 2007 -
*/

#ifndef FILE_FORMATER_H
///Define this macro to prevent from including this header file more than once.
#define FILE_FORMATER_H

#include "stl.h"
#include "file_operation.h"
#include "string_operation.h"

class file_formater{
public:
	string buf;
	file_formater();
	void clear_buf();
	bool load_from_template_file(const string filename);
	bool write_to_file(const string filename);
	bool replace_keyword(const string keyword, const string value);
};

inline file_formater::file_formater(){
}

inline bool file_formater::load_from_template_file(const string filename){
	char *newbuf;
	long bufsize;
	if (!load_file(filename, newbuf, bufsize)) return false;
	buf = newbuf;
	delete[] newbuf;
	return true;
}

inline bool file_formater::write_to_file(const string filename){
	return (write_file(filename, buf.c_str(), (int)buf.length()));
}

inline bool file_formater::replace_keyword(const string keyword, const string value){ // works for text file only
	string newbuf = substitute(buf, keyword, value);
	buf = newbuf;
	return true;
}

#endif //FILE_FORMATER_H
