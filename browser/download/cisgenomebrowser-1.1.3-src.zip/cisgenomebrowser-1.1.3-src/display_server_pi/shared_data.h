#ifndef _SHARED_DATA_H_
#define _SHARED_DATA_H_

#include "inc_pi/stl.h"
#include "default_values.h"
#include "wx/event.h"
#include "inc_pi/genefile.h"

extern bool local_only;
extern int port_num;

extern bool new_local_only;
extern int new_port_num;

extern string wwwroot;
extern string template_path;
extern string session_path;
extern string log_filename;

extern int max_cache_size_MB;
extern bool cache_genefiles;
extern map<string,time_t> genefile_time_cache;
extern map<string,genefile> genefile_cache;

//future usage
extern string module_path;

//determined automatically
extern string program_path;
extern string ini_filename;
extern string temp_path;
extern string server_temp_path;
extern string local_host_name;

//change every session
extern string host_name;
extern string server_ip;
extern string client_ip;
extern bool local_client;

extern string title;

extern string folder_to_be_opened;

#endif //_SHARED_DATA_H_
