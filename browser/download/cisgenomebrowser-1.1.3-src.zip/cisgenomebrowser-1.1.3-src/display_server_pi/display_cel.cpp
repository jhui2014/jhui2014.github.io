#include "display_cel.h"
#include "drawCommon.h"
#include "inc_pi/html_formater.h"

display_cel::display_cel(http_request* r)
{
	src_filename = "";
	pic_filename = "";
	req = r;
}

bool display_cel::load_from_file(string file_name)
{
	src_filename = ReadIni(file_name, "cel/src_filename", wxString(""));
	pic_filename = ReadIni(file_name, "cel/pic_filename", wxString(""));
	return true;
}

bool display_cel::update_params()
{
	bool updated = false;
	/*	for (std::map<std::string, std::string>::const_iterator i = req->params_.begin(); i != req->params_.end(); i++) {
	if (i->first == "cel_filename") {
	src_filename = i->second;
	updated = true;
	} else if (i->first == "cel_pic_filename") {
	pic_filename = i->second;
	updated = true;
	}
	}*/

	if (req->params_.count("create_cel_session") > 0)
	{
		src_filename = req->params_["cel_filename"];
		updated = true;
	}

	return updated;
}

bool display_cel::write_to_file(string file_name)
{
	WriteIni(file_name, "cel/src_filename", src_filename, src_filename != "");
	WriteIni(file_name, "cel/pic_filename", pic_filename, pic_filename != "");
	return true;
}

string display_cel::get_html()
{
	html_formater my_html_formater;
	if (src_filename == "")
	{
		my_html_formater.load_from_template_file(template_path
			+ "new_cel_session.html");
	}
	else
	{
		if (pic_filename == "")
		{
			pic_filename = get_random_pic_file_name();
		}
		if (!file_exists(temp_path + client_ip + pic_filename) || refresh)
		{
			//string command_line = module_path + "draw_cel.exe " + src_filename + " " + temp_path + pic_filename;
			/*string command_line = string("\"") + module_path + "draw_figure.exe\" cel \"" + temp_path + pic_filename + "\" \"" + src_filename + "\"";
			call_external(command_line);*/
			draw_cel my_draw;
			my_draw.cel_filename = src_filename;
			my_draw.load_data();
			my_draw.prepare_data();
			my_draw.drawfile(temp_path + client_ip + pic_filename);
		}

		my_html_formater.load_from_template_file(template_path
			+ "draw_cel.html");
		my_html_formater.replace_keyword("$CEL_FILE_NAME$", server_temp_path + client_ip
			+ pic_filename);
	}
	return my_html_formater.buf;
}
