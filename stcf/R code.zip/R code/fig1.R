#generate Figure 1

library(rootSolve)

pdf("fig1.pdf", width=4, height=3)
par(mar=c(3, 3, 0, 0) + 0.1, mgp=c(2,0.8,0))
f1<-function(x)  apply( matrix(  c( 4*x^2+1, rep(3,length(x)) ), ncol=2), 1, min)
f2<-function(x)  apply( matrix(  c( 2*(x-1)^2+2, rep(4,length(x)) ), ncol=2), 1,min)
x<-seq(-2,3,by=0.001)
y1<-f1(x)
y2<-f2(x)
g1<-function(x) 4*x^2+1-3
g2<-function(x)  2*(x-1)^2+2-4
uni1<-multiroot(g1,c(-2,3))$root
uni2<-multiroot(g2,c(-2,3))$root
plot(x, y1+y2, type="l", lwd=2, ylim=c(0,8), xlim=c(-2,3), ylab=expression(f), xlab="x",col="black")
lines(x, y1, lty=2, lwd=2, col="blue")
lines(x, y2, lty=4, lwd=2, col="red")
abline(v =c(uni1,uni2) , lty=3)
legend("bottomright",c(expression(f[1]+f[2]),expression(f[1]),expression(f[2])),col=c("black","blue","red"),lty=c(1,2,4),lwd=c(2,2,2), cex=0.75)
dev.off()
