#include <string>
//#include "mykernel.h"
#include "shared_data.h"

bool local_only;
std::string wwwroot;
std::string program_path;
std::string ini_filename;
std::string module_path;
std::string template_path;
std::string session_path;
std::string temp_path;
std::string log_filename;
std::string server_temp_path;
std::string server_ip;
std::string client_ip;
bool local_client;
std::string local_host_name;
std::string host_name;
int port_num;

bool new_local_only;
int new_port_num;

int max_cache_size_MB;
bool cache_genefiles;
map<string, FILETIME> genefile_time_cache;
map<string, genefile> genefile_cache;

std::string title;

//MyKernel *kernel;