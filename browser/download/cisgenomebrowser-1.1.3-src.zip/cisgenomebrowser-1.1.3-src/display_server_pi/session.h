#ifndef _SESSION_H_
#define _SESSION_H_

#include "inc_pi/stl.h"

class display_type;
struct http_request;

class session
{
public:
	string name;
	string type;
	int seed;
	bool seed_match;
	string password;
	display_type* display;
	http_request* req;
	bool refresh;

	session(http_request* r);
	~session();
	void cleanup();
	virtual bool load_from_file(string file_name);
	void create_display();
	virtual bool update_params();
	virtual bool write_to_file(string file_name);
	virtual string get_html();
};

#endif //#define SESSION_H
