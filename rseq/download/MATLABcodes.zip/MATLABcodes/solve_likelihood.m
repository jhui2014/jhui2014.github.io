function [ X, f, I ] = solve_likelihood( A, T )

epsilon = 1e-10;

[m,n] = size(A);

X = ones(n, 1);

[X, f] = fmax_coord(A, T, X);

I = fisher(A, T, X);

