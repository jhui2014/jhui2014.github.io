rm(list = ls())
source("rSeqRobust.R")
source("sim.R")

#source("https://bioconductor.org/biocLite.R")
#biocLite("seqc")

library(ROCR)
library(seqc)
library(xtable)

rnaseq_data = ILM_refseq_gene_AGR
rownames(rnaseq_data) = rnaseq_data[, 1]
rnaseq_data = rnaseq_data[, 5:length(rnaseq_data)]
samples = substr(names(rnaseq_data), 1, 3)
unique_samples = unique(samples)
for (sample in unique_samples) {
    rnaseq_data[, sample] = rowSums(rnaseq_data[, samples == sample])
}
rnaseq_data = rnaseq_data[, unique_samples]

pcr_data = taqman
rownames(pcr_data) = pcr_data[, 1]
pcr_data = pcr_data[, 3:length(pcr_data)]
names(pcr_data) = unique_samples
n1 = nrow(pcr_data)

g1 = "A"
groups = c("B", "C", "D")
AUCs = NULL
TIMEs = NULL
methods = c("edgeR-robust", "DESeq2", "limma-voom", "rSeqRobust")
comparisons = paste(g1, "vs", groups)
pdf(file = "ROC.real.data.analysis.pdf", height = 4, width = 12)
par(mfrow = c(1, 3))
for (j in 1:length(groups)) {
    g2 = groups[j]
    p_values = rep(NA, n1)
    log2fc = rep(NA, n1)
    group1 = which(substr(unique_samples, 1, 1) == g1)
    group2 = which(substr(unique_samples, 1, 1) == g2)
    for (i in 1:n1) {
        if (sd(pcr_data[i, group1]) > 0 && sd(pcr_data[i, group2]) > 0) {
            p_values[i] = t.test(pcr_data[i, group1], pcr_data[i, group2])$p.value
        } else {
            p_values[i] = 1.0
        }
        log2fc[i] = log2(mean(as.numeric(pcr_data[i, group1])) / mean(as.numeric(pcr_data[i, group2])))
    }
    q_values = p.adjust(p_values, method = "fdr")
    DE = ((p_values < 0.05) & (abs(log2fc) > 1))
    Up = (DE & (log2fc > 0))

    group = as.factor(c(rep(0, 4), rep(1, 4)))
    design = model.matrix( ~ group)
    time.edgeR = system.time(p.edgeR <- edgeR_robust.pfun(rnaseq_data[, c(group1, group2)], group, design)[, 1])[3]
    time.DESeq2 = system.time(p.DESeq2 <- DESeq2.pfun(rnaseq_data[, c(group1, group2)], group, design)[, 1])[3]
    time.limma = system.time(p.limma <- limma_voom.pfun(rnaseq_data[, c(group1, group2)], group, design)[, 1])[3]
    time.rSeqRobust = system.time(p.rSeqRobust <- rSeqRobust.pfun(rnaseq_data[, c(group1, group2)], group)[, 1])[3]

    p.combined = cbind(p.edgeR, p.DESeq2, p.limma, p.rSeqRobust)
    names(p.combined) = rownames(rnaseq_data)
    p.combined = p.combined[rownames(pcr_data),]

    colors = c("blue", "brown", "red", "black")
    auc = rep(NA, 4)
    for (i in 1:4) {
        auc[i] = performance(prediction(1 - p.combined[, i], DE), 'auc')@y.values[[1]]
        if (i > 1) {
            par(new = T)
        }
        plot(performance(prediction(1 - p.combined[, i], DE), 'tpr', 'fpr'), cex = 2, cex.axis = 2, cex.lab = 1.5, cex.main = 1.5,  ann = (i == 1), col = colors[i], lty = i, lwd = 2, main = comparisons[j])
    }
    if (j == 3) legend("bottomright", methods, lty = 1:4, col = colors, lwd = 2, cex = 1.5)
    max_ind = which.max(auc)
    auc = format(round(auc, 3), nsmall = 3)
    auc[max_ind] = paste(auc[max_ind], "*")
    perc.DE = format(round(100 * sum(DE) / length(DE), 1), nsmall = 1)
    perc.Up = format(round(100 * sum(Up) / sum(DE), 1), nsmall = 1)
    AUCs = rbind(AUCs, as.character(c(perc.DE, perc.Up, auc)))

    time = c(time.edgeR, time.DESeq2, time.limma, time.rSeqRobust)
    min_ind = which.min(time)
    time = format(round(time, 3), nsmall = 3)
    time[min_ind] = paste(time[min_ind], "*")
    TIMEs = rbind(TIMEs, time)
}

bold <- function(x) {
    l = nchar(x)
    last_char = substr(x, l, l)
    if (last_char == "*") {
        x = substr(x, 1, l - 2)
        paste('{\\textbf{', x, '}}', sep = '')
    } else {
        x
    }
}

colnames(AUCs) = c("DE\\%", "Up\\%", methods)
rownames(AUCs) = comparisons
sink(file = "AUC.real.data.analysis.tex")
print(xtable(AUCs), sanitize.text.function = function(col) { sapply(col, bold) })
sink()
colnames(TIMEs) = methods
rownames(TIMEs) = comparisons
sink(file = "TIME.real.data.analysis.tex")
print(xtable(TIMEs), sanitize.text.function = function(col) { sapply(col, bold) })
sink()
dev.off()
