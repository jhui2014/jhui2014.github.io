#ifndef DRAW_MOTIF_HTML_H
#define DRAW_MOTIF_HTML_H

#include "draw_motif.h"
#include "string_operation.h"
#include "file_operation.h"
#include "math_utils.h"
#include "html_formater.h"
#include <atlimage.h>

class draw_motif_html: public draw_figure_structure
{
public:
	string motif_filename;
	bool left_axis, right_axis, top_axis, bottom_axis;

	draw_motif_html();
	virtual string print_usage();
	virtual bool get_params(const vector<string> &params);
	virtual bool drawfile(const string pic_filename_prefix);
	inline bool get_html(const string pic_filename_prefix, const string link_filename_prefix, string &html);
};

inline draw_motif_html::draw_motif_html(){
	motif_filename = "";
	left_axis = right_axis = top_axis = bottom_axis = false;
	size.cx = 400;
	size.cy = 150;
}

inline string draw_motif_html::print_usage(){
	return "<input motif file name> [/size:<picture width>x<picture height>] [/axis:xxxx]\n";
}

inline bool draw_motif_html::get_params(const vector<string> &params){
	if (params.size() == 0) return false;
	motif_filename = params[0];

	bool good_options = true;
	for (int i=1; i<(int)params.size(); i++) {
		string option = params[i];

		string command = "";
		string parameter = "";
		if (option[0] != '/') {
			good_options = false;
			break;
		}
		size_t index = option.find (":");
		if (index != string::npos ) {
			command = option.substr(1, index - 1);
			parameter = option.substr(index + 1);
		} else {
			command = option.substr(1);
		}
		if (command == "size"){
			sscanf(parameter.c_str(), "%dx%d", &size.cx, &size.cy);
			if (size.cx <=0 || size.cy <=0) {
				error_msg = "Invalid parameter. wrong picture size.\n";
				good_options = false;
				break;
			}
		} else if (command == "axis"){
			int mask;
			sscanf(parameter.c_str(), "%d", &mask);
			top_axis = (mask >= 1000);
			mask %= 1000;
			bottom_axis = (mask >= 100);
			mask %= 100;
			left_axis = (mask >= 10);
			mask %= 10;
			right_axis = (mask >= 1);
		} else {
			good_options = false;
			break;
		}
	}
	return good_options;
}

void reverse_weights(vector<vector<pair<double, int> > > &weights){
	vector<vector<pair<double, int> > > weights1;
	for (int i=(int)weights.size() - 1; i>=0; i--) {
		vector<pair<double, int> > ww;
		for (int j=0; j<4; j++) {
			ww.push_back(pair<double, int>(weights[i][j].first, 3 - weights[i][j].second));
		}
		weights1.push_back(ww);
	}
	weights = weights1;
}

bool LoadMotifFile(FILE *file, vector<vector<pair<double, int> > > &weights){
	for (int i=0; i<(int)weights.size(); i++) 
		weights[i].clear();
	weights.clear();
	while (!feof(file)){
		char buf[1025];
		buf[0] = 0;
		fgets(buf, 1024, file);
		double w[4];
		if (4 != sscanf(buf, " %lf %lf %lf %lf", w, w+1, w+2, w+3)) break;
		vector<pair<double, int> > ww;
		ww.clear();
		for (int i=0; i<4; i++) {
			//fix later
			//w[i] -= .49;
			ww.push_back(pair<double, int>(w[i], i));
		}
		weights.push_back(ww);
	}
	return true;
}

inline bool get_motif_file_type(const string motif_filename, string &motif_file_type, bool &has_score, bool &has_consensus, string &error_msg) {
	if (!file_exists(motif_filename)) {
		error_msg = "file does not exist.";
		return false;
	}
	motif_file_type = "";
	error_msg = "";
	has_score = false;
	has_consensus = false;
	ifstream ifs(motif_filename.c_str());
	string readline;
	while (getline(ifs, readline)) {
		if (is_empty(readline)) continue;
		vector<string> tokens = string_tokenize(readline, " \t");
		if (tokens.size() == 3 && tokens[0] == "******") {
			motif_file_type = "flex_module";
			has_score = true;
			has_consensus = true;
			return true;
		} else if (tokens.size() == 4 && is_num(tokens[0])) {
			motif_file_type = "matrix";
			return true;
		} else if ((tokens.size() >= 1 || tokens.size() <= 3) && file_exists(tokens[0])) {
			motif_file_type = "file list";
			has_score = (tokens.size() >= 2);
			has_consensus = (tokens.size() >= 3);
			return true;
		} else if (tokens.size() == 1) {
			motif_file_type = "matrix list";
			return true;
		} else {
			error_msg = "unrecognized format.";
			return false;
		}
	}
	ifs.close();
	return true;
}

inline bool draw_motif_html::get_html(const string pic_filename_prefix, const string link_filename_prefix, string &html){
	bool has_score = false, has_consensus = false;
	string motif_file_type;
	if (!get_motif_file_type(motif_filename, motif_file_type, has_score, has_consensus, error_msg)) return false;

	FILE *file = fopen(motif_filename.c_str(), "rt");
	if (NULL == file) {
		error_msg = "error opening input file.\n";
		return false;
	}

	char img_filename1[1025], img_filename2[1025], link_img_filename1[1025], link_img_filename2[1025];

	vector<vector<string> > table;
	vector<string> row;
	row.push_back("Motif");
	if (has_score) row.push_back("Score");
	if (has_consensus) row.push_back("Consensus");
	row.push_back("Logo");
	row.push_back("Reversed Logo");
	table.push_back(row);

	int i = 0;
	char buf[1025];

	while (!feof(file)) {
		buf[0] = 0;
		fgets(buf, 1024, file);
		if (is_empty(string(buf))) continue;
		double score = 0;
		char consensus[1025];
		string temp_motif_filename = "";
		vector<vector<pair<double, int> > > weights;

		if (motif_file_type == "flex_module") {
			if (1 != sscanf(buf, "Motif Score: %lf", &score)) continue;
			buf[0] = 0;
			fgets(buf, 1024, file);
			if (strcmp(buf, "Motif Matrix: \n")) {
				error_msg = "bad format in motif file.\n";
				return false;
			}
		} else if (motif_file_type == "file list") {
			vector<string> tokens = string_tokenize(string(buf), " \t\n\r");
			if ((int)tokens.size() != 1 + (has_score?1:0) + (has_consensus?1:0)) {
				error_msg = "bad format in motif file.";
				return false;
			}
			temp_motif_filename = tokens[0];
			if (has_score) score = str2double(tokens[1]);
			if (has_consensus) strcpy(consensus, tokens[2].c_str());
			FILE *tempfile = fopen(temp_motif_filename.c_str(), "rt");
			if (NULL == tempfile) {
				error_msg = "error opening input file.\n";
				return false;
			}
			if (!LoadMotifFile(tempfile, weights)){
				error_msg = "Failed to read motif file.\n";
				return false;
			}
			fclose(tempfile);
		}
		if (motif_file_type == "flex_module" || motif_file_type == "matrix" || motif_file_type == "matrix list") {
			if (!LoadMotifFile(file, weights)){
				error_msg = "Failed to read motif file.\n";
				return false;
			}
		}
		if (weights.size() == 0) {
			error_msg = "no motif information found.\n";
			return false;
		}
		sprintf(img_filename1, "%s%d.gif", pic_filename_prefix.c_str(), i);
		sprintf(link_img_filename1, "%s%d.gif", link_filename_prefix.c_str(), i);
		draw_motif *_draw_motif = new draw_motif();
		_draw_motif->left_axis = left_axis;
		_draw_motif->right_axis = right_axis;
		_draw_motif->top_axis = top_axis;
		_draw_motif->bottom_axis = bottom_axis;
		_draw_motif->box = false;
		_draw_motif->size.cx = size.cx;
		_draw_motif->size.cy = size.cy;
		_draw_motif->weights = weights;
		if (!_draw_motif->prepare_data()) {
			error_msg = _draw_motif->error_msg;
			return false;
		}
		if (!_draw_motif->drawfile(img_filename1)) {
			error_msg = _draw_motif->error_msg;
			return false;
		}

		delete _draw_motif;

		reverse_weights(weights);
		sprintf(img_filename2, "%s%dr.gif", pic_filename_prefix.c_str(), i);
		sprintf(link_img_filename2, "%s%dr.gif", link_filename_prefix.c_str(), i);
		_draw_motif = new draw_motif();
		_draw_motif->left_axis = left_axis;
		_draw_motif->right_axis = right_axis;
		_draw_motif->top_axis = top_axis;
		_draw_motif->bottom_axis = bottom_axis;
		_draw_motif->box = false;
		_draw_motif->size.cx = size.cx;
		_draw_motif->size.cy = size.cy;
		_draw_motif->weights = weights;
		if (!_draw_motif->prepare_data()) {
			error_msg = _draw_motif->error_msg;
			return false;
		}

		if (!_draw_motif->drawfile(img_filename2)) {
			error_msg = _draw_motif->error_msg;
			return false;
		}

		delete _draw_motif;

		if (motif_file_type == "flex_module") {
			buf[0] = 0;
			fgets(buf, 1024, file);
			if (strcmp(buf, "Consensus:\n")) {
				error_msg = "bad format in motif file.\n";
				return false;
			}
			fscanf(file, "%s\n", consensus);
		}
		row.clear();
		row.push_back(int2str(i));
		if (has_score) row.push_back(double2str(score));
		if (has_consensus) row.push_back(consensus);
		row.push_back(image_html(link_img_filename1));
		row.push_back(image_html(link_img_filename2));
		table.push_back(row);
		i++;
		if (motif_file_type == "matrix" && i > 0) break;
	}
	fclose(file);
	html = table_html(table);
	return true;
}

inline bool draw_motif_html::drawfile(const string filename_prefix){
	string html;
	if (!get_html(filename_prefix, filename_prefix, html)) {
		return false;
	}

	char html_filename[1025];
	sprintf(html_filename, "%s.html", filename_prefix.c_str());
	FILE *html_file = fopen(html_filename, "wt");
	if (NULL == html_file) {
		error_msg = "error opening output file.\n";
		return false;
	}

	fprintf(html_file, "<html>\n<body>\n<center><h1>Motifs</h1></center><p>\n");
	fprintf(html_file, html.c_str());
	fprintf(html_file, "</body>\n</html>\n");

	fclose(html_file);
	return true;
}

#endif //DRAW_MOTIF_HTML_H
