// For compilers that support precompilation, includes "wx.h".
#include "wx/wxprec.h"
#include "wx/cmdline.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

// the application icon (under Windows and OS/2 it is in resources)
#if defined(__WXGTK__) || defined(__WXMOTIF__) || defined(__WXMAC__) || defined(__WXMGL__) || defined(__WXX11__)
#include "icon2.xpm"
#else
#include "icon2.xpm"
#endif

#include "wx/taskbar.h"
#include "wx/socket.h"

#include "mainDlg.h"
#include "main_thread.h"
#include "webserver.h"
#include "shared_data.h"

#include <boost/thread/mutex.hpp>
#include <boost/thread/locks.hpp>

MyDialog   *dialog = NULL;
IMPLEMENT_APP(MyApp)

bool MyApp::OnInit()
{
	wxInitAllImageHandlers();
	wxImage::AddHandler(new wxPNGHandler);
	//wxSocketBase::Initialize();

	startup();

	wxCmdLineParser parser(g_cmdLineDesc, argc, argv);
	if (!parser.Parse()) {
		if (!parser.Found(wxT("s"))) {
			dialog = new MyDialog(NULL, wxID_ANY, wxT("Main Dialog, You shouldn't see this."), wxDefaultPosition, wxSize(100, 100));
			dialog->Show(false); // hide it
		}
#if defined(__WXGTK__) || defined(__WXMOTIF__) || defined(__WXMAC__) || defined(__WXMGL__) || defined(__WXX11__)
		wxIPV4address remote;
		remote.Hostname(_T("www.wxwidgets.org"));
		remote.Service(80);
		wxIPV4address local;
		wxSocketClient client;
		if (client.Connect(remote))
			client.GetLocal(local);
#else
		wxIPV4address local;
		local.Hostname(wxGetFullHostName());
#endif
		wxString ipAddr = local.IPAddress();
		wxString message;
		if (ipAddr == wxT("127.0.0.1") ||
			ipAddr == wxT("0.0.0.0") ||
			ipAddr == wxT("255.255.255.255")) {
			message = wxT("localhost:") + wxS(int2str(port_num));
		} else {
			message = wxT("http://") + ipAddr + wxT(":") + wxS(int2str(port_num));
		}
		//wxSafeShowMessage("Server location", message);
		cout << "Server started at " << message << endl;
	}

	// WebServerMainLoop(&server, this);
	return true;
}

int MyApp::OnExit()
{
	cleanup();
	return 0;
}

enum {
	TIMER = 20001,
};

BEGIN_EVENT_TABLE(MyDialog, wxDialog)
EVT_BUTTON(wxID_EXIT, MyDialog::OnExit)
EVT_CLOSE(MyDialog::OnCloseWindow)
EVT_TIMER(TIMER, MyDialog::OnTimer) 
END_EVENT_TABLE()

MyDialog::MyDialog(wxWindow* parent, const wxWindowID id, const wxString& title,
				   const wxPoint& pos, const wxSize& size, const long windowStyle):
wxDialog(parent, id, title, pos, size, windowStyle)
{
	m_timer = NULL; 
	Init();
}

MyDialog::~MyDialog()
{
	delete m_taskBarIcon;
#if defined(__WXCOCOA__)
	delete m_dockIcon;
#endif
	delete m_timer; 
}

void MyDialog::OnExit(wxCommandEvent& WXUNUSED(event))
{
	Close(true);
}

void MyDialog::OnCloseWindow(wxCloseEvent& WXUNUSED(event))
{
	Destroy();
}

void MyDialog::Init(void)
{
	m_taskBarIcon = new MyTaskBarIcon();
#if defined(__WXCOCOA__)
	m_dockIcon = new MyTaskBarIcon(wxTaskBarIcon::DOCK);
#endif
	if (!m_taskBarIcon->SetIcon(wxIcon(icon2_xpm), wxT("Genome Browser")))
		wxMessageBox(wxT("Could not set icon."));
	
	m_timer = new wxTimer(this,TIMER);
    m_timer->Start(500); 
}

static boost::mutex gmutex;

void MyDialog::OnTimer(wxTimerEvent& event) {
	boost::lock_guard<boost::mutex> lock(gmutex);
	if (folder_to_be_opened.length() > 1) {
		wxLaunchDefaultBrowser(wxT("file:///") + wxS(folder_to_be_opened));
		folder_to_be_opened = "";
	}
}

enum {
	PU_BROWSE = 10001,
	PU_SETTING,
	PU_ABOUT,
	PU_EXIT,
};
 
BEGIN_EVENT_TABLE(MyTaskBarIcon, wxTaskBarIcon)
EVT_MENU(PU_BROWSE,    MyTaskBarIcon::OnMenuBrowse)
EVT_MENU(PU_SETTING,    MyTaskBarIcon::OnMenuSetting)
EVT_MENU(PU_ABOUT,    MyTaskBarIcon::OnMenuAbout)
EVT_MENU(PU_EXIT,    MyTaskBarIcon::OnMenuExit)
EVT_TASKBAR_LEFT_DCLICK  (MyTaskBarIcon::OnLeftButtonDClick)
END_EVENT_TABLE()

// Overridables
wxMenu *MyTaskBarIcon::CreatePopupMenu()
{
	wxMenu *menu = new wxMenu;
	menu->Append(PU_BROWSE,    _T("&Browse"));
	menu->Append(PU_SETTING,    _T("&Setting"));
	menu->Append(PU_ABOUT,    _T("&About"));
#ifndef __WXMAC_OSX__ /*Mac has built-in quit menu*/
	menu->AppendSeparator();
	menu->Append(PU_EXIT,    _T("E&xit"));
#endif
	return menu;
}

void MyTaskBarIcon::OnLeftButtonDClick(wxTaskBarIconEvent&)
{
	wxLaunchDefaultBrowser(wxS(local_host_name));
}

void MyTaskBarIcon::OnMenuBrowse(wxCommandEvent& )
{
	wxLaunchDefaultBrowser(wxS(local_host_name));
}

void MyTaskBarIcon::OnMenuSetting(wxCommandEvent& )
{
	std::string url = local_host_name + "setting";
	wxLaunchDefaultBrowser(wxS(url));
}

void MyTaskBarIcon::OnMenuAbout(wxCommandEvent& )
{
	std::string url = local_host_name + "about.html";
	wxLaunchDefaultBrowser(wxS(url));
}

void MyTaskBarIcon::OnMenuExit(wxCommandEvent& )
{
	dialog->Close(true);
}
