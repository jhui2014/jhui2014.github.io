library(MASS)

# This is the main function. "counts" is the input matrix of m * n, where m is the number of genes and n is the number of samples. "x" is the treatment data.

################################## Multiple linear regression model with type I penalty ##################################
pfun.ADMM.mlr_typeIpenalty <- function(counts, X, sigma_sq = NULL, B_0 = NULL, percentile = 0.50, rho = 1, log.add = 1) {
  
  if (min(counts)>0)
    log.add <- 0
      
  Y <- log(counts + log.add) # log.add may take 0 after more genes are filtered out based on Pearson correlation test
  
  m <- nrow(Y)
  n <- ncol(Y)
  
  if (is.null(sigma_sq)) {
    # 1. Estimate noise variance
    sigma_sq <- noise_variance_esti.mlr(X, Y, 0.000001)
  }
  
  # 2. Tranform data: center X to zero column mean
  X_tilde <- scale(X, center = TRUE, scale = FALSE)
  
  # Center Y to have zero means across both rows and columns
  mean_y_over_j <- rowMeans(Y)
  weighted_mean_y_over_i <- colSums(diag(1 / sigma_sq) %*% Y) / sum(1 / sigma_sq)
  weighted_mean_y_over_ij <- mean(weighted_mean_y_over_i)
  Y_tilde <- Y - mean_y_over_j - rep(weighted_mean_y_over_i, each = m) + weighted_mean_y_over_ij
  
  # 3. Select tuning parameter
  # p <- ncol(X)
  # if (p==1)
  #   alpha_max <- max(abs(diag(1 / sigma_sq) %*% Y_tilde %*% X_tilde))
  # else {
  #   x_p <- X_tilde[, p]
  #   X_1 <- X_tilde[, 1:p - 1]
  #   alpha_max <- max(abs(diag(1 / sigma_sq) %*% Y_tilde %*% (diag(n) - X_1 %*% solve(t(X_1) %*% X_1) %*% t(X_1)) %*% x_p))
  # }
  # alpha <- epsilon * alpha_max
  
  p <- ncol(X)
  if (p==1)
    alpha <- quantile(abs(diag(1 / sigma_sq) %*% Y_tilde %*% X_tilde), probs = percentile)
  else {
    x_p <- X_tilde[, p]
    X_1 <- X_tilde[, 1:p - 1]
    alpha <- quantile(abs(diag(1 / sigma_sq) %*% Y_tilde %*% (diag(n) - X_1 %*% solve(t(X_1) %*% X_1) %*% t(X_1)) %*% x_p), probs = percentile)
  }
  
  # 4. Model fitting by ADMM
  out <- fit.ADMM.mlr_typeIpenalty(X_tilde, Y_tilde, alpha, rho, sigma_sq, B_0 = NULL)
  B_esti <- out$B
  
  mean_beta_esti <- wmean(B_esti, 1 / sigma_sq)
  beta0_esti <- mean_y_over_j + weighted_mean_y_over_i[1] - weighted_mean_y_over_ij - sum(X_tilde[1, ] * mean_beta_esti)
  d_esti <- (weighted_mean_y_over_i - weighted_mean_y_over_i[1]) - as.numeric((X_tilde - rep(X_tilde[1, ], each = n)) %*% mean_beta_esti)
  
  # 5. Recover the original parameter space:
  beta0_esti <- beta0_esti - as.numeric(B_esti %*% as.matrix(colMeans(X)))
  
  # 6. Calculate p values and adjusted p values
  p.value = rep(0, m)
  
  for (i in 1:m) {
    yi <- Y[i, ] - d_esti
    fit <- lm(yi ~ X)
    p.value[i] <- summary(fit)$coefficients[p + 1, 4]
    
    # model.full    = lm(yi ~ X)
    # model.reduced = lm(yi ~ X[, 1:p-1])
    # p.value[i] <- anova(model.reduced, model.full)[2, 6]
  }
  
  p.adj <- p.adjust(p.value, "BH")
  
  result <- cbind(pval = p.value, padj = p.adj, B = B_esti)
  rownames(result) <- rownames(counts) # need to complete
  colnames(result) <- c("pval", "padj", paste('beta_', 1:p, sep = ""))
  
  return (list(result = result, d = d_esti))
}


fit.ADMM.mlr_typeIpenalty <- function(X, Y, alpha, rho, sigma_sq, B_0 = NULL) {
  
  t_start <- proc.time()
  
  # Global constants and defaults
  QUIET    <- 0
  MAX_ITER <- 500
  ABSTOL   <- 1e-8# empirically <= 1e-7
  RELTOL   <- 1e-4# empirically <= 1e-3
  
  # Data preprocessing
  m <- nrow(Y)
  p <- ncol(X)
  
  # save a matrix - vector multiply
  # for inner loop of solving beta_i
  SumOfWeight <- sum(1 / sigma_sq)
  
  XtX <- t(X) %*% X
  YX <- Y %*% X
  
  
  A <- 1 / SumOfWeight * kronecker(t(1 / sigma_sq), diag(p))
  
  
  if (is.null(B_0)) {
    # M <- diag(m) - 1 / SumOfWeight * matrix(1, m, 1) %*% t(1 / sigma_sq)
    # B <- ginv((t(M) %*% diag(1 / sigma_sq) %*% M)) %*% t(M) %*% diag(1 / sigma_sq) %*% Y %*% X %*% solve(XtX)
    B <- matrix(rnorm(m * p), nrow = m, ncol = p)
  } else {
    B <- B_0
  }
  
  delta_0 <- wmean(B, 1 / sigma_sq)
  u <- rep(0, p)
  
  if (!QUIET)
    cat(sprintf('%3s%10s%10s%10s%10s%10s\n', 'iter', 'r norm', 'eps pri', 's norm', 'eps dual', 'objective', sep = "\t"))
  #print('iter')
  
  history <- list(objval = rep(0, MAX_ITER), 
                  r_norm = rep(0, MAX_ITER), 
                  s_norm = rep(0, MAX_ITER), 
                  eps_pri = rep(0, MAX_ITER), 
                  eps_dual = rep(0, MAX_ITER))
  
  for (k in 1:MAX_ITER) {
    
    # B - update
    if (p==1) {
      for(i in 1:m) {
        Q <- 1 / sigma_sq[i] * XtX + rho / (sigma_sq[i]^2 * SumOfWeight^2)
        v <- 1.0 / sigma_sq[i] * (YX[i, ] + XtX %*% delta_0) - rho / (sigma_sq[i] * SumOfWeight) * (1 / SumOfWeight * colSums(diag(1 / sigma_sq[setdiff(1:m, i)]) %*% B[setdiff(1:m, i)]) - delta_0 + u) 
        
        B[i] <- 1 / Q * soft_threshold(v, alpha)
      }
    } 
    else {
      for(i in 1:m) {
        Q <- 1 / sigma_sq[i] * XtX + rho / (sigma_sq[i]^2 * SumOfWeight^2) * diag(p)
        Q_11 <- Q[1:p - 1, 1:p - 1]
        q <- Q[1:p - 1, p]
        
        v <- 1.0 / sigma_sq[i] * (YX[i, ] + XtX %*% delta_0) - rho / (sigma_sq[i] * SumOfWeight) * (1 / SumOfWeight * colSums(diag(1 / sigma_sq[setdiff(1:m, i)]) %*% B[setdiff(1:m, i), ]) - delta_0 + u) 
        # view(1 / (Q[p, p] - t(q) %*% solve(Q_11, q)))
        # view(v[p] - t(q) %*% solve(Q_11, v[1:p - 1]))
        B[i, p] <- 1 / (Q[p, p] - t(q) %*% solve(Q_11, q)) * soft_threshold(v[p] - t(q) %*% solve(Q_11, v[1:p - 1]), alpha)
        B[i, 1:p - 1] <- solve(Q_11, v[1:p - 1] - q * B[i, p])
      }
    }
    
    
    # delta - update
    delta_0_old <- delta_0
    delta_0 <- solve(SumOfWeight * XtX + rho * diag(1, p), rho * u) + wmean(B, 1 / sigma_sq)
    
    # u - update
    u <- u + wmean(B, 1 / sigma_sq) - delta_0
    
    # diagnostics, reporting, termination checks
    history$objval[k] <- obj_func.mlr_typeIpenalty(X, Y, alpha, B, delta_0, sigma_sq)
    
    
    # Reference:
    # S. Boyd, N. Parikh, E. Chu, B. Peleato, and J. Eckstein, “Distributed optimization and statistical learning via the alternating direction method of multipliers,” Foundations and Trends in Machine Learning, vol. 3, no. 1, pp. 1–122, 2011.
    # Problem:  minimize    f(x) + g(z)
    #           subject to  A * x + B * z = c
    
    # primal residual at iteration k + 1: r^{k+1} = A * x^{k+1} + B * z^{k+1} − c
    #   dual residual at iteration k + 1: s^{k+1} = rho * A^T * B * (z^{k+1} − z^k)
    history$r_norm[k] <- sqrt(sum((wmean(B, 1 / sigma_sq) - delta_0)^2))
    history$s_norm[k] <- sqrt(sum((rho * (-t(A)) %*% (delta_0 - delta_0_old))^2))
    
    # history$eps_pri[k] <- sqrt(p) * ABSTOL + RELTOL * max(norm(A * x), norm(B * z), norm(c))
    # history$eps_dual[k] <- sqrt(n) * ABSTOL + RELTOL * norm(rho * A^T * u)
    # where
    # p: dimension of dual variable u, i.e., number of constraints
    # n: dimension of primal variable x
    history$eps_pri[k] <- sqrt(p) * ABSTOL + RELTOL * max(sqrt(sum(wmean(B, 1 / sigma_sq)^2)), sqrt(sum((-delta_0)^2)), 0)
    history$eps_dual[k] <- sqrt(p * m) * ABSTOL + RELTOL * sqrt(sum((rho * t(A) %*% u)^2))
    
    
    if (!QUIET)
      cat(sprintf('%3d%12.4f%12.4f%12.4f%12.4f%12.2f\n', k, history$r_norm[k], history$eps_pri[k], history$s_norm[k], history$eps_dual[k], history$objval[k], sep = "\t"))
    
    if (history$r_norm[k] < history$eps_pri[k] && history$s_norm[k] < history$eps_dual[k])
      break
  }
  
  if (!QUIET)
    time <- (proc.time() - t_start)
  
  return (list(B = B, history = history))
}


soft_threshold <- function(X, kappa) {
  
  z <- pmax(0, X - kappa) - pmax(0, - X - kappa)
  return(z)
}


obj_func.mlr_typeIpenalty <- function(X, Y, alpha, B, delta_0, sigma_sq) {
  p <- ncol(X)
  f <- 1 / 2 * sum(diag(1 / sigma_sq) %*% (Y - sweep(B, 2, t(delta_0)) %*% t(X))^2) + alpha * sum(abs(B[, p]))
  return(f)
}


################################## Multiple linear regression model with type II penalty ##################################
pfun.ADMM.mlr_typeIIpenalty <- function(counts, X, sigma_sq = NULL, B_0 = NULL, percentile = 0.50, rho = 1, log.add = 1) {
  
  if (min(counts)>0)
    log.add <- 0
  
  Y <- log(counts + log.add) # log.add may take 0 after more genes are filtered out based on Pearson correlation test
  
  m <- nrow(Y)
  n <- ncol(Y)
  
  if (is.null(sigma_sq)) {
    # 1. Estimate noise variance
    sigma_sq <- noise_variance_esti.mlr(X, Y, 0.000001)
  }
  
  # 2. Tranform data: center X to zero column mean
  X_tilde <- scale(X, center = TRUE, scale = FALSE)
  
  # Center Y to have zero means across both rows and columns
  mean_y_over_j <- rowMeans(Y)
  weighted_mean_y_over_i <- colSums(diag(1 / sigma_sq) %*% Y) / sum(1 / sigma_sq)
  weighted_mean_y_over_ij <- mean(weighted_mean_y_over_i)
  Y_tilde <- Y - mean_y_over_j - rep(weighted_mean_y_over_i, each = m) + weighted_mean_y_over_ij
  
  # 3. Select tuning parameter
  # alpha_max <- max(sqrt(apply((diag(1 / sigma_sq) %*% Y_tilde %*% X_tilde)^2, 1, sum)))
  # alpha <- epsilon * alpha_max
  alpha <- quantile(sqrt(rowSums((diag(1 / sigma_sq) %*% Y_tilde %*% X_tilde)^2)), probs = percentile)
  
  # 4. Model fitting by ADMM
  out <- fit.ADMM.mlr_typeIIpenalty(X_tilde, Y_tilde, alpha, rho, sigma_sq, B_0 = NULL)
  B_esti <- out$B
  
  mean_beta_esti <- wmean(B_esti, 1 / sigma_sq)
  beta0_esti <- mean_y_over_j + weighted_mean_y_over_i[1] - weighted_mean_y_over_ij - sum(X_tilde[1, ] * mean_beta_esti)
  d_esti <- (weighted_mean_y_over_i - weighted_mean_y_over_i[1]) - as.numeric((X_tilde - rep(X_tilde[1, ], each = n)) %*% mean_beta_esti)
  
  # 5. Recover the original parameter space:
  beta0_esti <- beta0_esti - as.numeric(B_esti %*% as.matrix(colMeans(X)))
  
  # 6. Calculate p values and adjusted p values
  p.value = rep(0, m)
  
  for (i in 1:m) {
    yi <- Y[i, ] - d_esti
    fit <- lm(yi ~ X)
    p.value[i] <- anova(fit)[1, 5]
  }
  
  p.adj <- p.adjust(p.value, "BH")
  
  result <- cbind(pval = p.value, padj = p.adj, B = B_esti)
  rownames(result) <- rownames(counts)
  colnames(result) <- c("pval", "padj", paste('beta_', 1:ncol(X), sep = ""))
  
  return (list(result = result, d = d_esti))
}


fit.ADMM.mlr_typeIIpenalty <- function(X, Y, alpha, rho, sigma_sq, B_0 = NULL) {
  
  t_start <- proc.time()
  
  # Global constants and defaults
  QUIET    <- 0
  MAX_ITER <- 500
  ABSTOL   <- 1e-8# empirically <= 1e-7
  RELTOL   <- 1e-4# empirically <= 1e-3
  
  # Data preprocessing
  m <- nrow(Y)
  p <- ncol(X)
  
  # save a matrix - vector multiply
  SumOfWeight <- sum(1 / sigma_sq)
  
  XtX <- t(X) %*% X
  if (p>1) {
    eig_XtX <- eigen(XtX)
    U <- eig_XtX$vectors
    D <- diag(eig_XtX$values, nrow = ncol(X), ncol = ncol(X))
  }
  
  YX <- Y %*% X
  
  
  A <- 1 / SumOfWeight * kronecker(t(1 / sigma_sq), diag(p))
  
  
  if (is.null(B_0)) {
    # M <- diag(m) - 1 / SumOfWeight * matrix(1, m, 1) %*% t(1 / sigma_sq)
    # B <- ginv((t(M) %*% diag(1 / sigma_sq) %*% M)) %*% t(M) %*% diag(1 / sigma_sq) %*% Y %*% X %*% solve(XtX)
    B <- matrix(rnorm(m * p), nrow = m, ncol = p)
  } else {
    B <- B_0
  }
  
  delta_0 <- wmean(B, 1 / sigma_sq)
  u <- rep(0, p)
  
  if (!QUIET)
    cat(sprintf('%3s%10s%10s%10s%10s%10s\n', 'iter', 'r norm', 'eps pri', 's norm', 'eps dual', 'objective', sep = "\t"))
  #print('iter')
  
  history <- list(objval = rep(0, MAX_ITER), 
                  r_norm = rep(0, MAX_ITER), 
                  s_norm = rep(0, MAX_ITER), 
                  eps_pri = rep(0, MAX_ITER), 
                  eps_dual = rep(0, MAX_ITER))
  
  for (k in 1:MAX_ITER) {
    
    # B - update
    if (p==1) {
      for(i in 1:m) {
        v <- 1.0 / sigma_sq[i] * (YX[i, ] + XtX %*% delta_0) - rho / (sigma_sq[i] * SumOfWeight) * (1 / SumOfWeight * colSums(diag(1 / sigma_sq[setdiff(1:m, i)]) %*% B[setdiff(1:m, i)]) - delta_0 + u)
        
        if (abs(v)<=alpha)
          B[i] <- 0
        else{
          Q <- 1 / sigma_sq[i] * XtX + rho / (sigma_sq[i]^2 * SumOfWeight^2)
          
          B[i] <- 1 / Q * soft_threshold(v, alpha)
        }
      }
    }
    else {
      for(i in 1:m) {
        
        # estimate beta_i via one-dimensional search.
        v <- 1.0 / sigma_sq[i] * (YX[i, ] + XtX %*% delta_0) - rho / (sigma_sq[i] * SumOfWeight) * (1 / SumOfWeight * colSums(diag(1 / sigma_sq[setdiff(1:m, i)]) %*% B[setdiff(1:m, i), ]) - delta_0 + u) # some terms of the right hand side can be moved out of the loop for saving computational time
        
        if (sqrt(sum(v^2))<=alpha)
          B[i, ] <- rep(0, p)
        
        else{
          Z <- sqrt(1 / sigma_sq[i] * D + rho / (sigma_sq[i]^2 * SumOfWeight^2) * diag(p)) %*% t(U)
          b <- solve(sqrt(1 / sigma_sq[i] * D + rho / (sigma_sq[i]^2 * SumOfWeight^2) * diag(p)), t(U) %*% v)
          
          beta_i <- B[i, ]
          for(iter_inner in 1:25) {
            beta_i_old <- beta_i 
            
            for(s in 1:p) {
              r <- b - as.matrix(Z[, setdiff(1:p, s)]) %*% beta_i[setdiff(1:p, s)]
              sum_of_squares_beta_i_except_for_index_s <- sum(beta_i[setdiff(1:p, s)]^2)
              
              z <- Z[, s]
              beta_is_ols <- (t(z) %*% r) / sum(z^2)
              beta_i[s] <- optimize(fun, lower = min(0, beta_is_ols), upper = max(0, beta_is_ols), r = r, z = z, b = sum_of_squares_beta_i_except_for_index_s, alpha = alpha)$minimum
            }
            if (sqrt(sum((beta_i - beta_i_old)^2) / sum(beta_i_old^2)) < 1e-3)
              break
          }
          B[i, ] <- beta_i
        }
      }
    }
    
    
    # delta - update
    delta_0_old <- delta_0
    delta_0 <- solve(SumOfWeight * XtX + rho * diag(1, p), rho * u) + wmean(B, 1 / sigma_sq)
    
    # u - update
    u <- u + wmean(B, 1 / sigma_sq) - delta_0
    
    # diagnostics, reporting, termination checks
    history$objval[k] <- obj_func.mlr_typeIIpenalty(X, Y, alpha, B, delta_0, sigma_sq)
    
    
    # Reference:
    # S. Boyd, N. Parikh, E. Chu, B. Peleato, and J. Eckstein, “Distributed optimization and statistical learning via the alternating direction method of multipliers,” Foundations and Trends in Machine Learning, vol. 3, no. 1, pp. 1–122, 2011.
    # Problem:  minimize    f(x) + g(z)
    #           subject to  A * x + B * z = c
    
    # primal residual at iteration k + 1: r^{k+1} = A * x^{k+1} + B * z^{k+1} − c
    #   dual residual at iteration k + 1: s^{k+1} = rho * A^T * B * (z^{k+1} − z^k)
    history$r_norm[k] <- sqrt(sum((wmean(B, 1 / sigma_sq) - delta_0)^2))
    history$s_norm[k] <- sqrt(sum((rho * (-t(A)) %*% (delta_0 - delta_0_old))^2))
    
    # history$eps_pri[k] <- sqrt(p) * ABSTOL + RELTOL * max(norm(A * x), norm(B * z), norm(c))
    # history$eps_dual[k] <- sqrt(n) * ABSTOL + RELTOL * norm(rho * A^T * u)
    # where
    # p: dimension of dual variable u, i.e., number of constraints
    # n: dimension of primal variable x
    history$eps_pri[k] <- sqrt(p) * ABSTOL + RELTOL * max(sqrt(sum(wmean(B, 1 / sigma_sq)^2)), sqrt(sum((-delta_0)^2)), 0)
    history$eps_dual[k] <- sqrt(p * m) * ABSTOL + RELTOL * sqrt(sum((rho * t(A) %*% u)^2))
    
    
    if (!QUIET)
      cat(sprintf('%3d%12.4f%12.4f%12.4f%12.4f%12.2f\n', k, history$r_norm[k], history$eps_pri[k], history$s_norm[k], history$eps_dual[k], history$objval[k], sep="\t"))
    
    if (history$r_norm[k] < history$eps_pri[k] && history$s_norm[k] < history$eps_dual[k])
      break
  }
  
  if (!QUIET)
    time <- (proc.time() - t_start)
  
  return (list(B = B, history = history))
}


fun <- function(x, r, z, b, alpha)  1 / 2 * sum((r - z * x)^2) + alpha * sqrt(b + x^2)


obj_func.mlr_typeIIpenalty <- function(X, Y, alpha, B, delta_0, sigma_sq) {
  f <- 1 / 2 * sum(diag(1 / sigma_sq) %*% (Y - sweep(B, 2, t(delta_0)) %*% t(X))^2) + alpha * sum(sqrt(rowSums(B^2)))
  return(f)
}



#################################################### common functions #####################################################
noise_variance_esti.mlr <-  function (X, Y, epsilon = 1e-3, MAX_ITER = 10000, shrinkage = TRUE) {
  
  m <- nrow(Y)
  n <- ncol(Y)
  p <- ncol(X)
  
  # Center X to zero column mean
  X_tilde <- scale(X, center = TRUE, scale = FALSE)
  
  sigma_sq <- rep(1, m)
  B <- matrix(0, m, p)
  delta_0 <- wmean(B, 1 / sigma_sq)
  
  for (k in 1:MAX_ITER) {
    
    mean_y_over_j <- rowMeans(Y)
    weighted_mean_y_over_i <- colSums(diag(1 / sigma_sq) %*% Y) / sum(1 / sigma_sq)
    weighted_mean_y_over_ij <- mean(weighted_mean_y_over_i)
    Y_tilde <- Y - mean_y_over_j - rep(weighted_mean_y_over_i, each = m) + weighted_mean_y_over_ij
    
    # Compute B
    for (i in 1:m) {
      B[i, ] <- (Y_tilde[i, ] %*% X_tilde) %*% solve(t(X_tilde) %*% X_tilde) + delta_0
    }
    
    # Compute noise variance
    sigma_sq_old <- sigma_sq
    sigma_sq <- 1 / (n - p - 1) * rowSums((Y_tilde - sweep(B, 2, delta_0) %*% t(X_tilde))^2)
    
    # Compute weighted mean of B
    delta_0 <- wmean(B, 1 / sigma_sq)
    
    if (sqrt(sum((sigma_sq - sigma_sq_old)^2)) / sqrt(sum(sigma_sq_old^2)) < epsilon)
      break
  }
  
  if (shrinkage) {
    sigma_sq.mean <- mean(sigma_sq)
    w <- (2 / (n - p - 1)) / (1 + 2 / (n - p - 1)) * (m - 1) * (1 / m + sigma_sq.mean^2 / sum((sigma_sq - sigma_sq.mean)^2))
    if (w > 1) w <- 1
    sigma_sq.new <- (1 - w) * sigma_sq + w * sigma_sq.mean
    
    return(sigma_sq.new)}
  
  else
    return(sigma_sq)
  
}

wmean <- function(B, weight) {
  delta_0 <- colSums(weight * B) / sum(weight)
  return(delta_0)
}