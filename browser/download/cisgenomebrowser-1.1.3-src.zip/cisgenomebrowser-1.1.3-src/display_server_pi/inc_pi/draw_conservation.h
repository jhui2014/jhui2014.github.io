#ifndef DRAW_CONSERVATION_H
#define DRAW_CONSERVATION_H

#include "draw_signal.h"

class draw_conservation: public draw_signal
{
public:
	bool box;

	string file_path;
	string chr;
	int startpos, endpos;

	draw_conservation();
	virtual string print_usage();
	virtual bool get_params(const vector<string> &params);
	virtual bool prepare_data();
	virtual bool load_data();
};

#endif //DRAW_CONSERVATION_H
