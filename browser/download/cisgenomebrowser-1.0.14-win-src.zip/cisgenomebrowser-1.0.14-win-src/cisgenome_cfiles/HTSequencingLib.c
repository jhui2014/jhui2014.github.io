/* ----------------------------------------------------------------------- */
/*  HTSequencingLib.c : implementation of the high throughput sequencing   */
/*  library                                                                */
/*  Author : Ji HongKai ; Time: 2007.10                                    */
/* ----------------------------------------------------------------------- */

#include "stdlib.h"
#include "stdio.h"
#include "string.h"
#include "math.h"
#include "limits.h"

#include "MathLib.h"
#include "MatrixLib.h"
#include "RandomLib.h"
#include "StringLib.h"
#include "GenomeLib.h"
#include "HTSequencingLib.h"
#include "AffyLib.h"
#include "TilingArrayLib.h"

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Window_Main()                                                  */
/*  Convert high throughput sequencing alignment to windowed bar tiling    */
/*  data. Each sample will be scaled to have the same number of aligned    */
/*  reads if specified.                                                    */
/* ----------------------------------------------------------------------- */ 
int HTS_Aln2Window_Main(char strParamPath[])
{	
	/* Sample name */
	struct tagHTSAln2WinParam *pParam = NULL;
	struct INTMATRIX *pChrLen = NULL;
	struct tagBARData *pBARData = NULL;
	int ni;
	double dCount;
	char strFileName[LONG_LINE_LENGTH];
	struct INTMATRIX *pCol;
	int nx,ny;
	FILE *fpOut;

	/* Load Parameters */
	pParam = HTS_Aln2Window_LoadParamter(strParamPath);
	if(pParam == NULL)
	{
		printf("Error: HTS_Aln2Window_Main, cannot allocate memory for loading parameters!\n");
		exit(EXIT_FAILURE);
	}

	/* Load Chromosome */
	pChrLen = IMLOAD(pParam->strChrLen);
	if(pChrLen == NULL)
	{
		printf("Error: HTS_Aln2Window_Main, cannot load chromosome length!\n");
		exit(EXIT_FAILURE);
	}

	/* prepare BAR object */
	pBARData = HTS_Aln2Window_PrepareBARData(pParam, pChrLen);
	if(pBARData == NULL)
	{
		printf("Error: HTS_Aln2Window_Main, cannot create bar data object!\n");
		exit(EXIT_FAILURE);
	}

	/* process data one by one */
	pCol = NULL;
	pCol = CreateIntMatrix(1,pBARData->nColNum);
	if(pCol == NULL)
	{
		printf("Error: HTS_Aln2Window_Main, cannot create output column information!\n");
		exit(EXIT_FAILURE);
	}
	pCol->pMatElement[0] = 1;
	pCol->pMatElement[1] = 1;
	for(ni=0; ni<pParam->nSampleNum; ni++)
	{
		/* count */
		sprintf(strFileName, "%s%s", pParam->strDataFolder, pParam->vSampleFile[ni]->m_pString);
		dCount = 0;
		dCount = HTS_Aln2Window_CountHits(pBARData, strFileName, pParam->nW);

		/* scaling */
		if(dCount > 0.0)
		{
			if(pParam->dScaling > 0.0)
			{
				/* HTS_Aln2Window_Scaling(pBARData, pParam->dScaling/dCount, pParam->nW); */
				/* HTS_Aln2Window_Scaling(pBARData, pParam->nW); */
			}
		}

		/* output */
		sprintf(strFileName, "%s%s.bar", pParam->strExportFolder, pParam->vSampleFile[ni]->m_pString);
		Affy_SaveBAR_Columns_Fast(strFileName, pBARData, pCol);
		sprintf(strFileName, "%s%s.bar.txt", pParam->strExportFolder, pParam->vSampleFile[ni]->m_pString);
		fpOut = NULL;
		fpOut = fopen(strFileName, "w");
		for(nx=0; nx<3; nx++)
		{
			for(ny=0; ny<pBARData->vSeqData[nx]->nDataNum; ny++)
			{
				fprintf(fpOut, "%f\n", pBARData->vSeqData[nx]->vData[1]->pMatElement[ny]);
			}
		}
		fclose(fpOut);
	}
	DestroyIntMatrix(pCol);

	/* write cgw file */
	HTS_Aln2Window_WriteCGW(pParam);
	
	/* write cgb file */
	HTS_Aln2Window_WriteCGB(pParam);

	/* Destroy Paramter */
	HTSAln2WinParam_Destroy(&pParam);
	DestroyIntMatrix(pChrLen);
	pChrLen = NULL;
	Affy_BARData_Destroy(&pBARData);

	/* return */
	return PROC_SUCCESS;
}


/* ----------------------------------------------------------------------- */ 
/*  HTSAln2WinParam_Create()                                               */
/*  Create hts_aln2window paramter.                                        */
/* ----------------------------------------------------------------------- */ 
struct tagHTSAln2WinParam *HTSAln2WinParam_Create()
{
	/* define */
	struct tagHTSAln2WinParam *pParam = NULL;

	/* create */
	pParam = (struct tagHTSAln2WinParam *)calloc(1, sizeof(struct tagHTSAln2WinParam));
	if(pParam == NULL)
	{
		printf("Error: HTSAln2WinParam_Create, cannot allocate memory for creating HTSAln2WinParam object!\n");
		exit(EXIT_FAILURE);
	}

	/* return */
	return pParam;
}

/* ----------------------------------------------------------------------- */ 
/*  HTSAln2WinParam_Destroy()                                              */
/*  Destroy hts_aln2window paramter.                                       */
/* ----------------------------------------------------------------------- */ 
void HTSAln2WinParam_Destroy(struct tagHTSAln2WinParam **pParam)
{
	int ni;

	if(pParam == NULL)
		return;

	if(*pParam == NULL)
		return;

	DestroyIntMatrix((*pParam)->vGroupLabel);
	(*pParam)->vGroupLabel = NULL;

	for(ni=0; ni<(*pParam)->nSampleNum; ni++)
	{
		DeleteString((*pParam)->vSampleAlias[ni]);
		(*pParam)->vSampleAlias[ni] = NULL;
		DeleteString((*pParam)->vSampleFile[ni]);
		(*pParam)->vSampleFile[ni] = NULL;
	}
	free((*pParam)->vSampleAlias);
	(*pParam)->vSampleAlias = NULL;
	free((*pParam)->vSampleFile);
	(*pParam)->vSampleFile = NULL;

	free(*pParam);
	*pParam = NULL;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Window_LoadParamter()                                          */
/*  Load hts_aln2window paramter.                                          */
/* ----------------------------------------------------------------------- */ 
struct tagHTSAln2WinParam *HTS_Aln2Window_LoadParamter(char strParamPath[])
{
	/* define */
	struct tagHTSAln2WinParam *pParam = NULL;
	FILE *fpIn = NULL;
	char strLine[LONG_LINE_LENGTH];
	char strKey[MED_LINE_LENGTH];
	char strValue[LONG_LINE_LENGTH];
	char *chp;
	int ni;

	/* load */
	pParam = HTSAln2WinParam_Create();
	if(pParam == NULL)
	{
		printf("Error: HTS_Aln2Window_LoadParamter, cannot allocate memory for loading parameter!\n");
		exit(EXIT_FAILURE);
	}

	fpIn = fopen(strParamPath, "r");
	if(fpIn == NULL)
	{
		printf("Error: HTS_Aln2Window_LoadParamter, cannot open input parameter file!\n");
		exit(EXIT_FAILURE);
	}

	while(fgets(strLine, LONG_LINE_LENGTH, fpIn) != NULL)
	{
		StrTrimLeft(strLine);
		StrTrimRight(strLine);
		if(strLine[0] == '\0')
			continue;
		if(strLine[0] == '#')
			continue;

		chp = strchr(strLine, '=');
		if(chp == NULL)
		{
			printf("Error: HTS_Aln2Window_LoadParamter, wrong parameter file!\n");
			exit(EXIT_FAILURE);
		}

		*chp = '\0';
		strcpy(strKey, strLine);
		StrTrimRight(strKey);

		chp++;
		strcpy(strValue, chp);
		StrTrimLeft(strValue);

		if(strcmp(strKey, "project_name") == 0)
		{
			strcpy(pParam->strProjectName, strValue);
		}
		else if(strcmp(strKey, "chrlist") == 0)
		{
			strcpy(pParam->strChrList, strValue);
		}
		else if(strcmp(strKey, "chrlen") == 0)
		{
			strcpy(pParam->strChrLen, strValue);
		}
		else if(strcmp(strKey, "data_folder") == 0)
		{
			strcpy(pParam->strDataFolder, strValue);
			AdjustDirectoryPath(pParam->strDataFolder);
		}
		else if(strcmp(strKey, "sample_num") == 0)
		{
			pParam->nSampleNum = atoi(strValue);
			if( pParam->nSampleNum <= 0 )
			{
				printf("Error: HTS_Aln2Window_LoadParamter, no sample available!\n");
				exit(EXIT_FAILURE);
			}

			pParam->vSampleAlias = (struct tagString **)calloc(pParam->nSampleNum, sizeof(struct tagString *));
			pParam->vSampleFile = (struct tagString **)calloc(pParam->nSampleNum, sizeof(struct tagString *));
			pParam->vGroupLabel = CreateIntMatrix(1, pParam->nSampleNum);

			if( (pParam->vSampleAlias == NULL) || (pParam->vSampleFile == NULL) || (pParam->vGroupLabel == NULL))
			{
				printf("Error: HTS_Aln2Window_LoadParamter, cannot create memory for loading sample information!\n");
				exit(EXIT_FAILURE);
			}

		}
		else if(strstr(strKey, "sample_alias") == strKey)
		{
			chp = strrchr(strKey, '_');
			if(chp == NULL)
			{
				printf("Error: HTS_Aln2Window_LoadParamter, wrong parameter file!\n");
				exit(EXIT_FAILURE);
			}
			chp++;
			ni = atoi(chp)-1;
			StringAddTail(pParam->vSampleAlias+ni, strValue);
		}
		else if(strstr(strKey, "sample_group") == strKey)
		{
			chp = strrchr(strKey, '_');
			if(chp == NULL)
			{
				printf("Error: HTS_Aln2Window_LoadParamter, wrong parameter file!\n");
				exit(EXIT_FAILURE);
			}
			chp++;
			ni = atoi(chp)-1;
			pParam->vGroupLabel->pMatElement[ni] = atoi(strValue);
		}
		else if(strstr(strKey, "sample_file") == strKey)
		{
			
			chp = strrchr(strKey, '_');
			if(chp == NULL)
			{
				printf("Error: HTS_Aln2Window_LoadParamter, wrong parameter file!\n");
				exit(EXIT_FAILURE);
			}
			chp++;
			ni = atoi(chp)-1;
			StringAddTail(pParam->vSampleFile+ni, strValue);
		}
		else if(strcmp(strKey, "group_num") == 0)
		{
			pParam->nGroupNum = atoi(strValue);
		}
		else if(strcmp(strKey, "scaling") == 0)
		{
			pParam->dScaling = atof(strValue);
		}
		else if(strcmp(strKey, "window_size") == 0)
		{
			pParam->nW = atoi(strValue);
		}
		else if(strcmp(strKey, "step_size") == 0)
		{
			pParam->nS = atoi(strValue);
		}
		else if(strcmp(strKey, "export_folder") == 0)
		{
			strcpy(pParam->strExportFolder, strValue);
			AdjustDirectoryPath(pParam->strExportFolder);
		}
	}

	fclose(fpIn);

	/* return */
	return pParam;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Window_PrepareBARData()                                        */
/*  Prepare the bar data object.                                           */
/* ----------------------------------------------------------------------- */ 
struct tagBARData * HTS_Aln2Window_PrepareBARData(struct tagHTSAln2WinParam *pParam, 
				struct INTMATRIX *pChrLen)
{
	/* define */
	struct tagBARData *pBARData;
	int nSeqNum;
	int nColNum;
	int nDataNum;
	FILE *fpIn;
	char strLine[LONG_LINE_LENGTH];
	int ni,nj,nk;
	
	/* init */
	nSeqNum = pChrLen->nHeight;
	nColNum = 2;

	/* create */
	pBARData = Affy_BARData_Create();
	if(pBARData == NULL)
	{
		printf("Error: HTS_Aln2Window_PrepareBARData, BARData object was not created!\n");
		exit(EXIT_FAILURE);
	}
	strcpy(pBARData->strMagicnumber, "barr\r\n\032\n");
	pBARData->fVersionnumber = 2.0;
    pBARData->nSeqNum = nSeqNum;
	pBARData->nColNum = nColNum;
	pBARData->nParamNum = 0;
	pBARData->vParamName = NULL;
	pBARData->vParamValue = NULL;
	pBARData->pFieldType = CreateIntMatrix(1, pBARData->nColNum);
	if(pBARData->pFieldType == NULL)
	{
		printf("Error: HTS_Aln2Window_PrepareBARData, cannot allocate memory for field type.\n");
		exit(EXIT_FAILURE);
	}
	pBARData->pFieldType->pMatElement[0] = 2;
	for(ni=1; ni<pBARData->nColNum; ni++)
		pBARData->pFieldType->pMatElement[ni] = 1;

	pBARData->vSeqData = (struct tagBARSeq **)calloc(pBARData->nSeqNum, sizeof(struct tagBARSeq *));
	if(pBARData->vSeqData == NULL)
	{
		printf("Error: HTS_Aln2Window_PrepareBARData, cannot allocate memory for loading sequence data.\n");
		exit(EXIT_FAILURE);
	}

	for(ni=0; ni<pBARData->nSeqNum; ni++)
	{
		/* create BARSeq object */
		pBARData->vSeqData[ni] = Affy_BARSeq_Create();
		if(pBARData->vSeqData[ni] == NULL)
		{
			printf("Error: HTS_Aln2Window_PrepareBARData, cannot create BARSeq object.\n");
			exit(EXIT_FAILURE);
		}

		pBARData->vSeqData[ni]->pSeqGroupName = NULL;
		pBARData->vSeqData[ni]->pSeqVersion = NULL;
		pBARData->vSeqData[ni]->nParamNum = 0;
		pBARData->vSeqData[ni]->vParamName = NULL;
		pBARData->vSeqData[ni]->vParamValue = NULL;

		pBARData->vSeqData[ni]->nColNum = pBARData->nColNum;

		nDataNum = pChrLen->pMatElement[ni]/pParam->nW;
		if(pChrLen->pMatElement[ni]%pParam->nW != 0)
			nDataNum++;

		pBARData->vSeqData[ni]->nDataNum = nDataNum;
		pBARData->vSeqData[ni]->vData = (struct DOUBLEMATRIX **)calloc(pBARData->vSeqData[ni]->nColNum, sizeof(struct DOUBLEMATRIX *));
		if(pBARData->vSeqData[ni]->vData == NULL)
		{
			printf("Error: HTS_Aln2Window_PrepareBARData, cannot allocate memory for loading bpmap coordinate data!\n");
			exit(EXIT_FAILURE);
		}
		if(pBARData->vSeqData[ni]->nDataNum > 0)
		{
			for(nj=0; nj<pBARData->vSeqData[ni]->nColNum; nj++)
			{
				pBARData->vSeqData[ni]->vData[nj] = CreateDoubleMatrix(1, pBARData->vSeqData[ni]->nDataNum );
				if(pBARData->vSeqData[ni]->vData[nj] == NULL)
				{
					printf("Error: HTS_Aln2Window_PrepareBARData, cannot allocate memory for loading bpmap coordinate data!\n");
					exit(EXIT_FAILURE);
				}
			}
		}

		nk = pParam->nW/2;
		for(nj=0; nj<nDataNum; nj++)
		{
			pBARData->vSeqData[ni]->vData[0]->pMatElement[nj] = nk;
			nk += pParam->nW;
		}
	}

	fpIn = NULL;
	fpIn = fopen(pParam->strChrList, "r");
	if(fpIn == NULL)
	{
		printf("Error: HTS_Aln2Window_PrepareBARData, cannot open chrlist file!\n");
		exit(EXIT_FAILURE);
	}

	ni = 0;
	while(fgets(strLine, LONG_LINE_LENGTH, fpIn) != NULL)
	{
		StrTrimLeft(strLine);
		StrTrimRight(strLine);
		if(strLine[0] == '\0')
			continue;
		if(strLine[0] == '#')
			continue;

		if(ni >= nSeqNum)
		{
			printf("Error: HTS_Aln2Window_PrepareBARData, chromosome number wrong!\n");
			exit(EXIT_FAILURE);
		}

		StringAddTail(&(pBARData->vSeqData[ni]->pSeqName), strLine);
		ni++;
	}
	
	fclose(fpIn);

	if(ni != nSeqNum)
	{
		printf("Error: HTS_Aln2Window_PrepareBARData, chromosome number wrong!\n");
		exit(EXIT_FAILURE);
	}

	/* return */
	return pBARData;
}


/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Window_CountHits()                                             */
/*  Count hits in each window.                                             */
/* ----------------------------------------------------------------------- */ 
double HTS_Aln2Window_CountHits(struct tagBARData *pBARData, char strInFile[], int nW)
{
	/* define */
	FILE *fpIn = NULL;
	char strLine[LONG_LINE_LENGTH];
	char strChr[MED_LINE_LENGTH];
	int nPos,nId;
	int ni;
	double dCount = 0.0;

	/* reset matrix */
	for(ni=0; ni<pBARData->nSeqNum; ni++)
	{
		DestroyDoubleMatrix(pBARData->vSeqData[ni]->vData[1]);
		pBARData->vSeqData[ni]->vData[1] = NULL;
		pBARData->vSeqData[ni]->vData[1] = CreateDoubleMatrix(1, pBARData->vSeqData[ni]->nDataNum);
		if(pBARData->vSeqData[ni]->vData[1] == NULL)
		{
			printf("Error: HTS_Aln2Window_PrepareBARData, cannot create memory for counting!\n");
			exit(EXIT_FAILURE);
		}
	}

	/* open file */
	fpIn = fopen(strInFile, "r");
	if(fpIn == NULL)
	{
		printf("Error: HTS_Aln2Window_PrepareBARData, cannot open input file!\n");
		exit(EXIT_FAILURE);
	}

	while(fgets(strLine, LONG_LINE_LENGTH, fpIn) != NULL)
	{
		StrTrimLeft(strLine);
		StrTrimRight(strLine);
		if(strLine[0] == '\0')
			continue;
		if(strLine[0] == '#')
			continue;

		sscanf(strLine, "%s %d", strChr, &nPos);
		for(ni=0; ni<pBARData->nSeqNum; ni++)
		{
			if(strcmp(strChr, pBARData->vSeqData[ni]->pSeqName->m_pString) == 0)
			{
				nId = nPos/nW;
				if(nId < pBARData->vSeqData[ni]->nDataNum)
				{
					pBARData->vSeqData[ni]->vData[1]->pMatElement[nId] += 1;
					dCount += 1.0;
				}
				break;
			}
		}
	}


	/* close file */
	fclose(fpIn);

	/* return */ 
	return dCount;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Window_Scaling()                                               */
/*  Scaling HTS data.                                                      */
/* ----------------------------------------------------------------------- */ 
int HTS_Aln2Window_Scaling(struct tagBARData *pBARData, double dScale)
{
	int ni,nj;

	/* 
	for(ni=0; ni<pBARData->nSeqNum; ni++)
	{
		for(nj=0; nj<pBARData->vSeqData[ni]->nDataNum; nj++)
		{
			pBARData->vSeqData[ni]->vData[1]->pMatElement[nj] *= dScale;
		}
	} */

	double dM = 0.0;
	double dV = 0.0;
	double dTotalC = 0.0;
	double dA,dB;
	double dSum = 0.0;

	for(ni=0; ni<pBARData->nSeqNum; ni++)
	{
		dTotalC += pBARData->vSeqData[ni]->nDataNum;
		for(nj=0; nj<pBARData->vSeqData[ni]->nDataNum; nj++)
		{
			dM += pBARData->vSeqData[ni]->vData[1]->pMatElement[nj];
		}
	}
	dM /= dTotalC;

	for(ni=0; ni<pBARData->nSeqNum; ni++)
	{
		for(nj=0; nj<pBARData->vSeqData[ni]->nDataNum; nj++)
		{
			dV += (pBARData->vSeqData[ni]->vData[1]->pMatElement[nj]-dM)*(pBARData->vSeqData[ni]->vData[1]->pMatElement[nj]-dM);
		}
	}
	dV /= (dTotalC-1.0);

	dB = dM/(dV-dM);
	dA = dB*dM;


	for(ni=0; ni<pBARData->nSeqNum; ni++)
	{
		for(nj=0; nj<pBARData->vSeqData[ni]->nDataNum; nj++)
		{
			pBARData->vSeqData[ni]->vData[1]->pMatElement[nj] = (pBARData->vSeqData[ni]->vData[1]->pMatElement[nj]+dA)/(1.0+dB);
			dSum += pBARData->vSeqData[ni]->vData[1]->pMatElement[nj];
		}
	}

	for(ni=0; ni<pBARData->nSeqNum; ni++)
	{
		for(nj=0; nj<pBARData->vSeqData[ni]->nDataNum; nj++)
		{
			pBARData->vSeqData[ni]->vData[1]->pMatElement[nj] /= dSum;
		}
	}

	return PROC_SUCCESS;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Window_WriteCGW()                                              */
/*  Write to CGW file.                                                     */
/* ----------------------------------------------------------------------- */ 
int HTS_Aln2Window_WriteCGW(struct tagHTSAln2WinParam *pParam)
{
	/* define */
	FILE *fpOut;
	char strFileName[LONG_LINE_LENGTH];
	int ni;

	/* write to CGW file */
	sprintf(strFileName, "%s%s.cgw", pParam->strExportFolder, pParam->strProjectName);
	fpOut = NULL;
	fpOut = fopen(strFileName, "w");
	if(fpOut == NULL)
	{
		printf("Error: HTS_Aln2Window_WriteCGW, cannot open output file!\n");
		exit(EXIT_FAILURE);
	}

	fprintf(fpOut, "[item1]\n");
	fprintf(fpOut, "type=bartilingexp\n");
	fprintf(fpOut, "item_name=%s\n", pParam->strProjectName);
	fprintf(fpOut, "bar_folder=%s\n", pParam->strExportFolder);
	fprintf(fpOut, "lib_num=1\n");
	fprintf(fpOut, "sample_num=%d\n", pParam->nSampleNum);
	fprintf(fpOut, "group_num=%d\n", pParam->nGroupNum);
	for(ni=0; ni<pParam->nSampleNum; ni++)
	{
		fprintf(fpOut, "sample_alias_%d=%s\n", ni+1, pParam->vSampleAlias[ni]->m_pString);
		fprintf(fpOut, "sample_group_%d=%d\n", ni+1, pParam->vGroupLabel->pMatElement[ni]);
		fprintf(fpOut, "bar_file_%d_1=%s.bar\n", ni+1, pParam->vSampleFile[ni]->m_pString);
	}
	fclose(fpOut);

	/* return */
	return PROC_SUCCESS;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Window_WriteCGB()                                              */
/*  Write to CGB file.                                                     */
/* ----------------------------------------------------------------------- */
int HTS_Aln2Window_WriteCGB(struct tagHTSAln2WinParam *pParam)
{
	/* define */
	FILE *fpOut;
	char strFileName[LONG_LINE_LENGTH];
	char strCommand[LONG_LINE_LENGTH];
	int ni,nj;
	int nTrackNum;
	char strInName[MED_LINE_LENGTH];
	char strOutName[MED_LINE_LENGTH];

	/* write to CGW file */
	nTrackNum = 2*pParam->nSampleNum;

	sprintf(strFileName, "%s%s.ini", pParam->strExportFolder, pParam->strProjectName);
	fpOut = NULL;
	fpOut = fopen(strFileName, "w");
	if(fpOut == NULL)
	{
		printf("Error: HTS_Aln2Window_WriteCGB, cannot open output file!\n");
		exit(EXIT_FAILURE);
	}

	fprintf(fpOut, "[session]\n");
	fprintf(fpOut, "type=genome\n");
	fprintf(fpOut, "[genome]\n");
	fprintf(fpOut, "num_tracks=%d\n", nTrackNum);
	fprintf(fpOut, "region=chr1:1-5000\n");

	nj = 1;
	for(ni=0; ni<pParam->nSampleNum; ni++)
	{
		sprintf(strInName, "%s%s", pParam->strDataFolder, pParam->vSampleFile[ni]->m_pString);
		sprintf(strOutName, "%s%s.sort", pParam->strExportFolder, pParam->vSampleFile[ni]->m_pString);
		sprintf(strCommand, "tablesorter %s %s", strInName, strOutName);
		system(strCommand);

		strcpy(strInName, strOutName);
		sprintf(strOutName, "%s.raw", pParam->vSampleFile[ni]->m_pString);
		TileMapv2_TXT2BAR(strInName, pParam->strExportFolder, strOutName);

		fprintf(fpOut, "[track%d]\n", nj);
		fprintf(fpOut, "title=%s_raw\n", pParam->vSampleAlias[ni]->m_pString);
		fprintf(fpOut, "type=signal\n");
		fprintf(fpOut, "pic_height=50\n");
		fprintf(fpOut, "src_filename=%s%s.raw.bar\n", pParam->strExportFolder, pParam->vSampleFile[ni]->m_pString);
		nj++;

		fprintf(fpOut, "[track%d]\n", nj);
		fprintf(fpOut, "title=%s_win\n", pParam->vSampleAlias[ni]->m_pString);
		fprintf(fpOut, "type=signal\n");
		fprintf(fpOut, "src_filename=%s%s.bar\n", pParam->strExportFolder, pParam->vSampleFile[ni]->m_pString);
		nj++;
	}
	fclose(fpOut);

	/* return */
	return PROC_SUCCESS;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Diff_Main()                                                    */
/*  Detect differentially aligned regions.                                 */
/* ----------------------------------------------------------------------- */ 
int HTS_Aln2Diff_Main(char strParamPath[])
{	
	/* Sample name */
	struct tagHTSAln2WinParam *pParam = NULL;
	struct INTMATRIX *pChrLen = NULL;
	struct tagBARData *pBARData = NULL;
	int ni,nj,nk,nx,nt;
	double dCount;
	char strFileName[LONG_LINE_LENGTH];
	char strInName[MED_LINE_LENGTH];
	char strOutName[MED_LINE_LENGTH];
	char strCommand[MED_LINE_LENGTH];
	char strTemp[MED_LINE_LENGTH];
	struct INTMATRIX *pCol;
	double *vP;
	struct DOUBLEMATRIX *pCount = NULL;

	/* Load Parameters */
	pParam = HTS_Aln2Window_LoadParamter(strParamPath);
	if(pParam == NULL)
	{
		printf("Error: HTS_Aln2Diff_Main, cannot allocate memory for loading parameters!\n");
		exit(EXIT_FAILURE);
	}

	/* Load Chromosome */
	pChrLen = IMLOAD(pParam->strChrLen);
	if(pChrLen == NULL)
	{
		printf("Error: HTS_Aln2Diff_Main, cannot load chromosome length!\n");
		exit(EXIT_FAILURE);
	}

	/* prepare BAR object */
	pBARData = HTS_Aln2Diff_PrepareBARData(pParam, pChrLen);
	if(pBARData == NULL)
	{
		printf("Error: HTS_Aln2Diff_Main, cannot create bar data object!\n");
		exit(EXIT_FAILURE);
	}

	/* process data one by one */
	pCol = NULL;
	pCol = CreateIntMatrix(1,pBARData->nColNum);
	if(pCol == NULL)
	{
		printf("Error: HTS_Aln2Diff_Main, cannot create output column information!\n");
		exit(EXIT_FAILURE);
	}
	pCol->pMatElement[0] = 1;
	for(ni=0; ni<pParam->nSampleNum; ni++)
	{
		/* count */
		sprintf(strFileName, "%s%s", pParam->strDataFolder, pParam->vSampleFile[ni]->m_pString);
		dCount = 0;
		dCount = HTS_Aln2Diff_CountHits(pBARData, strFileName, pParam->nW, ni);

		/* output */
		pCol->pMatElement[1+ni] = 1;
		sprintf(strFileName, "%s%s.bar", pParam->strExportFolder, pParam->vSampleFile[ni]->m_pString);
		Affy_SaveBAR_Columns_Fast(strFileName, pBARData, pCol);
		pCol->pMatElement[1+ni] = 0;
	}
	DestroyIntMatrix(pCol);

	/* pCount = CreateDoubleMatrix(1001,1001);
	sprintf(strTemp, "%sdave_stat.txt", pParam->strExportFolder);
	for(ni=0; ni<pBARData->nSeqNum; ni++)
	{
		for(nj=0; nj<pBARData->vSeqData[ni]->nDataNum; nj++)
		{
			nx = (int)pBARData->vSeqData[ni]->vData[1]->pMatElement[nj];
			nk = nx+(int)pBARData->vSeqData[ni]->vData[2]->pMatElement[nj];

			if(nk>1000)
				nk = 1000;
			if(nx>1000)
				nx = 1000;
			nt = (int)DMGETAT(pCount, nk, nx)+1;
			DMSETAT(pCount, nk, nx, nt);
		}
	}
	DMSAVE(pCount, strTemp);
	DestroyDoubleMatrix(pCount);	
	*/

	/* estimate paramters */
	vP = NULL;
	/* vP = (double *)calloc(pParam->nSampleNum+2, sizeof(double)); */
	/* vP = (double *)calloc(2, sizeof(double)); */
	vP = (double *)calloc(9, sizeof(double)); 
	if(vP == NULL)
	{
		printf("Error: HTS_Aln2Diff_Main, cannot create vP!\n");
		exit(EXIT_FAILURE);
	}
	
	/* HTS_Aln2Diff_EstimateP(pBARData, vP, pParam->nSampleNum); */

	/* estimate prior probability */
	/* dPriorP = 0.01;
	HTS_Aln2Diff_EstimatePrior2Col(pBARData, pParam->nSampleNum, vP, &dPriorP); */
	/* HTS_Aln2Diff_EstimatePBinom(pBARData, pParam->nSampleNum, vP); */
	
	HTS_Aln2Diff_EstimateP3(pBARData, pParam->nSampleNum, vP);

	/* output */
	for(ni=0; ni<pParam->nSampleNum; ni++)
	{
		sprintf(strInName, "%s%s", pParam->strDataFolder, pParam->vSampleFile[ni]->m_pString);
		sprintf(strOutName, "%s%s.sort", pParam->strExportFolder, pParam->vSampleFile[ni]->m_pString);
		sprintf(strCommand, "tablesorter %s %s", strInName, strOutName);
		system(strCommand);
	}
	
	HTS_Aln2Diff_CallRegion(pParam, vP);
	
	/* Destroy Paramter */
	free(vP);
	HTSAln2WinParam_Destroy(&pParam);
	DestroyIntMatrix(pChrLen);
	pChrLen = NULL;
	Affy_BARData_Destroy(&pBARData);

	/* return */
	return PROC_SUCCESS;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Diff_PrepareBARData()                                          */
/*  Prepare the bar data object.                                           */
/* ----------------------------------------------------------------------- */ 
struct tagBARData * HTS_Aln2Diff_PrepareBARData(struct tagHTSAln2WinParam *pParam, 
				struct INTMATRIX *pChrLen)
{
	/* define */
	struct tagBARData *pBARData;
	int nSeqNum;
	int nColNum;
	int nDataNum;
	FILE *fpIn;
	char strLine[LONG_LINE_LENGTH];
	int ni,nj,nk;
	
	/* init */
	nSeqNum = pChrLen->nHeight;
	nColNum = pParam->nSampleNum+1;

	/* create */
	pBARData = Affy_BARData_Create();
	if(pBARData == NULL)
	{
		printf("Error: HTS_Aln2Diff_PrepareBARData, BARData object was not created!\n");
		exit(EXIT_FAILURE);
	}
	strcpy(pBARData->strMagicnumber, "barr\r\n\032\n");
	pBARData->fVersionnumber = 2.0;
    pBARData->nSeqNum = nSeqNum;
	pBARData->nColNum = nColNum;
	pBARData->nParamNum = 0;
	pBARData->vParamName = NULL;
	pBARData->vParamValue = NULL;
	pBARData->pFieldType = CreateIntMatrix(1, pBARData->nColNum);
	if(pBARData->pFieldType == NULL)
	{
		printf("Error: HTS_Aln2Diff_PrepareBARData, cannot allocate memory for field type.\n");
		exit(EXIT_FAILURE);
	}
	pBARData->pFieldType->pMatElement[0] = 2;
	for(ni=1; ni<pBARData->nColNum; ni++)
		pBARData->pFieldType->pMatElement[ni] = 1;

	pBARData->vSeqData = (struct tagBARSeq **)calloc(pBARData->nSeqNum, sizeof(struct tagBARSeq *));
	if(pBARData->vSeqData == NULL)
	{
		printf("Error: HTS_Aln2Diff_PrepareBARData, cannot allocate memory for loading sequence data.\n");
		exit(EXIT_FAILURE);
	}

	for(ni=0; ni<pBARData->nSeqNum; ni++)
	{
		/* create BARSeq object */
		pBARData->vSeqData[ni] = Affy_BARSeq_Create();
		if(pBARData->vSeqData[ni] == NULL)
		{
			printf("Error: HTS_Aln2Diff_PrepareBARData, cannot create BARSeq object.\n");
			exit(EXIT_FAILURE);
		}

		pBARData->vSeqData[ni]->pSeqGroupName = NULL;
		pBARData->vSeqData[ni]->pSeqVersion = NULL;
		pBARData->vSeqData[ni]->nParamNum = 0;
		pBARData->vSeqData[ni]->vParamName = NULL;
		pBARData->vSeqData[ni]->vParamValue = NULL;

		pBARData->vSeqData[ni]->nColNum = pBARData->nColNum;

		nDataNum = pChrLen->pMatElement[ni]/pParam->nW;
		if(pChrLen->pMatElement[ni]%pParam->nW != 0)
			nDataNum++;

		pBARData->vSeqData[ni]->nDataNum = nDataNum;
		pBARData->vSeqData[ni]->vData = (struct DOUBLEMATRIX **)calloc(pBARData->vSeqData[ni]->nColNum, sizeof(struct DOUBLEMATRIX *));
		if(pBARData->vSeqData[ni]->vData == NULL)
		{
			printf("Error: HTS_Aln2Diff_PrepareBARData, cannot allocate memory for loading bpmap coordinate data!\n");
			exit(EXIT_FAILURE);
		}
		if(pBARData->vSeqData[ni]->nDataNum > 0)
		{
			for(nj=0; nj<pBARData->vSeqData[ni]->nColNum; nj++)
			{
				pBARData->vSeqData[ni]->vData[nj] = CreateDoubleMatrix(1, pBARData->vSeqData[ni]->nDataNum );
				if(pBARData->vSeqData[ni]->vData[nj] == NULL)
				{
					printf("Error: HTS_Aln2Diff_PrepareBARData, cannot allocate memory for loading bpmap coordinate data!\n");
					exit(EXIT_FAILURE);
				}
			}
		}

		nk = pParam->nW/2;
		for(nj=0; nj<nDataNum; nj++)
		{
			pBARData->vSeqData[ni]->vData[0]->pMatElement[nj] = nk;
			nk += pParam->nW;
		}
	}

	fpIn = NULL;
	fpIn = fopen(pParam->strChrList, "r");
	if(fpIn == NULL)
	{
		printf("Error: HTS_Aln2Diff_PrepareBARData, cannot open chrlist file!\n");
		exit(EXIT_FAILURE);
	}

	ni = 0;
	while(fgets(strLine, LONG_LINE_LENGTH, fpIn) != NULL)
	{
		StrTrimLeft(strLine);
		StrTrimRight(strLine);
		if(strLine[0] == '\0')
			continue;
		if(strLine[0] == '#')
			continue;

		if(ni >= nSeqNum)
		{
			printf("Error: HTS_Aln2Diff_PrepareBARData, chromosome number wrong!\n");
			exit(EXIT_FAILURE);
		}

		StringAddTail(&(pBARData->vSeqData[ni]->pSeqName), strLine);
		ni++;
	}
	
	fclose(fpIn);

	if(ni != nSeqNum)
	{
		printf("Error: HTS_Aln2Diff_PrepareBARData, chromosome number wrong!\n");
		exit(EXIT_FAILURE);
	}

	/* return */
	return pBARData;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Diff_PrepareRecountingData()                                   */
/*  Prepare the bar data object.                                           */
/* ----------------------------------------------------------------------- */ 
struct tagBARData * HTS_Aln2Diff_PrepareRecountingData(struct tagHTSAln2WinParam *pParam, 
				struct INTMATRIX *pChrLen)
{
	/* define */
	struct tagBARData *pBARData;
	int nSeqNum;
	int nColNum;
	int nDataNum;
	FILE *fpIn;
	char strLine[LONG_LINE_LENGTH];
	int ni,nj,nk;
	
	/* init */
	nSeqNum = pChrLen->nHeight;
	nColNum = pParam->nSampleNum+2;

	/* create */
	pBARData = Affy_BARData_Create();
	if(pBARData == NULL)
	{
		printf("Error: HTS_Aln2Diff_PrepareRecountingData, BARData object was not created!\n");
		exit(EXIT_FAILURE);
	}
	strcpy(pBARData->strMagicnumber, "barr\r\n\032\n");
	pBARData->fVersionnumber = 2.0;
    pBARData->nSeqNum = nSeqNum;
	pBARData->nColNum = nColNum;
	pBARData->nParamNum = 0;
	pBARData->vParamName = NULL;
	pBARData->vParamValue = NULL;
	pBARData->pFieldType = CreateIntMatrix(1, pBARData->nColNum);
	if(pBARData->pFieldType == NULL)
	{
		printf("Error: HTS_Aln2Diff_PrepareRecountingData, cannot allocate memory for field type.\n");
		exit(EXIT_FAILURE);
	}
	pBARData->pFieldType->pMatElement[0] = 2;
	for(ni=1; ni<pBARData->nColNum; ni++)
		pBARData->pFieldType->pMatElement[ni] = 1;

	pBARData->vSeqData = (struct tagBARSeq **)calloc(pBARData->nSeqNum, sizeof(struct tagBARSeq *));
	if(pBARData->vSeqData == NULL)
	{
		printf("Error: HTS_Aln2Diff_PrepareRecountingData, cannot allocate memory for loading sequence data.\n");
		exit(EXIT_FAILURE);
	}

	for(ni=0; ni<pBARData->nSeqNum; ni++)
	{
		/* create BARSeq object */
		pBARData->vSeqData[ni] = Affy_BARSeq_Create();
		if(pBARData->vSeqData[ni] == NULL)
		{
			printf("Error: HTS_Aln2Diff_PrepareRecountingData, cannot create BARSeq object.\n");
			exit(EXIT_FAILURE);
		}

		pBARData->vSeqData[ni]->pSeqGroupName = NULL;
		pBARData->vSeqData[ni]->pSeqVersion = NULL;
		pBARData->vSeqData[ni]->nParamNum = 0;
		pBARData->vSeqData[ni]->vParamName = NULL;
		pBARData->vSeqData[ni]->vParamValue = NULL;

		pBARData->vSeqData[ni]->nColNum = pBARData->nColNum;

		nDataNum = pChrLen->pMatElement[ni]/pParam->nS;
		if(pChrLen->pMatElement[ni]%pParam->nS != 0)
			nDataNum++;

		pBARData->vSeqData[ni]->nDataNum = nDataNum;
		pBARData->vSeqData[ni]->vData = (struct DOUBLEMATRIX **)calloc(pBARData->vSeqData[ni]->nColNum, sizeof(struct DOUBLEMATRIX *));
		if(pBARData->vSeqData[ni]->vData == NULL)
		{
			printf("Error: HTS_Aln2Diff_PrepareRecountingData, cannot allocate memory for loading bpmap coordinate data!\n");
			exit(EXIT_FAILURE);
		}
		if(pBARData->vSeqData[ni]->nDataNum > 0)
		{
			for(nj=0; nj<pBARData->vSeqData[ni]->nColNum; nj++)
			{
				pBARData->vSeqData[ni]->vData[nj] = CreateDoubleMatrix(1, pBARData->vSeqData[ni]->nDataNum );
				if(pBARData->vSeqData[ni]->vData[nj] == NULL)
				{
					printf("Error: HTS_Aln2Diff_PrepareRecountingData, cannot allocate memory for loading bpmap coordinate data!\n");
					exit(EXIT_FAILURE);
				}
			}
		}

		nk = pParam->nS/2;
		for(nj=0; nj<nDataNum; nj++)
		{
			pBARData->vSeqData[ni]->vData[0]->pMatElement[nj] = nk;
			nk += pParam->nS;
		}
	}

	fpIn = NULL;
	fpIn = fopen(pParam->strChrList, "r");
	if(fpIn == NULL)
	{
		printf("Error: HTS_Aln2Diff_PrepareRecountingData, cannot open chrlist file!\n");
		exit(EXIT_FAILURE);
	}

	ni = 0;
	while(fgets(strLine, LONG_LINE_LENGTH, fpIn) != NULL)
	{
		StrTrimLeft(strLine);
		StrTrimRight(strLine);
		if(strLine[0] == '\0')
			continue;
		if(strLine[0] == '#')
			continue;

		if(ni >= nSeqNum)
		{
			printf("Error: HTS_Aln2Diff_PrepareRecountingData, chromosome number wrong!\n");
			exit(EXIT_FAILURE);
		}

		StringAddTail(&(pBARData->vSeqData[ni]->pSeqName), strLine);
		ni++;
	}
	
	fclose(fpIn);

	if(ni != nSeqNum)
	{
		printf("Error: HTS_Aln2Diff_PrepareRecountingData, chromosome number wrong!\n");
		exit(EXIT_FAILURE);
	}

	/* return */
	return pBARData;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Diff_CountHits()                                               */
/*  Count hits in each window.                                             */
/* ----------------------------------------------------------------------- */ 
double HTS_Aln2Diff_CountHits(struct tagBARData *pBARData, char strInFile[], int nW, int nSampleID)
{
	/* define */
	FILE *fpIn = NULL;
	char strLine[LONG_LINE_LENGTH];
	char strChr[MED_LINE_LENGTH];
	int nPos,nId;
	int ni;
	double dCount = 0.0;
	int nCol;

	/* open file */
	nCol = nSampleID+1;

	fpIn = fopen(strInFile, "r");
	if(fpIn == NULL)
	{
		printf("Error: HTS_Aln2Diff_CountHits, cannot open input file!\n");
		exit(EXIT_FAILURE);
	}

	while(fgets(strLine, LONG_LINE_LENGTH, fpIn) != NULL)
	{
		StrTrimLeft(strLine);
		StrTrimRight(strLine);
		if(strLine[0] == '\0')
			continue;
		if(strLine[0] == '#')
			continue;

		sscanf(strLine, "%s %d", strChr, &nPos);
		for(ni=0; ni<pBARData->nSeqNum; ni++)
		{
			if(strcmp(strChr, pBARData->vSeqData[ni]->pSeqName->m_pString) == 0)
			{
				nId = nPos/nW;
				if(nId < pBARData->vSeqData[ni]->nDataNum)
				{
					pBARData->vSeqData[ni]->vData[nCol]->pMatElement[nId] += 1;
					dCount += 1.0;
				}
				break;
			}
		}
	}


	/* close file */
	fclose(fpIn);

	/* return */ 
	return dCount;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Diff_EstimateP()                                               */
/*  Estimate hyperparameter.                                               */
/* ----------------------------------------------------------------------- */ 
int HTS_Aln2Diff_EstimateP(struct tagBARData *pBARData, double *vP, int nSampleNum)
{
	int ni,nj,nk;
	double *vM = NULL;
	double *vV = NULL;

	double dM = 0.0;
	double dV = 0.0;
	double dTotalC = 0.0;
	double dA,dB;
	double dSum = 0.0;

	vM = (double *)calloc(nSampleNum, sizeof(double));
	vV = (double *)calloc(nSampleNum, sizeof(double));

	if(vM == NULL || vV == NULL)
	{
		printf("Error: HTS_Aln2Diff_EstimateP, cannot estimate parameter!\n");
		exit(EXIT_FAILURE);
	}

	for(ni=0; ni<pBARData->nSeqNum; ni++)
	{
		dTotalC += pBARData->vSeqData[ni]->nDataNum;
		for(nk=1; nk<=nSampleNum; nk++)
		{
			for(nj=0; nj<pBARData->vSeqData[ni]->nDataNum; nj++)
			{
				vM[nk-1] += pBARData->vSeqData[ni]->vData[nk]->pMatElement[nj];
			}
		}
	}
	for(nk=0; nk<nSampleNum; nk++)
	{
		vM[nk] /= dTotalC;
	}

	for(ni=0; ni<pBARData->nSeqNum; ni++)
	{
		for(nk=1; nk<=nSampleNum; nk++)
		{
			for(nj=0; nj<pBARData->vSeqData[ni]->nDataNum; nj++)
			{
				vV[nk-1] += (pBARData->vSeqData[ni]->vData[nk]->pMatElement[nj]-vM[nk-1])*(pBARData->vSeqData[ni]->vData[nk]->pMatElement[nj]-vM[nk-1]);
			}
		}
	}
	for(nk=0; nk<nSampleNum; nk++)
	{
		vV[nk] /= (dTotalC-1.0);
	}

	dA = 0.0;
	for(nk=0; nk<nSampleNum; nk++)
	{
		vP[nk] = vM[nk]*vM[nk]/(vV[nk]-vM[nk]);
		dA += vP[nk];
	}
	dA /= nSampleNum;

	dB = 0.0;
	for(nk=0; nk<nSampleNum; nk++)
	{
		dB += (vP[nk]-dA)*(vP[nk]-dA);
	}
	dB = sqrt(dB/(nSampleNum-1.0));

	printf("NegBin CV(alpha) = %f\n", dB/dA);
	if(dB/dA > 0.1)
	{
		printf("Warning: when NegBin CV(alpha) > 0.1, the model assumptions used here may not hold!\n");
	}

	vP[nSampleNum] = dA;
	for(nk=0; nk<nSampleNum; nk++)
	{
		vP[nk] = vP[nSampleNum]/vM[nk];
	}
	vP[nSampleNum+1] = vP[0];
	for(nk=0; nk<nSampleNum; nk++)
	{
		vP[nk] = vP[nSampleNum+1]/vP[nk];
	}

	free(vM);
	free(vV);

	return PROC_SUCCESS;
}


/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Diff_EstimatePrior2Col()                                       */
/*  Estimate prior probability of difference                               */
/* ----------------------------------------------------------------------- */ 
int HTS_Aln2Diff_EstimatePrior2Col(struct tagBARData *pBARData, int nSampleNum, 
								   double *vP, double *dPriorP)
{
	/* define */
	double dL0,dL1;
	int ni,nj;
	double vC[2];
	double dX,dY,dT,dT1,dT2;
	double dA,dB;
	double dTemp = *dPriorP;

	*dPriorP = dTemp/2;

	while( fabs(dTemp-(*dPriorP))/(*dPriorP) > 0.01 )
	{
		*dPriorP = dTemp;

		for(ni=0; ni<2; ni++)
			vC[ni] = 0.0;

		for(ni=0; ni<pBARData->nSeqNum; ni++)
		{
			for(nj=0; nj<pBARData->vSeqData[ni]->nDataNum; nj++)
			{
				dA = vP[nSampleNum];
				dB = vP[nSampleNum+1];

				dX = pBARData->vSeqData[ni]->vData[1]->pMatElement[nj];
				dY = pBARData->vSeqData[ni]->vData[2]->pMatElement[nj];

				dT = vP[0]+vP[1]+dB;

				dL0 = gammaln(dX+dY+dA)-gammaln(dA)-gammaln(dX+1.0)-gammaln(dY+1.0)
					+dA*log(dB/dT)+dX*log(vP[0]/dT)+dY*log(vP[1]/dT);

				dT1 = vP[0]+dB;
				dT2 = vP[1]+dB;
				dL1 = gammaln(dX+dA)-gammaln(dA)-gammaln(dX+1.0)+dA*log(dB/dT1)+dX*log(vP[0]/dT1)
					+gammaln(dY+dA)-gammaln(dA)-gammaln(dY+1.0)+dA*log(dB/dT2)+dY*log(vP[1]/dT2);

				dTemp = (1-(*dPriorP))*exp(dL0-dL1)/(*dPriorP);
				dTemp = 1.0/(1.0+dTemp);
				vC[1] += dTemp;
				vC[0] += 1.0-dTemp;
			}
		}

		dTemp = vC[1]/(vC[1]+vC[0]);
	}

	/* return */
	return PROC_SUCCESS;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Diff_EstimatePBinom()                                          */
/*  Estimate hyperparamter for mixture binominal                           */
/* ----------------------------------------------------------------------- */ 
int HTS_Aln2Diff_EstimatePBinom(struct tagBARData *pBARData, int nSampleNum, 
								   double *vP)
{
	/* define */
	double dL0,dL1;
	int ni,nj;
	double vC[2];
	double dX,dY;
	double dA,dB;
	double dTemp;
	double dTotal;

	vC[0] = 0.01;
	vC[1] = 0.0;
	
	dA = 0.0;
	dB = 0.0;
	dTotal = 0.0;
	for(ni=0; ni<pBARData->nSeqNum; ni++)
	{
		dTotal += pBARData->vSeqData[ni]->nDataNum;
		for(nj=0; nj<pBARData->vSeqData[ni]->nDataNum; nj++)
		{
			dA += pBARData->vSeqData[ni]->vData[1]->pMatElement[nj];
			dB += pBARData->vSeqData[ni]->vData[2]->pMatElement[nj];		
		}
	}

	vC[1] = dA/(dA+dB);
	vP[0] = vC[0]/2.0;
	vP[1] = vC[1]/2.0;

	while( (fabs(vC[0]-vP[0])/vP[0]>0.01) || (fabs(vC[1]-vP[1])/vP[1]>0.01) )
	{
		for(ni=0; ni<2; ni++)
		{
			vP[ni] = vC[ni];
			vC[ni] = 0.0;
		}

			
		dA = 0.0;
		dB = 0.0;
		for(ni=0; ni<pBARData->nSeqNum; ni++)
		{
			for(nj=0; nj<pBARData->vSeqData[ni]->nDataNum; nj++)
			{
				dX = pBARData->vSeqData[ni]->vData[1]->pMatElement[nj];
				dY = pBARData->vSeqData[ni]->vData[2]->pMatElement[nj];

				dL0 = log(1.0-vP[0])+gammaln(dX+dY+1.0)-gammaln(dX+1.0)-gammaln(dY+1.0)+dX*log(vP[1])+dY*log(1.0-vP[1]);

				dL1 = log(vP[0])-log(dX+dY+1.0);

				dTemp = exp(dL0-dL1);
				dTemp = 1.0/(1.0+dTemp);
				vC[0] += dTemp;
				dA += (1.0-dTemp)*dX;
				dB += (1.0-dTemp)*dY;
			}
		}

		vC[0] /= dTotal;
		vC[1] = dA/(dA+dB);
	}

	/* return */
	return PROC_SUCCESS;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Diff_EstimateP3()                                              */
/*  Estimate hyperparamter for mixture binominal                           */
/* ----------------------------------------------------------------------- */ 
int HTS_Aln2Diff_EstimateP3(struct tagBARData *pBARData, int nSampleNum, 
								   double *vP)
{
	/* define */
	int nMinC = 2;
	int nParamNum = 9;
	double vC[9];
	double vBackUp[9];
	double dQ0,dQ1,dQ2;
	double dLam0,dLam1,dPro0,dPro1;
	double dBetaP;
	double dL0,dL1,dL2;
	int ni,nj,nk;
	double dX,dY,dN;
	double dA,dB,dC,dD;
	double dTemp,dTemp2;
	double dTotal;
	double dError;
	double logBetaP, logBetaPC;
	double logPi0, logPi1, logPi2, logP0, logP0C, logLambda, logGab, logGn;
	double logGam;
	double dLMax;
	int nMaxIter = 20;
	int nIter;
	double dLike0,dLike1;
	double logGalpha0,logGalpha;
	double dM1Lam,dM2Lam,dM1Beta,dM2Beta,dMTBeta;
	struct DOUBLEMATRIX *pDQ0,*pDQ1,*pDQ2,*pDLike;
	int nDQSIZE;
	double vSumDist[256];
	int nTestParameter = 0;
	int nSuppressDisplay = 0;
	char strFileName[255];
	FILE *fpOut;


	vC[0] = 0.98; /* pi_0 */
	vC[1] = 0.01; /* pi_1 */
	vC[2] = 0.01; /* pi_2 */
	vC[3] = 0.05; /* lambda_0 */
	vC[4] = 0.5; /* p_0 */
	vC[5] = 0.05; /* beta */
	vC[6] = 1.0; /* alpha */
	vC[7] = 1.0; /* a */
	vC[8] = 1.0; /* b */

	nDQSIZE = 21;
	pDQ0 = NULL;
	pDQ0 = CreateDoubleMatrix(nDQSIZE,nDQSIZE);
	pDQ1 = NULL;
	pDQ1 = CreateDoubleMatrix(nDQSIZE,nDQSIZE);
	pDQ2 = NULL;
	pDQ2 = CreateDoubleMatrix(nDQSIZE,nDQSIZE);
	pDLike = NULL;
	pDLike = CreateDoubleMatrix(nDQSIZE,nDQSIZE);
	if( (pDQ0 == NULL) || (pDQ1 == NULL) || (pDQ2 == NULL) || (pDLike == NULL) )
	{
		printf("Error: cannot create Q database!\n");
		exit(EXIT_FAILURE);
	}

	for(ni=0; ni<256; ni++)
	{
		vSumDist[ni] = 0.0;
	}

	dA = 0.0;
	dB = 0.0;
	dC = 0.0;
	dD = 0.0;
	dTotal = 0.0;
	for(ni=0; ni<pBARData->nSeqNum; ni++)
	{
		dTotal += pBARData->vSeqData[ni]->nDataNum;
		for(nj=0; nj<pBARData->vSeqData[ni]->nDataNum; nj++)
		{
			dA += pBARData->vSeqData[ni]->vData[1]->pMatElement[nj];
			dB += pBARData->vSeqData[ni]->vData[2]->pMatElement[nj];
			nk = (int)(pBARData->vSeqData[ni]->vData[1]->pMatElement[nj]+pBARData->vSeqData[ni]->vData[2]->pMatElement[nj]);
			if(nk > 255)
				nk = 255;
			vSumDist[nk] += 1;
			if(nk >= nMinC)
			{
				dC += nk;
				dD += 1.0;
			}
		}
	}

	vC[3] = (dA+dB)/dTotal;
	if((double)nMinC < vC[3])
	{
		nMinC = (int)(vC[3])+2;
	}
	vC[4] = dA/(dA+dB);
	dC /= dD;
	if(dC < nMinC)
		dC = nMinC+1;
	vC[5] = 1/(2.0*dC);
	dD = vC[3];

	dTemp = 0.0;
	for(nk=0; nk<256; nk++)
	{
		dTemp += vSumDist[nk];
	}
	for(nk=0; nk<256; nk++)
	{
		vSumDist[nk] /= dTemp;
	}
	strcpy(strFileName, "wincount_summary.txt");
	fpOut = fopen(strFileName, "w");
	if(fpOut == NULL)
	{
		printf("Error: cannot open output file!\n");
		exit(EXIT_FAILURE);
	}
	for(nk=0; nk<256; nk++)
	{
		fprintf(fpOut, "%f\n", vSumDist[nk]);
	}
	fclose(fpOut);

	for(ni=0; ni<nParamNum; ni++)
	{
		vP[ni] = vC[ni]/2.0;
	}
	dError = 1.0;

	dLike0 = -1e20;
	dLike1 = -1e20;
	nIter = 0;
	nTestParameter = 0;
	while( dError > 0.01 )
	{
		if(nIter%10 == 0)
		{
			if(nSuppressDisplay == 1)
			{
				nSuppressDisplay = 0;
			}
			else
			{
				printf("EM iteration %d ...\n", nIter);
			}
		}

		if(nTestParameter == 1)
		{
			for(ni=0; ni<5; ni++)
			{
				vBackUp[ni] = vC[ni];
				vP[ni] = vC[ni];
				vC[ni] = 0.0;
			}
			for(; ni<nParamNum; ni++)
			{
				vBackUp[ni] = vP[ni];
				vP[ni] = vC[ni];
				vC[ni] = 0.0;
			}
		}
		else
		{
			for(ni=0; ni<nParamNum; ni++)
			{
				vP[ni] = vC[ni];
				vC[ni] = 0.0;
			}
		}

		dA = 0.0;
		dB = 0.0;
		dLam0 = 0.0;
		dLam1 = 0.0;
		dPro0 = 0.0;
		dPro1 = 0.0;
		dLike0 = dLike1;
		dLike1 = 0.0;
		dM1Lam = 0.0;
		dM2Lam = 0.0;
		dM1Beta = 0.0;
		dM2Beta = 0.0;
		dMTBeta = 0.0;

		logPi0 = log(vP[0]);
		logPi1 = log(vP[1]);
		logPi2 = log(vP[2]);

		logLambda = log(vP[3]);

		logP0 = log(vP[4]);
		logP0C = log(1.0-vP[4]);
		
		dBetaP = 1.0/(1.0+vP[5]);
		logBetaP = log(dBetaP);
		logBetaPC = log(1.0-dBetaP);

		logGab = gammaln(vP[7]+vP[8])-gammaln(vP[7])-gammaln(vP[8]);
		logGalpha0 = gammaln(vP[6]);
			

		for(ni=0; ni<nDQSIZE; ni++)
		{
			for(nj=0; nj<nDQSIZE; nj++)
			{
				dX = ni;
				dY = nj;
				dN = dX+dY;
			
				if((int)dN < nMinC)
				{
					logGam = gammaln(dX+1.0)+gammaln(dY+1.0);
					dL0 = logPi0+dN*logLambda-vP[3]+dX*logP0+dY*logP0C-logGam;
					dQ0 = 1.0;
					dQ1 = 0.0;
					dQ2 = 0.0;
					DMSETAT(pDQ0, ni, nj, dQ0);
					DMSETAT(pDQ1, ni, nj, dQ1);
					DMSETAT(pDQ2, ni, nj, dQ2);
					DMSETAT(pDLike, ni, nj, dL0);
				}
				else
				{
					logGam = gammaln(dX+1.0)+gammaln(dY+1.0);
					logGalpha = gammaln(dN+vP[6]-nMinC);
					logGn = 0.0;
					for(nk=0; nk<nMinC; nk++)
						logGn += log(dN-nk);

					dL0 = logPi0+dN*logLambda-vP[3]+dX*logP0+dY*logP0C-logGam;
					dLMax = dL0;

					dL1 = logPi1+logGalpha-logGalpha0+vP[6]*logBetaPC+(dN-nMinC)*logBetaP+dX*logP0+dY*logP0C-logGam+logGn;
					if(dL1 > dLMax)
						dLMax = dL1;

					dL2 = logPi2+logGalpha-logGalpha0+vP[6]*logBetaPC+(dN-nMinC)*logBetaP+logGab-logGam+logGn+gammaln(dX+vP[7])+gammaln(dY+vP[8])-gammaln(dN+vP[7]+vP[8]);
					if(dL2 > dLMax)
						dLMax = dL2;

					dL0 -= dLMax;
					dL1 -= dLMax;
					dL2 -= dLMax;

					dL0 = exp(dL0);
					dL1 = exp(dL1);
					dL2 = exp(dL2);
					dTemp = dL0+dL1+dL2;
					dQ0 = dL0/dTemp;
					dQ1 = dL1/dTemp;
					dQ2 = dL2/dTemp;

					DMSETAT(pDQ0, ni, nj, dQ0);
					DMSETAT(pDQ1, ni, nj, dQ1);
					DMSETAT(pDQ2, ni, nj, dQ2);
					dTemp = dLMax+log(dTemp);
					DMSETAT(pDLike, ni, nj, dTemp);
				}
			}
		}

		for(ni=0; ni<pBARData->nSeqNum; ni++)
		{
			for(nj=0; nj<pBARData->vSeqData[ni]->nDataNum; nj++)
			{
				dX = pBARData->vSeqData[ni]->vData[1]->pMatElement[nj];
				dY = pBARData->vSeqData[ni]->vData[2]->pMatElement[nj];
				dN = dX+dY;

				if( ((int)dX<nDQSIZE) && ((int)dY<nDQSIZE) )
				{
					dQ0 = DMGETAT(pDQ0, (int)dX, (int)dY);
					dQ1 = DMGETAT(pDQ1, (int)dX, (int)dY);
					dQ2 = DMGETAT(pDQ2, (int)dX, (int)dY);
					dLike1 += DMGETAT(pDLike, (int)dX, (int)dY);
				}
				else
				{
					logGam = gammaln(dX+1.0)+gammaln(dY+1.0);
					logGalpha = gammaln(dN+vP[6]-nMinC);
					logGn = 0.0;
					for(nk=0; nk<nMinC; nk++)
						logGn += log(dN-nk);

					dL0 = logPi0+dN*logLambda-vP[3]+dX*logP0+dY*logP0C-logGam;
					dLMax = dL0;

					dL1 = logPi1+logGalpha-logGalpha0+vP[6]*logBetaPC+(dN-nMinC)*logBetaP+dX*logP0+dY*logP0C-logGam+logGn;
					if(dL1 > dLMax)
						dLMax = dL1;

					dL2 = logPi2+logGalpha-logGalpha0+vP[6]*logBetaPC+(dN-nMinC)*logBetaP+logGab-logGam+logGn+gammaln(dX+vP[7])+gammaln(dY+vP[8])-gammaln(dN+vP[7]+vP[8]);
					if(dL2 > dLMax)
						dLMax = dL2;

					dL0 -= dLMax;
					dL1 -= dLMax;
					dL2 -= dLMax;

					dL0 = exp(dL0);
					dL1 = exp(dL1);
					dL2 = exp(dL2);
					dTemp = dL0+dL1+dL2;
					dQ0 = dL0/dTemp;
					dQ1 = dL1/dTemp;
					dQ2 = dL2/dTemp;

					dLike1 += dLMax+log(dTemp);
				}

				vC[0] += dQ0;
				vC[1] += dQ1;
				vC[2] += dQ2;

				dLam0 += dQ0;
				dLam1 += dQ0*dN;

				dPro0 += (dQ0+dQ1)*dN;
				dPro1 += (dQ0+dQ1)*dX;

				dA += (dQ1+dQ2);
				dB += (dQ1+dQ2)*dN;

				dM1Lam += (dQ1+dQ2)*dN;
				dM2Lam += (dQ1+dQ2)*dN*dN;
				/* if(dN > 0.5)
				{ */
					dTemp = (dX+vP[7])/(dN+vP[7]+vP[8]);
					dM1Beta += dQ2*dTemp;
					dM2Beta += dQ2*dTemp*dTemp;
					dMTBeta += dQ2;
				/* } */
			}
		}

		dM1Lam /= dA;
		dM2Lam /= dA;
		dM1Beta /= dMTBeta;
		dM2Beta /= dMTBeta;

		if(nTestParameter == 1)
		{
			nTestParameter = 0;
			if(dLike1 < dLike0)
			{
				dLike1 = dLike0;
				for(nk=0; nk<nParamNum; nk++)
				{
					vC[nk] = vBackUp[nk];
				}
				dError = 1.0;
				nSuppressDisplay = 1;
				continue;
			}
		}

		dTotal = vC[0]+vC[1]+vC[2];
		vC[0] /= dTotal;
		vC[1] /= dTotal;
		vC[2] /= dTotal;
		vC[3] = dLam1/dLam0;
		if(vC[3] > dD)
			vC[3] = dD;

		/* vC[4] = vP[4]; */
		vC[4] = dPro1/dPro0;
		/* vC[5] = dA/dB;
		if(vC[5] > 1.0)
			vC[5] = 1.0; */
		vC[5] = vP[5];
		vC[6] = vP[6];
		vC[7] = vP[7];
		vC[8] = vP[8];

		if(dLike1 < dLike0)
		{
			printf("Warning: likelihood decreasing!\n");
			/* break; */
		}

		dError = 0.0;
		for(ni=0; ni<nParamNum; ni++)
		{
			dTemp = fabs(vC[ni]-vP[ni])/vP[ni];
			if(dTemp > dError)
				dError = dTemp;
		}

		
		nIter++;

		if(nIter%5 == 0)
		{
			if(nIter%10 == 0)
			{
				dTemp2 = dM1Beta*dM1Beta*(1.0-dM1Beta)/(dM2Beta-dM1Beta*dM1Beta)-dM1Beta;
				if( dTemp2 > 0.0 )
				{
					vC[7] = dTemp2;
					vC[8] = (1.0-dM1Beta)*vC[7]/dM1Beta;
				}
			}
			else
			{
				dTemp = dM1Lam/(dM2Lam-dM1Lam*dM1Lam-dM1Lam);
				
				if(dM1Lam >= dC)
				{
					if( dTemp > 0.0 )
					{
						vC[5] = dTemp;
						vC[6] = dM1Lam*vC[5];
					}
				}
			}

			nTestParameter = 1;
		}

		if(nIter >= nMaxIter)
			break;
	}


	DestroyDoubleMatrix(pDQ0);
	DestroyDoubleMatrix(pDQ1);
	DestroyDoubleMatrix(pDQ2);
	DestroyDoubleMatrix(pDLike);

	printf("Estimated Parameters [Relative Error]:\n");
	printf("pi_0 = %f [%f%%]\n", vP[0], 100.0*fabs(vC[0]-vP[0])/vP[0]);
	printf("pi_1 = %f [%f%%]\n", vP[1], 100.0*fabs(vC[1]-vP[1])/vP[1]);
	printf("pi_2 = %f [%f%%]\n", vP[2], 100.0*fabs(vC[2]-vP[2])/vP[2]);
	printf("lambda_0 = %f [%f%%]\n", vP[3], 100.0*fabs(vC[3]-vP[3])/vP[3]);
	printf("p_0 = %f [%f%%]\n", vP[4], 100.0*fabs(vC[4]-vP[4])/vP[4]);
	printf("alpha = %f [%f%%]\n", vP[6], 100.0*fabs(vC[6]-vP[6])/vP[6]);
	printf("beta = %f [%f%%]\n", vP[5], 100.0*fabs(vC[5]-vP[5])/vP[5]);
	printf("a = %f [%f%%]\n", vP[7], 100.0*fabs(vC[7]-vP[7])/vP[7]);
	printf("b = %f [%f%%]\n", vP[8], 100.0*fabs(vC[8]-vP[8])/vP[8]);

	/* return */
	return PROC_SUCCESS;
}


/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Diff_CallRegion()                                              */
/*  Call differentially expressed regions.                                 */
/* ----------------------------------------------------------------------- */ 
int HTS_Aln2Diff_CallRegion(struct tagHTSAln2WinParam *pParam, double *vP)
{
	/* define */
	FILE *vfpIn[2];
	FILE *fpOut;
	int ni,nj,nk;
	char strFileName[MED_LINE_LENGTH];
	char strOutFileName[MED_LINE_LENGTH];
	char strLine[LONG_LINE_LENGTH];
	char strChr1[LINE_LENGTH];
	char strChr2[LINE_LENGTH];
	char strChr[LINE_LENGTH];
	int nW1,nW2;
	int nR1,nR2;
	int nPos1,nPos2;
	int nX,nY;
	int nl,nu;
	int nStrCmpR;
	int nFile1End,nFile2End;
	struct tagBARData *pBARData;
	int nWrite1;
	int nStart,nEnd;

	int nMinC = 2;
	int nParamNum = 9;
	double dQ0,dQ1,dQ2;
	double dLam0,dLam1,dPro0,dPro1;
	double dBetaP;
	double dL0,dL1,dL2;
	double dX,dY,dN;
	double dA,dB,dC,dD;
	double dTemp,dTemp2;
	double dTotal;
	double logBetaP, logBetaPC;
	double logPi0, logPi1, logPi2, logP0, logP0C, logLambda, logGab, logGn;
	double logGam;
	double dLMax;
	double dLike0,dLike1;
	double logGalpha0,logGalpha;
	struct DOUBLEMATRIX *pDQ0,*pDQ1,*pDQ2;
	int nDQSIZE = 21;
	double dMaxQ = 0.0;
	double dMaxR = 0.0;
	int nMaxX = 0;
	int nMaxY = 0;
	int nRID = 0;

	/* prepare display file */
	for(ni=0; ni<2; ni++)
	{
		vfpIn[ni] = NULL;
		sprintf(strFileName, "%s%s.sort", pParam->strExportFolder, pParam->vSampleFile[ni]->m_pString);
		vfpIn[ni] = fopen(strFileName, "r");
		if(vfpIn[ni] == NULL)
		{
			printf("Error: HTS_Aln2Diff_CallRegion, cannot open input file!\n");
			exit(EXIT_FAILURE);
		}

		fpOut = NULL;
		sprintf(strFileName, "%s%s.sortm", pParam->strExportFolder, pParam->vSampleFile[ni]->m_pString);
		fpOut = fopen(strFileName, "w");
		if(fpOut == NULL)
		{
			printf("Error: HTS_Aln2Diff_CallRegion, cannot open output file!\n");
			exit(EXIT_FAILURE);
		}

		fprintf(fpOut, "#chr\tpos\t%s.raw\n", pParam->vSampleFile[ni]->m_pString);
		fprintf(fpOut, "#chr\tpos\t1\n");

		strcpy(strChr2, "");
		nPos2 = -1;
		dX = 0.0;
		while(fgets(strLine, LONG_LINE_LENGTH, vfpIn[ni]) != NULL)
		{
			StrTrimLeft(strLine);
			StrTrimRight(strLine);
			if(strLine[0] == '\0')
				continue;
			if(strLine[0] == '#')
				continue;

			sscanf(strLine, "%s %d", strChr1, &nPos1);
			if( (strcmp(strChr1, strChr2) == 0) && (nPos1 == nPos2) )
			{
				dX += 1.0;
			}
			else
			{
				if(strcmp(strChr2, "") != 0)
				{
					fprintf(fpOut, "%s\t%d\t%f\n", strChr2, nPos2, dX);
				}
				strcpy(strChr2, strChr1);
				nPos2 = nPos1;
				dX = 1.0;
			}
		}

		if(strcmp(strChr2, "") != 0)
		{
			fprintf(fpOut, "%s\t%d\t%f\n", strChr2, nPos2, dX);
		}

		fclose(vfpIn[ni]);
		fclose(fpOut);

		sprintf(strOutFileName, "%s_raw.cgw", pParam->vSampleFile[ni]->m_pString);
		TileMapv2_TXT2BAR(strFileName, pParam->strExportFolder, strOutFileName);
	}

	/* open files */
	for(ni=0; ni<2; ni++)
	{
		vfpIn[ni] = NULL;
		sprintf(strFileName, "%s%s.sort", pParam->strExportFolder, pParam->vSampleFile[ni]->m_pString);
		vfpIn[ni] = fopen(strFileName, "r");
		if(vfpIn[ni] == NULL)
		{
			printf("Error: HTS_Aln2Diff_CallRegion, cannot open input file!\n");
			exit(EXIT_FAILURE);
		}
	}

	fpOut = NULL;
	sprintf(strFileName, "%s%s.cod", pParam->strExportFolder, pParam->strProjectName);
	fpOut = fopen(strFileName, "w");
	if(fpOut == NULL)
	{
		printf("Error: HTS_Aln2Diff_CallRegion, cannot open output file!\n");
		exit(EXIT_FAILURE);
	}

	fprintf(fpOut, "#chr\tpos\t%s_raw\n", pParam->strProjectName);
	fprintf(fpOut, "#chr\tpos\t1\n");

	/* load file */
	nFile1End = 1;
	while(fgets(strLine, LONG_LINE_LENGTH, vfpIn[0]) != NULL)
	{
		StrTrimLeft(strLine);
		StrTrimRight(strLine);
		if(strLine[0] == '\0')
			continue;
		if(strLine[0] == '#')
			continue;

		sscanf(strLine, "%s %d", strChr1, &nPos1);
		nFile1End = 0;
		break;
	}

	nFile2End = 1;
	while(fgets(strLine, LONG_LINE_LENGTH, vfpIn[1]) != NULL)
	{
		StrTrimLeft(strLine);
		StrTrimRight(strLine);
		if(strLine[0] == '\0')
			continue;
		if(strLine[0] == '#')
			continue;

		sscanf(strLine, "%s %d", strChr2, &nPos2);
		nFile2End = 0;
		break;
	}

	while( (nFile1End == 0) || (nFile2End == 0) )
	{
		if(nFile1End == 1)
		{
			fprintf(fpOut, "%s\t%d\t-1\n", strChr2, nPos2);
			while(fgets(strLine, LONG_LINE_LENGTH, vfpIn[1]) != NULL)
			{
				StrTrimLeft(strLine);
				StrTrimRight(strLine);
				if(strLine[0] == '\0')
					continue;
				if(strLine[0] == '#')
					continue;

				sscanf(strLine, "%s %d", strChr2, &nPos2);
				fprintf(fpOut, "%s\t%d\t-1\n", strChr2, nPos2);
			}
			nFile2End = 1;
		}
		else if(nFile2End == 1)
		{
			fprintf(fpOut, "%s\t%d\t1\n", strChr1, nPos1);
			while(fgets(strLine, LONG_LINE_LENGTH, vfpIn[0]) != NULL)
			{
				StrTrimLeft(strLine);
				StrTrimRight(strLine);
				if(strLine[0] == '\0')
					continue;
				if(strLine[0] == '#')
					continue;

				sscanf(strLine, "%s %d", strChr1, &nPos1);
				fprintf(fpOut, "%s\t%d\t1\n", strChr1, nPos1);
			}
			nFile1End = 1;
		}
		else
		{
			nStrCmpR = strcmp(strChr1, strChr2);
			if(nStrCmpR < 0)
			{
				nWrite1 = 1;
			}
			else if(nStrCmpR == 0 && nPos1 <= nPos2)
			{
				nWrite1 = 1;
			}
			else
			{
				nWrite1 = 0;
			}

			if(nWrite1 == 1)
			{
				fprintf(fpOut, "%s\t%d\t1\n", strChr1, nPos1);
				nFile1End = 1;
				while(fgets(strLine, LONG_LINE_LENGTH, vfpIn[0]) != NULL)
				{
					StrTrimLeft(strLine);
					StrTrimRight(strLine);
					if(strLine[0] == '\0')
						continue;
					if(strLine[0] == '#')
						continue;

					sscanf(strLine, "%s %d", strChr1, &nPos1);
					nFile1End = 0;
					break;
				}
			}
			else
			{
				fprintf(fpOut, "%s\t%d\t-1\n", strChr2, nPos2);
				nFile2End = 1;
				while(fgets(strLine, LONG_LINE_LENGTH, vfpIn[1]) != NULL)
				{
					StrTrimLeft(strLine);
					StrTrimRight(strLine);
					if(strLine[0] == '\0')
						continue;
					if(strLine[0] == '#')
						continue;

					sscanf(strLine, "%s %d", strChr2, &nPos2);
					nFile2End = 0;
					break;
				}
			}

		}
	}

	/* close files */
	for(ni=0; ni<2; ni++)
		fclose(vfpIn[ni]);
	fclose(fpOut);


	/* convert txt to bar */
	sprintf(strOutFileName, "%s_raw.cgw", pParam->strProjectName);
	TileMapv2_TXT2BAR(strFileName, pParam->strExportFolder, strOutFileName);
	sprintf(strOutFileName, "%s%s_raw.bar", pParam->strExportFolder, pParam->strProjectName);
	pBARData = NULL;
	pBARData = Affy_LoadBAR_Fast(strOutFileName);
	if(pBARData == NULL)
	{
		printf("Error: cannot load bar data!\n");
		exit(EXIT_FAILURE);
	}

	fpOut = NULL;
	sprintf(strFileName, "%s%s.cod", pParam->strExportFolder, pParam->strProjectName);
	fpOut = fopen(strFileName, "w");
	if(fpOut == NULL)
	{
		printf("Error: HTS_Aln2Diff_CallRegion, cannot open output file!\n");
		exit(EXIT_FAILURE);
	}

	pDQ0 = NULL;
	pDQ0 = CreateDoubleMatrix(nDQSIZE,nDQSIZE);
	pDQ1 = NULL;
	pDQ1 = CreateDoubleMatrix(nDQSIZE,nDQSIZE);
	pDQ2 = NULL;
	pDQ2 = CreateDoubleMatrix(nDQSIZE,nDQSIZE);
	if( (pDQ0 == NULL) || (pDQ1 == NULL) || (pDQ2 == NULL) )
	{
		printf("Error: cannot create Q database!\n");
		exit(EXIT_FAILURE);
	}

	logPi0 = log(vP[0]);
	logPi1 = log(vP[1]);
	logPi2 = log(vP[2]);

	logLambda = log(vP[3]);

	logP0 = log(vP[4]);
	logP0C = log(1.0-vP[4]);
	
	dBetaP = 1.0/(1.0+vP[5]);
	logBetaP = log(dBetaP);
	logBetaPC = log(1.0-dBetaP);

	logGab = gammaln(vP[7]+vP[8])-gammaln(vP[7])-gammaln(vP[8]);
	logGalpha0 = gammaln(vP[6]);
		

	for(ni=0; ni<nDQSIZE; ni++)
	{
		for(nj=0; nj<nDQSIZE; nj++)
		{
			dX = ni;
			dY = nj;
			dN = dX+dY;
		
			if((int)dN < nMinC)
			{
				logGam = gammaln(dX+1.0)+gammaln(dY+1.0);
				dL0 = logPi0+dN*logLambda-vP[3]+dX*logP0+dY*logP0C-logGam;
				dQ0 = 1.0;
				dQ1 = 0.0;
				dQ2 = 0.0;
				DMSETAT(pDQ0, ni, nj, dQ0);
				DMSETAT(pDQ1, ni, nj, dQ1);
				DMSETAT(pDQ2, ni, nj, dQ2);
			}
			else
			{
				logGam = gammaln(dX+1.0)+gammaln(dY+1.0);
				logGalpha = gammaln(dN+vP[6]-nMinC);
				logGn = 0.0;
				for(nk=0; nk<nMinC; nk++)
					logGn += log(dN-nk);

				dL0 = logPi0+dN*logLambda-vP[3]+dX*logP0+dY*logP0C-logGam;
				dLMax = dL0;

				dL1 = logPi1+logGalpha-logGalpha0+vP[6]*logBetaPC+(dN-nMinC)*logBetaP+dX*logP0+dY*logP0C-logGam+logGn;
				if(dL1 > dLMax)
					dLMax = dL1;

				dL2 = logPi2+logGalpha-logGalpha0+vP[6]*logBetaPC+(dN-nMinC)*logBetaP+logGab-logGam+logGn+gammaln(dX+vP[7])+gammaln(dY+vP[8])-gammaln(dN+vP[7]+vP[8]);
				if(dL2 > dLMax)
					dLMax = dL2;

				dL0 -= dLMax;
				dL1 -= dLMax;
				dL2 -= dLMax;

				dL0 = exp(dL0);
				dL1 = exp(dL1);
				dL2 = exp(dL2);
				dTemp = dL0+dL1+dL2;
				dQ0 = dL0/dTemp;
				dQ1 = dL1/dTemp;
				dQ2 = dL2/dTemp;

				DMSETAT(pDQ0, ni, nj, dQ0);
				DMSETAT(pDQ1, ni, nj, dQ1);
				DMSETAT(pDQ2, ni, nj, dQ2);
			}
		}
	}

	/* check */
	nRID = 0;
	for(ni=0; ni<pBARData->nSeqNum; ni++)
	{
		if(pBARData->vSeqData[ni]->nDataNum <= 0)
			continue;

		nR1 = -1;
		nR2 = -1;

		nj = pBARData->vSeqData[ni]->nDataNum-1;
		nStart = (int)(pBARData->vSeqData[ni]->vData[0]->pMatElement[0]-pParam->nW+1);
		nEnd = (int)(pBARData->vSeqData[ni]->vData[0]->pMatElement[nj]+1);
		nX = 0;
		nY = 0;
		nl = 0;
		nu = 0;
		for(nW1=nStart; nW1<nEnd; nW1++)
		{
			if(nl < pBARData->vSeqData[ni]->nDataNum)
			{
				while( pBARData->vSeqData[ni]->vData[0]->pMatElement[nl] < nW1 )
				{
					if(pBARData->vSeqData[ni]->vData[1]->pMatElement[nl] > 0)
						nX--;
					else
						nY--;
					nl++;
					if(nl >= pBARData->vSeqData[ni]->nDataNum)
						break;
				}
			}
			
			if(nu < pBARData->vSeqData[ni]->nDataNum)
			{

				while( pBARData->vSeqData[ni]->vData[0]->pMatElement[nu] < (nW1+pParam->nW) )
				{
					if(pBARData->vSeqData[ni]->vData[1]->pMatElement[nu] > 0)
						nX++;
					else
						nY++;
					nu++;

					if(nu >= pBARData->vSeqData[ni]->nDataNum)
						break;

				}
			}

			/* compute */
			if( (nX < nDQSIZE) && (nY < nDQSIZE) )
			{
				dQ1 = DMGETAT(pDQ1, nX, nY);
				dQ2 = DMGETAT(pDQ2, nX, nY);
			}
			else
			{
				dX = nX;
				dY = nY;
				dN = dX+dY;

				logGam = gammaln(dX+1.0)+gammaln(dY+1.0);
				logGalpha = gammaln(dN+vP[6]-nMinC);
				logGn = 0.0;
				for(nk=0; nk<nMinC; nk++)
					logGn += log(dN-nk);

				dL0 = logPi0+dN*logLambda-vP[3]+dX*logP0+dY*logP0C-logGam;
				dLMax = dL0;

				dL1 = logPi1+logGalpha-logGalpha0+vP[6]*logBetaPC+(dN-nMinC)*logBetaP+dX*logP0+dY*logP0C-logGam+logGn;
				if(dL1 > dLMax)
					dLMax = dL1;

				dL2 = logPi2+logGalpha-logGalpha0+vP[6]*logBetaPC+(dN-nMinC)*logBetaP+logGab-logGam+logGn+gammaln(dX+vP[7])+gammaln(dY+vP[8])-gammaln(dN+vP[7]+vP[8]);
				if(dL2 > dLMax)
					dLMax = dL2;

				dL0 -= dLMax;
				dL1 -= dLMax;
				dL2 -= dLMax;

				dL0 = exp(dL0);
				dL1 = exp(dL1);
				dL2 = exp(dL2);
				dTemp = dL0+dL1+dL2;
				dQ0 = dL0/dTemp;
				dQ1 = dL1/dTemp;
				dQ2 = dL2/dTemp;
			}
			
			if(dQ2 > 0.5)
			{
				if(nR1 < 0)
				{
					nR1 = nW1;
					nR2 = nW1;
				}
				else
				{
					nR2 = nW1;
				}

				if(dQ2 > dMaxQ)
				{
					dMaxQ = dQ2;
					dMaxR = ((double)nX/(double)(nX+nY) - vP[4])/vP[4];
					nMaxX = nX;
					nMaxY = nY;
				}
			}
			else
			{
				if(nR1 >= 0)
				{
					/* save to file */
					nR2 += pParam->nW-1;
					if( (nMaxX+nMaxY) > 10)
					{
						fprintf(fpOut, "%d\t%s\t%d\t%d\t+\t%d\t%d\t%f\t%f\n", nRID, pBARData->vSeqData[ni]->pSeqName->m_pString,
							nR1, nR2, nMaxX, nMaxY, dMaxQ, dMaxR);
						nRID++;
					}
				}

				nR1 = -1;
				nR2 = -1;
				dMaxQ = 0.0;
				dMaxR = 0.0;
				nMaxX = 0;
				nMaxY = 0;
			}
		}

		if(nR1 >= 0)
		{
			/* save to file */
			nR2 += pParam->nW-1;
			if( (nMaxX+nMaxY) > 10)
			{
				fprintf(fpOut, "%d\t%s\t%d\t%d\t+\t%d\t%d\t%f\t%f\n", nRID, pBARData->vSeqData[ni]->pSeqName->m_pString,
					nR1, nR2, nMaxX, nMaxY, dMaxQ, dMaxR);
				nRID++;
			}
		}
	}

	fclose(fpOut);

	Affy_BARData_Destroy(&pBARData);

	/* return */
	return PROC_SUCCESS;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Enrich_Main()                                                  */
/*  Detect enriched alignment regions.                                     */
/* ----------------------------------------------------------------------- */ 
int HTS_Aln2Enrich_Main(char strParamPath[])
{	
	/* Sample name */
	struct tagHTSAln2WinParam *pParam = NULL;
	struct INTMATRIX *pChrLen = NULL;
	struct tagBARData *pBARData = NULL;
	int ni;
	double dCount;
	char strFileName[LONG_LINE_LENGTH];
	struct INTMATRIX *pCol;
	double *vP;

	/* Load Parameters */
	pParam = HTS_Aln2Window_LoadParamter(strParamPath);
	if(pParam == NULL)
	{
		printf("Error: HTS_Aln2Enrich_Main, cannot allocate memory for loading parameters!\n");
		exit(EXIT_FAILURE);
	}

	/* Load Chromosome */
	pChrLen = IMLOAD(pParam->strChrLen);
	if(pChrLen == NULL)
	{
		printf("Error: HTS_Aln2Enrich_Main, cannot load chromosome length!\n");
		exit(EXIT_FAILURE);
	}

	/* prepare BAR object */
	pBARData = HTS_Aln2Diff_PrepareBARData(pParam, pChrLen);
	if(pBARData == NULL)
	{
		printf("Error: HTS_Aln2Enrich_Main, cannot create bar data object!\n");
		exit(EXIT_FAILURE);
	}

	/* process data one by one */
	pCol = NULL;
	pCol = CreateIntMatrix(1,pBARData->nColNum);
	if(pCol == NULL)
	{
		printf("Error: HTS_Aln2Enrich_Main, cannot create output column information!\n");
		exit(EXIT_FAILURE);
	}
	pCol->pMatElement[0] = 2;
	for(ni=0; ni<pParam->nSampleNum; ni++)
	{
		/* count */
		sprintf(strFileName, "%s%s", pParam->strDataFolder, pParam->vSampleFile[ni]->m_pString);
		dCount = 0;
		dCount = HTS_Aln2Diff_CountHits(pBARData, strFileName, pParam->nW, ni);

		/* output */
		pCol->pMatElement[1+ni] = 1;
		sprintf(strFileName, "%s%s.bar", pParam->strExportFolder, pParam->vSampleFile[ni]->m_pString);
		Affy_SaveBAR_Columns_Fast(strFileName, pBARData, pCol);
		pCol->pMatElement[1+ni] = 0;
	}
	DestroyIntMatrix(pCol);
	
	/* estimate paramters */
	vP = NULL;
	vP = (double *)calloc(6, sizeof(double)); 
	if(vP == NULL)
	{
		printf("Error: HTS_Aln2Enrich_Main, cannot create vP!\n");
		exit(EXIT_FAILURE);
	}
	
	/* estimate prior probability */
	HTS_Aln2Enrich_EstimateP(pBARData, pParam->nSampleNum, vP);

	/* Destroy Paramter */
	free(vP);
	HTSAln2WinParam_Destroy(&pParam);
	DestroyIntMatrix(pChrLen);
	pChrLen = NULL;
	Affy_BARData_Destroy(&pBARData);

	/* return */
	return PROC_SUCCESS;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Enrich_EstimateP()                                             */
/*  Estimate hyperparamter for mixture binominal                           */
/* ----------------------------------------------------------------------- */ 
int HTS_Aln2Enrich_EstimateP(struct tagBARData *pBARData, int nSampleNum, 
								   double *vP)
{
	/* define */
	int nMinC = 2;
	int nParamNum = 6;
	double vC[6];
	double vBackUp[6];
	double dQ0,dQ1;
	double dLam0,dLam1;
	double dBetaP;
	double dL0,dL1;
	int ni,nj,nk;
	double dN;
	double dA,dB,dC,dD;
	double dTemp;
	double dTotal;
	double dError;
	double logBetaP, logBetaPC;
	double logPi0, logPi1, logLambda, logGn;
	double logGam;
	double dLMax;
	int nMaxIter = 50;
	int nIter;
	double dLike0,dLike1;
	double logGalpha0,logGalpha;
	double dM1Lam,dM2Lam;
	struct DOUBLEMATRIX *pDQ0,*pDQ1,*pDLike;
	int nDQSIZE;
	double vSumDist[256];
	int nTestParameter = 0;
	int nSuppressDisplay = 0;
	char strFileName[255];
	FILE *fpOut;


	vC[0] = 0.99; /* pi_0 */
	vC[1] = 0.01; /* pi_1 */
	vC[2] = 0.05; /* lambda_0 */
	vC[3] = 0.5; /* p_0 */
	vC[4] = 0.05; /* beta */
	vC[5] = 1.0; /* alpha */
	
	nDQSIZE = 21;
	pDQ0 = NULL;
	pDQ0 = CreateDoubleMatrix(1,nDQSIZE);
	pDQ1 = NULL;
	pDQ1 = CreateDoubleMatrix(1,nDQSIZE);
	pDLike = NULL;
	pDLike = CreateDoubleMatrix(1,nDQSIZE);
	if( (pDQ0 == NULL) || (pDQ1 == NULL) || (pDLike == NULL) )
	{
		printf("Error: cannot create Q database!\n");
		exit(EXIT_FAILURE);
	}

	for(ni=0; ni<256; ni++)
	{
		vSumDist[ni] = 0.0;
	}

	dA = 0.0;
	dB = 0.0;
	dC = 0.0;
	dD = 0.0;
	dTotal = 0.0;
	for(ni=0; ni<pBARData->nSeqNum; ni++)
	{
		dTotal += pBARData->vSeqData[ni]->nDataNum;
		for(nj=0; nj<pBARData->vSeqData[ni]->nDataNum; nj++)
		{
			dA += pBARData->vSeqData[ni]->vData[1]->pMatElement[nj];
			nk = (int)(pBARData->vSeqData[ni]->vData[1]->pMatElement[nj]);
			if(nk > 255)
				nk = 255;
			vSumDist[nk] += 1;
			if(nk >= nMinC)
			{
				dC += nk;
				dD += 1.0;
			}
		}
	}

	vC[2] = dA/dTotal;
	if((double)nMinC < vC[2])
	{
		nMinC = (int)(vC[2])+2;
	}
	
	dC /= dD;
	if(dC < nMinC)
		dC = nMinC+1;
	vC[4] = 1/(2.0*dC);
	dD = vC[2];

	dTemp = 0.0;
	for(nk=0; nk<256; nk++)
	{
		dTemp += vSumDist[nk];
	}
	for(nk=0; nk<256; nk++)
	{
		vSumDist[nk] /= dTemp;
	}
	strcpy(strFileName, "wincount_summary.txt");
	fpOut = fopen(strFileName, "w");
	if(fpOut == NULL)
	{
		printf("Error: cannot open output file!\n");
		exit(EXIT_FAILURE);
	}
	for(nk=0; nk<256; nk++)
	{
		fprintf(fpOut, "%e\n", vSumDist[nk]);
	}
	fclose(fpOut);

	for(ni=0; ni<nParamNum; ni++)
	{
		vP[ni] = vC[ni]/2.0;
	}
	dError = 1.0;

	dLike0 = -1e20;
	dLike1 = -1e20;
	nIter = 0;
	nTestParameter = 0;
	while( dError > 0.01 )
	{
		if(nIter%10 == 0)
		{
			if(nSuppressDisplay == 1)
			{
				nSuppressDisplay = 0;
			}
			else
			{
				printf("EM iteration %d ...\n", nIter);
			}
		}

		if(nTestParameter == 1)
		{
			for(ni=0; ni<4; ni++)
			{
				vBackUp[ni] = vC[ni];
				vP[ni] = vC[ni];
				vC[ni] = 0.0;
			}
			for(; ni<nParamNum; ni++)
			{
				vBackUp[ni] = vP[ni];
				vP[ni] = vC[ni];
				vC[ni] = 0.0;
			}
		}
		else
		{
			for(ni=0; ni<nParamNum; ni++)
			{
				vP[ni] = vC[ni];
				vC[ni] = 0.0;
			}
		}

		dA = 0.0;
		dB = 0.0;
		dLam0 = 0.0;
		dLam1 = 0.0;
		dLike0 = dLike1;
		dLike1 = 0.0;
		dM1Lam = 0.0;
		dM2Lam = 0.0;

		logPi0 = log(vP[0]);
		logPi1 = log(vP[1]);
		logLambda = log(vP[2]);		
		dBetaP = 1.0/(1.0+vP[4]);
		logBetaP = log(dBetaP);
		logBetaPC = log(1.0-dBetaP);
		logGalpha0 = gammaln(vP[5]);
	
		for(ni=0; ni<nDQSIZE; ni++)
		{
			dN = ni;
			if((int)dN < nMinC)
			{
				logGn = gammaln(dN+1.0);
				dL0 = logPi0+dN*logLambda-vP[2]-logGn;
				dQ0 = 1.0;
				dQ1 = 0.0;
				DMSETAT(pDQ0, 0, nj, dQ0);
				DMSETAT(pDQ1, 0, nj, dQ1);
				DMSETAT(pDLike, 0, nj, dL0);
			}
			else
			{
				logGn = gammaln(dN+1.0);
				logGam = gammaln(dN-nMinC);
				logGalpha = gammaln(dN+vP[5]-nMinC);
				
				dL0 = logPi0+dN*logLambda-vP[2]-logGn;
				dLMax = dL0;

				dL1 = logPi1+logGalpha-logGalpha0+vP[5]*logBetaPC+(dN-nMinC)*logBetaP-logGam;
				if(dL1 > dLMax)
					dLMax = dL1;

				dL0 -= dLMax;
				dL1 -= dLMax;

				dL0 = exp(dL0);
				dL1 = exp(dL1);
				dTemp = dL0+dL1;
				dQ0 = dL0/dTemp;
				dQ1 = dL1/dTemp;

				DMSETAT(pDQ0, 0, nj, dQ0);
				DMSETAT(pDQ1, 0, nj, dQ1);
				dTemp = dLMax+log(dTemp);
				DMSETAT(pDLike, 0, nj, dTemp);
			}
		}

		for(ni=0; ni<pBARData->nSeqNum; ni++)
		{
			for(nj=0; nj<pBARData->vSeqData[ni]->nDataNum; nj++)
			{
				dN = pBARData->vSeqData[ni]->vData[1]->pMatElement[nj];
				
				if((int)dN<nDQSIZE)
				{
					dQ0 = DMGETAT(pDQ0, 0, (int)dN);
					dQ1 = DMGETAT(pDQ1, 0, (int)dN);
					dLike1 += DMGETAT(pDLike, 0, (int)dN);
				}
				else
				{
					logGn = gammaln(dN+1.0);
					logGam = gammaln(dN-nMinC);
					logGalpha = gammaln(dN+vP[5]-nMinC);
					
					dL0 = logPi0+dN*logLambda-vP[2]-logGn;
					dLMax = dL0;

					dL1 = logPi1+logGalpha-logGalpha0+vP[5]*logBetaPC+(dN-nMinC)*logBetaP-logGam;
					if(dL1 > dLMax)
						dLMax = dL1;

					dL0 -= dLMax;
					dL1 -= dLMax;

					dL0 = exp(dL0);
					dL1 = exp(dL1);
					dTemp = dL0+dL1;
					dQ0 = dL0/dTemp;
					dQ1 = dL1/dTemp;
					dLike1 += dLMax+log(dTemp);
				}

				vC[0] += dQ0;
				vC[1] += dQ1;

				dLam0 += dQ0;
				dLam1 += dQ0*dN;

				dA += dQ1;
				dB += dQ1*dN;

				dM1Lam += dQ1*dN;
				dM2Lam += dQ1*dN*dN;
			}
		}

		dM1Lam /= dA;
		dM2Lam /= dA;

		if(nTestParameter == 1)
		{
			nTestParameter = 0;
			if(dLike1 < dLike0)
			{
				dLike1 = dLike0;
				for(nk=0; nk<nParamNum; nk++)
				{
					vC[nk] = vBackUp[nk];
				}
				dError = 1.0;
				nSuppressDisplay = 1;
				continue;
			}
		}

		dTotal = vC[0]+vC[1];
		vC[0] /= dTotal;
		vC[1] /= dTotal;
		vC[2] = dLam1/dLam0;
		if(vC[2] > dD)
			vC[2] = dD;

		vC[4] = vP[4];
		vC[5] = vP[5];
		
		if(dLike1 < dLike0)
		{
			printf("Warning: likelihood decreasing!\n");
			/* break; */
		}

		dError = 0.0;
		for(ni=0; ni<nParamNum; ni++)
		{
			dTemp = fabs(vC[ni]-vP[ni])/vP[ni];
			if(dTemp > dError)
				dError = dTemp;
		}

		
		nIter++;

		if(nIter%5 == 0)
		{
			dTemp = dM1Lam/(dM2Lam-dM1Lam*dM1Lam-dM1Lam);
				
			if(dM1Lam >= dC)
			{
				if( dTemp > 0.0 )
				{
					vC[4] = dTemp;
					vC[5] = dM1Lam*vC[4];
				}
			}

			nTestParameter = 1;
		}

		if(nIter >= nMaxIter)
			break;
	}


	DestroyDoubleMatrix(pDQ0);
	DestroyDoubleMatrix(pDQ1);
	DestroyDoubleMatrix(pDLike);

	printf("Estimated Parameters [Relative Error]:\n");
	printf("pi_0 = %f [%f%%]\n", vP[0], 100.0*fabs(vC[0]-vP[0])/vP[0]);
	printf("pi_1 = %f [%f%%]\n", vP[1], 100.0*fabs(vC[1]-vP[1])/vP[1]);
	printf("lambda_0 = %f [%f%%]\n", vP[2], 100.0*fabs(vC[2]-vP[2])/vP[2]);
	printf("alpha = %f [%f%%]\n", vP[5], 100.0*fabs(vC[5]-vP[5])/vP[5]);
	printf("beta = %f [%f%%]\n", vP[4], 100.0*fabs(vC[4]-vP[4])/vP[4]);
	
	/* return */
	return PROC_SUCCESS;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2BAR()                                                          */
/*  Convert high throughput sequencing alignment to bar file.              */
/* ----------------------------------------------------------------------- */ 
int HTS_Aln2BAR(char strTXTFile[], char strBARFile[])
{
	/* define */
	unsigned int x = 1;
	int little_endian_machine = (1 == *((char*)(&x)));

	struct tagBARData *pBARData = NULL;
	FILE *fpIn;
	FILE *fpOut;

	/* variables */
	int nFieldNum = 0;
	int nSeqNum = 0;
	int nColNum = 0;
	struct tagString *pSeqInfo = NULL;
	int nProbeNum = 0;
	int nTotalProbeNum = 0;
	char strLine[LONG_LINE_LENGTH];
	char strTemp[LONG_LINE_LENGTH];
	char *chp1,*chp2;
	char strChr[MED_LINE_LENGTH];
	char strLastChr[MED_LINE_LENGTH];
	int nLastPos;
	int nPos,nAlnCount;
	char strBARTmpFileName[MED_LINE_LENGTH];
	struct INTMATRIX *pCol = NULL;
	
	/* count */
	int ni,nj,nk;

	/* load */
	fpIn = NULL;
	fpIn = fopen(strTXTFile, "r");
	if(fpIn == NULL)
	{
		printf("Error: HTS_Aln2BAR, cannot open source file!\n");
		exit(EXIT_FAILURE);
	}

	sprintf(strBARTmpFileName, "%s.tmp", strBARFile);
	fpOut = NULL;
	fpOut = fopen(strBARTmpFileName, "w");
	if(fpOut == NULL)
	{
		printf("Error: HTS_Aln2BAR, cannot open temporary output file!\n");
		exit(EXIT_FAILURE);
	}

	/* load input */
	pSeqInfo = NULL;
	strcpy(strLastChr, "");
	nLastPos = -1;
	nProbeNum = 0;
	nColNum = 1;
	nSeqNum = 0;
	nFieldNum = 3;

	while(fgets(strLine, LONG_LINE_LENGTH, fpIn) != NULL)
	{
		StrTrimLeft(strLine);
		StrTrimRight(strLine);
		if(strLine[0] == '0')
			continue;
		if(strLine[0] == '#')
		{
			/* fprintf(fpOut, "%s\n", strLine); */
			continue;
		}

		sscanf(strLine, "%s %d", strChr, &nPos);
		
		if(strcmp(strChr, strLastChr) != 0)
		{
			if(strcmp(strLastChr, "") != 0)
			{
				sprintf(strTemp, "%s\t%d\t", strLastChr, nProbeNum);
				StringAddTail(&pSeqInfo, strTemp);
				fprintf(fpOut, "%s\t%d\t%d\n", strLastChr, nLastPos, nAlnCount);
			}

			nSeqNum++;
			strcpy(strLastChr, strChr);
			nLastPos = nPos;
			nProbeNum = 1;
			nAlnCount = 1;
		}
		else
		{
			if(nPos != nLastPos)
			{
				fprintf(fpOut, "%s\t%d\t%d\n", strLastChr, nLastPos, nAlnCount);
				nLastPos = nPos;
				nAlnCount = 1;
				nProbeNum++;
			}
			else
			{
				nAlnCount += 1;
			}
		}
	}

	if(strcmp(strLastChr, "") != 0)
	{
		sprintf(strTemp, "%s\t%d\t", strLastChr, nProbeNum);
		StringAddTail(&pSeqInfo, strTemp);
		fprintf(fpOut, "%s\t%d\t%d\n", strLastChr, nLastPos, nAlnCount);
	}

	fclose(fpIn);
	fclose(fpOut);


	/* load head */
	if(nSeqNum <= 0)
	{
		printf("Warning: empty sequences!\n");
		return PROC_FAILURE;
	}

	/* create BAR object */
	pBARData = Affy_BARData_Create();
	if(pBARData == NULL)
	{
		printf("Error: HTS_Aln2BAR, BARData object was not created!\n");
		exit(EXIT_FAILURE);
	}
	strcpy(pBARData->strMagicnumber, "barr\r\n\032\n");
	pBARData->fVersionnumber = 2.0;
    pBARData->nSeqNum = nSeqNum;
	pBARData->nColNum = nColNum+1;
	pBARData->nParamNum = 0;
	pBARData->vParamName = NULL;
	pBARData->vParamValue = NULL;
	pBARData->pFieldType = CreateIntMatrix(1, pBARData->nColNum);
	if(pBARData->pFieldType == NULL)
	{
		printf("Error: HTS_Aln2BAR, cannot allocate memory for field type.\n");
		exit(EXIT_FAILURE);
	}
	pBARData->pFieldType->pMatElement[0] = 2;
	for(ni=1; ni<pBARData->nColNum; ni++)
		pBARData->pFieldType->pMatElement[ni] = 1;

	pBARData->vSeqData = (struct tagBARSeq **)calloc(pBARData->nSeqNum, sizeof(struct tagBARSeq *));
	if(pBARData->vSeqData == NULL)
	{
		printf("Error: TileMapv2_TXT2BAR, cannot allocate memory for loading sequence data.\n");
		exit(EXIT_FAILURE);
	}

	chp1 = pSeqInfo->m_pString;
	for(ni=0; ni<pBARData->nSeqNum; ni++)
	{
		/* create BARSeq object */
		pBARData->vSeqData[ni] = Affy_BARSeq_Create();
		if(pBARData->vSeqData[ni] == NULL)
		{
			printf("Error: TileMapv2_TXT2BAR, cannot create BARSeq object.\n");
			exit(EXIT_FAILURE);
		}

		pBARData->vSeqData[ni]->pSeqGroupName = NULL;
		pBARData->vSeqData[ni]->pSeqVersion = NULL;
		pBARData->vSeqData[ni]->nParamNum = 0;
		pBARData->vSeqData[ni]->vParamName = NULL;
		pBARData->vSeqData[ni]->vParamValue = NULL;

		pBARData->vSeqData[ni]->nColNum = pBARData->nColNum;

		chp2 = strchr(chp1, '\t');
		*chp2 = '\0';
		strcpy(strTemp, chp1);
		StringAddTail(&(pBARData->vSeqData[ni]->pSeqName), strTemp);
		chp1 = chp2+1;

		chp2 = strchr(chp1, '\t');
		*chp2 = '\0';
		strcpy(strTemp, chp1);
		pBARData->vSeqData[ni]->nDataNum = atoi(strTemp);
		chp1 = chp2+1;


		pBARData->vSeqData[ni]->vData = (struct DOUBLEMATRIX **)calloc(pBARData->vSeqData[ni]->nColNum, sizeof(struct DOUBLEMATRIX *));
		if(pBARData->vSeqData[ni]->vData == NULL)
		{
			printf("Error: HTS_Aln2BAR, cannot allocate memory for loading bpmap coordinate data!\n");
			exit(EXIT_FAILURE);
		}
		if(pBARData->vSeqData[ni]->nDataNum > 0)
		{
			for(nj=0; nj<pBARData->vSeqData[ni]->nColNum; nj++)
			{
				pBARData->vSeqData[ni]->vData[nj] = CreateDoubleMatrix(1, pBARData->vSeqData[ni]->nDataNum );
				if(pBARData->vSeqData[ni]->vData[nj] == NULL)
				{
					printf("Error: HTS_Aln2BAR, cannot allocate memory for loading bpmap coordinate data!\n");
					exit(EXIT_FAILURE);
				}
			}
		}
	}
	
	/* load data */
	fpIn = NULL;
	fpIn = fopen(strBARTmpFileName, "r");
	if(fpIn == NULL)
	{
		printf("Error: HTS_Aln2BAR, cannot open source file!\n");
		exit(EXIT_FAILURE);
	}

	strcpy(strLastChr, "");
	nSeqNum = -1;
	nProbeNum = 0;
	while(fgets(strLine, LONG_LINE_LENGTH, fpIn) != NULL)
	{
		StrTrimLeft(strLine);
		StrTrimRight(strLine);
		if(strLine[0] == '0')
			continue;
		if(strLine[0] == '#')
			continue;

		chp1 = strLine;
		chp2 = strchr(chp1, '\t');
		if(chp2 == NULL)
		{
			printf("Error: HTS_Aln2BAR, wrong input file format!\n");
			exit(EXIT_FAILURE);
		}
		*chp2 = '\0';
		StrTrimRight(chp1);
		strcpy(strChr, chp1);

		if(strcmp(strChr, strLastChr) != 0)
		{
			if(strcmp(strLastChr, "") != 0)
			{
				if(nProbeNum != (pBARData->vSeqData[nSeqNum]->nDataNum-1))
				{
					printf("Error: HTS_Aln2BAR, cannot read input file correctly!");
					exit(EXIT_FAILURE);
				}
			}

			nSeqNum++;
			strcpy(strLastChr, strChr);
			nProbeNum = 0;
		}
		else
		{
			nProbeNum++;
		}

		chp1 = chp2+1;
		chp2 = strchr(chp1, '\t');
		nk = 0;
		while(chp2 != NULL)
		{
			if(nk >= pBARData->vSeqData[nSeqNum]->nColNum)
			{
				printf("Error: HTS_Aln2BAR, input file format error, column number inconsistent!");
				exit(EXIT_FAILURE);
			}

			*chp2 = '\0';
			StrTrimLeft(chp1);
			StrTrimRight(chp1);
			pBARData->vSeqData[nSeqNum]->vData[nk]->pMatElement[nProbeNum] = atof(chp1);
			nk++;

			chp1 = chp2+1;
			chp2 = strchr(chp1, '\t');
		}

		if(nk >= pBARData->vSeqData[nSeqNum]->nColNum)
		{
			printf("Error: HTS_Aln2BAR, input file format error, column number inconsistent!");
			exit(EXIT_FAILURE);
		}
		
		StrTrimLeft(chp1);
		StrTrimRight(chp1);
		pBARData->vSeqData[nSeqNum]->vData[nk]->pMatElement[nProbeNum] = atof(chp1);
		nk++;

		if(nk != pBARData->vSeqData[nSeqNum]->nColNum)
		{
			printf("Error: HTS_Aln2BAR, input file format error, column number inconsistent!");
			exit(EXIT_FAILURE);
		}
	}

	
	/* close file */
	fclose(fpIn);

	if(nProbeNum != (pBARData->vSeqData[nSeqNum]->nDataNum-1))
	{
		printf("Error: HTS_Aln2BAR, cannot read input file correctly!");
		exit(EXIT_FAILURE);
	}

	if(nSeqNum != pBARData->nSeqNum-1)
	{
		printf("Error: HTS_Aln2BAR, cannot read input file correctly!");
		exit(EXIT_FAILURE);
	}
	
	/* write to BAR file */
	pCol = NULL;
	pCol = CreateIntMatrix(1,pBARData->nColNum);
	if(pCol == NULL)
	{
		printf("Error: HTS_Aln2BAR, cannot create output column information!\n");
		exit(EXIT_FAILURE);
	}
	
	pCol->pMatElement[0] = 1;
	for(ni=0; ni<nColNum; ni++)
	{
		pCol->pMatElement[1+ni] = 1;
		Affy_SaveBAR_Columns_Fast(strBARFile, pBARData, pCol);
		pCol->pMatElement[1+ni] = 0;
	}
	DestroyIntMatrix(pCol);

	
	/* release memory */
	DeleteString(pSeqInfo);
	pSeqInfo = NULL;

	Affy_BARData_Destroy(&pBARData);

	RemoveFiles(strBARTmpFileName);

	/* return */
	return PROC_SUCCESS;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2BARv2()                                                        */
/*  Convert high throughput sequencing alignment to bar file.              */
/* ----------------------------------------------------------------------- */ 
int HTS_Aln2BARv2(char strTXTFile[], char strBARFile[])
{
	/* define */
	unsigned int x = 1;
	int little_endian_machine = (1 == *((char*)(&x)));

	struct tagBARData *pBARData = NULL;
	FILE *fpIn;
	FILE *fpOut;

	/* variables */
	int nFieldNum = 0;
	int nSeqNum = 0;
	int nColNum = 0;
	struct tagString *pSeqInfo = NULL;
	int nProbeNum = 0;
	char chStrand;
	int nTotalProbeNum = 0;
	char strLine[LONG_LINE_LENGTH];
	char strTemp[LONG_LINE_LENGTH];
	char *chp1,*chp2;
	char strChr[MED_LINE_LENGTH];
	char strLastChr[MED_LINE_LENGTH];
	int nLastPos;
	int nPos,nAlnCount;
	int nAlnCountF = 0;
	int nAlnCountR = 0;
	char strBARTmpFileName[MED_LINE_LENGTH];
	struct INTMATRIX *pCol = NULL;
	
	/* count */
	int ni,nj,nk;

	/* load */
	fpIn = NULL;
	fpIn = fopen(strTXTFile, "r");
	if(fpIn == NULL)
	{
		printf("Error: HTS_Aln2BAR, cannot open source file!\n");
		exit(EXIT_FAILURE);
	}

	sprintf(strBARTmpFileName, "%s.tmp", strBARFile);
	fpOut = NULL;
	fpOut = fopen(strBARTmpFileName, "w");
	if(fpOut == NULL)
	{
		printf("Error: HTS_Aln2BAR, cannot open temporary output file!\n");
		exit(EXIT_FAILURE);
	}

	/* load input */
	pSeqInfo = NULL;
	strcpy(strLastChr, "");
	nLastPos = -1;
	nProbeNum = 0;
	nColNum = 3;
	nSeqNum = 0;
	nFieldNum = 3;

	while(fgets(strLine, LONG_LINE_LENGTH, fpIn) != NULL)
	{
		StrTrimLeft(strLine);
		StrTrimRight(strLine);
		if(strLine[0] == '0')
			continue;
		if(strLine[0] == '#')
		{
			/* fprintf(fpOut, "%s\n", strLine); */
			continue;
		}

		sscanf(strLine, "%s %d %c", strChr, &nPos, &chStrand);
		
		if(strcmp(strChr, strLastChr) != 0)
		{
			if(strcmp(strLastChr, "") != 0)
			{
				sprintf(strTemp, "%s\t%d\t", strLastChr, nProbeNum);
				StringAddTail(&pSeqInfo, strTemp);
				fprintf(fpOut, "%s\t%d\t%d\t%d\t%d\n", strLastChr, nLastPos, nAlnCount, nAlnCountF, nAlnCountR);
			}

			nSeqNum++;
			strcpy(strLastChr, strChr);
			nLastPos = nPos;
			nProbeNum = 1;
			nAlnCount = 1;
			if( (chStrand == 'R') || (chStrand == '-') || (chStrand == '1') || (chStrand == 'r') )
			{
				nAlnCountF = 0;
				nAlnCountR = 1;
			}
			else
			{
				nAlnCountF = 1;
				nAlnCountR = 0;
			}
		}
		else
		{
			if(nPos != nLastPos)
			{
				fprintf(fpOut, "%s\t%d\t%d\t%d\t%d\n", strLastChr, nLastPos, nAlnCount, nAlnCountF, nAlnCountR);
				nLastPos = nPos;
				nAlnCount = 1;
				if( (chStrand == 'R') || (chStrand == '-') || (chStrand == '1') || (chStrand == 'r') )
				{
					nAlnCountF = 0;
					nAlnCountR = 1;
				}
				else
				{
					nAlnCountF = 1;
					nAlnCountR = 0;
				}
				nProbeNum++;
			}
			else
			{
				nAlnCount += 1;
				if( (chStrand == 'R') || (chStrand == '-') || (chStrand == '1') || (chStrand == 'r') )
				{
					nAlnCountR += 1;
				}
				else
				{
					nAlnCountF += 1;
				}
			}
		}
	}

	if(strcmp(strLastChr, "") != 0)
	{
		sprintf(strTemp, "%s\t%d\t", strLastChr, nProbeNum);
		StringAddTail(&pSeqInfo, strTemp);
		fprintf(fpOut, "%s\t%d\t%d\t%d\t%d\n", strLastChr, nLastPos, nAlnCount, nAlnCountF, nAlnCountR);
	}

	fclose(fpIn);
	fclose(fpOut);


	/* load head */
	if(nSeqNum <= 0)
	{
		printf("Warning: empty sequences!\n");
		return PROC_FAILURE;
	}

	/* create BAR object */
	pBARData = Affy_BARData_Create();
	if(pBARData == NULL)
	{
		printf("Error: HTS_Aln2BAR, BARData object was not created!\n");
		exit(EXIT_FAILURE);
	}
	strcpy(pBARData->strMagicnumber, "barr\r\n\032\n");
	pBARData->fVersionnumber = 2.0;
    pBARData->nSeqNum = nSeqNum;
	pBARData->nColNum = nColNum+1;
	pBARData->nParamNum = 0;
	pBARData->vParamName = NULL;
	pBARData->vParamValue = NULL;
	pBARData->pFieldType = CreateIntMatrix(1, pBARData->nColNum);
	if(pBARData->pFieldType == NULL)
	{
		printf("Error: HTS_Aln2BAR, cannot allocate memory for field type.\n");
		exit(EXIT_FAILURE);
	}
	pBARData->pFieldType->pMatElement[0] = 2;
	for(ni=1; ni<pBARData->nColNum; ni++)
		pBARData->pFieldType->pMatElement[ni] = 1;

	pBARData->vSeqData = (struct tagBARSeq **)calloc(pBARData->nSeqNum, sizeof(struct tagBARSeq *));
	if(pBARData->vSeqData == NULL)
	{
		printf("Error: TileMapv2_TXT2BAR, cannot allocate memory for loading sequence data.\n");
		exit(EXIT_FAILURE);
	}

	chp1 = pSeqInfo->m_pString;
	for(ni=0; ni<pBARData->nSeqNum; ni++)
	{
		/* create BARSeq object */
		pBARData->vSeqData[ni] = Affy_BARSeq_Create();
		if(pBARData->vSeqData[ni] == NULL)
		{
			printf("Error: TileMapv2_TXT2BAR, cannot create BARSeq object.\n");
			exit(EXIT_FAILURE);
		}

		pBARData->vSeqData[ni]->pSeqGroupName = NULL;
		pBARData->vSeqData[ni]->pSeqVersion = NULL;
		pBARData->vSeqData[ni]->nParamNum = 0;
		pBARData->vSeqData[ni]->vParamName = NULL;
		pBARData->vSeqData[ni]->vParamValue = NULL;

		pBARData->vSeqData[ni]->nColNum = pBARData->nColNum;

		chp2 = strchr(chp1, '\t');
		*chp2 = '\0';
		strcpy(strTemp, chp1);
		StringAddTail(&(pBARData->vSeqData[ni]->pSeqName), strTemp);
		chp1 = chp2+1;

		chp2 = strchr(chp1, '\t');
		*chp2 = '\0';
		strcpy(strTemp, chp1);
		pBARData->vSeqData[ni]->nDataNum = atoi(strTemp);
		chp1 = chp2+1;


		pBARData->vSeqData[ni]->vData = (struct DOUBLEMATRIX **)calloc(pBARData->vSeqData[ni]->nColNum, sizeof(struct DOUBLEMATRIX *));
		if(pBARData->vSeqData[ni]->vData == NULL)
		{
			printf("Error: HTS_Aln2BAR, cannot allocate memory for loading bpmap coordinate data!\n");
			exit(EXIT_FAILURE);
		}
		if(pBARData->vSeqData[ni]->nDataNum > 0)
		{
			for(nj=0; nj<pBARData->vSeqData[ni]->nColNum; nj++)
			{
				pBARData->vSeqData[ni]->vData[nj] = CreateDoubleMatrix(1, pBARData->vSeqData[ni]->nDataNum );
				if(pBARData->vSeqData[ni]->vData[nj] == NULL)
				{
					printf("Error: HTS_Aln2BAR, cannot allocate memory for loading bpmap coordinate data!\n");
					exit(EXIT_FAILURE);
				}
			}
		}
	}
	
	/* load data */
	fpIn = NULL;
	fpIn = fopen(strBARTmpFileName, "r");
	if(fpIn == NULL)
	{
		printf("Error: HTS_Aln2BAR, cannot open source file!\n");
		exit(EXIT_FAILURE);
	}

	strcpy(strLastChr, "");
	nSeqNum = -1;
	nProbeNum = 0;
	while(fgets(strLine, LONG_LINE_LENGTH, fpIn) != NULL)
	{
		StrTrimLeft(strLine);
		StrTrimRight(strLine);
		if(strLine[0] == '0')
			continue;
		if(strLine[0] == '#')
			continue;

		chp1 = strLine;
		chp2 = strchr(chp1, '\t');
		if(chp2 == NULL)
		{
			printf("Error: HTS_Aln2BAR, wrong input file format!\n");
			exit(EXIT_FAILURE);
		}
		*chp2 = '\0';
		StrTrimRight(chp1);
		strcpy(strChr, chp1);

		if(strcmp(strChr, strLastChr) != 0)
		{
			if(strcmp(strLastChr, "") != 0)
			{
				if(nProbeNum != (pBARData->vSeqData[nSeqNum]->nDataNum-1))
				{
					printf("Error: HTS_Aln2BAR, cannot read input file correctly!");
					exit(EXIT_FAILURE);
				}
			}

			nSeqNum++;
			strcpy(strLastChr, strChr);
			nProbeNum = 0;
		}
		else
		{
			nProbeNum++;
		}

		chp1 = chp2+1;
		chp2 = strchr(chp1, '\t');
		nk = 0;
		while(chp2 != NULL)
		{
			if(nk >= pBARData->vSeqData[nSeqNum]->nColNum)
			{
				printf("Error: HTS_Aln2BAR, input file format error, column number inconsistent!");
				exit(EXIT_FAILURE);
			}

			*chp2 = '\0';
			StrTrimLeft(chp1);
			StrTrimRight(chp1);
			pBARData->vSeqData[nSeqNum]->vData[nk]->pMatElement[nProbeNum] = atof(chp1);
			nk++;

			chp1 = chp2+1;
			chp2 = strchr(chp1, '\t');
		}

		if(nk >= pBARData->vSeqData[nSeqNum]->nColNum)
		{
			printf("Error: HTS_Aln2BAR, input file format error, column number inconsistent!");
			exit(EXIT_FAILURE);
		}
		
		StrTrimLeft(chp1);
		StrTrimRight(chp1);
		pBARData->vSeqData[nSeqNum]->vData[nk]->pMatElement[nProbeNum] = atof(chp1);
		nk++;

		if(nk != pBARData->vSeqData[nSeqNum]->nColNum)
		{
			printf("Error: HTS_Aln2BAR, input file format error, column number inconsistent!");
			exit(EXIT_FAILURE);
		}
	}

	
	/* close file */
	fclose(fpIn);

	if(nProbeNum != (pBARData->vSeqData[nSeqNum]->nDataNum-1))
	{
		printf("Error: HTS_Aln2BAR, cannot read input file correctly!");
		exit(EXIT_FAILURE);
	}

	if(nSeqNum != pBARData->nSeqNum-1)
	{
		printf("Error: HTS_Aln2BAR, cannot read input file correctly!");
		exit(EXIT_FAILURE);
	}
	
	/* write to BAR file */
	pCol = NULL;
	pCol = CreateIntMatrix(1,pBARData->nColNum);
	if(pCol == NULL)
	{
		printf("Error: HTS_Aln2BAR, cannot create output column information!\n");
		exit(EXIT_FAILURE);
	}
	
	pCol->pMatElement[0] = 1;
	pCol->pMatElement[1] = 1;
	Affy_SaveBAR_Columns_Fast(strBARFile, pBARData, pCol);
	pCol->pMatElement[1] = 0;
	pCol->pMatElement[2] = 1;
	sprintf(strTemp, "%s_F.bar", strBARFile);
	Affy_SaveBAR_Columns_Fast(strTemp, pBARData, pCol);
	pCol->pMatElement[2] = 0;
	pCol->pMatElement[3] = 1;
	sprintf(strTemp, "%s_R.bar", strBARFile);
	Affy_SaveBAR_Columns_Fast(strTemp, pBARData, pCol);
	DestroyIntMatrix(pCol);

	
	/* release memory */
	DeleteString(pSeqInfo);
	pSeqInfo = NULL;

	Affy_BARData_Destroy(&pBARData);

	RemoveFiles(strBARTmpFileName);

	/* return */
	return PROC_SUCCESS;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_WindowSummary()                                                    */
/*  Summarize window counts.                                               */
/* ----------------------------------------------------------------------- */ 
int HTS_WindowSummary(char strBARFile[], char strChrList[], char strChrLen[], 
					  int nW, char strOutFile[])
{
	/* define */
	FILE *fpIn;
	FILE *fpOut;

	struct tagBARData *pBARData = NULL;
	struct INTMATRIX *pChrLen = NULL;
	struct DOUBLEMATRIX *pCount = NULL;
	int nMaxC = 0;
	int nUpperC = 4096;
	int *vC;
	double dTotal;
	
	char strLine[LONG_LINE_LENGTH];
	int ni,nj,nk,nl,nLen;

	double dR0,dR1,dR2;
	double dlambda,dpoisp,dalpha,dbeta,dnegp;
	double dP1,dP2,dTemp;

	/* initial check */
	if(nW <= 0)
	{
		nW = 100;
		printf("Warning: Window size<=0! Proceed with default window size = 100\n");
	}

	/* load bar data */
	pBARData = NULL;
	pBARData = Affy_LoadBAR_Fast(strBARFile);
	if(pBARData == NULL)
	{
		printf("Error: HTS_WindowSummary, cannot load raw data!\n");
		exit(EXIT_FAILURE);
	}

	/* load chromosome length */
	pChrLen = IMLOAD(strChrLen);
	if(pChrLen == NULL)
	{
		printf("Error: HTS_WindowSummary, cannot load chromosome length!\n");
		exit(EXIT_FAILURE);
	}

	/* create count matrix */
	pCount = CreateDoubleMatrix(nUpperC, 1);
	if(pCount == NULL)
	{
		printf("Error: HTS_WindowSummary, cannot create count matrix!\n");
		exit(EXIT_FAILURE);
	}

	/* process chromosome one by one */
	fpIn = NULL;
	fpIn = fopen(strChrList, "r");
	if(fpIn == NULL)
	{
		printf("Error: HTS_WindowSummary, cannot open chrlist file!\n");
		exit(EXIT_FAILURE);
	}

	ni = 0;
	nMaxC = 0;
	while(fgets(strLine, LONG_LINE_LENGTH, fpIn) != NULL)
	{
		StrTrimLeft(strLine);
		StrTrimRight(strLine);
		if(strLine[0] == '\0')
			continue;
		if(strLine[0] == '#')
			continue;

		nLen = pChrLen->pMatElement[ni]/nW;
		if(pChrLen->pMatElement[ni]%nW != 0)
			nLen += 1;

		/* prepare memory */
		vC = NULL;
		vC = (int *)calloc(nLen, sizeof(int));
		if(vC == NULL)
		{
			printf("Error: HTS_WindowSummary, cannot create memory for counting!\n");
			exit(EXIT_FAILURE);
		}

		/* find matching chromosome */
		for(nj=0; nj<pBARData->nSeqNum; nj++)
		{
			if(strcmp(strLine, pBARData->vSeqData[nj]->pSeqName->m_pString) != 0)
				continue;

			for(nk=0; nk<pBARData->vSeqData[nj]->nDataNum; nk++)
			{
				nl = (int)(pBARData->vSeqData[nj]->vData[0]->pMatElement[nk])/nW;
				if(nl == nLen)
					nl = nLen-1;
				else if(nl > nLen)
				{
					printf("Error: HTS_WindowSummary, index out of range! Please check if the genomes are matching\n");
					exit(EXIT_FAILURE);
				}

				vC[nl] += (int)(pBARData->vSeqData[nj]->vData[1]->pMatElement[nk]);
			}
		}


		/* count */
		for(nj=0; nj<nLen; nj++)
		{
			nk = vC[nj];
			if(nk >= nUpperC)
				nk -= 1;

			if(nk>nMaxC)
				nMaxC = nk;

			pCount->pMatElement[nk] += 1;
		}

		/* free memory */
		free(vC);

		ni++;
	}
	
	fclose(fpIn);


	/* output summary statistics */
	fpOut = NULL;
	fpOut = fopen(strOutFile, "w");
	if(fpOut == NULL)
	{
		printf("Error: HTS_WindowSummary, cannot open output file!\n");
		exit(EXIT_FAILURE);
	}

	dTotal = 0.0;
	for(ni=0; ni<=nMaxC; ni++)
	{
		dTotal += pCount->pMatElement[ni];
	}

	/* estimate poisson and neg-binonmial */
	dR0 = pCount->pMatElement[0]/dTotal;
	dR1 = pCount->pMatElement[1]/dTotal;
	dR2 = pCount->pMatElement[2]/dTotal;
	dR2 = dR2/dR1;
	dR1 = dR1/dR0;

	dlambda = dR1;
	dpoisp = dR0/exp(-dlambda);
	if(dpoisp > 1.0)
		dpoisp = 1.0;

	dalpha = dR1/(2.0*dR2-dR1);
	dbeta = 1.0/(2.0*dR2-dR1)-1.0;
	dnegp = dR0/pow( (dbeta/(dbeta+1.0)), dalpha);
	if(dnegp > 1.0)
		dnegp = 1.0;


	fprintf(fpOut,"# Window_Size=%d\tPoisson_Lambda=%f\tPoisson_p=%f\tNegBinomial_Alpha=%f\tNegBinomial_Beta=%f\tNegBinomial_p=%f\n", nW, dlambda, dpoisp, dalpha, dbeta, dnegp);
	fprintf(fpOut, "#No_of_reads/window\tNo_of_window\tpercentage\tpoisson_expected\tpoisson_exp/obs\tnegbinomial_expected\tnegbinomial_exp/obs\n");
	for(ni=0; ni<=nMaxC; ni++)
	{
		dP1 = 0.0;
		dP1 = ni*log(dlambda)-dlambda-gammaln(ni+1.0)+log(dpoisp);
		dP1 = exp(dP1);

		dP2 = 0.0;
		dP2 = gammaln(ni+dalpha)-gammaln(ni+1.0)-gammaln(dalpha)+dalpha*log(dbeta/(dbeta+1.0))-ni*log(dbeta+1.0)+log(dnegp);
		dP2 = exp(dP2);

		dTemp = pCount->pMatElement[ni]/dTotal;
		
		fprintf(fpOut, "%d\t%d\t%f\t%f\t%f\t%f\t%f\n", ni, (int)(pCount->pMatElement[ni]), dTemp, dP1, dP1/(dTemp+1e-20), dP2, dP2/(dTemp+1e-20));
	}

	fclose(fpOut);

	/* destroy memory */
	Affy_BARData_Destroy(&pBARData);
	DestroyIntMatrix(pChrLen);
	DestroyDoubleMatrix(pCount);

	/* return */
	return PROC_SUCCESS;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_WindowSummaryv2()                                                  */
/*  Summarize window counts.                                               */
/* ----------------------------------------------------------------------- */ 
int HTS_WindowSummaryv2(char strBARFile[], char strChrList[], char strChrLen[], 
					  int nW, char strOutFile[])
{
	/* define */
	char strFileName[MED_LINE_LENGTH];
	char strFileName1[MED_LINE_LENGTH];
	char strFileName2[MED_LINE_LENGTH];
	char strFileName3[MED_LINE_LENGTH];
	FILE *fpIn;
	FILE *fpOut;
	char strLine[LONG_LINE_LENGTH];

	/* run one by one */
	sprintf(strFileName1, "%s.tmp1", strOutFile);
	sprintf(strFileName2, "%s.tmp2", strOutFile);
	sprintf(strFileName3, "%s.tmp3", strOutFile);

	HTS_WindowSummary(strBARFile, strChrList, strChrLen, nW, strFileName1);
	sprintf(strFileName, "%s_F.bar", strBARFile);
	HTS_WindowSummary(strFileName, strChrList, strChrLen, nW, strFileName2);
	sprintf(strFileName, "%s_R.bar", strBARFile);
	HTS_WindowSummary(strFileName, strChrList, strChrLen, nW, strFileName3);

	/* summarize results */
	fpOut = NULL;
	fpOut = fopen(strOutFile, "w");
	if(fpOut == NULL)
	{
		printf("Error: HTS_WindowSummaryv2, cannot open output file!\n");
		exit(EXIT_FAILURE);
	}

	fprintf(fpOut, "#Forward+Reverse_Combined\n");
	fpIn = NULL;
	fpIn = fopen(strFileName1, "r");
	if(fpIn == NULL)
	{
		printf("Error: HTS_WindowSummaryv2, cannot open input file!\n");
		exit(EXIT_FAILURE);
	}

	while(fgets(strLine, LONG_LINE_LENGTH, fpIn) != NULL)
	{
		StrTrimLeft(strLine);
		StrTrimRight(strLine);

		fprintf(fpOut, "%s\n", strLine);
	}

	fclose(fpIn);

	fprintf(fpOut, "\n#Forward_Only\n");
	fpIn = NULL;
	fpIn = fopen(strFileName2, "r");
	if(fpIn == NULL)
	{
		printf("Error: HTS_WindowSummaryv2, cannot open input file!\n");
		exit(EXIT_FAILURE);
	}

	while(fgets(strLine, LONG_LINE_LENGTH, fpIn) != NULL)
	{
		StrTrimLeft(strLine);
		StrTrimRight(strLine);

		fprintf(fpOut, "%s\n", strLine);
	}

	fclose(fpIn);

	fprintf(fpOut, "\n#Reverse_Only\n");
	fpIn = NULL;
	fpIn = fopen(strFileName3, "r");
	if(fpIn == NULL)
	{
		printf("Error: HTS_WindowSummaryv2, cannot open input file!\n");
		exit(EXIT_FAILURE);
	}

	while(fgets(strLine, LONG_LINE_LENGTH, fpIn) != NULL)
	{
		StrTrimLeft(strLine);
		StrTrimRight(strLine);

		fprintf(fpOut, "%s\n", strLine);
	}

	fclose(fpIn);

	fclose(fpOut);

	/* clear temp files */
	RemoveFiles(strFileName1);
	RemoveFiles(strFileName2);
	RemoveFiles(strFileName3);

	/* return */
	return PROC_SUCCESS;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_OneSample_Main()                                            */
/*  Find enriched region from a sequencing data set.                       */
/* ----------------------------------------------------------------------- */ 
int HTS_Enrich_OneSample_Main(char strBARFile[], int nW, int nS, int nCutoff,
					  int nMinLen, int nMaxGap,
					  char strExportFolder[], char strOutFileTitle[])
{
	/* define */
	struct tagBARData *pBARData = NULL;
	struct DOUBLEMATRIX *pRegion0;
	struct DOUBLEMATRIX *pRegion;
	char strFileName[MED_LINE_LENGTH];
	struct INTMATRIX *pType = NULL;
	struct INTMATRIX *pPriority = NULL;
	struct DOUBLEMATRIX *pRegionSort = NULL;
	struct LONGMATRIX *pRegionSid = NULL;

	/* initial check */
	AdjustDirectoryPath(strExportFolder);
	
	/* load bar data */
	pBARData = NULL;
	pBARData = Affy_LoadBAR_Fast(strBARFile);
	if(pBARData == NULL)
	{
		printf("Error: HTS_Enrich_OneSample_Main, cannot load raw data!\n");
		exit(EXIT_FAILURE);
	}

	/* initial region call */
	pRegion0 = NULL;
	pRegion0 = HTS_Enrich_OneSample_CallRegion_Initial(pBARData, nW, nS, nCutoff,
					  strExportFolder, strOutFileTitle);

	/* merge and filter regions */
	pRegion = HTS_Enrich_OneSample_MergeRegion(pRegion0, nMinLen, nMaxGap);
	DestroyDoubleMatrix(pRegion0);
	

	/* collect region information */
	HTS_Enrich_OneSample_RegionCollectInfo(pRegion, pBARData);
	
	/* sort regions */
	pType = NULL;
	pType = CreateIntMatrix(1, pRegion->nWidth);
	if(pType == NULL)
	{
		printf("Error: HTS_Enrich_OneSample_Main, cannot allocate memory for summarizing results!\n");
		exit(EXIT_FAILURE);
	}
	pType->pMatElement[0] = 2;
	pType->pMatElement[1] = 2;
	pType->pMatElement[2] = 2;
	pType->pMatElement[3] = 2;
	pType->pMatElement[4] = 2;
	pType->pMatElement[5] = 2;
	pType->pMatElement[6] = 2;

	pPriority = NULL;
	pPriority = CreateIntMatrix(1, 3);
	if(pPriority == NULL)
	{
		printf("Error: HTS_Enrich_OneSample_Main, cannot allocate memory for summarizing results!\n");
		exit(EXIT_FAILURE);
	}
	pPriority->pMatElement[0] = 4;
	pPriority->pMatElement[1] = 6;
	pPriority->pMatElement[2] = 3;

	pRegionSort = NULL;
	pRegionSid = NULL;
	DMSORTROWS(pRegion, pType, pPriority, &pRegionSort, &pRegionSid);
	
	DestroyIntMatrix(pType);
	DestroyIntMatrix(pPriority);
	DestroyDoubleMatrix(pRegion);
	
	/* export result */
	/* rank, chr, start, end, strand, length, biggest n, pos of biggest n, total reads */
	sprintf(strFileName, "%s%s.cod", strExportFolder, strOutFileTitle);
	HTS_Enrich_OneSample_ExportResults(pRegionSort, pBARData, strFileName);
	DestroyDoubleMatrix(pRegionSort);
	DestroyLongMatrix(pRegionSid);


	/* destroy memory */
	Affy_BARData_Destroy(&pBARData);

	/* return */
	return PROC_SUCCESS;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_OneSamplev2_Main()                                          */
/*  Find enriched region from a sequencing data set.                       */
/* ----------------------------------------------------------------------- */ 
int HTS_Enrich_OneSamplev2_Main_Old(char strBARFile[], int nW, int nS, int nCutoff,
					  int nCutoffF, int nCutoffR, int nMinLen, int nMaxGap,
					  char strExportFolder[], char strOutFileTitle[])
{
	/* define */
	struct tagBARData *pBARData = NULL;
	struct tagBARData *pBARDataF = NULL;
	struct tagBARData *pBARDataR = NULL;
	struct DOUBLEMATRIX *pRegion0;
	struct DOUBLEMATRIX *pRegion;
	struct DOUBLEMATRIX *pNewRegion;
	struct DOUBLEMATRIX *pRegionF;
	struct DOUBLEMATRIX *pRegionR;
	char strFileName[MED_LINE_LENGTH];
	char strOutFileName[MED_LINE_LENGTH];
	struct INTMATRIX *pType = NULL;
	struct INTMATRIX *pPriority = NULL;
	struct DOUBLEMATRIX *pRegionSort = NULL;
	struct LONGMATRIX *pRegionSid = NULL;
	int ni;

	/* initial check */
	AdjustDirectoryPath(strExportFolder);

	
	/* load bar data */
	pBARData = NULL;
	pBARData = Affy_LoadBAR_Fast(strBARFile);
	if(pBARData == NULL)
	{
		printf("Error: HTS_Enrich_OneSamplev2_Main, cannot load raw data!\n");
		exit(EXIT_FAILURE);
	}

	/* initial region call */
	pRegion0 = NULL;
	pRegion0 = HTS_Enrich_OneSample_CallRegion_Initial(pBARData, nW, nS, nCutoff,
					  strExportFolder, strOutFileTitle);

	/* merge and filter regions */
	pRegion = HTS_Enrich_OneSample_MergeRegion(pRegion0, nMinLen, nMaxGap);
	DestroyDoubleMatrix(pRegion0);

	/* load forward */
	sprintf(strFileName, "%s_F.bar", strBARFile);
	sprintf(strOutFileName, "%s_F", strOutFileTitle);
	pBARDataF = NULL;
	pBARDataF = Affy_LoadBAR_Fast(strFileName);
	if(pBARDataF == NULL)
	{
		printf("Error: HTS_Enrich_OneSamplev2_Main, cannot load raw data!\n");
		exit(EXIT_FAILURE);
	}

	/* initial region call */
	pRegion0 = NULL;
	pRegion0 = HTS_Enrich_OneSample_CallRegion_Initial(pBARDataF, nW, nS, nCutoffF,
					  strExportFolder, strOutFileName);

	/* merge and filter regions */
	pRegionF = HTS_Enrich_OneSample_MergeRegion(pRegion0, nMinLen, nMaxGap);
	DestroyDoubleMatrix(pRegion0);

	/* load reverse */
	sprintf(strFileName, "%s_R.bar", strBARFile);
	sprintf(strOutFileName, "%s_R", strOutFileTitle);
	pBARDataR = NULL;
	pBARDataR = Affy_LoadBAR_Fast(strFileName);
	if(pBARDataR == NULL)
	{
		printf("Error: HTS_Enrich_OneSamplev2_Main, cannot load raw data!\n");
		exit(EXIT_FAILURE);
	}

	/* initial region call */
	pRegion0 = NULL;
	pRegion0 = HTS_Enrich_OneSample_CallRegion_Initial(pBARDataR, nW, nS, nCutoffR,
					  strExportFolder, strOutFileName);

	/* merge and filter regions */
	pRegionR = HTS_Enrich_OneSample_MergeRegion(pRegion0, nMinLen, nMaxGap);
	DestroyDoubleMatrix(pRegion0);

	/* collect region information */
	HTS_Enrich_OneSample_RegionCollectInfo(pRegion, pBARData);
	HTS_Enrich_OneSample_RegionCollectInfo(pRegionF, pBARDataF);
	HTS_Enrich_OneSample_RegionCollectInfo(pRegionR, pBARDataR);
	
	/* match forward and reverse regions */
	pNewRegion = pRegion;
	pRegion = NULL;
	pRegion = HTS_Enrich_OneSamplev2_MatchFRRegions(pNewRegion, pRegionF, pRegionR);
	DestroyDoubleMatrix(pNewRegion);
	
	/* sort regions */
	pType = NULL;
	pType = CreateIntMatrix(1, pRegion->nWidth);
	if(pType == NULL)
	{
		printf("Error: HTS_Enrich_OneSample_Main, cannot allocate memory for summarizing results!\n");
		exit(EXIT_FAILURE);
	}
	for(ni=0; ni<pType->nWidth; ni++)
	{
		IMSETAT(pType, 0, ni, 2);
	}

	pPriority = NULL;
	pPriority = CreateIntMatrix(1, 3);
	if(pPriority == NULL)
	{
		printf("Error: HTS_Enrich_OneSample_Main, cannot allocate memory for summarizing results!\n");
		exit(EXIT_FAILURE);
	}
	pPriority->pMatElement[0] = 4;
	pPriority->pMatElement[1] = 6;
	pPriority->pMatElement[2] = 3;

	pRegionSort = NULL;
	pRegionSid = NULL;
	DMSORTROWS(pRegion, pType, pPriority, &pRegionSort, &pRegionSid);
	
	DestroyIntMatrix(pType);
	DestroyIntMatrix(pPriority);
	DestroyDoubleMatrix(pRegion);
	DestroyDoubleMatrix(pRegionF);
	DestroyDoubleMatrix(pRegionR);
	
	/* export result */
	/* rank, chr, start, end, strand, length, biggest n, pos of biggest n, total reads */
	sprintf(strFileName, "%s%s.cod", strExportFolder, strOutFileTitle);
	HTS_Enrich_OneSamplev2_ExportResults(pRegionSort, pBARData, strFileName, 0, 0, 0, 0, 0);
	DestroyDoubleMatrix(pRegionSort);
	DestroyLongMatrix(pRegionSid);


	/* destroy memory */
	Affy_BARData_Destroy(&pBARData);
	Affy_BARData_Destroy(&pBARDataF);
	Affy_BARData_Destroy(&pBARDataR);

	/* return */
	return PROC_SUCCESS;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_OneSamplev2_Main()                                          */
/*  Find enriched region from a sequencing data set.                       */
/* ----------------------------------------------------------------------- */ 
int HTS_Enrich_OneSamplev2_Main(char strBARFile[], int nW, int nS, int nCutoff, 
					  int nCutoffF, int nCutoffR, int nMinLen, int nMaxGap, 
					  char strExportFolder[], char strOutFileTitle[],
					  int nBR, int nBRL, int nSSF)
{
	/* define */
	struct tagBARData *pBARData = NULL;
	struct tagBARData *pBARDataF = NULL;
	struct tagBARData *pBARDataR = NULL;
	struct DOUBLEMATRIX *pRegion0;
	struct DOUBLEMATRIX *pRegion;
	struct DOUBLEMATRIX *pNewRegion;
	char strFileName[MED_LINE_LENGTH];
	char strOutFileName[MED_LINE_LENGTH];
	struct INTMATRIX *pType = NULL;
	struct INTMATRIX *pPriority = NULL;
	struct DOUBLEMATRIX *pRegionSort = NULL;
	struct LONGMATRIX *pRegionSid = NULL;
	int ni;

	/* initial check */
	AdjustDirectoryPath(strExportFolder);

	/* load bar data */
	pBARData = NULL;
	pBARData = Affy_LoadBAR_Fast(strBARFile);
	if(pBARData == NULL)
	{
		printf("Error: HTS_Enrich_OneSamplev2_Main, cannot load raw data!\n");
		exit(EXIT_FAILURE);
	}

	/* initial region call */
	pRegion0 = NULL;
	pRegion0 = HTS_Enrich_OneSample_CallRegion_Initial(pBARData, nW, nS, nCutoff,
					  strExportFolder, strOutFileTitle);

	/* merge and filter regions */
	pRegion = HTS_Enrich_OneSample_MergeRegion(pRegion0, nMinLen, nMaxGap);
	DestroyDoubleMatrix(pRegion0);

	/* load forward */
	sprintf(strFileName, "%s_F.bar", strBARFile);
	sprintf(strOutFileName, "%s_F", strOutFileTitle);
	pBARDataF = NULL;
	pBARDataF = Affy_LoadBAR_Fast(strFileName);
	if(pBARDataF == NULL)
	{
		printf("Error: HTS_Enrich_OneSamplev2_Main, cannot load raw data!\n");
		exit(EXIT_FAILURE);
	}

	/* initial region call */
	pRegion0 = NULL;
	pRegion0 = HTS_Enrich_OneSample_CallRegion_Initial(pBARDataF, nW, nS, nCutoffF,
					  strExportFolder, strOutFileName);
	DestroyDoubleMatrix(pRegion0);


	/* load reverse */
	sprintf(strFileName, "%s_R.bar", strBARFile);
	sprintf(strOutFileName, "%s_R", strOutFileTitle);
	pBARDataR = NULL;
	pBARDataR = Affy_LoadBAR_Fast(strFileName);
	if(pBARDataR == NULL)
	{
		printf("Error: HTS_Enrich_OneSamplev2_Main, cannot load raw data!\n");
		exit(EXIT_FAILURE);
	}

	/* initial region call */
	pRegion0 = NULL;
	pRegion0 = HTS_Enrich_OneSample_CallRegion_Initial(pBARDataR, nW, nS, nCutoffR,
					  strExportFolder, strOutFileName);
	DestroyDoubleMatrix(pRegion0);

	/* collect region information */
	HTS_Enrich_OneSample_RegionCollectInfo(pRegion, pBARData);
	pNewRegion = pRegion;
	pRegion = NULL;
	pRegion = HTS_Enrich_OneSamplev2_RegionCollectInfo(pNewRegion, pBARDataF, nW);
	DestroyDoubleMatrix(pNewRegion);
	pNewRegion = NULL;
	pNewRegion = pRegion;
	pRegion = HTS_Enrich_OneSamplev2_RegionCollectInfo(pNewRegion, pBARDataR, nW);
	DestroyDoubleMatrix(pNewRegion);

	/* sort regions */
	pType = NULL;
	pType = CreateIntMatrix(1, pRegion->nWidth);
	if(pType == NULL)
	{
		printf("Error: HTS_Enrich_OneSample_Main, cannot allocate memory for summarizing results!\n");
		exit(EXIT_FAILURE);
	}
	for(ni=0; ni<pType->nWidth; ni++)
	{
		IMSETAT(pType, 0, ni, 2);
	}

	pPriority = NULL;
	pPriority = CreateIntMatrix(1, 3);
	if(pPriority == NULL)
	{
		printf("Error: HTS_Enrich_OneSample_Main, cannot allocate memory for summarizing results!\n");
		exit(EXIT_FAILURE);
	}
	pPriority->pMatElement[0] = 4;
	pPriority->pMatElement[1] = 6;
	pPriority->pMatElement[2] = 3;

	pRegionSort = NULL;
	pRegionSid = NULL;
	DMSORTROWS(pRegion, pType, pPriority, &pRegionSort, &pRegionSid);
	
	DestroyIntMatrix(pType);
	DestroyIntMatrix(pPriority);
	DestroyDoubleMatrix(pRegion);
	
	/* export result */
	/* rank, chr, start, end, strand, length, biggest n, pos of biggest n, total reads */
	sprintf(strFileName, "%s%s.cod", strExportFolder, strOutFileTitle);
	HTS_Enrich_OneSamplev2_ExportResults(pRegionSort, pBARData, strFileName, 
		nBR, nBRL, nSSF, nCutoffF, nCutoffR);
	DestroyDoubleMatrix(pRegionSort);
	DestroyLongMatrix(pRegionSid);


	/* destroy memory */
	Affy_BARData_Destroy(&pBARData);
	Affy_BARData_Destroy(&pBARDataF);
	Affy_BARData_Destroy(&pBARDataR);

	/* return */
	return PROC_SUCCESS;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_OneSample_CallRegion_Initial()                              */
/*  Search for enriched windows.                                           */
/* ----------------------------------------------------------------------- */ 
struct DOUBLEMATRIX *HTS_Enrich_OneSample_CallRegion_Initial(struct tagBARData *pBARData,
			int nW, int nS, int nCutoff, char strExportFolder[], char strOutFileTitle[])
{
	/* define */
	FILE *fpOut;
	FILE *fpReg;
	char strWinBarTmpFile[MED_LINE_LENGTH];
	char strRegTmpFile[MED_LINE_LENGTH];
	char strFileName[MED_LINE_LENGTH];
	struct DOUBLEMATRIX *pRegion = NULL;
	int ni,nj,nk,nl,nx;
	int nP1,nP2;
	int nN;
	int nW2 = nW/2;
	int nStart,nEnd,nMaxN,nMaxNPos,nMaxNPos2;

	/* init */
	if(pBARData == NULL)
		return NULL;

	/* process one by one */
	sprintf(strWinBarTmpFile, "%s%s.bar.tmp", strExportFolder, strOutFileTitle);
	fpOut = NULL;
	fpOut = fopen(strWinBarTmpFile, "w");
	if(fpOut == NULL)
	{
		printf("Error: HTS_Enrich_OneSample_CallRegion_Initial, cannot open temporary file to write display information!\n");
		exit(EXIT_FAILURE);
	}
	fprintf(fpOut, "#chr\tpos\t%s\n", strOutFileTitle);
	fprintf(fpOut, "#chr\tpos\t1\n");

	sprintf(strRegTmpFile, "%s%s.regtmp", strExportFolder, strOutFileTitle);
	fpReg = NULL;
	fpReg = fopen(strRegTmpFile, "w");
	if(fpReg == NULL)
	{
		printf("Error: HTS_Enrich_OneSample_CallRegion_Initial, cannot open temporary file to write region information!\n");
		exit(EXIT_FAILURE);
	}

	for(ni=0; ni<pBARData->nSeqNum; ni++)
	{
		if(pBARData->vSeqData[ni]->nDataNum <= 0)
			continue;

		nx = pBARData->vSeqData[ni]->nDataNum-1;
		nP1 = (int)(pBARData->vSeqData[ni]->vData[0]->pMatElement[0])-nW;
		nP2 = (int)(pBARData->vSeqData[ni]->vData[0]->pMatElement[nx]);
		nStart = -1;
		nEnd = -1;
		nMaxN = 0;
		nMaxNPos = -1;
		nMaxNPos2 = -1;

		nN = 0;
		nk = 0;
		nl = 0;
		for(nj=nP1; nj<=nP2; nj++)
		{
			for(; nl<pBARData->vSeqData[ni]->nDataNum; nl++)
			{
				if((int)(pBARData->vSeqData[ni]->vData[0]->pMatElement[nl]) >= nj)
					break;
				
				nN -= (int)(pBARData->vSeqData[ni]->vData[1]->pMatElement[nl]);
			}

			for(; nk<pBARData->vSeqData[ni]->nDataNum; nk++)
			{
				if((int)(pBARData->vSeqData[ni]->vData[0]->pMatElement[nk]) >= (nj+nW))
					break;

				nN += (int)(pBARData->vSeqData[ni]->vData[1]->pMatElement[nk]);
			}

			if( (nj+nW2)%nS == 0)
			{
				if( ((nj+nW2)>=0) && (nN>0) )
					fprintf(fpOut, "%s\t%d\t%d\n", pBARData->vSeqData[ni]->pSeqName->m_pString, (int)(nj+nW2), nN);
			}

			if( nN>= nCutoff )
			{
				if(nStart < 0)
				{
					nStart = nj;
					nEnd = nj+nW-1;
					nMaxN = nN;
					nMaxNPos = nj+nW2;
					nMaxNPos2 = nMaxNPos;
				}
				else
				{
					nEnd = nj+nW-1;
					if(nN > nMaxN)
					{
						nMaxN = nN;
						nMaxNPos = nj+nW2;
						nMaxNPos2 = nMaxNPos;
					}
					else if(nN == nMaxN)
					{
						nMaxNPos2 = nj+nW2;
					}
				}
			}
			else
			{
				if(nStart >= 0)
				{
					fprintf(fpReg, "%d\t%d\t%d\t%d\t%d\n", ni, nStart, nEnd, nMaxN, (nMaxNPos+nMaxNPos2)/2);
					nStart = -1;
					nEnd = -1;
					nMaxN = 0;
					nMaxNPos = -1;
					nMaxNPos2 = -1;
				}
			}
		}

		if(nStart >= 0)
		{
			fprintf(fpReg, "%d\t%d\t%d\t%d\t%d\n", ni, nStart, nEnd, nMaxN, (nMaxNPos+nMaxNPos2)/2);
			nStart = -1;
			nEnd = -1;
			nMaxN = 0;
			nMaxNPos = -1;
			nMaxNPos2 = -1;
		}
	}

	fclose(fpOut);
	fclose(fpReg);

	/* load region information */
	pRegion = DMLOAD(strRegTmpFile);

	/* convert temp file to bar file */
	sprintf(strFileName, "%s.cgw", strOutFileTitle);
	TileMapv2_TXT2BAR(strWinBarTmpFile, strExportFolder, strFileName);
	
	/* remove temp file */
	RemoveFiles(strWinBarTmpFile);
	RemoveFiles(strRegTmpFile);

	/* return */
	return pRegion;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_OneSample_MergeRegion()                                     */
/*  Merge and filter regions.                                              */
/* ----------------------------------------------------------------------- */ 
struct DOUBLEMATRIX *HTS_Enrich_OneSample_MergeRegion(struct DOUBLEMATRIX *pRegion0, 
	int nMinLen, int nMaxGap)
{
	/* define */
	struct DOUBLEMATRIX *pMReg = NULL;
	struct DOUBLEMATRIX *pRegion = NULL;
	int nRegNum;
	int ni;
	int nChr0,nChr;
	int nStart0,nStart;
	int nEnd0,nEnd;
	int nMaxN0,nMaxN;
	int nMaxNPos0,nMaxNPos;
	int nIsNew;
	int nLen;

	/* init check */
	if(pRegion0 == NULL)
		return NULL;
	if(pRegion0->nHeight <= 0)
		return NULL;

	/* merge */
	pMReg = CreateDoubleMatrix(pRegion0->nHeight, pRegion0->nWidth+2);
	if(pMReg == NULL)
	{
		printf("Error: HTS_Enrich_OneSample_MergeRegion, cannot create memory for merging regions!\n");
		exit(EXIT_FAILURE);
	}

	nRegNum = 0;
	nChr0 = (int)(DMGETAT(pRegion0, 0, 0));
	nStart0 = (int)(DMGETAT(pRegion0, 0, 1));
	nEnd0 = (int)(DMGETAT(pRegion0, 0, 2));
	nMaxN0 = (int)(DMGETAT(pRegion0, 0, 3));
	nMaxNPos0 = (int)(DMGETAT(pRegion0, 0, 4));

	for(ni=1; ni<pRegion0->nHeight; ni++)
	{
		nIsNew = 0;
		nChr = (int)(DMGETAT(pRegion0, ni, 0));
		nStart = (int)(DMGETAT(pRegion0, ni, 1));
		nEnd = (int)(DMGETAT(pRegion0, ni, 2));
		nMaxN = (int)(DMGETAT(pRegion0, ni, 3));
		nMaxNPos = (int)(DMGETAT(pRegion0, ni, 4));

		if(nChr != nChr0)
		{
			nIsNew = 1;
		}
		else
		{
			if( (nStart-nEnd0) > nMaxGap)
				nIsNew = 1;
		}

		if(nIsNew == 1)
		{
			nLen = nEnd0-nStart0+1;
			if(nLen >= nMinLen)
			{
				DMSETAT(pMReg, nRegNum, 0, (double)nChr0);
				DMSETAT(pMReg, nRegNum, 1, (double)nStart0);
				DMSETAT(pMReg, nRegNum, 2, (double)nEnd0);
				DMSETAT(pMReg, nRegNum, 3, (double)nLen);
				DMSETAT(pMReg, nRegNum, 4, (double)nMaxN0);
				DMSETAT(pMReg, nRegNum, 5, (double)nMaxNPos0);
				nRegNum++;
			}

			nChr0 = nChr;
			nStart0 = nStart;
			nEnd0 = nEnd;
			nMaxN0 = nMaxN;
			nMaxNPos0 = nMaxNPos;
		}
		else
		{
			if(nEnd > nEnd0)
				nEnd0 = nEnd;
			if(nMaxN > nMaxN0)
			{
				nMaxN0 = nMaxN;
				nMaxNPos0 = nMaxNPos;
			}
		}
	}

	nLen = nEnd0-nStart0+1;
	if(nLen >= nMinLen)
	{
		DMSETAT(pMReg, nRegNum, 0, (double)nChr0);
		DMSETAT(pMReg, nRegNum, 1, (double)nStart0);
		DMSETAT(pMReg, nRegNum, 2, (double)nEnd0);
		DMSETAT(pMReg, nRegNum, 3, (double)nLen);
		DMSETAT(pMReg, nRegNum, 4, (double)nMaxN0);
		DMSETAT(pMReg, nRegNum, 5, (double)nMaxNPos0);
		nRegNum++;
	}


	/* prepare the regions */
	pRegion = CreateDoubleMatrix(nRegNum, pMReg->nWidth);
	if(pRegion == NULL)
	{
		printf("Error: HTS_Enrich_OneSample_MergeRegion, cannot create memory for merging regions!\n");
		exit(EXIT_FAILURE);
	}
	memcpy(pRegion->pMatElement, pMReg->pMatElement, (sizeof(double)*nRegNum*pMReg->nWidth));

	DestroyDoubleMatrix(pMReg);

	/* return */
	return pRegion;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_OneSample_MergeRegion()                                     */
/*  Merge and filter regions.                                              */
/* ----------------------------------------------------------------------- */ 
struct DOUBLEMATRIX *HTS_Enrich_OneSamplev2_MatchFRRegions(struct DOUBLEMATRIX *pRegion, 
		struct DOUBLEMATRIX *pRegionF, struct DOUBLEMATRIX *pRegionR)
{
	/* define */
	struct DOUBLEMATRIX *pNewRegion = NULL;
	int ni,nj,nk;
	double dTemp;
	int nChr,nStart,nEnd;

	/* init check */
	if( (pRegion == NULL) || (pRegionF == NULL) || (pRegionR == NULL) )
	{
		printf("Warning: HTS_Enrich_OneSamplev2_MatchFRRegions, empty region!\n");
		return NULL;
	}


	/* create */
	pNewRegion = CreateDoubleMatrix(pRegion->nHeight, pRegion->nWidth+10);
	if(pNewRegion == NULL)
	{
		printf("Error: HTS_Enrich_OneSamplev2_MatchFRRegions, cannot create matrix for linking regions!\n");
		exit(EXIT_FAILURE);
	}

	for(ni=0; ni<pRegion->nHeight; ni++)
	{
		nChr = (int)(DMGETAT(pRegion, ni, 0));
		nStart = (int)(DMGETAT(pRegion, ni, 1));
		nEnd = (int)(DMGETAT(pRegion, ni, 2));

		for(nj=0; nj<pRegion->nWidth; nj++)
		{
			dTemp = DMGETAT(pRegion, ni, nj);
			DMSETAT(pNewRegion, ni, nj, dTemp);
		}

		nk = HTS_Enrich_OneSamplev2_FindOverlap(pRegionF, nChr, nStart, nEnd);
		if(nk < 0)
		{
			dTemp = -1.0;
			for(; nj<(5+pRegion->nWidth); nj++)
			{
				DMSETAT(pNewRegion, ni, nj, dTemp);
			}
		}
		else
		{
			dTemp = DMGETAT(pRegionF, nk, 1);
			DMSETAT(pNewRegion, ni, nj, dTemp);
			nj++;
			dTemp = DMGETAT(pRegionF, nk, 2);
			DMSETAT(pNewRegion, ni, nj, dTemp);
			nj++;
			dTemp = DMGETAT(pRegionF, nk, 4);
			DMSETAT(pNewRegion, ni, nj, dTemp);
			nj++;
			dTemp = DMGETAT(pRegionF, nk, 5);
			DMSETAT(pNewRegion, ni, nj, dTemp);
			nj++;
			dTemp = DMGETAT(pRegionF, nk, 6);
			DMSETAT(pNewRegion, ni, nj, dTemp);
			nj++;
		}

		nk = HTS_Enrich_OneSamplev2_FindOverlap(pRegionR, nChr, nStart, nEnd);
		if(nk < 0)
		{
			dTemp = -1.0;
			for(; nj<(10+pRegion->nWidth); nj++)
			{
				DMSETAT(pNewRegion, ni, nj, dTemp);
			}
		}
		else
		{
			dTemp = DMGETAT(pRegionR, nk, 1);
			DMSETAT(pNewRegion, ni, nj, dTemp);
			nj++;
			dTemp = DMGETAT(pRegionR, nk, 2);
			DMSETAT(pNewRegion, ni, nj, dTemp);
			nj++;
			dTemp = DMGETAT(pRegionR, nk, 4);
			DMSETAT(pNewRegion, ni, nj, dTemp);
			nj++;
			dTemp = DMGETAT(pRegionR, nk, 5);
			DMSETAT(pNewRegion, ni, nj, dTemp);
			nj++;
			dTemp = DMGETAT(pRegionR, nk, 6);
			DMSETAT(pNewRegion, ni, nj, dTemp);
			nj++;
		}
	}

	/* return */
	return pNewRegion;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_OneSamplev2_FindOverlap()                                   */
/*  Find overlap region.                                                   */
/* ----------------------------------------------------------------------- */ 
int HTS_Enrich_OneSamplev2_FindOverlap(struct DOUBLEMATRIX *pRegion, 
					int nChr, int nStart, int nEnd)
{
	/* define */
	int ni,nj,nk;
	int nIdx = -1;
	int nChr2,nStart2,nEnd2;
	int nMaxN,nN;

	/* init */
	if(pRegion == NULL)
		return -1;

	ni = 0;
	nj = pRegion->nHeight-1;
	while((nj-ni) > 1)
	{
		nk = (nj+ni)/2;
		nChr2 = (int)(DMGETAT(pRegion, nk, 0));
		nStart2 = (int)(DMGETAT(pRegion, nk, 1));
		nEnd2 = (int)(DMGETAT(pRegion, nk, 2));

		if(nChr < nChr2)
		{
			nj = nk;
		}
		else if(nChr > nChr2)
		{
			ni = nk;
		}
		else if(nEnd < nStart2)
		{
			nj = nk;
		}
		else if(nStart > nEnd2)
		{
			ni = nk;
		}
		else
		{
			nIdx = nk;
			nMaxN = (int)(DMGETAT(pRegion, ni, 4));

			ni = nk-1;
			while(ni >= 0)
			{
				nChr2 = (int)(DMGETAT(pRegion, ni, 0));
				nStart2 = (int)(DMGETAT(pRegion, ni, 1));
				nEnd2 = (int)(DMGETAT(pRegion, ni, 2));
				nN = (int)(DMGETAT(pRegion, ni, 4));

				if( (nChr == nChr2) && (nStart <= nEnd2) && ( nEnd>= nStart2) )
				{
					if(nN > nMaxN)
					{
						nMaxN = nN;
						nIdx = ni;
					}
				}
				else
				{
					break;
				}

				ni--;
			}

			ni = nk+1;
			while(ni < pRegion->nHeight)
			{
				nChr2 = (int)(DMGETAT(pRegion, ni, 0));
				nStart2 = (int)(DMGETAT(pRegion, ni, 1));
				nEnd2 = (int)(DMGETAT(pRegion, ni, 2));
				nN = (int)(DMGETAT(pRegion, ni, 4));

				if( (nChr == nChr2) && (nStart <= nEnd2) && ( nEnd>= nStart2) )
				{
					if(nN > nMaxN)
					{
						nMaxN = nN;
						nIdx = ni;
					}
				}
				else
				{
					break;
				}

				ni++;
			}

			break;
		}
	}

	if(nIdx < 0)
	{
		nChr2 = (int)(DMGETAT(pRegion, ni, 0));
		nStart2 = (int)(DMGETAT(pRegion, ni, 1));
		nEnd2 = (int)(DMGETAT(pRegion, ni, 2));

		if( (nChr == nChr2) && (nStart <= nEnd2) && ( nEnd>= nStart2) )
		{
			nIdx = ni;
		}
	}

	if(nIdx < 0)
	{
		nChr2 = (int)(DMGETAT(pRegion, nj, 0));
		nStart2 = (int)(DMGETAT(pRegion, nj, 1));
		nEnd2 = (int)(DMGETAT(pRegion, nj, 2));

		if( (nChr == nChr2) && (nStart <= nEnd2) && ( nEnd>= nStart2) )
		{
			nIdx = nj;
		}
	}

	/* return */
	return nIdx;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_OneSample_ExportResults()                                   */
/*  Export results.                                                        */
/* ----------------------------------------------------------------------- */ 
int	HTS_Enrich_OneSample_ExportResults(struct DOUBLEMATRIX *pRegion, 
				struct tagBARData *pBARData, char strFileName[])
{
	/* define */
	FILE *fpOut;
	int ni,nj,nk;

	/* open file */
	fpOut = NULL;
	fpOut = fopen(strFileName, "w");
	if(fpOut == NULL)
	{
		printf("Error: HTS_Enrich_OneSample_ExportResults, cannot open output file!\n");
		exit(EXIT_FAILURE);
	}

	fprintf(fpOut, "#rank\tchr\tstart\tend\tstrand\tlength\tmaxN\tmaxN_pos\ttotal_reads\n");

	/* write */
	for(nj=0; nj<pRegion->nHeight; nj++)
	{
		ni = pRegion->nHeight-1-nj; 
		nk = (int)(DMGETAT(pRegion, ni,0));
		fprintf(fpOut, "%d\t%s\t%d\t%d\t+\t%d\t%d\t%d\t%d\n", nj+1, pBARData->vSeqData[nk]->pSeqName->m_pString,
			(int)(DMGETAT(pRegion, ni,1)), (int)(DMGETAT(pRegion, ni,2)), (int)(DMGETAT(pRegion, ni,3)),
			(int)(DMGETAT(pRegion, ni,4)), (int)(DMGETAT(pRegion, ni,5)), (int)(DMGETAT(pRegion, ni,6)));
	}

	/* close file */
	fclose(fpOut);

	/* return */
	return PROC_SUCCESS;
}


/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_OneSamplev2_ExportResults()                                 */
/*  Export results.                                                        */
/* ----------------------------------------------------------------------- */ 
int	HTS_Enrich_OneSamplev2_ExportResults_Old(struct DOUBLEMATRIX *pRegion, 
				struct tagBARData *pBARData, char strFileName[])
{
	/* define */
	FILE *fpOut;
	int ni,nj,nk;

	/* open file */
	fpOut = NULL;
	fpOut = fopen(strFileName, "w");
	if(fpOut == NULL)
	{
		printf("Error: HTS_Enrich_OneSample_ExportResults, cannot open output file!\n");
		exit(EXIT_FAILURE);
	}

	fprintf(fpOut, "#rank\tchr\tstart\tend\tstrand\tlength\tmaxN\tmaxN_pos\ttotal_reads\tFstart\tFend\tFmaxN\tFmaxN_pos\tFtot_reads\tRstart\tRend\tRmaxN\tRmaxN_pos\tRtot_reads\n");

	/* write */
	for(nj=0; nj<pRegion->nHeight; nj++)
	{
		ni = pRegion->nHeight-1-nj; 
		nk = (int)(DMGETAT(pRegion, ni,0));
		fprintf(fpOut, "%d\t%s\t%d\t%d\t+\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\n", 
			nj+1, pBARData->vSeqData[nk]->pSeqName->m_pString,
			(int)(DMGETAT(pRegion, ni,1)), (int)(DMGETAT(pRegion, ni,2)), (int)(DMGETAT(pRegion, ni,3)),
			(int)(DMGETAT(pRegion, ni,4)), (int)(DMGETAT(pRegion, ni,5)), (int)(DMGETAT(pRegion, ni,6)),
			(int)(DMGETAT(pRegion, ni,7)), (int)(DMGETAT(pRegion, ni,8)), (int)(DMGETAT(pRegion, ni,9)),
			(int)(DMGETAT(pRegion, ni,10)), (int)(DMGETAT(pRegion, ni,11)), (int)(DMGETAT(pRegion, ni,12)),
			(int)(DMGETAT(pRegion, ni,13)), (int)(DMGETAT(pRegion, ni,14)), (int)(DMGETAT(pRegion, ni,15)),
			(int)(DMGETAT(pRegion, ni,16)));
	}

	/* close file */
	fclose(fpOut);

	/* return */
	return PROC_SUCCESS;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_OneSamplev2_ExportResults()                                 */
/*  Export results.                                                        */
/* ----------------------------------------------------------------------- */ 
int	HTS_Enrich_OneSamplev2_ExportResults(struct DOUBLEMATRIX *pRegion, 
				struct tagBARData *pBARData, char strFileName[], int nBR, int nBRL,
				int nSSF, int nSSFF, int nSSFR)
{
	/* define */
	FILE *fpOut;
	int ni,nj,nk,nz;
	double dMaxN,dMinN,dTemp;
	int nRegLen1,nRegLen2,nMR,nMF,nB1,nB2,nBRW,nP1,nP2;

	/* open file */
	fpOut = NULL;
	fpOut = fopen(strFileName, "w");
	if(fpOut == NULL)
	{
		printf("Error: HTS_Enrich_OneSample_ExportResults, cannot open output file!\n");
		exit(EXIT_FAILURE);
	}

	fprintf(fpOut, "#rank\tchr\tstart\tend\tstrand\tlength\tmaxN\tmaxN_pos\ttotal_reads\tFtot_reads\tFmaxN\tFmaxN_pos\tRtot_reads\tRmaxN\tRmaxN_pos\tRmaxpos-Fmaxpos\tDelta\n");

	/* write */
	nz = 0;
	for(nj=0; nj<pRegion->nHeight; nj++)
	{
		ni = pRegion->nHeight-1-nj; 
		nk = (int)(DMGETAT(pRegion, ni, 0));
		nP1 = (int)(DMGETAT(pRegion, ni, 1));
		nP2 = (int)(DMGETAT(pRegion, ni, 2));
		nRegLen1 = (int)(DMGETAT(pRegion, ni,3));
		nB1 = (int)(DMGETAT(pRegion, ni,9));
		nB2 = (int)(DMGETAT(pRegion, ni,12));
		nRegLen2 = nB2-nB1+1;
		nMF = (int)(DMGETAT(pRegion, ni,8));
		nMR = (int)(DMGETAT(pRegion, ni,11));

		if(nSSF == 1)
		{
			if( (nMF < nSSFF) || (nMR < nSSFR) )
				continue;
		}
		if(nBR == 1)
		{
			if(nRegLen2 >= 0)
			{
				if(nRegLen2 < nBRL)
				{
					nBRW = (nBRL-nRegLen2)/2;
					nP1 = nB1-nBRW;
					nP2 = nB2+nBRW;
				}
				else
				{
					nP1 = nB1;
					nP2 = nB2;
				}
				nRegLen1 = nP2-nP1+1;
			}
		}

		fprintf(fpOut, "%d\t%s\t%d\t%d\t+\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t", 
			nz+1, pBARData->vSeqData[nk]->pSeqName->m_pString,
			nP1, nP2, nRegLen1,
			(int)(DMGETAT(pRegion, ni,4)), (int)(DMGETAT(pRegion, ni,5)), (int)(DMGETAT(pRegion, ni,6)),
			(int)(DMGETAT(pRegion, ni,7)), nMF, nB1,
			(int)(DMGETAT(pRegion, ni,10)), nMR, nB2,
			nRegLen2);

		dMaxN = DMGETAT(pRegion, ni,8);
		dMinN = DMGETAT(pRegion, ni,11);
		if(dMaxN < dMinN)
		{
			dTemp = dMinN;
			dMinN = dMaxN;
			dMaxN = dTemp;
		}
		dTemp = (dMinN+1.0)/(dMaxN+1.0);

		fprintf(fpOut, "%f\n", dTemp);
		nz++;
	}

	/* close file */
	fclose(fpOut);

	/* return */
	return PROC_SUCCESS;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_OneSample_RegionCollectInfo()                               */
/*  Collect reads number.                                                  */
/* ----------------------------------------------------------------------- */ 
int HTS_Enrich_OneSample_RegionCollectInfo(struct DOUBLEMATRIX *pRegion, struct tagBARData *pBARData)
{
	/* define */
	int ni,nj,nk,nl;
	int nChr,nStart,nEnd;
	int nP1,nP2;

	/* init */
	if( (pRegion == NULL) || (pBARData == NULL) )
		return PROC_SUCCESS;

	/* collect */
	for(ni=0; ni<pRegion->nHeight; ni++)
	{
		nChr = (int)(DMGETAT(pRegion, ni, 0));
		nStart = (int)(DMGETAT(pRegion, ni, 1));
		nEnd = (int)(DMGETAT(pRegion, ni, 2));

		if(pBARData->vSeqData[nChr]->nDataNum <= 0)
			continue;

		nj = 0;
		nk = pBARData->vSeqData[nChr]->nDataNum-1;

		if(nStart > pBARData->vSeqData[nChr]->vData[0]->pMatElement[nk])
		{
			nP1 = nk+1;
		}
		else if(nStart <= pBARData->vSeqData[nChr]->vData[0]->pMatElement[0])
		{
			nP1 = 0;
		}
		else
		{
			while( (nk-nj) > 1)
			{
				nl = (nk+nj)/2;
				if( pBARData->vSeqData[nChr]->vData[0]->pMatElement[nl] >= nStart)
				{
					nk = nl;
				}
				else
				{
					nj = nl;
				}
			}
			nP1 = nk;
		}

		nj = 0;
		nk = pBARData->vSeqData[nChr]->nDataNum-1;

		if(nEnd >= pBARData->vSeqData[nChr]->vData[0]->pMatElement[nk])
		{
			nP2 = nk;
		}
		else if(nEnd < pBARData->vSeqData[nChr]->vData[0]->pMatElement[0])
		{
			nP2 = -1;
		}
		else
		{
			while( (nk-nj) > 1)
			{
				nl = (nk+nj)/2;
				if( pBARData->vSeqData[nChr]->vData[0]->pMatElement[nl] > nEnd)
				{
					nk = nl;
				}
				else
				{
					nj = nl;
				}
			}
			nP2 = nj;
		}

		nk = 0;
		for(nj=nP1; nj<=nP2; nj++)
		{
			nk += (int)(pBARData->vSeqData[nChr]->vData[1]->pMatElement[nj]);
		}

		DMSETAT(pRegion, ni, 6, (double)nk);
	}


	/* return */
	return PROC_SUCCESS;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_OneSamplev2_RegionCollectInfo()                             */
/*  Collect forward/reverse reads info                                     */
/* ----------------------------------------------------------------------- */ 
struct DOUBLEMATRIX *HTS_Enrich_OneSamplev2_RegionCollectInfo(struct DOUBLEMATRIX *pRegion, 
				struct tagBARData *pBARData, int nW)
{
	/* define */
	struct DOUBLEMATRIX *pNewRegion = NULL;

	/* define */
	int ni,nj,nk,nl;
	int nChr,nStart,nEnd;
	int nP1,nP2,nQ1,nQ2;
	double dTemp;
	int nN = 0;
	int nMaxN = 0;
	int nMaxNPos,nMaxNPos2;
	int nW2 = nW/2;

	
	/* init */
	if( (pRegion == NULL) || (pBARData == NULL) )
		return NULL;

	pNewRegion = CreateDoubleMatrix(pRegion->nHeight, pRegion->nWidth+3);
	if(pNewRegion == NULL)
	{
		printf("Error: cannot create memory for collecting forward/reverse read information!\n");
		exit(EXIT_FAILURE);
	}

	/* collect */
	for(ni=0; ni<pRegion->nHeight; ni++)
	{
		for(nj=0; nj<pRegion->nWidth; nj++)
		{
			dTemp = DMGETAT(pRegion, ni, nj);
			DMSETAT(pNewRegion, ni, nj, dTemp);
		}

		nChr = (int)(DMGETAT(pRegion, ni, 0));
		nStart = (int)(DMGETAT(pRegion, ni, 1));
		nEnd = (int)(DMGETAT(pRegion, ni, 2));

		if(pBARData->vSeqData[nChr]->nDataNum <= 0)
			continue;

		nj = 0;
		nk = pBARData->vSeqData[nChr]->nDataNum-1;

		if(nStart > pBARData->vSeqData[nChr]->vData[0]->pMatElement[nk])
		{
			nP1 = nk+1;
		}
		else if(nStart <= pBARData->vSeqData[nChr]->vData[0]->pMatElement[0])
		{
			nP1 = 0;
		}
		else
		{
			while( (nk-nj) > 1)
			{
				nl = (nk+nj)/2;
				if( pBARData->vSeqData[nChr]->vData[0]->pMatElement[nl] >= nStart)
				{
					nk = nl;
				}
				else
				{
					nj = nl;
				}
			}
			nP1 = nk;
		}

		nj = 0;
		nk = pBARData->vSeqData[nChr]->nDataNum-1;

		if(nEnd >= pBARData->vSeqData[nChr]->vData[0]->pMatElement[nk])
		{
			nP2 = nk;
		}
		else if(nEnd < pBARData->vSeqData[nChr]->vData[0]->pMatElement[0])
		{
			nP2 = -1;
		}
		else
		{
			while( (nk-nj) > 1)
			{
				nl = (nk+nj)/2;
				if( pBARData->vSeqData[nChr]->vData[0]->pMatElement[nl] > nEnd)
				{
					nk = nl;
				}
				else
				{
					nj = nl;
				}
			}
			nP2 = nj;
		}

		nk = 0;
		for(nj=nP1; nj<=nP2; nj++)
		{
			nk += (int)(pBARData->vSeqData[nChr]->vData[1]->pMatElement[nj]);
		}

		DMSETAT(pNewRegion, ni, pRegion->nWidth, (double)nk);


		/* fine peak */
		if(nP1 > nP2)
			continue;

		nQ1 = nStart;
		nQ2 = nEnd-nW+1;

		nMaxN = -1;
		nMaxNPos = -1;
		nMaxNPos2 = -1;

		nN = 0;
		nk = nP1;
		nl = nP1;
		for(nj=nQ1; nj<=nQ2; nj++)
		{
			for(; nl<=nP2; nl++)
			{
				if((int)(pBARData->vSeqData[nChr]->vData[0]->pMatElement[nl]) >= nj)
					break;
				
				nN -= (int)(pBARData->vSeqData[nChr]->vData[1]->pMatElement[nl]);
			}

			for(; nk<=nP2; nk++)
			{
				if((int)(pBARData->vSeqData[nChr]->vData[0]->pMatElement[nk]) >= (nj+nW))
					break;

				nN += (int)(pBARData->vSeqData[nChr]->vData[1]->pMatElement[nk]);
			}

			if(nN > nMaxN)
			{
				nMaxN = nN;
				nMaxNPos = nj+nW2;
				nMaxNPos2 = nMaxNPos;
			}
			else if(nN == nMaxN)
			{
				nMaxNPos2 = nj+nW2;
			}
		}

		nMaxNPos = (nMaxNPos+nMaxNPos2)/2;
		DMSETAT(pNewRegion, ni, (pRegion->nWidth+1), (double)nMaxN);
		DMSETAT(pNewRegion, ni, (pRegion->nWidth+2), (double)nMaxNPos);
	}

	/* return */
	return pNewRegion;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_TwoSample_WindowSummary()                                          */
/*  Summarize window counts.                                               */
/* ----------------------------------------------------------------------- */ 
int HTS_TwoSample_WindowSummary(char strPosBARFile[], char strNegBARFile[],
					char strChrList[], char strChrLen[], 
					int nW, char strOutFile[])
{
	/* define */
	FILE *fpIn;
	FILE *fpOut;

	struct tagBARData *pBARDataPos = NULL;
	struct tagBARData *pBARDataNeg = NULL;
	struct INTMATRIX *pChrLen = NULL;
	struct DOUBLEMATRIX *pCount = NULL;
	struct DOUBLEMATRIX *pCount2D = NULL;
	
	struct DOUBLEMATRIX *pFDR = NULL;
	double dPi0 = 0.0;
	
	int nMaxC = 0;
	int nMaxCPos = 0;
	int nMaxCNeg = 0;
	int nUpperC = 4096;
	int *vCPos;
	int *vCNeg;

	double dTotal;
	
	char strLine[LONG_LINE_LENGTH];
	int ni,nj,nk,nl,nLen;

	double dR0,dR1,dR2;
	double dlambda,dpoisp,dalpha,dbeta,dnegp;
	double dP1,dP2,dTemp;

	/* initial check */
	if(nW <= 0)
	{
		nW = 100;
		printf("Warning: Window size<=0! Proceed with default window size = 100\n");
	}

	/* load bar data */
	pBARDataPos = NULL;
	pBARDataPos = Affy_LoadBAR_Fast(strPosBARFile);
	if(pBARDataPos == NULL)
	{
		printf("Error: HTS_TwoSample_WindowSummary, cannot load raw data!\n");
		exit(EXIT_FAILURE);
	}

	pBARDataNeg = NULL;
	pBARDataNeg = Affy_LoadBAR_Fast(strNegBARFile);
	if(pBARDataNeg == NULL)
	{
		printf("Error: HTS_TwoSample_WindowSummary, cannot load raw data!\n");
		exit(EXIT_FAILURE);
	}

	/* load chromosome length */
	pChrLen = IMLOAD(strChrLen);
	if(pChrLen == NULL)
	{
		printf("Error: HTS_TwoSample_WindowSummary, cannot load chromosome length!\n");
		exit(EXIT_FAILURE);
	}

	/* create count matrix */
	pCount = CreateDoubleMatrix(nUpperC, 1);
	if(pCount == NULL)
	{
		printf("Error: HTS_TwoSample_WindowSummary, cannot create count matrix!\n");
		exit(EXIT_FAILURE);
	}

	pCount2D = CreateDoubleMatrix(nUpperC, nUpperC);
	if(pCount2D == NULL)
	{
		printf("Error: HTS_TwoSample_WindowSummary, cannot create count matrix!\n");
		exit(EXIT_FAILURE);
	}

	/* process chromosome one by one */
	fpIn = NULL;
	fpIn = fopen(strChrList, "r");
	if(fpIn == NULL)
	{
		printf("Error: HTS_TwoSample_WindowSummary, cannot open chrlist file!\n");
		exit(EXIT_FAILURE);
	}

	ni = 0;
	nMaxCPos = 0;
	nMaxCNeg = 0;
	nMaxC = 0;
	while(fgets(strLine, LONG_LINE_LENGTH, fpIn) != NULL)
	{
		StrTrimLeft(strLine);
		StrTrimRight(strLine);
		if(strLine[0] == '\0')
			continue;
		if(strLine[0] == '#')
			continue;

		nLen = pChrLen->pMatElement[ni]/nW;
		if(pChrLen->pMatElement[ni]%nW != 0)
			nLen += 1;

		/* prepare memory */
		vCPos = NULL;
		vCPos = (int *)calloc(nLen, sizeof(int));
		if(vCPos == NULL)
		{
			printf("Error: HTS_TwoSample_WindowSummary, cannot create memory for counting!\n");
			exit(EXIT_FAILURE);
		}

		vCNeg = NULL;
		vCNeg = (int *)calloc(nLen, sizeof(int));
		if(vCNeg == NULL)
		{
			printf("Error: HTS_TwoSample_WindowSummary, cannot create memory for counting!\n");
			exit(EXIT_FAILURE);
		}

		/* find matching chromosome */
		for(nj=0; nj<pBARDataPos->nSeqNum; nj++)
		{
			if(strcmp(strLine, pBARDataPos->vSeqData[nj]->pSeqName->m_pString) != 0)
				continue;

			for(nk=0; nk<pBARDataPos->vSeqData[nj]->nDataNum; nk++)
			{
				nl = (int)(pBARDataPos->vSeqData[nj]->vData[0]->pMatElement[nk])/nW;
				if(nl == nLen)
					nl = nLen-1;
				else if(nl > nLen)
				{
					printf("Error: HTS_TwoSample_WindowSummary, index out of range! Please check if the genomes are matching\n");
					exit(EXIT_FAILURE);
				}

				vCPos[nl] += (int)(pBARDataPos->vSeqData[nj]->vData[1]->pMatElement[nk]);
			}
		}

		for(nj=0; nj<pBARDataNeg->nSeqNum; nj++)
		{
			if(strcmp(strLine, pBARDataNeg->vSeqData[nj]->pSeqName->m_pString) != 0)
				continue;

			for(nk=0; nk<pBARDataNeg->vSeqData[nj]->nDataNum; nk++)
			{
				nl = (int)(pBARDataNeg->vSeqData[nj]->vData[0]->pMatElement[nk])/nW;
				if(nl == nLen)
					nl = nLen-1;
				else if(nl > nLen)
				{
					printf("Error: HTS_TwoSample_WindowSummary, index out of range! Please check if the genomes are matching\n");
					exit(EXIT_FAILURE);
				}

				vCNeg[nl] += (int)(pBARDataNeg->vSeqData[nj]->vData[1]->pMatElement[nk]);
			}
		}

		/* count */
		for(nj=0; nj<nLen; nj++)
		{
			nk = vCPos[nj]+vCNeg[nj];
			if(nk >= nUpperC)
				nk -= 1;

			if(nk>nMaxC)
				nMaxC = nk;

			pCount->pMatElement[nk] += 1;

			nl = vCPos[nj];
			if(nl >= nUpperC)
				nl -= 1;

			if(vCPos[nj]>nMaxCPos)
				nMaxCPos = vCPos[nj];
			if(vCNeg[nj]>nMaxCNeg)
				nMaxCNeg = vCNeg[nj];


			dTemp = DMGETAT(pCount2D, nk, nl)+1.0;
			DMSETAT(pCount2D, nk, nl, dTemp);
		}

		/* free memory */
		free(vCPos);
		free(vCNeg);

		ni++;
	}
	
	fclose(fpIn);

	if(nMaxCPos >= nUpperC)
		nMaxCPos = nUpperC-1;
	if(nMaxCNeg >= nUpperC)
		nMaxCNeg = nUpperC-1;

	/* TODO: compute FDR */
	HTS_TwoSample_FDR(pCount, pCount2D, nMaxC, nMaxCPos, &pFDR, &dPi0);
	sprintf(strLine, "%s.fdr", strOutFile);
	DMSAVE(pFDR, strLine);
	DestroyDoubleMatrix(pFDR);

	/* output summary statistics */
	dTotal = 0.0;
	for(ni=0; ni<=nMaxC; ni++)
	{
		dTotal += pCount->pMatElement[ni];
	}

	/* estimate poisson and neg-binonmial */
	dR0 = pCount->pMatElement[0]/dTotal;
	dR1 = pCount->pMatElement[1]/dTotal;
	dR2 = pCount->pMatElement[2]/dTotal;
	dR2 = dR2/dR1;
	dR1 = dR1/dR0;

	dlambda = dR1;
	dpoisp = dR0/exp(-dlambda);
	if(dpoisp > 1.0)
		dpoisp = 1.0;

	dalpha = dR1/(2.0*dR2-dR1);
	dbeta = 1.0/(2.0*dR2-dR1)-1.0;
	dnegp = dR0/pow( (dbeta/(dbeta+1.0)), dalpha);
	if(dnegp > 1.0)
		dnegp = 1.0;


	fpOut = NULL;
	fpOut = fopen(strOutFile, "w");
	if(fpOut == NULL)
	{
		printf("Error: HTS_WindowSummary, cannot open output file!\n");
		exit(EXIT_FAILURE);
	}

	fprintf(fpOut, "#Window_Size=%d\tdP0_hat=%f\n", nW, dPi0);
	fprintf(fpOut, "#Poisson_Lambda=%f\tPoisson_p=%f\n", dlambda, dpoisp);
	fprintf(fpOut, "#NegBinomial_Alpha=%f\tNegBinomial_Beta=%f\tNegBinomial_p=%f\n", dalpha, dbeta, dnegp);
	fprintf(fpOut, "#No_of_reads/window\tNo_of_window\tpercentage\tpoisson_expected\tpoisson_exp/obs\tnegbinomial_expected\tnegbinomial_exp/obs\n");
	for(ni=0; ni<=nMaxC; ni++)
	{
		dP1 = 0.0;
		dP1 = ni*log(dlambda)-dlambda-gammaln(ni+1.0)+log(dpoisp);
		dP1 = exp(dP1);

		dP2 = 0.0;
		dP2 = gammaln(ni+dalpha)-gammaln(ni+1.0)-gammaln(dalpha)+dalpha*log(dbeta/(dbeta+1.0))-ni*log(dbeta+1.0)+log(dnegp);
		dP2 = exp(dP2);

		dTemp = pCount->pMatElement[ni]/dTotal;
		
		fprintf(fpOut, "%d\t%d\t%f\t%f\t%f\t%f\t%f\n", ni, (int)(pCount->pMatElement[ni]), dTemp, dP1, dP1/(dTemp+1e-20), dP2, dP2/(dTemp+1e-20));
	}

	fprintf(fpOut, "\n\n");
	fprintf(fpOut, "#total_reads/window\tpos_reads/window\n");
	fprintf(fpOut, "#");
	for(ni=0; ni<=nMaxCPos; ni++)
	{
		fprintf(fpOut, "\t%d", ni);
	}
	fprintf(fpOut, "\n");

	for(ni=0; ni<=nMaxC; ni++)
	{
		fprintf(fpOut, "%d", ni);
		for(nj=0; nj<=nMaxCPos; nj++)
		{
			dTemp = DMGETAT(pCount2D, ni, nj);
			fprintf(fpOut, "\t%d", (int)dTemp);
		}
		fprintf(fpOut, "\n");
	}

	fclose(fpOut);

	/* destroy memory */
	Affy_BARData_Destroy(&pBARDataPos);
	Affy_BARData_Destroy(&pBARDataNeg);
	DestroyIntMatrix(pChrLen);
	DestroyDoubleMatrix(pCount);
	DestroyDoubleMatrix(pCount2D);

	/* return */
	return PROC_SUCCESS;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_TwoSample_WindowSummaryv2()                                        */
/*  Summarize window counts.                                               */
/* ----------------------------------------------------------------------- */ 
int HTS_TwoSample_WindowSummaryv2(char strPosBARFile[], char strNegBARFile[],
					char strChrList[], char strChrLen[], 
					int nW, char strOutFile[])
{
	/* define */
	char strFileNamePos[MED_LINE_LENGTH];
	char strFileNameNeg[MED_LINE_LENGTH];
	char strFileName1[MED_LINE_LENGTH];
	char strFileName2[MED_LINE_LENGTH];
	FILE *fpIn;
	FILE *fpOut;
	char strLine[LONG_LINE_LENGTH];

	/* run one by one */
	sprintf(strFileName1, "%s.pos", strOutFile);
	sprintf(strFileName2, "%s.neg", strOutFile);

	HTS_TwoSample_WindowSummary(strPosBARFile, strNegBARFile,
					strChrList, strChrLen, 
					nW, strOutFile);
	
	sprintf(strFileNamePos, "%s_F.bar", strPosBARFile);
	sprintf(strFileNameNeg, "%s_F.bar", strNegBARFile);
	HTS_TwoSample_WindowSummary(strPosBARFile, strNegBARFile,
					strChrList, strChrLen, 
					nW, strFileName1);

	sprintf(strFileNamePos, "%s_R.bar", strPosBARFile);
	sprintf(strFileNameNeg, "%s_R.bar", strNegBARFile);
	HTS_TwoSample_WindowSummary(strPosBARFile, strNegBARFile,
					strChrList, strChrLen, 
					nW, strFileName2);

	/* summarize results */
	fpOut = NULL;
	fpOut = fopen(strOutFile, "at");
	if(fpOut == NULL)
	{
		printf("Error: HTS_TwoSample_WindowSummaryv2, cannot open output file!\n");
		exit(EXIT_FAILURE);
	}

	fprintf(fpOut, "\n#Forward_Only\n");
	fpIn = NULL;
	fpIn = fopen(strFileName1, "r");
	if(fpIn == NULL)
	{
		printf("Error: HTS_WindowSummaryv2, cannot open input file!\n");
		exit(EXIT_FAILURE);
	}

	while(fgets(strLine, LONG_LINE_LENGTH, fpIn) != NULL)
	{
		StrTrimLeft(strLine);
		StrTrimRight(strLine);

		fprintf(fpOut, "%s\n", strLine);
	}

	fclose(fpIn);

	fprintf(fpOut, "\n#Reverse_Only\n");
	fpIn = NULL;
	fpIn = fopen(strFileName2, "r");
	if(fpIn == NULL)
	{
		printf("Error: HTS_WindowSummaryv2, cannot open input file!\n");
		exit(EXIT_FAILURE);
	}

	while(fgets(strLine, LONG_LINE_LENGTH, fpIn) != NULL)
	{
		StrTrimLeft(strLine);
		StrTrimRight(strLine);

		fprintf(fpOut, "%s\n", strLine);
	}

	fclose(fpIn);

	fclose(fpOut);

	/* clear temp files */
	RemoveFiles(strFileName1);
	RemoveFiles(strFileName2);

	/* return */
	return PROC_SUCCESS;
}


/* ----------------------------------------------------------------------- */ 
/*  HTS_TwoSample_FDR()                                                    */
/*  Compute FDR for two sample comparison.                                 */
/* ----------------------------------------------------------------------- */ 
int HTS_TwoSample_FDR(struct DOUBLEMATRIX *pCount, struct DOUBLEMATRIX *pCount2D, 
					  int nMaxC, int nMaxCPos, struct DOUBLEMATRIX **pFDR, 
					  double *dP0)
{
	/* define */
	int nR2I = 1;
	int nR2J;
	int ni,nj;
	double dR;
	double dRCut = 2.0;
	double dPi0 = 0.5;
	double dL0,dL1;
	double dT,dE,dO,dF;
	double dTemp1,dTemp2;
	double dMaxE;
	int nMaxj;

	/* init */
	if( (nMaxC >= pCount2D->nHeight) || (nMaxCPos >= pCount2D->nWidth) )
	{
		printf("Error: HTS_TwoSample_FDR, max count inconsistent!\n");
		exit(EXIT_FAILURE);
	}

	if( (nMaxC < 1) || (nMaxCPos < 1) )
	{
		printf("Error: HTS_TwoSample_FDR, too few data to estimate FDR!\n");
		return PROC_FAILURE;
	}

	/* get p0 */
	dPi0 = (DMGETAT(pCount2D, 1, 0)+1.0)/(DMGETAT(pCount2D, 1, 1)+1.0);
	dPi0 = 1.0/(dPi0+1.0);
	(*dP0) = dPi0;
	dL0 = log(1.0-dPi0);
	dL1 = log(dPi0);

	/* get r2 cutoff */
	for(ni=1; ni<=nMaxC; ni++)
	{
		dR = pCount->pMatElement[ni]/(double)ni;
		if(dR < dRCut)
		{
			break;
		}
	}

	nR2I = ni;
	nR2J = nR2I;
	if((nMaxCPos+1) < nR2J)
		nR2J = nMaxCPos+1;

	/* get proportion, expectation, and fdr */
	(*pFDR) = NULL;
	(*pFDR) = CreateDoubleMatrix(nR2I, nR2J);
	if( *pFDR == NULL )
	{
		printf("Error: HTS_TwoSample_FDR, cannot create FDR matrix!\n");
	}

	DMSETAT((*pFDR), 0, 0, 1.0);
	for(ni=1; ni<nR2I; ni++)
	{
		dT = log(pCount->pMatElement[ni]+ni+1);
		nMaxj = -1;

		/* compute */
		for(nj=0; nj<=ni; nj++)
		{
			if(nj >= nR2J)
				break;
			
			dE = dT+gammaln((double)(ni+1))-gammaln((double)(nj+1))-gammaln((double)(ni-nj+1))+(ni-nj)*dL0+nj*dL1;
			
			if(nMaxj == -1)
			{
				nMaxj = nj;
				dMaxE = dE;
			}
			else
			{
				if(dE > dMaxE)
				{
					dMaxE = dE;
					nMaxj = nj;
				}
			}

			dE = exp(dE);

			dO = DMGETAT(pCount2D, ni, nj)+1.0;
			dF = dE/dO;
			if( dF > 1.0 )
				dF = 1.0;

			DMSETAT( (*pFDR), ni, nj, dF);
		}

		/* adjust monotonicity */
		for(nj = nMaxj-1; nj>=0; nj--)
		{
			dTemp1 = DMGETAT((*pFDR), ni, nj);
			dTemp2 = DMGETAT((*pFDR), ni, (nj+1));
			if(dTemp1 > dTemp2)
				dTemp1 = dTemp2;
			DMSETAT( (*pFDR), ni, nj, dTemp1);
		}

		for(nj = nMaxj+1; nj<=ni; nj++)
		{
			if(nj >= nR2J)
				break;

			dTemp1 = DMGETAT((*pFDR), ni, nj);
			dTemp2 = DMGETAT((*pFDR), ni, (nj-1));
			if(dTemp1 > dTemp2)
				dTemp1 = dTemp2;
			DMSETAT( (*pFDR), ni, nj, dTemp1);
		}
	}

	/* return */
	return PROC_SUCCESS;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_TwoSample_Main()                                            */
/*  Find enriched region from a sequencing data set.                       */
/* ----------------------------------------------------------------------- */ 
int HTS_Enrich_TwoSample_Main(char strPosBARFile[], char strNegBARFile[], 
					  int nOneSide, int nW, int nS, int nTCut, char strFDRFile[], double dFDRCut,
					  int nMinLen, int nMaxGap, double dP0,
					  char strExportFolder[], char strOutFileTitle[])
{
	/* define */
	struct tagBARData *pBARDataPos = NULL;
	struct tagBARData *pBARDataNeg = NULL;
	struct DOUBLEMATRIX *pFDR = NULL;

	struct DOUBLEMATRIX *pRegion0;
	struct DOUBLEMATRIX *pRegion;
	char strFileName[MED_LINE_LENGTH];
	struct INTMATRIX *pType = NULL;
	struct INTMATRIX *pPriority = NULL;
	struct DOUBLEMATRIX *pRegionSort = NULL;
	struct LONGMATRIX *pRegionSid = NULL;

	/* initial check */
	AdjustDirectoryPath(strExportFolder);
	
	/* load bar data */
	pBARDataPos = NULL;
	pBARDataPos = Affy_LoadBAR_Fast(strPosBARFile);
	if(pBARDataPos == NULL)
	{
		printf("Error: HTS_Enrich_TwoSample_Main, cannot load raw data!\n");
		exit(EXIT_FAILURE);
	}

	pBARDataNeg = NULL;
	pBARDataNeg = Affy_LoadBAR_Fast(strNegBARFile);
	if(pBARDataNeg == NULL)
	{
		printf("Error: HTS_Enrich_TwoSample_Main, cannot load raw data!\n");
		exit(EXIT_FAILURE);
	}

	pFDR = NULL;
	pFDR = DMLOAD(strFDRFile);
	if(pFDR == NULL)
	{
		printf("Error: HTS_Enrich_TwoSample_Main, cannot load FDR!\n");
		exit(EXIT_FAILURE);
	}


	/* initial region call */
	pRegion0 = NULL;
	pRegion0 = HTS_Enrich_TwoSample_CallRegion_Initial(pBARDataPos, pBARDataNeg,
					  nW, nS, nTCut, pFDR, dFDRCut, dP0, nOneSide,
					  strExportFolder, strOutFileTitle);

	/* merge and filter regions */
	pRegion = HTS_Enrich_TwoSample_MergeRegion(pRegion0, nMinLen, nMaxGap);
	DestroyDoubleMatrix(pRegion0);
	

	/* collect region information */
	HTS_Enrich_TwoSample_RegionCollectInfo(pRegion, pBARDataPos, pBARDataNeg);
	
	/* sort regions */
	pType = NULL;
	pType = CreateIntMatrix(1, pRegion->nWidth);
	if(pType == NULL)
	{
		printf("Error: HTS_Enrich_TwoSample_Main, cannot allocate memory for summarizing results!\n");
		exit(EXIT_FAILURE);
	}
	pType->pMatElement[0] = 2;
	pType->pMatElement[1] = 2;
	pType->pMatElement[2] = 2;
	pType->pMatElement[3] = 2;
	pType->pMatElement[4] = 2;
	pType->pMatElement[5] = 1;
	pType->pMatElement[6] = 2;
	pType->pMatElement[7] = 1;
	pType->pMatElement[8] = 2;
	pType->pMatElement[9] = 2;
	pType->pMatElement[10] = 2;

	pPriority = NULL;
	pPriority = CreateIntMatrix(1, 3);
	if(pPriority == NULL)
	{
		printf("Error: HTS_Enrich_OneSample_Main, cannot allocate memory for summarizing results!\n");
		exit(EXIT_FAILURE);
	}
	pPriority->pMatElement[0] = 5;
	pPriority->pMatElement[1] = 7;
	pPriority->pMatElement[2] = 4;

	pRegionSort = NULL;
	pRegionSid = NULL;
	DMSORTROWS(pRegion, pType, pPriority, &pRegionSort, &pRegionSid);
	
	DestroyIntMatrix(pType);
	DestroyIntMatrix(pPriority);
	DestroyDoubleMatrix(pRegion);
	
	/* export result */
	/* rank, chr, start, end, strand, length, biggest n, pos of biggest n, total reads */
	sprintf(strFileName, "%s%s.cod", strExportFolder, strOutFileTitle);
	HTS_Enrich_TwoSample_ExportResults(pRegionSort, pBARDataPos, pBARDataNeg, strFileName);
	DestroyDoubleMatrix(pRegionSort);
	DestroyLongMatrix(pRegionSid);


	/* destroy memory */
	Affy_BARData_Destroy(&pBARDataPos);
	Affy_BARData_Destroy(&pBARDataNeg);
	DestroyDoubleMatrix(pFDR);

	/* return */
	return PROC_SUCCESS;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_TwoSamplev2_Main()                                          */
/*  Find enriched region from a sequencing data set.                       */
/* ----------------------------------------------------------------------- */ 
int HTS_Enrich_TwoSamplev2_Main(char strPosBARFile[], char strNegBARFile[], 
					  int nOneSide, int nW, int nS, int nTCut, char strFDRFile[], double dFDRCut,
					  int nMinLen, int nMaxGap, double dP0,
					  char strExportFolder[], char strOutFileTitle[],
					  int nBR, int nBRL, int nSSF, int nSSFF, int nSSFR)
{
	/* define */
	struct tagBARData *pBARDataPos = NULL;
	struct tagBARData *pBARDataNeg = NULL;
	struct DOUBLEMATRIX *pFDR = NULL;
	struct DOUBLEMATRIX *pFDRF = NULL;
	struct DOUBLEMATRIX *pFDRR = NULL;

	struct tagBARData *pBARDataPosF = NULL;
	struct tagBARData *pBARDataNegF = NULL;
	struct tagBARData *pBARDataPosR = NULL;
	struct tagBARData *pBARDataNegR = NULL;
	

	struct DOUBLEMATRIX *pRegion0;
	struct DOUBLEMATRIX *pRegion;
	struct DOUBLEMATRIX *pNewRegion;
	char strFileName[MED_LINE_LENGTH];
	struct INTMATRIX *pType = NULL;
	struct INTMATRIX *pPriority = NULL;
	struct DOUBLEMATRIX *pRegionSort = NULL;
	struct LONGMATRIX *pRegionSid = NULL;
	int ni;
	char *chp;

	/* initial check */
	AdjustDirectoryPath(strExportFolder);
	
	/* load bar data */
	pBARDataPos = NULL;
	pBARDataPos = Affy_LoadBAR_Fast(strPosBARFile);
	if(pBARDataPos == NULL)
	{
		printf("Error: HTS_Enrich_TwoSample_Main, cannot load raw data!\n");
		exit(EXIT_FAILURE);
	}

	pBARDataNeg = NULL;
	pBARDataNeg = Affy_LoadBAR_Fast(strNegBARFile);
	if(pBARDataNeg == NULL)
	{
		printf("Error: HTS_Enrich_TwoSample_Main, cannot load raw data!\n");
		exit(EXIT_FAILURE);
	}

	pFDR = NULL;
	pFDR = DMLOAD(strFDRFile);
	if(pFDR == NULL)
	{
		printf("Error: HTS_Enrich_TwoSample_Main, cannot load FDR!\n");
		exit(EXIT_FAILURE);
	}

	chp = strstr(strFDRFile, ".fdr");
	if(chp == NULL)
	{
		printf("Error: HTS_Enrich_TwoSample_Main, FDR file needs to be ended with .fdr!\n");
		exit(EXIT_FAILURE);
	}
	*chp = '\0';
	sprintf(strFileName, "%s.pos.fdr", strFDRFile);
	pFDRF = NULL;
	pFDRF = DMLOAD(strFileName);
	if(pFDRF == NULL)
	{
		printf("Error: HTS_Enrich_TwoSample_Main, cannot load FDR!\n");
		exit(EXIT_FAILURE);
	}
	sprintf(strFileName, "%s.neg.fdr", strFDRFile);
	pFDRR = NULL;
	pFDRR = DMLOAD(strFileName);
	if(pFDRR == NULL)
	{
		printf("Error: HTS_Enrich_TwoSample_Main, cannot load FDR!\n");
		exit(EXIT_FAILURE);
	}


	/* initial region call */
	pRegion0 = NULL;
	pRegion0 = HTS_Enrich_TwoSample_CallRegion_Initial(pBARDataPos, pBARDataNeg,
					  nW, nS, nTCut, pFDR, dFDRCut, dP0, nOneSide,
					  strExportFolder, strOutFileTitle);

	/* merge and filter regions */
	pRegion = HTS_Enrich_TwoSample_MergeRegion(pRegion0, nMinLen, nMaxGap);
	DestroyDoubleMatrix(pRegion0);
	

	/* collect region information */
	HTS_Enrich_TwoSample_RegionCollectInfo(pRegion, pBARDataPos, pBARDataNeg);

	/* process forward */
	/* load bar data */
	sprintf(strFileName, "%s_F.bar", strPosBARFile);
	pBARDataPosF = NULL;
	pBARDataPosF = Affy_LoadBAR_Fast(strFileName);
	if(pBARDataPosF == NULL)
	{
		printf("Error: HTS_Enrich_TwoSample_Main, cannot load raw data!\n");
		exit(EXIT_FAILURE);
	}

	sprintf(strFileName, "%s_F.bar", strNegBARFile);
	pBARDataNegF = NULL;
	pBARDataNegF = Affy_LoadBAR_Fast(strFileName);
	if(pBARDataNegF == NULL)
	{
		printf("Error: HTS_Enrich_TwoSample_Main, cannot load raw data!\n");
		exit(EXIT_FAILURE);
	}

	/* initial region call */
	sprintf(strFileName, "%s_F", strOutFileTitle);
	pRegion0 = NULL;
	pRegion0 = HTS_Enrich_TwoSample_CallRegion_Initial(pBARDataPosF, pBARDataNegF,
					  nW, nS, nTCut, pFDR, dFDRCut, dP0, nOneSide,
					  strExportFolder, strFileName);
	DestroyDoubleMatrix(pRegion0);

	/* process reverse */
	/* load bar data */
	sprintf(strFileName, "%s_R.bar", strPosBARFile);
	pBARDataPosR = NULL;
	pBARDataPosR = Affy_LoadBAR_Fast(strFileName);
	if(pBARDataPosR == NULL)
	{
		printf("Error: HTS_Enrich_TwoSample_Main, cannot load raw data!\n");
		exit(EXIT_FAILURE);
	}

	sprintf(strFileName, "%s_R.bar", strNegBARFile);
	pBARDataNegR = NULL;
	pBARDataNegR = Affy_LoadBAR_Fast(strFileName);
	if(pBARDataNegR == NULL)
	{
		printf("Error: HTS_Enrich_TwoSample_Main, cannot load raw data!\n");
		exit(EXIT_FAILURE);
	}

	/* initial region call */
	sprintf(strFileName, "%s_R", strOutFileTitle);
	pRegion0 = NULL;
	pRegion0 = HTS_Enrich_TwoSample_CallRegion_Initial(pBARDataPosR, pBARDataNegR,
					  nW, nS, nTCut, pFDR, dFDRCut, dP0, nOneSide,
					  strExportFolder, strFileName);
	DestroyDoubleMatrix(pRegion0);
	

	pNewRegion = pRegion;
	pRegion = NULL;
	pRegion = HTS_Enrich_TwoSamplev2_RegionCollectInfo(pNewRegion, pBARDataPosF, pBARDataNegF, nW, pFDRF, dP0, nOneSide);
	DestroyDoubleMatrix(pNewRegion);
	pNewRegion = NULL;
	pNewRegion = pRegion;
	pRegion = HTS_Enrich_TwoSamplev2_RegionCollectInfo(pNewRegion, pBARDataPosR, pBARDataNegR, nW, pFDRR, dP0, nOneSide);
	DestroyDoubleMatrix(pNewRegion);

	/* sort regions */
	pType = NULL;
	pType = CreateIntMatrix(1, pRegion->nWidth);
	if(pType == NULL)
	{
		printf("Error: HTS_Enrich_TwoSample_Main, cannot allocate memory for summarizing results!\n");
		exit(EXIT_FAILURE);
	}
	for(ni=0; ni<pType->nWidth; ni++)
		pType->pMatElement[ni] = 2;
	pType->pMatElement[5] = 1;
	pType->pMatElement[7] = 1;
	
	pPriority = NULL;
	pPriority = CreateIntMatrix(1, 3);
	if(pPriority == NULL)
	{
		printf("Error: HTS_Enrich_TwoSample_Main, cannot allocate memory for summarizing results!\n");
		exit(EXIT_FAILURE);
	}
	pPriority->pMatElement[0] = 5;
	pPriority->pMatElement[1] = 7;
	pPriority->pMatElement[2] = 4;

	pRegionSort = NULL;
	pRegionSid = NULL;
	DMSORTROWS(pRegion, pType, pPriority, &pRegionSort, &pRegionSid);
	
	DestroyIntMatrix(pType);
	DestroyIntMatrix(pPriority);
	DestroyDoubleMatrix(pRegion);
	
	/* export result */
	/* rank, chr, start, end, strand, length, biggest n, pos of biggest n, total reads */
	sprintf(strFileName, "%s%s.cod", strExportFolder, strOutFileTitle);
	HTS_Enrich_TwoSamplev2_ExportResults(pRegionSort, pBARDataPos, pBARDataNeg, strFileName, 
		nBR, nBRL, nSSF, nSSFF, nSSFR);
	DestroyDoubleMatrix(pRegionSort);
	DestroyLongMatrix(pRegionSid);


	/* destroy memory */
	Affy_BARData_Destroy(&pBARDataPos);
	Affy_BARData_Destroy(&pBARDataNeg);
	Affy_BARData_Destroy(&pBARDataPosF);
	Affy_BARData_Destroy(&pBARDataNegF);
	Affy_BARData_Destroy(&pBARDataPosR);
	Affy_BARData_Destroy(&pBARDataNegR);
	DestroyDoubleMatrix(pFDR);
	DestroyDoubleMatrix(pFDRF);
	DestroyDoubleMatrix(pFDRR);

	/* return */
	return PROC_SUCCESS;
}


/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_TwoSample_CallRegion_Initial()                              */
/*  Search for differentially expressed windows.                           */
/* ----------------------------------------------------------------------- */ 
struct DOUBLEMATRIX *HTS_Enrich_TwoSample_CallRegion_Initial(struct tagBARData *pBARDataPos,
			struct tagBARData *pBARDataNeg, int nW, int nS, int nTCut,
			struct DOUBLEMATRIX *pFDR, double dFDRCut, double dP0, int nOneSide,
			char strExportFolder[], char strOutFileTitle[])
{
	/* define */
	FILE *fpOut;
	FILE *fpReg;

	char strWinBarTmpFile[MED_LINE_LENGTH];
	int nCmpResult;
	double dR0 = dP0/(1.0-dP0);
	double dLog2 = log(2.0);
	
	char strRegTmpFile[MED_LINE_LENGTH];
	char strFileName[MED_LINE_LENGTH];
	struct DOUBLEMATRIX *pRegion = NULL;
	int ni1,ni2,nj,nk,nl,nk2,nl2,nx;
	int nP1,nP2;
	int nN1,nN2,nN;
	int nN1Sub,nNSub;
	double dFC,dTemp;
	int nW2 = nW/2;
	int nStart,nEnd;
	double dMinFDR;
	int nMinFDRPos1;
	int nMinFDRPos2;
	double dMaxFC;
	int nMaxFCPos1;
	int nMaxFCPos2;
	double dMinFC;
	int nMinFCPos1;
	int nMinFCPos2;
	int nPosSide;


	/* init */
	if((pBARDataPos == NULL) || (pBARDataNeg == NULL))
		return NULL;

	/* process one by one */
	sprintf(strWinBarTmpFile, "%s%s.bar.tmp", strExportFolder, strOutFileTitle);
	
	fpOut = NULL;
	fpOut = fopen(strWinBarTmpFile, "w");
	if(fpOut == NULL)
	{
		printf("Error: HTS_Enrich_TwoSample_CallRegion_Initial, cannot open temporary file to write display information!\n");
		exit(EXIT_FAILURE);
	}
	fprintf(fpOut, "#chr\tpos\t%s.pos\t%s.neg\t%s.log2fc\n", strOutFileTitle, strOutFileTitle, strOutFileTitle);
	fprintf(fpOut, "#chr\tpos\t1\t1\t1\n");

	sprintf(strRegTmpFile, "%s%s.regtmp", strExportFolder, strOutFileTitle);
	fpReg = NULL;
	fpReg = fopen(strRegTmpFile, "w");
	if(fpReg == NULL)
	{
		printf("Error: HTS_Enrich_TwoSample_CallRegion_Initial, cannot open temporary file to write region information!\n");
		exit(EXIT_FAILURE);
	}

	ni1 = 0;
	ni2 = 0;
	while( (ni1<pBARDataPos->nSeqNum) || (ni2<pBARDataNeg->nSeqNum) )
	{
		if( (ni1<pBARDataPos->nSeqNum) && (ni2<pBARDataNeg->nSeqNum) )
			nCmpResult = strcmp(pBARDataPos->vSeqData[ni1]->pSeqName->m_pString, pBARDataNeg->vSeqData[ni2]->pSeqName->m_pString);
		else if( ni1<pBARDataPos->nSeqNum )
			nCmpResult = -1;
		else
			nCmpResult = 1;

		/* process both bar_pos and bar_neg only */
		if(nCmpResult == 0)
		{
			if( (pBARDataPos->vSeqData[ni1]->nDataNum <= 0) && (pBARDataNeg->vSeqData[ni2]->nDataNum <= 0) )
			{
				ni1++;
				ni2++;
				continue;
			}

			if( pBARDataPos->vSeqData[ni1]->nDataNum > 0)
			{
				nx = pBARDataPos->vSeqData[ni1]->nDataNum-1;
				nP1 = (int)(pBARDataPos->vSeqData[ni1]->vData[0]->pMatElement[0])-nW;
				nP2 = (int)(pBARDataPos->vSeqData[ni1]->vData[0]->pMatElement[nx]);
			
				if( pBARDataNeg->vSeqData[ni2]->nDataNum > 0)
				{
					nx = pBARDataNeg->vSeqData[ni2]->nDataNum-1;
					if( (int)(pBARDataNeg->vSeqData[ni2]->vData[0]->pMatElement[0])-nW < nP1)
						nP1 = (int)(pBARDataNeg->vSeqData[ni2]->vData[0]->pMatElement[0])-nW;
					if( (int)(pBARDataNeg->vSeqData[ni2]->vData[0]->pMatElement[nx]) > nP2)
						nP2 = (int)(pBARDataNeg->vSeqData[ni2]->vData[0]->pMatElement[nx]);
				}
			}
			else
			{
				nx = pBARDataNeg->vSeqData[ni2]->nDataNum-1;
				nP1 = (int)(pBARDataNeg->vSeqData[ni2]->vData[0]->pMatElement[0])-nW;
				nP2 = (int)(pBARDataNeg->vSeqData[ni2]->vData[0]->pMatElement[nx]);
			}
			
			nStart = -1;
			nEnd = -1;

			dMinFDR = 1.0;
			nMinFDRPos1 = -1;
			nMinFDRPos2 = -1;

			dMaxFC = 0.0;
			nMaxFCPos1 = -1;
			nMaxFCPos2 = -1;

			dMinFC = 0.0;
			nMinFCPos1 = -1;
			nMinFCPos2 = -1;


			nN1 = 0;
			nN2 = 0;
			dFC = 0.0;
			nk = 0;
			nl = 0;
			nk2 = 0;
			nl2 = 0;
			for(nj=nP1; nj<=nP2; nj++)
			{
				for(; nl<pBARDataPos->vSeqData[ni1]->nDataNum; nl++)
				{
					if((int)(pBARDataPos->vSeqData[ni1]->vData[0]->pMatElement[nl]) >= nj)
						break;
					
					nN1 -= (int)(pBARDataPos->vSeqData[ni1]->vData[1]->pMatElement[nl]);
				}

				for(; nk<pBARDataPos->vSeqData[ni1]->nDataNum; nk++)
				{
					if((int)(pBARDataPos->vSeqData[ni1]->vData[0]->pMatElement[nk]) >= (nj+nW))
						break;

					nN1 += (int)(pBARDataPos->vSeqData[ni1]->vData[1]->pMatElement[nk]);
				}

				for(; nl2<pBARDataNeg->vSeqData[ni2]->nDataNum; nl2++)
				{
					if((int)(pBARDataNeg->vSeqData[ni2]->vData[0]->pMatElement[nl2]) >= nj)
						break;
					
					nN2 -= (int)(pBARDataNeg->vSeqData[ni2]->vData[1]->pMatElement[nl2]);
				}

				for(; nk2<pBARDataNeg->vSeqData[ni2]->nDataNum; nk2++)
				{
					if((int)(pBARDataNeg->vSeqData[ni2]->vData[0]->pMatElement[nk2]) >= (nj+nW))
						break;

					nN2 += (int)(pBARDataNeg->vSeqData[ni2]->vData[1]->pMatElement[nk2]);
				}

				dTemp = nN2*dR0;
				if(dTemp < (double)nN1)
				{
					dFC = log((double)(nN1+1)/(dTemp+1.0))/dLog2;
				}
				else
				{
					dFC = -log((dTemp+1.0)/(double)(nN1+1))/dLog2;
				}

				nN = nN1+nN2;
				
				if( (nj+nW2)%nS == 0)
				{
					if( ((nj+nW2)>=0) && (nN>0) )
						fprintf(fpOut, "%s\t%d\t%d\t%d\t%f\n", pBARDataPos->vSeqData[ni1]->pSeqName->m_pString, (int)(nj+nW2), nN1, nN2, dFC);
				}

				/* get fdr */
				nN1Sub = nN1;
				if(nN < pFDR->nHeight)
				{
					if(nN1 >= pFDR->nWidth)
						nN1Sub = pFDR->nWidth-1;

					dTemp = DMGETAT(pFDR, nN, nN1Sub);
				}
				else
				{
					nNSub = pFDR->nHeight-1;
					dTemp = (double)(nNSub*nN1)/(double)nN;
					nN1Sub = (int)dTemp;
					if(dTemp-nN1Sub > 0.5)
						nN1Sub += 1;
					
					if(nN1Sub >= pFDR->nWidth)
						nN1Sub = pFDR->nWidth-1;

					dTemp = DMGETAT(pFDR, nNSub, nN1Sub);
				}

				if( nOneSide == 1 )
				{
					if( dFC < 0.0 )
						dTemp = 1.0;
				}

				if( (nN >= nTCut) && (dTemp <= dFDRCut) )
				{
					if(nStart < 0)
					{
						nStart = nj;
						nEnd = nj+nW-1;

						dMinFDR = dTemp;
						nMinFDRPos1 = nj+nW2;
						nMinFDRPos2 = nMinFDRPos1;
						if(dFC >= 0.0)
							nPosSide = 1;
						else
							nPosSide = 0;

						dMaxFC = dFC;
						nMaxFCPos1 = nj+nW2;
						nMaxFCPos2 = nMaxFCPos1;

						dMinFC = dFC;
						nMinFCPos1 = nj+nW2;
						nMinFCPos2 = nMinFCPos1;
					}
					else
					{
						nEnd = nj+nW-1;

						if( fabs(dTemp-dMinFDR) < 1e-10 )
						{
							nMinFDRPos2 = nj+nW2;
						}
						else if(dTemp < dMinFDR)
						{
							dMinFDR = dTemp;
							nMinFDRPos1 = nj+nW2;
							nMinFDRPos2 = nMinFDRPos1;

							if(dFC >= 0.0)
								nPosSide = 1;
							else
								nPosSide = 0;
						}

						if( fabs(dFC-dMaxFC) < 1e-10 )
						{
							nMaxFCPos2 = nj+nW2;
						}
						else if(dFC > dMaxFC)
						{
							dMaxFC = dFC;
							nMaxFCPos1 = nj+nW2;
							nMaxFCPos2 = nMaxFCPos1;
						}

						if( fabs(dFC-dMinFC) < 1e-10 )
						{
							nMinFCPos2 = nj+nW2;
						}
						else if(dFC < dMinFC)
						{
							dMinFC = dFC;
							nMinFCPos1 = nj+nW2;
							nMinFCPos2 = nMinFCPos1;
						}
					}
				}
				else
				{
					if(nStart >= 0)
					{
						if(nPosSide == 1)
						{
							fprintf(fpReg, "0\t%d\t%d\t%d\t%f\t%d\t%f\t%d\n", ni1, nStart, nEnd, 
								dMinFDR, (nMinFDRPos1+nMinFDRPos2)/2,
								dMaxFC, (nMaxFCPos1+nMaxFCPos2)/2);
						}
						else
						{
							fprintf(fpReg, "0\t%d\t%d\t%d\t%f\t%d\t%f\t%d\n", ni1, nStart, nEnd, 
								dMinFDR, (nMinFDRPos1+nMinFDRPos2)/2,
								dMinFC, (nMinFCPos1+nMinFCPos2)/2);
						}
						nStart = -1;
						nEnd = -1;
						
						dMinFDR = 1.0;
						nMinFDRPos1 = -1;
						nMinFDRPos2 = -1;

						dMaxFC = 0.0;
						nMaxFCPos1 = -1;
						nMaxFCPos2 = -1;

						dMinFC = 0.0;
						nMinFCPos1 = -1;
						nMinFCPos2 = -1;
					}
				}
			}

			if(nStart >= 0)
			{
				if(nPosSide == 1)
				{
					fprintf(fpReg, "0\t%d\t%d\t%d\t%f\t%d\t%f\t%d\n", ni1, nStart, nEnd, 
						dMinFDR, (nMinFDRPos1+nMinFDRPos2)/2,
						dMaxFC, (nMaxFCPos1+nMaxFCPos2)/2);
				}
				else
				{
					fprintf(fpReg, "0\t%d\t%d\t%d\t%f\t%d\t%f\t%d\n", ni1, nStart, nEnd, 
						dMinFDR, (nMinFDRPos1+nMinFDRPos2)/2,
						dMinFC, (nMinFCPos1+nMinFCPos2)/2);
				}
				nStart = -1;
				nEnd = -1;
				dMinFDR = 1.0;
				nMinFDRPos1 = -1;
				nMinFDRPos2 = -1;

				dMaxFC = 0.0;
				nMaxFCPos1 = -1;
				nMaxFCPos2 = -1;

				dMinFC = 0.0;
				nMinFCPos1 = -1;
				nMinFCPos2 = -1;
			}

			ni1++;
			ni2++;
		}

		/* process bar_pos only */
		else if(nCmpResult < 0)
		{
			if(pBARDataPos->vSeqData[ni1]->nDataNum <= 0)
			{
				ni1++;
				continue;
			}

			nx = pBARDataPos->vSeqData[ni1]->nDataNum-1;
			nP1 = (int)(pBARDataPos->vSeqData[ni1]->vData[0]->pMatElement[0])-nW;
			nP2 = (int)(pBARDataPos->vSeqData[ni1]->vData[0]->pMatElement[nx]);
			nStart = -1;
			nEnd = -1;

			dMinFDR = 1.0;
			nMinFDRPos1 = -1;
			nMinFDRPos2 = -1;

			dMaxFC = 0.0;
			nMaxFCPos1 = -1;
			nMaxFCPos2 = -1;

			dMinFC = 0.0;
			nMinFCPos1 = -1;
			nMinFCPos2 = -1;


			nN1 = 0;
			nN2 = 0;
			dFC = 0.0;
			nk = 0;
			nl = 0;
			for(nj=nP1; nj<=nP2; nj++)
			{
				for(; nl<pBARDataPos->vSeqData[ni1]->nDataNum; nl++)
				{
					if((int)(pBARDataPos->vSeqData[ni1]->vData[0]->pMatElement[nl]) >= nj)
						break;
					
					nN1 -= (int)(pBARDataPos->vSeqData[ni1]->vData[1]->pMatElement[nl]);
				}

				for(; nk<pBARDataPos->vSeqData[ni1]->nDataNum; nk++)
				{
					if((int)(pBARDataPos->vSeqData[ni1]->vData[0]->pMatElement[nk]) >= (nj+nW))
						break;

					nN1 += (int)(pBARDataPos->vSeqData[ni1]->vData[1]->pMatElement[nk]);
				}

				dTemp = nN2*dR0;
				if(dTemp < (double)nN1)
				{
					dFC = log((double)(nN1+1)/(dTemp+1.0))/dLog2;
				}
				else
				{
					dFC = -log((dTemp+1.0)/(double)(nN1+1))/dLog2;
				}

				
				nN = nN1+nN2;

				if( (nj+nW2)%nS == 0)
				{
					if( ((nj+nW2)>=0) && (nN>0) )
						fprintf(fpOut, "%s\t%d\t%d\t%d\t%f\n", pBARDataPos->vSeqData[ni1]->pSeqName->m_pString, (int)(nj+nW2), nN1, nN2, dFC);
				}

				/* get fdr */
				nN1Sub = nN1;
				if(nN < pFDR->nHeight)
				{
					if(nN1 >= pFDR->nWidth)
						nN1Sub = pFDR->nWidth-1;

					dTemp = DMGETAT(pFDR, nN, nN1Sub);
				}
				else
				{
					nNSub = pFDR->nHeight-1;
					dTemp = (double)(nNSub*nN1)/(double)nN;
					nN1Sub = (int)dTemp;
					if(dTemp-nN1Sub > 0.5)
						nN1Sub += 1;
					
					if(nN1Sub >= pFDR->nWidth)
						nN1Sub = pFDR->nWidth-1;

					dTemp = DMGETAT(pFDR, nNSub, nN1Sub);
				}

				if( nOneSide == 1 )
				{
					if( dFC < 0.0 )
						dTemp = 1.0;
				}

				if( (nN >= nTCut) && (dTemp <= dFDRCut) )
				{
					if(nStart < 0)
					{
						nStart = nj;
						nEnd = nj+nW-1;

						dMinFDR = dTemp;
						nMinFDRPos1 = nj+nW2;
						nMinFDRPos2 = nMinFDRPos1;
						if(dFC >= 0.0)
							nPosSide = 1;
						else
							nPosSide = 0;

						dMaxFC = dFC;
						nMaxFCPos1 = nj+nW2;
						nMaxFCPos2 = nMaxFCPos1;

						dMinFC = dFC;
						nMinFCPos1 = nj+nW2;
						nMinFCPos2 = nMinFCPos1;
					}
					else
					{
						nEnd = nj+nW-1;

						if( fabs(dTemp-dMinFDR) < 1e-10 )
						{
							nMinFDRPos2 = nj+nW2;
						}
						else if(dTemp < dMinFDR)
						{
							dMinFDR = dTemp;
							nMinFDRPos1 = nj+nW2;
							nMinFDRPos2 = nMinFDRPos1;

							if(dFC >= 0.0)
								nPosSide = 1;
							else
								nPosSide = 0;
						}

						if( fabs(dFC-dMaxFC) < 1e-10 )
						{
							nMaxFCPos2 = nj+nW2;
						}
						else if(dFC > dMaxFC)
						{
							dMaxFC = dFC;
							nMaxFCPos1 = nj+nW2;
							nMaxFCPos2 = nMaxFCPos1;
						}

						if( fabs(dFC-dMinFC) < 1e-10 )
						{
							nMinFCPos2 = nj+nW2;
						}
						else if(dFC < dMinFC)
						{
							dMinFC = dFC;
							nMinFCPos1 = nj+nW2;
							nMinFCPos2 = nMinFCPos1;
						}
					}
				}
				else
				{
					if(nStart >= 0)
					{
						if(nPosSide == 1)
						{
							fprintf(fpReg, "1\t%d\t%d\t%d\t%f\t%d\t%f\t%d\n", ni1, nStart, nEnd, 
								dMinFDR, (nMinFDRPos1+nMinFDRPos2)/2,
								dMaxFC, (nMaxFCPos1+nMaxFCPos2)/2);
						}
						else
						{
							fprintf(fpReg, "1\t%d\t%d\t%d\t%f\t%d\t%f\t%d\n", ni1, nStart, nEnd, 
								dMinFDR, (nMinFDRPos1+nMinFDRPos2)/2,
								dMinFC, (nMinFCPos1+nMinFCPos2)/2);
						}
						nStart = -1;
						nEnd = -1;
						
						dMinFDR = 1.0;
						nMinFDRPos1 = -1;
						nMinFDRPos2 = -1;

						dMaxFC = 0.0;
						nMaxFCPos1 = -1;
						nMaxFCPos2 = -1;

						dMinFC = 0.0;
						nMinFCPos1 = -1;
						nMinFCPos2 = -1;
					}
				}
			}

			if(nStart >= 0)
			{
				if(nPosSide == 1)
				{
					fprintf(fpReg, "1\t%d\t%d\t%d\t%f\t%d\t%f\t%d\n", ni1, nStart, nEnd, 
						dMinFDR, (nMinFDRPos1+nMinFDRPos2)/2,
						dMaxFC, (nMaxFCPos1+nMaxFCPos2)/2);
				}
				else
				{
					fprintf(fpReg, "1\t%d\t%d\t%d\t%f\t%d\t%f\t%d\n", ni1, nStart, nEnd, 
						dMinFDR, (nMinFDRPos1+nMinFDRPos2)/2,
						dMinFC, (nMinFCPos1+nMinFCPos2)/2);
				}
				nStart = -1;
				nEnd = -1;
				dMinFDR = 1.0;
				nMinFDRPos1 = -1;
				nMinFDRPos2 = -1;

				dMaxFC = 0.0;
				nMaxFCPos1 = -1;
				nMaxFCPos2 = -1;

				dMinFC = 0.0;
				nMinFCPos1 = -1;
				nMinFCPos2 = -1;
			}

			/* add seqnum */
			ni1++;
		}

		/* process bar_neg only */
		else
		{
			if(pBARDataNeg->vSeqData[ni2]->nDataNum <= 0)
			{
				ni2++;
				continue;
			}

			nx = pBARDataNeg->vSeqData[ni2]->nDataNum-1;
			nP1 = (int)(pBARDataNeg->vSeqData[ni2]->vData[0]->pMatElement[0])-nW;
			nP2 = (int)(pBARDataNeg->vSeqData[ni2]->vData[0]->pMatElement[nx]);
			nStart = -1;
			nEnd = -1;

			dMinFDR = 1.0;
			nMinFDRPos1 = -1;
			nMinFDRPos2 = -1;

			dMaxFC = 0.0;
			nMaxFCPos1 = -1;
			nMaxFCPos2 = -1;

			dMinFC = 0.0;
			nMinFCPos1 = -1;
			nMinFCPos2 = -1;


			nN1 = 0;
			nN2 = 0;
			dFC = 0.0;
			nk = 0;
			nl = 0;
			for(nj=nP1; nj<=nP2; nj++)
			{
				for(; nl<pBARDataNeg->vSeqData[ni2]->nDataNum; nl++)
				{
					if((int)(pBARDataNeg->vSeqData[ni2]->vData[0]->pMatElement[nl]) >= nj)
						break;
					
					nN2 -= (int)(pBARDataNeg->vSeqData[ni2]->vData[1]->pMatElement[nl]);
				}

				for(; nk<pBARDataNeg->vSeqData[ni2]->nDataNum; nk++)
				{
					if((int)(pBARDataNeg->vSeqData[ni2]->vData[0]->pMatElement[nk]) >= (nj+nW))
						break;

					nN2 += (int)(pBARDataNeg->vSeqData[ni2]->vData[1]->pMatElement[nk]);
				}

				dTemp = nN2*dR0;
				if(dTemp < (double)nN1)
				{
					dFC = log((double)(nN1+1)/(dTemp+1.0))/dLog2;
				}
				else
				{
					dFC = -log((dTemp+1.0)/(double)(nN1+1))/dLog2;
				}

				nN = nN1+nN2;

				if( (nj+nW2)%nS == 0)
				{
					if( ((nj+nW2)>=0) && (nN>0) )
						fprintf(fpOut, "%s\t%d\t%d\t%d\t%f\n", pBARDataNeg->vSeqData[ni2]->pSeqName->m_pString, (int)(nj+nW2), nN1, nN2, dFC);
				}

				/* get fdr */
				nN1Sub = nN1;
				if(nN < pFDR->nHeight)
				{
					if(nN1 >= pFDR->nWidth)
						nN1Sub = pFDR->nWidth-1;

					dTemp = DMGETAT(pFDR, nN, nN1Sub);
				}
				else
				{
					nNSub = pFDR->nHeight-1;
					dTemp = (double)(nNSub*nN1)/(double)nN;
					nN1Sub = (int)dTemp;
					if(dTemp-nN1Sub > 0.5)
						nN1Sub += 1;
					
					if(nN1Sub >= pFDR->nWidth)
						nN1Sub = pFDR->nWidth-1;

					dTemp = DMGETAT(pFDR, nNSub, nN1Sub);
				}

				if( nOneSide == 1 )
				{
					if( dFC < 0.0 )
						dTemp = 1.0;
				}

				if( (nN >= nTCut) && (dTemp <= dFDRCut) )
				{
					if(nStart < 0)
					{
						nStart = nj;
						nEnd = nj+nW-1;

						dMinFDR = dTemp;
						nMinFDRPos1 = nj+nW2;
						nMinFDRPos2 = nMinFDRPos1;
						if(dFC >= 0.0)
							nPosSide = 1;
						else
							nPosSide = 0;

						dMaxFC = dFC;
						nMaxFCPos1 = nj+nW2;
						nMaxFCPos2 = nMaxFCPos1;

						dMinFC = dFC;
						nMinFCPos1 = nj+nW2;
						nMinFCPos2 = nMinFCPos1;
					}
					else
					{
						nEnd = nj+nW-1;

						if( fabs(dTemp-dMinFDR) < 1e-10 )
						{
							nMinFDRPos2 = nj+nW2;
						}
						else if(dTemp < dMinFDR)
						{
							dMinFDR = dTemp;
							nMinFDRPos1 = nj+nW2;
							nMinFDRPos2 = nMinFDRPos1;

							if(dFC >= 0.0)
								nPosSide = 1;
							else
								nPosSide = 0;
						}

						if( fabs(dFC-dMaxFC) < 1e-10 )
						{
							nMaxFCPos2 = nj+nW2;
						}
						else if(dFC > dMaxFC)
						{
							dMaxFC = dFC;
							nMaxFCPos1 = nj+nW2;
							nMaxFCPos2 = nMaxFCPos1;
						}

						if( fabs(dFC-dMinFC) < 1e-10 )
						{
							nMinFCPos2 = nj+nW2;
						}
						else if(dFC < dMinFC)
						{
							dMinFC = dFC;
							nMinFCPos1 = nj+nW2;
							nMinFCPos2 = nMinFCPos1;
						}
					}
				}
				else
				{
					if(nStart >= 0)
					{
						if(nPosSide == 1)
						{
							fprintf(fpReg, "2\t%d\t%d\t%d\t%f\t%d\t%f\t%d\n", ni2, nStart, nEnd, 
								dMinFDR, (nMinFDRPos1+nMinFDRPos2)/2,
								dMaxFC, (nMaxFCPos1+nMaxFCPos2)/2);
						}
						else
						{
							fprintf(fpReg, "2\t%d\t%d\t%d\t%f\t%d\t%f\t%d\n", ni2, nStart, nEnd, 
								dMinFDR, (nMinFDRPos1+nMinFDRPos2)/2,
								dMinFC, (nMinFCPos1+nMinFCPos2)/2);
						}
						nStart = -1;
						nEnd = -1;
						
						dMinFDR = 1.0;
						nMinFDRPos1 = -1;
						nMinFDRPos2 = -1;

						dMaxFC = 0.0;
						nMaxFCPos1 = -1;
						nMaxFCPos2 = -1;

						dMinFC = 0.0;
						nMinFCPos1 = -1;
						nMinFCPos2 = -1;
					}
				}
			}

			if(nStart >= 0)
			{
				if(nPosSide == 1)
				{
					fprintf(fpReg, "2\t%d\t%d\t%d\t%f\t%d\t%f\t%d\n", ni2, nStart, nEnd, 
						dMinFDR, (nMinFDRPos1+nMinFDRPos2)/2,
						dMaxFC, (nMaxFCPos1+nMaxFCPos2)/2);
				}
				else
				{
					fprintf(fpReg, "2\t%d\t%d\t%d\t%f\t%d\t%f\t%d\n", ni2, nStart, nEnd, 
						dMinFDR, (nMinFDRPos1+nMinFDRPos2)/2,
						dMinFC, (nMinFCPos1+nMinFCPos2)/2);
				}
				nStart = -1;
				nEnd = -1;
				dMinFDR = 1.0;
				nMinFDRPos1 = -1;
				nMinFDRPos2 = -1;

				dMaxFC = 0.0;
				nMaxFCPos1 = -1;
				nMaxFCPos2 = -1;

				dMinFC = 0.0;
				nMinFCPos1 = -1;
				nMinFCPos2 = -1;
			}

			ni2++;
		}
	}

	fclose(fpOut);
	fclose(fpReg);

	/* load region information */
	pRegion = DMLOAD(strRegTmpFile);

	/* convert temp file to bar file */
	sprintf(strFileName, "%s.cgw", strOutFileTitle);
	TileMapv2_TXT2BAR(strWinBarTmpFile, strExportFolder, strFileName);
	
	/* remove temp file */
	RemoveFiles(strWinBarTmpFile);
	RemoveFiles(strRegTmpFile);

	/* return */
	return pRegion;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_TwoSample_MergeRegion()                                     */
/*  Merge and filter regions.                                              */
/* ----------------------------------------------------------------------- */ 
struct DOUBLEMATRIX *HTS_Enrich_TwoSample_MergeRegion(struct DOUBLEMATRIX *pRegion0, 
	int nMinLen, int nMaxGap)
{
	/* define */
	struct DOUBLEMATRIX *pMReg = NULL;
	struct DOUBLEMATRIX *pRegion = NULL;
	int nRegNum;
	int ni;
	int nBar0,nBar;
	int nChr0,nChr;
	int nStart0,nStart;
	int nEnd0,nEnd;
	double dMinFDR0,dMinFDR;
	int nMinFDRPos0,nMinFDRPos;
	double dMFC0,dMFC;
	int nMFCPos0,nMFCPos;
	int nPSide0,nPSide;
	int nIsNew;
	int nLen;

	/* init check */
	if(pRegion0 == NULL)
		return NULL;
	if(pRegion0->nHeight <= 0)
		return NULL;

	/* merge */
	pMReg = CreateDoubleMatrix(pRegion0->nHeight, pRegion0->nWidth+3);
	if(pMReg == NULL)
	{
		printf("Error: HTS_Enrich_TwoSample_MergeRegion, cannot create memory for merging regions!\n");
		exit(EXIT_FAILURE);
	}

	nRegNum = 0;
	nBar0 = (int)(DMGETAT(pRegion0, 0, 0));
	nChr0 = (int)(DMGETAT(pRegion0, 0, 1));
	nStart0 = (int)(DMGETAT(pRegion0, 0, 2));
	nEnd0 = (int)(DMGETAT(pRegion0, 0, 3));
	dMinFDR0 = DMGETAT(pRegion0, 0, 4);
	nMinFDRPos0 = (int)(DMGETAT(pRegion0, 0, 5));
	dMFC0 = DMGETAT(pRegion0, 0, 6);
	nMFCPos0 = (int)(DMGETAT(pRegion0, 0, 7));
	if(dMFC0 > 0.0)
		nPSide0 = 1;
	else
		nPSide0 = -1;

	for(ni=1; ni<pRegion0->nHeight; ni++)
	{
		nIsNew = 0;

		nBar = (int)(DMGETAT(pRegion0, ni, 0));
		nChr = (int)(DMGETAT(pRegion0, ni, 1));
		nStart = (int)(DMGETAT(pRegion0, ni, 2));
		nEnd = (int)(DMGETAT(pRegion0, ni, 3));
		dMinFDR = DMGETAT(pRegion0, ni, 4);
		nMinFDRPos = (int)(DMGETAT(pRegion0, ni, 5));
		dMFC = DMGETAT(pRegion0, ni, 6);
		nMFCPos = (int)(DMGETAT(pRegion0, ni, 7));
		if(dMFC > 0.0)
			nPSide = 1;
		else
			nPSide = -1;


		if( (nBar != nBar0) || (nChr != nChr0) )
		{
			nIsNew = 1;
		}
		else
		{
			if( (nStart-nEnd0) > nMaxGap)
				nIsNew = 1;
			else if( nPSide0 != nPSide )
				nIsNew = 1;
		}

		if(nIsNew == 1)
		{
			nLen = nEnd0-nStart0+1;
			if(nLen >= nMinLen)
			{
				DMSETAT(pMReg, nRegNum, 0, (double)nBar0);
				DMSETAT(pMReg, nRegNum, 1, (double)nChr0);
				DMSETAT(pMReg, nRegNum, 2, (double)nStart0);
				DMSETAT(pMReg, nRegNum, 3, (double)nEnd0);
				DMSETAT(pMReg, nRegNum, 4, (double)nLen);
				DMSETAT(pMReg, nRegNum, 5, -dMinFDR0);
				DMSETAT(pMReg, nRegNum, 6, (double)nMinFDRPos0);
				DMSETAT(pMReg, nRegNum, 7, dMFC0);
				DMSETAT(pMReg, nRegNum, 8, (double)nMFCPos0);
				nRegNum++;
			}

			nBar0 = nBar;
			nChr0 = nChr;
			nStart0 = nStart;
			nEnd0 = nEnd;
			dMinFDR0 = dMinFDR;
			nMinFDRPos0 = nMinFDRPos;
			dMFC0 = dMFC;
			nMFCPos0 = nMFCPos;
			nPSide0 = nPSide;
		}
		else
		{
			if(nEnd > nEnd0)
				nEnd0 = nEnd;

			if(dMinFDR < dMinFDR0)
			{
				dMinFDR0 = dMinFDR;
				nMinFDRPos0 = nMinFDRPos;
			}

			if(nPSide0 == 1)
			{
				if(dMFC > dMFC0)
				{
					dMFC0 = dMFC;
					nMFCPos0 = nMFCPos;
				}
			}
			else
			{
				if(dMFC < dMFC0)
				{
					dMFC0 = dMFC;
					nMFCPos0 = nMFCPos;
				}
			}
		}
	}

	nLen = nEnd0-nStart0+1;
	if(nLen >= nMinLen)
	{
		DMSETAT(pMReg, nRegNum, 0, (double)nBar0);
		DMSETAT(pMReg, nRegNum, 1, (double)nChr0);
		DMSETAT(pMReg, nRegNum, 2, (double)nStart0);
		DMSETAT(pMReg, nRegNum, 3, (double)nEnd0);
		DMSETAT(pMReg, nRegNum, 4, (double)nLen);
		DMSETAT(pMReg, nRegNum, 5, -dMinFDR0);
		DMSETAT(pMReg, nRegNum, 6, (double)nMinFDRPos0);
		DMSETAT(pMReg, nRegNum, 7, dMFC0);
		DMSETAT(pMReg, nRegNum, 8, (double)nMFCPos0);
		nRegNum++;
	}


	/* prepare the regions */
	pRegion = CreateDoubleMatrix(nRegNum, pMReg->nWidth);
	if(pRegion == NULL)
	{
		printf("Error: HTS_Enrich_TwoSample_MergeRegion, cannot create memory for merging regions!\n");
		exit(EXIT_FAILURE);
	}
	memcpy(pRegion->pMatElement, pMReg->pMatElement, (sizeof(double)*nRegNum*pMReg->nWidth));

	DestroyDoubleMatrix(pMReg);

	/* return */
	return pRegion;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_TwoSample_ExportResults()                                   */
/*  Export results.                                                        */
/* ----------------------------------------------------------------------- */ 
int	HTS_Enrich_TwoSample_ExportResults(struct DOUBLEMATRIX *pRegion, 
			struct tagBARData *pBARDataPos, struct tagBARData *pBARDataNeg,
			char strFileName[])
{
	/* define */
	FILE *fpOut;
	int ni,nj,nk,nl;

	/* open file */
	fpOut = NULL;
	fpOut = fopen(strFileName, "w");
	if(fpOut == NULL)
	{
		printf("Error: HTS_Enrich_TwoSample_ExportResults, cannot open output file!\n");
		exit(EXIT_FAILURE);
	}

	fprintf(fpOut, "#rank\tchr\tstart\tend\tstrand\tlength\tminFDR\tminFDR_pos\tmax|FC|\tmax|FC|_pos\tpos_read_num\tneg_read_num\n");

	/* write */
	for(nj=0; nj<pRegion->nHeight; nj++)
	{
		ni = pRegion->nHeight-1-nj; 
		nk = (int)(DMGETAT(pRegion, ni,0));
		nl = (int)(DMGETAT(pRegion, ni,1));
		if(nk <= 1)
		{
			fprintf(fpOut, "%d\t%s\t%d\t%d\t+\t%d\t%f\t%d\t%f\t%d\t%d\t%d\n", nj+1, pBARDataPos->vSeqData[nl]->pSeqName->m_pString,
				(int)(DMGETAT(pRegion, ni,2)), (int)(DMGETAT(pRegion, ni,3)), (int)(DMGETAT(pRegion, ni,4)),
				-DMGETAT(pRegion, ni,5), (int)(DMGETAT(pRegion, ni,6)), DMGETAT(pRegion, ni,7), (int)(DMGETAT(pRegion, ni,8)),
				(int)DMGETAT(pRegion, ni,9), (int)(DMGETAT(pRegion, ni,10)));
		}
		else
		{
			fprintf(fpOut, "%d\t%s\t%d\t%d\t+\t%d\t%f\t%d\t%f\t%d\t%d\t%d\n", nj+1, pBARDataNeg->vSeqData[nl]->pSeqName->m_pString,
				(int)(DMGETAT(pRegion, ni,2)), (int)(DMGETAT(pRegion, ni,3)), (int)(DMGETAT(pRegion, ni,4)),
				-DMGETAT(pRegion, ni,5), (int)(DMGETAT(pRegion, ni,6)), DMGETAT(pRegion, ni,7), (int)(DMGETAT(pRegion, ni,8)),
				(int)DMGETAT(pRegion, ni,9), (int)(DMGETAT(pRegion, ni,10)));
		}
	}

	/* close file */
	fclose(fpOut);

	/* return */
	return PROC_SUCCESS;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_TwoSamplev2_ExportResults()                                 */
/*  Export results.                                                        */
/* ----------------------------------------------------------------------- */ 
int	HTS_Enrich_TwoSamplev2_ExportResults(struct DOUBLEMATRIX *pRegion, 
			struct tagBARData *pBARDataPos, struct tagBARData *pBARDataNeg,
			char strFileName[], int nBR, int nBRL, int nSSF, int nSSFF, int nSSFR)
{
	/* define */
	FILE *fpOut;
	int ni,nj,nk,nl,nx,ny,nz;
	double dMin,dMax,dTemp;
	int nP1,nP2,nB1,nB2,nMF,nMR,nBRW;
	int nRegLen1,nRegLen2;

	/* open file */
	fpOut = NULL;
	fpOut = fopen(strFileName, "w");
	if(fpOut == NULL)
	{
		printf("Error: HTS_Enrich_TwoSample_ExportResults, cannot open output file!\n");
		exit(EXIT_FAILURE);
	}

	fprintf(fpOut, "#rank\tchr\tstart\tend\tstrand\tlength\tminFDR\tminFDR_pos\tmax|FC|\tmax|FC|_pos\tpos_read_num\tneg_read_num\tFminFDR\tFminFDR_Pos\tFmax|FC|\tFmax|FC|_pos\tFpos_readnum\tFneg_readnum\tFmaxpos_readnum\tFmaxpos_readnum_pos\tFmaxneg_readnum\tFmaxneg_readnum_pos\tRminFDR\tRminFDR_Pos\tRmax|FC|\tRmax|FC|_pos\tRpos_readnum\tRneg_readnum\tRmaxpos_readnum\tRmaxpos_readnum_pos\tRmaxneg_readnum\tRmaxneg_readnum_pos\tRmode-Fmode\tDelta\n");

	/* write */
	nz = 0;
	for(nj=0; nj<pRegion->nHeight; nj++)
	{
		ni = pRegion->nHeight-1-nj; 
		nk = (int)(DMGETAT(pRegion, ni,0));
		nl = (int)(DMGETAT(pRegion, ni,1));
		nP1 = (int)(DMGETAT(pRegion, ni,2));
		nP2 = (int)(DMGETAT(pRegion, ni,3));
		nRegLen1 = (int)(DMGETAT(pRegion, ni,4));
		nB1 = (int)(DMGETAT(pRegion, ni, 14));
		nB2 = (int)(DMGETAT(pRegion, ni, 24));
		nRegLen2 = nB2-nB1+1;
		nMF = (int)(DMGETAT(pRegion, ni, 17));
		nMR = (int)(DMGETAT(pRegion, ni, 27));


		if(nSSF == 1)
		{
			if( (nMF < nSSFF) || (nMR < nSSFR) )
				continue;
		}
		if(nBR == 1)
		{
			if(nRegLen2 >= 0)
			{
				if(nRegLen2 < nBRL)
				{
					nBRW = (nBRL-nRegLen2)/2;
					nP1 = nB1-nBRW;
					nP2 = nB2+nBRW;
				}
				else
				{
					nP1 = nB1;
					nP2 = nB2;
				}
				nRegLen1 = nP2-nP1+1;
			}
		}

		if(nk <= 1)
		{
			fprintf(fpOut, "%d\t%s\t%d\t%d\t+\t%d\t%f\t%d\t%f\t%d\t%d\t%d\t", nz+1, pBARDataPos->vSeqData[nl]->pSeqName->m_pString,
				nP1, nP2, nRegLen1,
				-DMGETAT(pRegion, ni,5), (int)(DMGETAT(pRegion, ni,6)), DMGETAT(pRegion, ni,7), (int)(DMGETAT(pRegion, ni,8)),
				(int)DMGETAT(pRegion, ni,9), (int)(DMGETAT(pRegion, ni,10)));
		}
		else
		{
			fprintf(fpOut, "%d\t%s\t%d\t%d\t+\t%d\t%f\t%d\t%f\t%d\t%d\t%d\t", nz+1, pBARDataNeg->vSeqData[nl]->pSeqName->m_pString,
				nP1, nP2, nRegLen1,
				-DMGETAT(pRegion, ni,5), (int)(DMGETAT(pRegion, ni,6)), DMGETAT(pRegion, ni,7), (int)(DMGETAT(pRegion, ni,8)),
				(int)DMGETAT(pRegion, ni,9), (int)(DMGETAT(pRegion, ni,10)));
		}

		ny = 11;
		for(nx=0; nx<2; nx++)
		{
			fprintf(fpOut, "%f\t%d\t%f\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t", (DMGETAT(pRegion, ni, ny+4)), (int)(DMGETAT(pRegion, ni, ny+5)),
				(DMGETAT(pRegion, ni, ny+2)), (int)(DMGETAT(pRegion, ni, ny+3)), 
				(int)(DMGETAT(pRegion, ni, ny)), (int)(DMGETAT(pRegion, ni, ny+1)),
				(int)(DMGETAT(pRegion, ni, ny+6)), (int)(DMGETAT(pRegion, ni, ny+7)),
				(int)(DMGETAT(pRegion, ni, ny+8)), (int)(DMGETAT(pRegion, ni, ny+9)) );
			ny += 10;
		}

		fprintf(fpOut, "%d\t", nRegLen2);

		dMax = DMGETAT(pRegion, ni, 13);
		dMin = DMGETAT(pRegion, ni, 23);
		if(dMin > dMax)
		{
			dTemp = dMax;
			dMax = dMin;
			dMin = dTemp;
		}

		dTemp = pow(2.0, dMin)/pow(2.0, dMax);

		fprintf(fpOut, "%f\n", dTemp);
		nz++;
	}

	/* close file */
	fclose(fpOut);

	/* return */
	return PROC_SUCCESS;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_TwoSample_RegionCollectInfo()                               */
/*  Collect reads number.                                                  */
/* ----------------------------------------------------------------------- */ 
int HTS_Enrich_TwoSample_RegionCollectInfo(struct DOUBLEMATRIX *pRegion, 
		struct tagBARData *pBARDataPos, struct tagBARData *pBARDataNeg)
{
	/* define */
	int ni,nj,nk,nl;
	int nBar,nChr,nStart,nEnd;
	int nP1,nP2;
	char strChr[MED_LINE_LENGTH];
	int nPosChr,nNegChr;

	/* init */
	if( (pRegion == NULL) || (pBARDataPos == NULL) || (pBARDataNeg == NULL) )
		return PROC_SUCCESS;

	/* collect */
	for(ni=0; ni<pRegion->nHeight; ni++)
	{
		nBar = (int)(DMGETAT(pRegion, ni, 0));
		nChr = (int)(DMGETAT(pRegion, ni, 1));
		nStart = (int)(DMGETAT(pRegion, ni, 2));
		nEnd = (int)(DMGETAT(pRegion, ni, 3));

		if(nBar == 0)
		{
			nPosChr = nChr;
			strcpy(strChr, pBARDataPos->vSeqData[nChr]->pSeqName->m_pString);
			for(nj=0; nj<pBARDataNeg->nSeqNum; nj++)
			{
				if(strcmp(strChr, pBARDataNeg->vSeqData[nj]->pSeqName->m_pString) == 0)
				{
					nNegChr = nj;
					break;
				}
			}
		}
		else if(nBar == 1)
		{
			nPosChr = nChr;
			nNegChr = -1; 
		}
		else
		{
			nPosChr = -1;
			nNegChr = nChr;
		}


		if(nPosChr >= 0)
		{
			if(pBARDataPos->vSeqData[nPosChr]->nDataNum > 0)
			{
		
				nj = 0;
				nk = pBARDataPos->vSeqData[nPosChr]->nDataNum-1;

				if(nStart > pBARDataPos->vSeqData[nPosChr]->vData[0]->pMatElement[nk])
				{
					nP1 = nk+1;
				}
				else if(nStart <= pBARDataPos->vSeqData[nPosChr]->vData[0]->pMatElement[0])
				{
					nP1 = 0;
				}
				else
				{
					while( (nk-nj) > 1)
					{
						nl = (nk+nj)/2;
						if( pBARDataPos->vSeqData[nPosChr]->vData[0]->pMatElement[nl] >= nStart)
						{
							nk = nl;
						}
						else
						{
							nj = nl;
						}
					}
					nP1 = nk;
				}

				nj = 0;
				nk = pBARDataPos->vSeqData[nPosChr]->nDataNum-1;

				if(nEnd >= pBARDataPos->vSeqData[nPosChr]->vData[0]->pMatElement[nk])
				{
					nP2 = nk;
				}
				else if(nEnd < pBARDataPos->vSeqData[nPosChr]->vData[0]->pMatElement[0])
				{
					nP2 = -1;
				}
				else
				{
					while( (nk-nj) > 1)
					{
						nl = (nk+nj)/2;
						if( pBARDataPos->vSeqData[nPosChr]->vData[0]->pMatElement[nl] > nEnd)
						{
							nk = nl;
						}
						else
						{
							nj = nl;
						}
					}
					nP2 = nj;
				}

				nk = 0;
				for(nj=nP1; nj<=nP2; nj++)
				{
					nk += (int)(pBARDataPos->vSeqData[nPosChr]->vData[1]->pMatElement[nj]);
				}

				DMSETAT(pRegion, ni, 9, (double)nk);
			}
		}

		if(nNegChr >= 0)
		{
			if(pBARDataNeg->vSeqData[nNegChr]->nDataNum > 0)
			{
		
				nj = 0;
				nk = pBARDataNeg->vSeqData[nNegChr]->nDataNum-1;

				if(nStart > pBARDataNeg->vSeqData[nNegChr]->vData[0]->pMatElement[nk])
				{
					nP1 = nk+1;
				}
				else if(nStart <= pBARDataNeg->vSeqData[nNegChr]->vData[0]->pMatElement[0])
				{
					nP1 = 0;
				}
				else
				{
					while( (nk-nj) > 1)
					{
						nl = (nk+nj)/2;
						if( pBARDataNeg->vSeqData[nNegChr]->vData[0]->pMatElement[nl] >= nStart)
						{
							nk = nl;
						}
						else
						{
							nj = nl;
						}
					}
					nP1 = nk;
				}

				nj = 0;
				nk = pBARDataNeg->vSeqData[nNegChr]->nDataNum-1;

				if(nEnd >= pBARDataNeg->vSeqData[nNegChr]->vData[0]->pMatElement[nk])
				{
					nP2 = nk;
				}
				else if(nEnd < pBARDataNeg->vSeqData[nNegChr]->vData[0]->pMatElement[0])
				{
					nP2 = -1;
				}
				else
				{
					while( (nk-nj) > 1)
					{
						nl = (nk+nj)/2;
						if( pBARDataNeg->vSeqData[nNegChr]->vData[0]->pMatElement[nl] > nEnd)
						{
							nk = nl;
						}
						else
						{
							nj = nl;
						}
					}
					nP2 = nj;
				}

				nk = 0;
				for(nj=nP1; nj<=nP2; nj++)
				{
					nk += (int)(pBARDataNeg->vSeqData[nNegChr]->vData[1]->pMatElement[nj]);
				}

				DMSETAT(pRegion, ni, 10, (double)nk);
			}
		}
	}


	/* return */
	return PROC_SUCCESS;
}

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_TwoSamplev2_RegionCollectInfo()                             */
/*  Collect reads number.                                                  */
/* ----------------------------------------------------------------------- */ 
struct DOUBLEMATRIX *HTS_Enrich_TwoSamplev2_RegionCollectInfo(struct DOUBLEMATRIX *pRegion, 
		struct tagBARData *pBARDataPos, struct tagBARData *pBARDataNeg, int nW, 
		struct DOUBLEMATRIX *pFDR, double dP0, int nOneSide)
{
	/* define */
	struct DOUBLEMATRIX *pNewRegion = NULL;
	int ni,nj,nk,nl,nk1,nl1,nk2,nl2,nu1,nu2;
	int nBar,nChr,nStart,nEnd;
	int nP1,nP2;
	char strChr[MED_LINE_LENGTH];
	int nPosChr,nNegChr;
	double dTemp;
	int nQ1,nQ2;
	double dR0 = dP0/(1.0-dP0);
	double dLog2 = log(2.0);
	double dMaxFC,dMinFC,dFC,dMinFDR,dFDR;
	int nMaxFCPos1,nMaxFCPos2,nMinFCPos1,nMinFCPos2,nMinFDRPos1,nMinFDRPos2;
	int nPMaxPos1,nPMaxPos2,nNMaxPos1,nNMaxPos2;
	int nPMax,nNMax;
	int nN1,nN2,nN,nNSub,nN1Sub;
	int nGlobalFCPos;
	int nW2 = nW/2;

	/* init */
	if( (pRegion == NULL) || (pBARDataPos == NULL) || (pBARDataNeg == NULL) )
		return NULL;

	pNewRegion = CreateDoubleMatrix(pRegion->nHeight, pRegion->nWidth+10);
	if(pNewRegion == NULL)
	{
		printf("Error: HTS_Enrich_TwoSamplev2_RegionCollectInfo, cannot create new region matrix.\n");
		exit(EXIT_FAILURE);
	}

	/* collect */
	for(ni=0; ni<pRegion->nHeight; ni++)
	{
		for(nj=0; nj<pRegion->nWidth; nj++)
		{
			dTemp = DMGETAT(pRegion, ni, nj);
			DMSETAT(pNewRegion, ni, nj, dTemp);
		}

		nBar = (int)(DMGETAT(pRegion, ni, 0));
		nChr = (int)(DMGETAT(pRegion, ni, 1));
		nStart = (int)(DMGETAT(pRegion, ni, 2));
		nEnd = (int)(DMGETAT(pRegion, ni, 3));

		if(DMGETAT(pRegion, ni, 7) >= 0.0)
			nGlobalFCPos = 1;
		else
			nGlobalFCPos = 0;

		if(nBar == 0)
		{
			nPosChr = nChr;
			strcpy(strChr, pBARDataPos->vSeqData[nChr]->pSeqName->m_pString);
			for(nj=0; nj<pBARDataNeg->nSeqNum; nj++)
			{
				if(strcmp(strChr, pBARDataNeg->vSeqData[nj]->pSeqName->m_pString) == 0)
				{
					nNegChr = nj;
					break;
				}
			}
		}
		else if(nBar == 1)
		{
			nPosChr = nChr;
			nNegChr = -1; 
		}
		else
		{
			nPosChr = -1;
			nNegChr = nChr;
		}

		nk1 = 0;
		nl1 = 0;
		nu1 = -1;
		nk2 = 0;
		nl2 = 0;
		nu2 = -1;

		if(nPosChr >= 0)
		{
			if(pBARDataPos->vSeqData[nPosChr]->nDataNum > 0)
			{
		
				nj = 0;
				nk = pBARDataPos->vSeqData[nPosChr]->nDataNum-1;

				if(nStart > pBARDataPos->vSeqData[nPosChr]->vData[0]->pMatElement[nk])
				{
					nP1 = nk+1;
				}
				else if(nStart <= pBARDataPos->vSeqData[nPosChr]->vData[0]->pMatElement[0])
				{
					nP1 = 0;
				}
				else
				{
					while( (nk-nj) > 1)
					{
						nl = (nk+nj)/2;
						if( pBARDataPos->vSeqData[nPosChr]->vData[0]->pMatElement[nl] >= nStart)
						{
							nk = nl;
						}
						else
						{
							nj = nl;
						}
					}
					nP1 = nk;
				}

				nj = 0;
				nk = pBARDataPos->vSeqData[nPosChr]->nDataNum-1;

				if(nEnd >= pBARDataPos->vSeqData[nPosChr]->vData[0]->pMatElement[nk])
				{
					nP2 = nk;
				}
				else if(nEnd < pBARDataPos->vSeqData[nPosChr]->vData[0]->pMatElement[0])
				{
					nP2 = -1;
				}
				else
				{
					while( (nk-nj) > 1)
					{
						nl = (nk+nj)/2;
						if( pBARDataPos->vSeqData[nPosChr]->vData[0]->pMatElement[nl] > nEnd)
						{
							nk = nl;
						}
						else
						{
							nj = nl;
						}
					}
					nP2 = nj;
				}

				nk = 0;
				for(nj=nP1; nj<=nP2; nj++)
				{
					nk += (int)(pBARDataPos->vSeqData[nPosChr]->vData[1]->pMatElement[nj]);
				}

				DMSETAT(pNewRegion, ni, pRegion->nWidth, (double)nk);
				nk1 = nP1;
				nl1 = nP1;
				nu1 = nP2;
			}
		}

		if(nNegChr >= 0)
		{
			if(pBARDataNeg->vSeqData[nNegChr]->nDataNum > 0)
			{
		
				nj = 0;
				nk = pBARDataNeg->vSeqData[nNegChr]->nDataNum-1;

				if(nStart > pBARDataNeg->vSeqData[nNegChr]->vData[0]->pMatElement[nk])
				{
					nP1 = nk+1;
				}
				else if(nStart <= pBARDataNeg->vSeqData[nNegChr]->vData[0]->pMatElement[0])
				{
					nP1 = 0;
				}
				else
				{
					while( (nk-nj) > 1)
					{
						nl = (nk+nj)/2;
						if( pBARDataNeg->vSeqData[nNegChr]->vData[0]->pMatElement[nl] >= nStart)
						{
							nk = nl;
						}
						else
						{
							nj = nl;
						}
					}
					nP1 = nk;
				}

				nj = 0;
				nk = pBARDataNeg->vSeqData[nNegChr]->nDataNum-1;

				if(nEnd >= pBARDataNeg->vSeqData[nNegChr]->vData[0]->pMatElement[nk])
				{
					nP2 = nk;
				}
				else if(nEnd < pBARDataNeg->vSeqData[nNegChr]->vData[0]->pMatElement[0])
				{
					nP2 = -1;
				}
				else
				{
					while( (nk-nj) > 1)
					{
						nl = (nk+nj)/2;
						if( pBARDataNeg->vSeqData[nNegChr]->vData[0]->pMatElement[nl] > nEnd)
						{
							nk = nl;
						}
						else
						{
							nj = nl;
						}
					}
					nP2 = nj;
				}

				nk = 0;
				for(nj=nP1; nj<=nP2; nj++)
				{
					nk += (int)(pBARDataNeg->vSeqData[nNegChr]->vData[1]->pMatElement[nj]);
				}

				DMSETAT(pNewRegion, ni, (pRegion->nWidth+1), (double)nk);
				nk2 = nP1;
				nl2 = nP1;
				nu2 = nP2;
			}
		}

		nQ1 = nStart;
		nQ2 = nEnd-nW+1;

		dMinFDR = 10.0;
		nMinFDRPos1 = -1;
		nMinFDRPos2 = -1;

		dMaxFC = -1e20;
		nMaxFCPos1 = -1;
		nMaxFCPos2 = -1;

		dMinFC = 1e20;
		nMinFCPos1 = -1;
		nMinFCPos2 = -1;

		nPMax = -1;
		nNMax = -1;
		nPMaxPos1 = -1;
		nPMaxPos2 = -1;
		nNMaxPos1 = -1;
		nNMaxPos2 = -1;


		nN1 = 0;
		nN2 = 0;
		dFC = 0.0;

		for(nj=nQ1; nj<=nQ2; nj++)
		{
			if(nPosChr >= 0)
			{
				for(; nl1<=nu1; nl1++)
				{
					if((int)(pBARDataPos->vSeqData[nPosChr]->vData[0]->pMatElement[nl1]) >= nj)
						break;
					
					nN1 -= (int)(pBARDataPos->vSeqData[nPosChr]->vData[1]->pMatElement[nl1]);
				}

				for(; nk1<=nu1; nk1++)
				{
					if((int)(pBARDataPos->vSeqData[nPosChr]->vData[0]->pMatElement[nk1]) >= (nj+nW))
						break;

					nN1 += (int)(pBARDataPos->vSeqData[nPosChr]->vData[1]->pMatElement[nk1]);
				}
			}

			if(nNegChr >= 0)
			{
				for(; nl2<=nu2; nl2++)
				{
					if((int)(pBARDataNeg->vSeqData[nNegChr]->vData[0]->pMatElement[nl2]) >= nj)
						break;
					
					nN2 -= (int)(pBARDataNeg->vSeqData[nNegChr]->vData[1]->pMatElement[nl2]);
				}

				for(; nk2<=nu2; nk2++)
				{
					if((int)(pBARDataNeg->vSeqData[nNegChr]->vData[0]->pMatElement[nk2]) >= (nj+nW))
						break;

					nN2 += (int)(pBARDataNeg->vSeqData[nNegChr]->vData[1]->pMatElement[nk2]);
				}
			}

			if( nPMax == nN1 )
			{
				nPMaxPos2 = nj+nW2;
			}
			else if( nN1 > nPMax )
			{
				nPMax = nN1;
				nPMaxPos1 = nj+nW2;
				nPMaxPos2 = nPMaxPos1;
			}

			if( nNMax == nN2 )
			{
				nNMaxPos2 = nj+nW2;
			}
			else if( nN2 > nNMax )
			{
				nNMax = nN2;
				nNMaxPos1 = nj+nW2;
				nNMaxPos2 = nPMaxPos1;
			}

			dTemp = nN2*dR0;
			dFC = log((double)(nN1+1)/(dTemp+1.0))/dLog2;
			
			if( fabs(dFC-dMaxFC) < 1e-10 )
			{
				nMaxFCPos2 = nj+nW2;
			}
			else if(dFC > dMaxFC)
			{
				dMaxFC = dFC;
				nMaxFCPos1 = nj+nW2;
				nMaxFCPos2 = nMaxFCPos1;
			}

			if( fabs(dFC-dMinFC) < 1e-10 )
			{
				nMinFCPos2 = nj+nW2;
			}
			else if(dFC < dMinFC)
			{
				dMinFC = dFC;
				nMinFCPos1 = nj+nW2;
				nMinFCPos2 = nMinFCPos1;
			}


			/* get fdr */
			if( ((nGlobalFCPos == 1) && (dFC>=0.0)) || ((nGlobalFCPos == 0) && (dFC<0.0)) )
			{
				nN = nN1+nN2;
				nN1Sub = nN1;
				if(nN < pFDR->nHeight)
				{
					if(nN1 >= pFDR->nWidth)
						nN1Sub = pFDR->nWidth-1;

					dFDR = DMGETAT(pFDR, nN, nN1Sub);
				}
				else
				{
					nNSub = pFDR->nHeight-1;
					dTemp = (double)(nNSub*nN1)/(double)nN;
					nN1Sub = (int)dTemp;
					if(dTemp-nN1Sub > 0.5)
						nN1Sub += 1;
					
					if(nN1Sub >= pFDR->nWidth)
						nN1Sub = pFDR->nWidth-1;

					dFDR = DMGETAT(pFDR, nNSub, nN1Sub);
				}
			}
			else
			{
				dFDR = 1.0;
			}

			if( nOneSide == 1 )
			{
				if( dFC < 0.0 )
					dFDR = 1.0;
			}
		
			if( fabs(dFDR-dMinFDR) < 1e-10 )
			{
				nMinFDRPos2 = nj+nW2;
			}
			else if(dFDR < dMinFDR)
			{
				dMinFDR = dFDR;
				nMinFDRPos1 = nj+nW2;
				nMinFDRPos2 = nMinFDRPos1;
			}
		}
	
		if(nPMax < 0)
		{
			nPMax = 0;
			nPMaxPos1 = -1;
			nPMaxPos2 = -1;
		}

		if(nNMax < 0)
		{
			nNMax = 0;
			nNMaxPos1 = -1;
			nNMaxPos2 = -1;
		}

		if(dMaxFC < (-1e20+1.0))
		{
			dMaxFC = 0.0;
			nMaxFCPos1 = -1;
			nMaxFCPos2 = -1;
		}

		if(dMinFC > (1e20-1.0))
		{
			dMinFC = 0.0;
			nMinFCPos1 = -1;
			nMinFCPos2 = -1;
		}

		if(dMinFDR > (1.01))
		{
			dMinFDR = 1.0;
			nMinFDRPos1 = -1;
			nMinFDRPos2 = -1;
		}

		if( nOneSide == 1 )
		{
			DMSETAT(pNewRegion, ni, (pRegion->nWidth+2), dMaxFC);
			nk = (nMaxFCPos1+nMaxFCPos2)/2;
			DMSETAT(pNewRegion, ni, (pRegion->nWidth+3), (double)nk);
		}
		else
		{
			if(DMGETAT(pRegion, ni, 7) >= 0.0)
			{
				DMSETAT(pNewRegion, ni, (pRegion->nWidth+2), dMaxFC);
				nk = (nMaxFCPos1+nMaxFCPos2)/2;
				DMSETAT(pNewRegion, ni, (pRegion->nWidth+3), (double)nk);
			}
			else
			{
				DMSETAT(pNewRegion, ni, (pRegion->nWidth+2), dMinFC);
				nk = (nMinFCPos1+nMinFCPos2)/2;
				DMSETAT(pNewRegion, ni, (pRegion->nWidth+3), (double)nk);
			}
		}
		DMSETAT(pNewRegion, ni, (pRegion->nWidth+4), dMinFDR);
		nk = (nMinFDRPos1+nMinFDRPos2)/2;
		DMSETAT(pNewRegion, ni, (pRegion->nWidth+5), (double)nk);

		DMSETAT(pNewRegion, ni, (pRegion->nWidth+6), nPMax);
		nk = (nPMaxPos1+nPMaxPos2)/2;
		DMSETAT(pNewRegion, ni, (pRegion->nWidth+7), (double)nk);

		DMSETAT(pNewRegion, ni, (pRegion->nWidth+8), nNMax);
		nk = (nNMaxPos1+nNMaxPos2)/2;
		DMSETAT(pNewRegion, ni, (pRegion->nWidth+9), (double)nk);
	}

	/* return */
	return pNewRegion;
}
