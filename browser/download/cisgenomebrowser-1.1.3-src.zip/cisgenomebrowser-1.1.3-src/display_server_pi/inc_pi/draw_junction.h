#ifndef DRAW_JUNCTION_H
#define DRAW_JUNCTION_H

#include "draw_axis.h"
#include "genefile.h"
#include "wx/colour.h"
#include "wxDCHelper.h"

class draw_junction: public draw_axis
{
public:
	draw_junction(const string& data_file_name, const string& exon1, const string& exon2);
	virtual string print_usage();
	virtual bool get_params(const vector<string> &params);
	virtual bool load_data();
	virtual bool prepare_data();
	virtual bool draw_contents(wxMemoryDC *pdc, const PIRect rect);
private:
	string data_file_name_;
	string chr_;
	int startpos_[2], endpos_[2];
	vector<gene_struct> genes_[2];
	void GenerateFakeData() {
		for (int i = 0; i < 2; ++i) {
			GenerateFakeData(genes_[i]);
			for (int j = 0; j < genes_[i].size(); ++j) {
				genes_[i][j].txStart = genes_[i][j].txStart > 0 ? genes_[i][j].txStart + startpos_[i] : startpos_[i];
				genes_[i][j].txEnd = genes_[i][j].txEnd < 0 ? genes_[i][j].txEnd + endpos_[i] : endpos_[i];
				if (i==0) {
					genes_[i][j].txEnd = endpos_[i];
				} else {
					genes_[i][j].txStart = startpos_[i];
				}
			}
		}
	}
	static void GenerateFakeData(vector<gene_struct>& genes) {
		int cnt = rand() % 5 + 15;
		genes.resize(cnt);
		for (int i = 0; i < cnt; ++i) {
			GenerateFakeData(genes[i]);
		}
	}
	static void GenerateFakeData(gene_struct& gene) {
		gene.txStart = rand() % 32 - 16;
		gene.txEnd = rand() % 32 - 16;
	}
};

class NucleotideSource {
public:
	NucleotideSource() {
		rand_sequence_.resize(rand_seq_len_);
		for (size_t i = 0; i < rand_seq_len_; ++i) {
			rand_sequence_[i] = GetRandNucleotide();
		}
	}
	static char GetRandNucleotide() {
		static char chars[] = {'A', 'T', 'C', 'G'};
		return chars[rand()%4];
	}
	string GetNucleotides(string chr, long start, long end, bool random) {
		string res; 
		for (int i = start; i <= end; ++i) {
			if (random && rand() % 100 == 0) {
				res += GetRandNucleotide();
			} else {
				res += rand_sequence_[i%rand_seq_len_];
			}
		}
		return res;
	}
	wxColor GetNucleotideColor(char n, int index) {
		PICOLORREF colors[2] = { RGB(200, 0, 0), RGB(0, 0, 200) };
		int color_ind = 1;
		if (rand_sequence_[index%rand_seq_len_] != n) color_ind = 0;
		return wxDCHelper::ColorFromCOLORREF(colors[color_ind]);
	}
private:
	static const int rand_seq_len_ = 30;
	string rand_sequence_;
};

#endif  // DRAW_JUNCTION_H
