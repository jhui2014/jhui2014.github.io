#include "draw_data.h"

#include "file_operation.h"
#include "string_operation.h"
#include "math_utils.h"
#include "wx/dcmemory.h"
#include "wxDCHelper.h"

draw_data::draw_data()
{
	top_axis = bottom_axis = true;
	left_axis = right_axis = true;

	plot_type = PLOT_TYPE_LINE;
	data_filename = "";
	signal_width = 0;
	box = false;
	no_data = false;
	v_grids = false;
}

string draw_data::print_usage()
{
	return "</data:<data file>> [/color:0xXXXXXX]s [/domain:<domain low>-<domain high>> [/range:<range low>-<range high>] [/size:<picture width>x<picture height>] [/axis:xxxx] [/plottype:<bar | dot | line | heatmap>] [/box] [/signal_width:width]\n";
}

bool draw_data::get_params(const vector<string> &params)
{
	bool good_options = true;
	for (int i = 0; i < (int) params.size(); i++)
	{
		string option = params[i];

		string command = "";
		string parameter = "";
		if (option[0] != '/')
		{
			good_options = false;
			break;
		}
		size_t index = option.find(":");
		if (index != string::npos)
		{
			command = option.substr(1, index - 1);
			parameter = option.substr(index + 1);
		}
		else
		{
			command = option.substr(1);
		}
		if (command == "range")
		{
			sscanf(parameter.c_str(), "%lf-%lf", &rangelow, &rangehigh);
		}
		else if (command == "data")
		{
			data_filename = parameter;
		}
		else if (command == "size")
		{
			sscanf(parameter.c_str(), "%dx%d", &size.cx, &size.cy);
			if (size.cx <= 0 || size.cy <= 0)
			{
				error_msg = "ERROR: Invalid parameter. wrong picture width.";
				good_options = false;
				break;
			}
		}
		else if (command == "color")
		{
			PICOLORREF color;
			sscanf(parameter.c_str(), "%x", &color);
			colors.push_back(color);
		}
		else if (command == "domain")
		{
			sscanf(parameter.c_str(), "%lf-%lf", &domainlow, &domainhigh);
		}
		else if (command == "axis")
		{
			int mask;
			sscanf(parameter.c_str(), "%d", &mask);
			top_axis = (mask >= 1000);
			mask %= 1000;
			bottom_axis = (mask >= 100);
			mask %= 100;
			left_axis = (mask >= 10);
			mask %= 10;
			right_axis = (mask >= 1);
		}
		else if (command == "plottype")
		{
			if (parameter == "bar")
			{
				plot_type = PLOT_TYPE_BAR;
			}
			else if (parameter == "dot")
			{
				plot_type = PLOT_TYPE_DOT;
			}
			else if (parameter == "line")
			{
				plot_type = PLOT_TYPE_LINE;
			}
			else if (parameter == "heatmap")
			{
				plot_type = PLOT_TYPE_HEATMAP;
			}
			else
			{
				error_msg = "ERROR: Invalid parameter. unknow plot type.";
				good_options = false;
				break;
			}
		}
		else if (command == "box")
		{
			box = true;
		}
		else if (command == "signal_width")
		{
			sscanf(parameter.c_str(), "%lf", &signal_width);
			if (signal_width <= epsilon)
			{
				error_msg = "ERROR: Invalid parameter. wrong signal_width.";
				good_options = false;
				break;
			}
		}
		else
		{
			good_options = false;
			break;
		}
	}
	return good_options;
}

bool draw_data::load_data()
{
	if (!file_exists(data_filename))
	{
		error_msg = "ERROR: file doesn't exist.";
		return false;
	}
	ifstream ifs(data_filename.c_str());
	string readline;
	vector<pair<double, vector<double> > > data;
	data.clear();
	bool first_line = true;
	int num_columns = 0;
	bool data_mode = false;
	while (getline(ifs, readline))
	{
		vector<string> tokens = string_tokenize(readline, " \t");
		if (tokens.empty())
			continue;
		if (data_mode)
		{
			if (first_line)
			{
				first_line = false;
				num_columns = (int) tokens.size() - 1;
				if (num_columns <= 0)
				{
					error_msg = "ERROR: bad format: no data column.";
					ifs.close();
					return false;
				}
			}
			else if (num_columns != (int) tokens.size() - 1)
			{
				error_msg = "ERROR: bad format: unequal column number.";
				ifs.close();
				return false;
			}
			pair<double, vector<double> > temp_data;
			if (!is_num(tokens[0]))
			{
				error_msg = "ERROR: bad format: wrong data";
				ifs.close();
				return false;
			}
			temp_data.first = str2double(tokens[0]);
			for (int i = 0; i < num_columns; i++)
			{
				if (!is_num(tokens[i + 1]))
				{
					error_msg = "ERROR: bad format: wrong data";
					ifs.close();
					return false;
				}
				temp_data.second.push_back(str2double(tokens[i + 1]));
			}
			data.push_back(temp_data);
		}
		else if (tokens[0] == "domain")
		{
			if (tokens.size() != 3 || !is_num(tokens[1]) || !is_num(tokens[2]))
			{
				error_msg = "ERROR: bad format: bad domain.";
				ifs.close();
				return false;
			}
			domainlow = str2double(tokens[1]);
			domainhigh = str2double(tokens[2]);
		}
		else if (tokens[0] == "range")
		{
			if (tokens.size() != 3 || !is_num(tokens[1]) || !is_num(tokens[2]))
			{
				error_msg = "ERROR: bad format: bad range.";
				ifs.close();
				return false;
			}
			rangelow = str2double(tokens[1]);
			rangehigh = str2double(tokens[2]);
		}
		else if (tokens[0] == "plottype")
		{
			if (tokens.size() != 2)
			{
				error_msg = "ERROR: bad format: bad plottype.";
				ifs.close();
				return false;
			}
			if (tokens[1] == "bar")
			{
				plot_type = PLOT_TYPE_BAR;
			}
			else if (tokens[1] == "dot")
			{
				plot_type = PLOT_TYPE_DOT;
			}
			else if (tokens[1] == "line")
			{
				plot_type = PLOT_TYPE_LINE;
			}
			else if (tokens[1] == "heatmap")
			{
				plot_type = PLOT_TYPE_HEATMAP;
			}
			else
			{
				error_msg = "ERROR: Invalid parameter. unknow plot type.";
				return false;
			}
		}
		else if (tokens[0] == "colors")
		{
			PICOLORREF color;
			for (int i = 1; i < (int) tokens.size(); i++)
			{
				sscanf(tokens[i].c_str(), "%x", &color);
				colors.push_back(color);
			}
		}
		else if (tokens[0] == "labels")
		{
			vector<string> tokens1 = string_tokenize(readline, "\"");
			for (int i = 1; i < (int) tokens1.size(); i++)
			{
				vector<string> tokens2 = string_tokenize(tokens1[i], " \t");
				if (tokens2.empty())
					continue;
				if (x_label == "")
					x_label = tokens1[i];
				else if (y_label == "")
					y_label = tokens1[i];
				else
				{
					error_msg = "ERROR: Invalid parameter. bad label.";
					return false;
				}
			}
		}
		else if (tokens[0] == "legend")
		{
			vector<string> tokens1 = string_tokenize(readline, "\"");
			for (int i = 1; i < (int) tokens1.size(); i++)
			{
				vector<string> tokens2 = string_tokenize(tokens1[i], " \t");
				if (tokens2.empty())
					continue;
				legends.push_back(tokens1[i]);
			}
		}
		else if (tokens[0] == "axis")
		{
			if (tokens.size() != 2 || !is_int(tokens[1]) || str2int(tokens[1])
				< 1000 || str2int(tokens[1]) > 1111)
			{
				error_msg = "ERROR: bad format: bad axis.";
				ifs.close();
				return false;
			}
			int mask;
			sscanf(tokens[1].c_str(), "%d", &mask);
			top_axis = (mask >= 1000);
			mask %= 1000;
			bottom_axis = (mask >= 100);
			mask %= 100;
			left_axis = (mask >= 10);
			mask %= 10;
			right_axis = (mask >= 1);
		}
		else if (tokens[0] == "size")
		{
			if (tokens.size() != 3 || !is_int(tokens[1]) || !is_int(tokens[2])
				|| str2int(tokens[1]) < 1 || str2int(tokens[2]) < 1)
			{
				error_msg = "ERROR: bad format: bad size.";
				ifs.close();
				return false;
			}
			size.cx = str2int(tokens[1]);
			size.cy = str2int(tokens[2]);
		}
		else if (tokens[0] == "data")
		{
			if (data_mode)
			{
				error_msg = "ERROR: bad format: two data section.";
				ifs.close();
				return false;
			}
			data_mode = true;
		}
		else
		{
			error_msg = "ERROR: bad format: unknown section.";
			ifs.close();
			return false;
		}
	}
	ifs.close();

	sort(data.begin(), data.end());

	positions.resize(num_columns);
	intensities.resize(num_columns);

	for (int i = 0; i < (int) data.size(); i++)
	{
		if (domainlow != domainhigh && (data[i].first < domainlow
			|| data[i].first > domainhigh))
			continue;
		for (int j = 0; j < num_columns; j++)
		{
			positions[j].push_back(data[i].first);
			intensities[j].push_back(data[i].second[j]);
		}
	}

	int data_size = 0;
	for (int i = 0; i < (int) positions.size(); i++)
	{
		data_size += (int) positions[i].size();
	}

	if (data_size == 0)
	{
		no_data = true;
		return true;
	}

	//if (plot_type == PLOT_TYPE_LINE) max_draw_line_distance = 500;

	if (plot_type == PLOT_TYPE_HEATMAP)
	{
		//rangelow = rangehigh = 0;
		left_space = left_axis;
		right_space = right_axis;
		left_axis = right_axis = false;
	}

	return true;
}

bool draw_data::prepare_data()
{
	if (signal_width > epsilon)
	{
		widthes.resize(intensities.size());
		for (int i = 0; i < (int) widthes.size(); i++)
		{
			widthes[i].resize(intensities[i].size());
			for (int j = 0; j < (int) widthes[i].size(); j++)
			{
				widthes[i][j] = signal_width;
			}
		}
	}

	draw_signal::prepare_data();
	return true;
}
