#include "display_conservation.h"
#include "drawCommon.h"
#include "display_genome.h"

display_conservation::display_conservation()
{

}

display_conservation::display_conservation(http_request* r,
										   string track_name, display_genome *g) :
display_track(r, track_name, g)
{
	pic_height = default_pic_height;
	file_path = "";
	plot_type = default_plot_type;
}

bool display_conservation::load_from_file(string file_name)
{
	display_track::load_from_file(file_name);
	pic_height = ReadIni(file_name, name + "/pic_height", default_pic_height);
	file_path = ReadIni(file_name, name + "/file_path", wxString(""));
	plot_type = ReadIni(file_name, name + "/plot_type", wxS(default_plot_type));
	if (title == "")
		title = file_path;
	return true;
}

bool display_conservation::update_params()
{
	if (!display_track::update_params())
		return false;
	if (req->params_.count("update_track") > 0)
	{
		file_path = get_path(req->params_["file_path"]);
		if (is_int(req->params_["track_height"]) && str2int(
			req->params_["track_height"]) >= 10 && str2int(
			req->params_["track_height"]) <= 4000)
		{
			pic_height = str2int(req->params_["track_height"]);
		}
		plot_type = req->params_["plot_type"];
		if (title == "")
			title = file_path;
	}
	else if (req->params_.count("update_tracks") > 0)
	{
		if (req->params_["track_height"] != "")
		{
			if (is_int(req->params_["track_height"]) && str2int(
				req->params_["track_height"]) >= 10 && str2int(
				req->params_["track_height"]) <= 4000)
			{
				pic_height = str2int(req->params_["track_height"]);
			}
		}
	}
	else
		return false;
	return true;
}

bool display_conservation::write_to_file(string file_name)
{
	display_track::write_to_file(file_name);
	WriteIni(file_name, name + "/type", "conservation", true);
	WriteIni(file_name, name + "/pic_height", pic_height, pic_height
		!= default_pic_height);
	WriteIni(file_name, name + "/plot_type", plot_type, plot_type
		!= default_plot_type);
	WriteIni(file_name, name + "/file_path", file_path, file_path != "");
	return true;
}

string display_conservation::get_configure_html()
{
	html_formater my_html_formater;
	my_html_formater.load_from_template_file(template_path
		+ "conservation_track_config.html");
	my_html_formater.replace_keyword("$FILE_PATH$", file_path);
	my_html_formater.replace_keyword("$TRACK_HEIGHT$", int2str(pic_height));
	my_html_formater.replace_keyword("$PLOT_TYPE_BAR$",
		plot_type == "bar" ? "checked" : "");
	my_html_formater.replace_keyword("$PLOT_TYPE_HEATMAP$", plot_type
		== "heatmap" ? "checked" : "");
	string result = my_html_formater.buf;
	my_html_formater.buf = display_track::get_configure_html();
	my_html_formater.replace_keyword("$TRACK_CONTENTS$", result);
	my_html_formater.replace_keyword("$TRACK_TYPE$", "conservation");
	return my_html_formater.buf;
}

bool display_conservation::generate_pic_file(bool get_intervals)
{
	if (!display_track::generate_pic_file(get_intervals))
		return false;

	draw_conservation my_draw;
	my_draw.intervals = intervals;
	my_draw.file_path = file_path;

	if (!parse_region(genome->region, my_draw.chr, my_draw.startpos,
		my_draw.endpos))
	{
		my_draw.error_msg = "bad region.";
	}

	my_draw.size.cx = genome->pic_width;
	my_draw.box_margin = genome->pic_margin / 3;
	my_draw.data_margin = genome->pic_margin * 2 / 3;
	my_draw.font_size = genome->font_size;
	my_draw.size.cy = pic_height;
	my_draw.left_axis = genome->left_axis;
	my_draw.right_axis = genome->right_axis;
	if (genome->grid == "off")
	{
		my_draw.v_grids = false;
	}
	else if (genome->grid == "gray")
	{
		my_draw.custom_grid_color = true;
		my_draw.shaded_background = false;
	}
	else if (genome->grid == "gray_shaded")
	{
		my_draw.custom_grid_color = true;
		my_draw.shaded_background = true;
	}
	else if (genome->grid == "color_shaded")
	{
		my_draw.custom_grid_color = false;
		my_draw.shaded_background = true;
	}
	else if (genome->grid == "color")
	{
		my_draw.custom_grid_color = false;
		my_draw.shaded_background = false;
	}
	my_draw.top_axis = top_axis;
	my_draw.bottom_axis = bottom_axis;
	my_draw.fast_draw = fast_draw;
	if (plot_type == "bar")
		my_draw.plot_type = PLOT_TYPE_BAR;
	else if (plot_type == "heatmap")
		my_draw.plot_type = PLOT_TYPE_HEATMAP;
	else
		return false;
	my_draw.load_data();
	my_draw.prepare_data();
	if (get_intervals)
	{
		my_draw.get_intervals();
		intervals = my_draw.intervals;
	}
	else
	{
		my_draw.drawfile(temp_path + client_ip + pic_filename);
		display_track::generate_hrefs(my_draw.map_rects, my_draw.map_strings);
	}
	return true;
}


string display_conservation::type()
{
	return "display_conservation";
}
