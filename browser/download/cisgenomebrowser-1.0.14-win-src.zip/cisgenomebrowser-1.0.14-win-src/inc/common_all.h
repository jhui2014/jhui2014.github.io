/*
common.h - Header file for all common stuff
written by JIANG Hui, 
Institute for Computational and Mathematical Engineering, Stanford University
May, 2007 -
*/

#ifndef COMMON_H
///Define this macro to prevent from including this header file more than once.
#define COMMON_H

//used for eliminating the boring waring messages produced by VC 6.0
//#pragma warning (disable : 4786)

#include "stl.h"
#include "type.h"
#include "endian.h"
#include "string_operation.h"
#include "file_operation.h"
#include "chr_region.h"
#include "timer.h"

#endif // COMMON_H
