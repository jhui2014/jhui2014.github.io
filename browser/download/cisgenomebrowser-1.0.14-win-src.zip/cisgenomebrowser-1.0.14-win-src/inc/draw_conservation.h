#ifndef DRAW_CONSERVATION_H
#define DRAW_CONSERVATION_H

#include "draw_signal.h"
#include "chr_region.h"
#include "file_operation.h"
#include "math_utils.h"
#include "cisgenome.h"

class draw_conservation: public draw_signal
{
public:
	bool box;

	string file_path;
	string chr;
	int startpos, endpos;

	draw_conservation();
	virtual string print_usage();
	virtual bool get_params(const vector<string> &params);
	virtual bool prepare_data();
	virtual bool load_data();
};

inline draw_conservation::draw_conservation(){
	top_axis = bottom_axis = true;
	left_space = right_space = true;

	file_path = "";
	chr = "";
	startpos = endpos = -1;
	box = false;
}

inline string draw_conservation::print_usage(){
	return "<conservation file path> [/color:0xXXXXXX] </region:<chr>:<sequence start position>-<sequence end position>> [/size:<picture width>x<picture height>] [/axis:xxxx] [/plottype:<bar | heatmap>] [/box]\n";
}

inline bool draw_conservation::get_params(const vector<string> &params){
	if (params.size() == 0) return false;
	file_path = params[0];

	bool good_options = true;
	for (int i=1; i<(int)params.size(); i++) {
		string option = params[i];

		string command = "";
		string parameter = "";
		if (option[0] != '/') {
			good_options = false;
			break;
		}
		size_t index = option.find (":");
		if (index != string::npos ) {
			command = option.substr(1, index - 1);
			parameter = option.substr(index + 1);
		} else {
			command = option.substr(1);
		}
		if (command == "size"){
			sscanf(parameter.c_str(), "%dx%d", &size.cx, &size.cy);
			if (size.cx <=0 || size.cy <=0) {
				error_msg = "Invalid parameter. wrong picture width.\n";
				good_options = false;
				break;
			}
		} else if (command == "color"){
			COLORREF color;
			sscanf(parameter.c_str(), "%hX", &color);
			colors.clear();
			colors.push_back(color);
		} else if (command == "region"){
			if (!parse_region(parameter, chr, startpos, endpos)){
				error_msg = "Invalid parameter. wrong region.\n";
				good_options = false;
				break;
			}
		} else if (command == "axis"){
			int mask;
			sscanf(parameter.c_str(), "%d", &mask);
			top_axis = (mask >= 1000);
			mask %= 1000;
			bottom_axis = (mask >= 100);
			mask %= 100;
			left_axis = (mask >= 10);
			mask %= 10;
			right_axis = (mask >= 1);
		} else if (command == "plottype"){
			if (parameter == "bar") {
				plot_type = PLOT_TYPE_BAR;
			} else if (parameter == "heatmap") {
				plot_type = PLOT_TYPE_HEATMAP;
			} else {
				error_msg = "Invalid parameter. unknow plot type.\n";
				good_options = false;
				break;
			}
		} else if (command == "box"){
			box = true;
		} else {
			good_options = false;
			break;
		}
	}
	return good_options;
}

inline bool draw_conservation::prepare_data(){
	if (error_msg != "") return false;
	left_space = left_axis;
	right_space = right_axis;
	left_axis = right_axis = false;
	draw_axis::prepare_data();
	return true;
}

inline bool draw_conservation::load_data(){
	if (error_msg != "") return false;

	if (startpos <=0 || endpos <=0 || chr == "") {
		error_msg = "Invalid parameter. no region information.\n";
		return false;
	}

	if (endpos - startpos > 10000000) {
		error_msg = "region is too long to load and display";
		return false;
		//skip long regions for faster display
	}

	domainlow = startpos;
	domainhigh = endpos;

	rangelow = 0;
	rangehigh = 255;

	positions.clear();
	intensities.clear();

	if (plot_type == PLOT_TYPE_HEATMAP) {
		cm.colors.clear();
		cm.values.clear();
		cm.values.push_back(0);
		cm.colors.push_back(RGB(255,255,255));
		cm.values.push_back(255);
		if (colors.size() == 0) cm.colors.push_back(RGB(0,0,0));
		else if (colors.size() == 1) cm.colors.push_back(colors[0]);
		else {
			error_msg = "error setting colormap.\n";
			return false;
		}
	}

	struct BYTEMATRIX *pCS = NULL;
	char filename[1024];
	sprintf(filename, "%s%s.cs", file_path.c_str(), chr.c_str());
	if (!file_exists(filename)) {
		error_msg = "error opening conservation file.\n";
		return false;
	}

	int64 file_size;
	if (!get_file_size(string(filename), &file_size)) {
		error_msg ="error getting file size.";
	}

	if (endpos >= (int)file_size) {
		endpos = (int)file_size - 1;
		if (startpos >= endpos) startpos = endpos - 1;
	}

	pCS = Genome_GetConsScore(filename, startpos, endpos);
	if(pCS == NULL) {
		error_msg = "error reading conservation file.\n";
		return false;
	}

	vector<double> position;
	position.resize(endpos-startpos+1);
	vector<double> intensity;
	intensity.resize(endpos-startpos+1);
	int i;
	for (i = startpos; i <= endpos; i++) {
		position[i-startpos] = i;
		intensity[i-startpos] = pCS->pMatElement[i-startpos];
	}
	positions.push_back(position);
	intensities.push_back(intensity);
	DestroyByteMatrix(pCS);

	return true;
}

#endif //DRAW_CONSERVATION_H
