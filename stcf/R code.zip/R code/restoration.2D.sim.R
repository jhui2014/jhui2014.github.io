#simulation of 2D image restoration

rm(list = ls())
set.seed(1234)
source("quadratic.R")
source("common.R")

run = function(z) {
    lam = 0.02
    weight = 2
    obj.value = function(z1, z) {
        return(sum((z - z1) ^ 2) + weight * sum(pmin((z[2:n,] - z[1:(n - 1),]) ^ 2, lam)) + weight * sum(pmin((z[, 2:n] - z[, 1:(n - 1)]) ^ 2, lam)))
    }

    z = (z - min(z)) / (max(z) - min(z))
    z1 = z + rnorm(n * n, 0, 0.1)
    z2 = gaussian.blur(z1)

    image(z, zlim = c(min(z1), max(z1)), col = gray((0:255) / 256), xaxt = 'n', yaxt = 'n')
    image(z1, zlim = c(min(z1), max(z1)), col = gray((0:255) / 256), xaxt = 'n', yaxt = 'n')
    image(z2, zlim = c(min(z1), max(z1)), col = gray((0:255) / 256), xaxt = 'n', yaxt = 'n')

    A1 = Diagonal(n = n * n, x = 1)
    A2 = Matrix(0, nrow = n * (n-1), ncol = n * n, sparse = T)
    A2[cbind(1:(n*n-n), 1:(n*n-n))] = sqrt(weight)
    A2[cbind(1:(n*n-n), (n+1):(n*n))] = -sqrt(weight)
    A3 = Matrix(0, nrow = n * (n-1), ncol = n * n, sparse = T)
    A3[cbind(1:(n*n-n), (1:(n*n))[-n*(1:n)])] = sqrt(weight)
    A3[cbind(1:(n*n-n), (1:(n*n))[-(1+n*(0:(n-1)))])] = -sqrt(weight)
    A = as(rbind(A1, A2, A3), "dgCMatrix")
    b = c(-z1, rep(0, 2*(n*n-n)))
    lambda = c(rep(Inf, n*n), rep(weight*lam, 2*(n*n-n)))
    z3 = matrix(quadratic_cpp(A = A, b = b, x0 = z1, lambda = lambda, tol = 1e-6)$par, nrow = n, ncol = n)
    image(z3, zlim = c(min(z1), max(z1)), col = gray((0:255) / 256), xaxt = 'n', yaxt = 'n')
}

library(imager)
for (image in c("wave", "cameraman.tif", "house.tif", "lena.tif")) {
    pdf(paste("image", image, "pdf", sep="."), height = 4, width = 16)
    par(mfrow = c(1, 4))
    par(mar=c(0.5, 0.5, 0.5, 0.5))
    n = 256
    if (image == "wave") {
        x = y = seq(0, 1, len = n)
        r = sqrt(outer((x - 0.5) ^ 2, (y - 0.5) ^ 2, "+"))
        z = outer(x, y, "+")
        z = sin(15 * z) * 2 + 4
        z[r > 0.3] = 0
    } else {
        z = load.image(image)
        z = resize(z, n, n)
        z = matrix(z, n, n)
        n = nrow(z)
        z = z[, n:1]
    }
    run(z)
    dev.off()
}
