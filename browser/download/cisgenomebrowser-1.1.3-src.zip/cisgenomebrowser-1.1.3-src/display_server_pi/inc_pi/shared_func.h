#ifndef SHARED_FUNC_H
#define SHARED_FUNC_H

#include "stl.h"
#include "string_operation.h"

#ifndef put2log
#define put2log(msg) \
	cout << trim_space(current_time()) << ": " << \
	msg << endl;
/*
#define put2log(msg) \
	cout << current_time() << " " << \
	__FILE__ << "[" << __LINE__ << "]:" << \
	__FUNCTION__ << ": " << (msg) << endl;*/
#endif

#endif //#ifdef SHARED_FUNC_H
