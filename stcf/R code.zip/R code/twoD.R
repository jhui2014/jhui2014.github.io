source("common.R")

#main function
twoD = function(data, lambda = 0, g_shift, g_val, g_min, g_intersect, g_radius, g_point) {
    #input: 'data' contains the parameters of a set of (unshifted) functions to be evaluated.
    #       'lambda' is a vector of length n indicating the truncation levels for each function. 
    #       'g_shift', 'g_val', 'g_min', 'g_intersect' and 'g_radius' are user-provided functions for processing a specific class of functions. 
    #output: the minimizer and objective function value

    #g_shift(data, lambda) {
    #input: 'data' contains parameters of a set of strictly convex (nontruncated) functions, could assume any class (of object).
    #       'lambda' is a vector indicating truncation levels for each function.
    #output: modified 'data' with parameters adjusted such that every function is shifted to be truncated at level zero.

    #g_val(data, i, x)
    #input: 'i' is the index set of a function fi whose parameters are stored in 'data'. 
    #        'x' is the location where the function is to be evaluated.
    #output: fi(x)

    #g_min(data_s, modifier, suff_stat = NULL)
    #input: 'data_s' contains parameters of a set of (shifted) functions. 
    #       'modifier' gives the indicies of functions to be added or removed from the calculation of the sufficient statistic for the minizing argument.
    #       'suff_stat', in the quadratic function case, is a vector of sums of coefficients of a subset of functions. 
    #        For example, c(1,-3) commands addition of the 1st function and removal of the 3rd function.        
    #output: a list containing the minizing argument and the minimum, followed by the current sufficient statistic.

    #g_intersect(data_s, i, j) 
    #Input: 'i' and 'j' are indices of two functions for which we want to find intersections of their level curves.         
    #       The parameters of the (shifted) functions are stored in 'data_s'.      
    #Output: a mx2 matrix whose rows are the locations of the m intersections.    

    #g_radius(data_s, i, center, theta) 
    #input: 'i' is the index of a (shifted) function, fi, whose parameters are stored in 'data_s'. 
    #       Given a point, p, on the level curve of the funciton fi at the truncated level (zero), 
    #       'theta' is the angle of its polar coordinate when a point 'center' within fi is taken as the origin.
    #output: the distance between the point, p, and minimum of fi.

    #g_point(data_s, i)
    #input: 'i' is the index of a (shifted) function, fi, whose parameters are stored in 'data_s'. 
    #output: a point in the truncated region of fi.

    if (is.matrix(data)) {
        n = nrow(data)
    } else if (is.list(data)) {
        n = length(data)
    }
    if (length(lambda) == 1) {
        lambda = rep(lambda, n)
    }
    data_s = g_shift(data, lambda)
    x = c() # x is a n by 2 matrix containing arguments that minimize fi's.
    m = c() # m is a vector of minima of fi's.
    for (i in 1:n) {
        h = g_min(data_s, i)
        m = c(m, h$value)
        x = rbind(x, g_point(data_s, i))
    }

    truncated = which((m < 0) & (lambda < Inf))

    value = Inf
    par = NULL
    if (any(lambda == Inf)) {
        sol = g_min(data_s, which(lambda == Inf))
        if (sol$value < value) {
            value = sol$value
            par = sol$par
        }
    }
    for (i in truncated) {
        pt = NULL
        for (j in setdiff(truncated, i)) {
            p = g_intersect(data_s, i, j)
            if (!is.null(p)) {
                theta = cart_polar(p - rep(x[i,], each = nrow(p)))[,2]
                pt <- rbind(pt, cbind(theta, j))
            }
        }
        if (!is.null(pt)) {
            pt = pt[order(pt[, 1]),]
        }
        theta_start = 0
        r_start = g_radius(data_s, i, x[i,], theta_start)
        p_start = polar_cart(cbind(r_start, theta_start)) + x[i,]
        for (include.s in c(T, F)) {
            s = rep(F, n)
            s[i] = include.s
            s[lambda == Inf] = T
            for (j in setdiff(truncated, i)) {
                s[j] = (g_val(data_s, j, p_start) < 0)
            }
            result = g_min(data_s, which(s))
            if (result$value < value) {
                value <- result$value
                par <- result$par
            }
            suff_stat = result$suff_stat
            for (idx in pt[, 2]) {
                s[idx] = !s[idx]
                sign = s[idx] * 2 - 1
                result = g_min(data_s, sign * idx, suff_stat = suff_stat)
                if (result$value < value) {
                    value <- result$value
                    par <- result$par
                }
                suff_stat = result$suff_stat
            }
        }
    }
    value = value + sum(lambda[lambda < Inf])
    return(list(par = par, value = value))
}
