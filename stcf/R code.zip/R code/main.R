#run all simulations

methods:::bind_activation(TRUE)

source("fig1.R")
source("cover.sim.R")
source("outlier.sim.R")
source("quadratic.2D.sim.R")
source("restoration.1D.sim.R")
source("restoration.2D.sim.R")
