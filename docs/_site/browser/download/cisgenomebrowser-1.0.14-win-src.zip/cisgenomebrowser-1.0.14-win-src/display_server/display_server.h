// display_server.h : main header file for the PROJECT_NAME application
//

#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols


// Cdisplay_serverApp:
// See display_server.cpp for the implementation of this class
//

class Cdisplay_serverApp : public CWinApp
{
public:
	Cdisplay_serverApp();

// Overrides
	public:
	virtual BOOL InitInstance();

// Implementation

	DECLARE_MESSAGE_MAP()
};

extern Cdisplay_serverApp theApp;