function [X_opt, GENE, CI_GENE, MEAN, CI, C_IS] = iso_opt(A, L, L1, N, N1, NN, read_len, gene, draw_plot)

epsilon = 1e-10;

[m,n] = size(A);

% find X_opt
L = [L L1];
L = L - read_len;
N = [N N1];
A1 = zeros(m*(m-1)/2, n);
l = 1;
for i=1:m
    for j=i+1:m
        A1(l,:) = A(i,:).*A(j,:);
        for k=i+1:j-1
            A1(l,:) = A1(l,:).*(1-A(k,:));
        end
        l = l + 1;
    end
end
A = [A; A1];

i = 1;
while i <= length(L)
    if L(i)<=0
        if N(i)~=0
            disp(sprintf('warning: L(i)<=0 & N(i)~=0 for gene %s.', gene));
            N(i)=0;
        end
        A(i,:)=[];
        L(i)=[];
        N(i)=[];
        continue;
    end
    i = i + 1;
end

i = 1;
while i <= length(L)
    if A(i,:)==0
        if N(i)~=0
            disp(sprintf('warning: A(i,:)==0 & N(i)~=0 for gene %s, probably new isoform.', gene));
            N(i)=0;
        end
        A(i,:)=[];
        L(i)=[];
        N(i)=[];
        continue;
    end
    j = i + 1;
    while j <= length(L)
        if A(i,:)==A(j,:)
            A(j,:)=[];
            L(i)=L(i)+L(j);
            L(j)=[];
            N(i)=N(i)+N(j);
            N(j)=[];
        else
            j = j + 1;
        end
    end
    i = i + 1;
end

[m,n]=size(A);

if rank(A) < n
    X_opt = -1;
    GENE = -1;
    CI_GENE = [];
    MEAN = -1;
    CI = [];
    C_IS = [];
    disp(sprintf('rank(A) < n for gene %s', gene));
    return;
end;

A = (NN / 1e6 * (L / 1e3)' * ones(1, n)) .* A;

[X_opt, l_opt, I]= solve_likelihood(A, N);

C = inv(I);

if draw_plot 
    C
end

if det(C) < 1
    C = C + eye(n) * sum(diag(C)) / 10;
end

C = C * 4;

if norm(C-C','fro') > 1e-6

    X_opt = -1;
    GENE = -1;
    CI_GENE = [];
    MEAN = -1;
    CI = [];
    C_IS = [];

    disp(sprintf('internal error: C~=C for gene %s.', gene));
    return;
end
C = (C + C')/2;

% sampling
N_SAMP = 50000;

% % t distribution
% SAMP = trnd(5,n,N_SAMP);
% p_SAMP = prod(tpdf(SAMP, 5));

% normal distribution
SAMP = mvnrnd(X_opt',C,N_SAMP); 
p_SAMP = mvnpdf(SAMP,X_opt',C);
SAMP = SAMP';
p_SAMP = p_SAMP';

lf = zeros(1,N_SAMP);
for i=1:N_SAMP
    if SAMP(:,i)>=0
        lf(i) = exp(log_likelihood(A, N, SAMP(:,i))-l_opt);
    else
        lf(i) = 0;
    end
end

W = lf ./ p_SAMP;
if sum(W)==0
    X_opt = -1;
    GENE = -1;
    CI_GENE = [];
    MEAN = -1;
    CI = [];
    C_IS = [];
    disp(sprintf('internal error: sum(W)==0 for gene %s', gene));
    return;
end
W = W / sum(W);

if n==2    
    num_col = max(n+1, n*(n-1)/2+2);
else
    num_col = max(n+1, n*(n-1)/2);
end

% plot samples
if n==2 & draw_plot    
    subplot(2, num_col, num_col + n*(n-1)/2 + 2);
    plot(SAMP(1, :), SAMP(2, :), '.');
    title(sprintf('(%c) Samples', 'a'+n+n*(n-1)/2+2));
    xlabel('\theta_1');
    ylabel('\theta_2');
end

%gene expression plot
if draw_plot 
    subplot(2, num_col, n+1);
end
[CI_GENE, BOUND_GENE, GENE] = weighted_hist(sum(SAMP), W, draw_plot);
if draw_plot 
    title(sprintf('(%c) Gene expression', 'a'+n));
    xlabel('expression');
    disp(sprintf('gene expression estimated by maximum likelihood is %f', sum(X_opt)));
    disp(sprintf('gene expression estimated by importance sampling is %f', GENE));
    disp(sprintf('95%% confidence interval for gene expression = [%f, %f]\n', CI_GENE(1), CI_GENE(2)));
end

% nxn plots
for i = 1:n
    for j = 1:n
        if i==j            
            if draw_plot
                subplot(2, num_col, i);
            end
            [CI(i,:), BOUND(i,:), MEAN(i)] = weighted_hist(SAMP(i, :), W, draw_plot);
            if draw_plot             
                title(sprintf('(%c) Marginal posterior\ndistribution of \\theta%d', 'a'+i-1, i));
                xlabel(sprintf('\\theta%d',i));
                disp(sprintf('expression of X%d estimated by maximum likelihood is %f', i, X_opt(i)));
                disp(sprintf('expression of X%d estimated by importance sampling is %f', i, MEAN(i)));
                disp(sprintf('95%% confidence interval the expression of X%d = [%f, %f]\n', i, CI(i, 1), CI(i, 2)));
            end
        elseif (i > j)
            if draw_plot
                subplot(2, num_col, num_col + (i-1)*(i-2)/2+j);
            end
            weighted_hist2([SAMP(j,:); SAMP(i,:)], W, 2, draw_plot);
            if draw_plot 
                if n==2
                    title(sprintf('(%c) Posterior distribution of \\theta%d and \\theta%d', 'a'+n+(i-1)*(i-2)/2+j, j, i));
                else
                    title(sprintf('(%c) Marginal posterior\ndistribution of \\theta%d and \\theta%d', 'a'+n+(i-1)*(i-2)/2+j, j, i));
                end
                xlabel(sprintf('\\theta%d', j));
                ylabel(sprintf('\\theta%d', i));
            end
        end
    end
end

% plot likelihood function
if n==2 & draw_plot
    BOUND(1,1) = max(0, BOUND(1,1));
    BOUND(2,1) = max(0, BOUND(2,1));
    subplot(2, num_col, num_col + n*(n-1)/2 + 1);
    N_MESH = 20;
    XX = zeros(N_MESH + 1);
    YY = zeros(N_MESH + 1);
    ZZ = zeros(N_MESH + 1);
    for i=1:N_MESH + 1
        for j=1:N_MESH + 1
            XX(i,j) = BOUND(1,1) + (BOUND(1,2) - BOUND(1,1)) * (i - 1) / N_MESH;
            YY(i,j) = BOUND(2,1) + (BOUND(2,2) - BOUND(2,1)) * (j - 1) / N_MESH;
            ZZ(i,j) = exp(log_likelihood(A, N, [XX(i,j); YY(i,j)]) - l_opt);
        end
    end
    pcolor(XX,YY,ZZ);
    title(sprintf('(%c) Likelihood function L(\\Theta|X)', 'a'+n+n*(n-1)/2+1));
    xlabel('\theta_1');
    ylabel('\theta_2');
    zlabel('f');
end

% IS covariance matrix
C_IS = zeros(n);
for i = 1:n
    for j = 1:n
        C_IS(i, j) = sum((SAMP(i, :) - MEAN(i)) .* (SAMP(j, :) - MEAN(j)) .* W);
    end
end

if draw_plot     
    disp('covariance matrix by importance sampling:')
    C_IS
end