// For compilers that support precompilation, includes "wx.h".
#include "wx/wxprec.h"
#include "wx/cmdline.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

#include "webserver.h"
#include <ctime>
#include <iostream>
#include <string>
#include <map>
#include <sstream>
#include <algorithm>
#include "shared_data.h"
#include "inc_pi/shared_func.h"
#include "main_thread.h"

#include "wx/file.h"
#include "wx/filename.h"
#include "base64.h"
#include "UrlHelper.h"
#include "wxSocketHelper.h"
#include "wx/socket.h"

#include "server/request.hpp"

#ifndef MAX_PATH
#define MAX_PATH 260
#endif

webserver::request_func webserver::request_func_ = main_handler;

MimeAssociation mimetypes[] = {
	{ ".txt", "text/plain" },
	{ ".ini","text/plain" },
	{ ".html","text/html" },
	{ ".htm", "text/html" },
	{ ".gif", "image/gif" },
	{ ".png", "image/png" },
	{ ".jar", "application/java-archive" },
	{ ".jpg", "image/jpeg" }
};

//--------------------------------------------------------------
//	findMimeType()
//		Performs linear search through mimetypes array looking for
//		matching file extension returning index of mime type
//--------------------------------------------------------------
int findMimeType(const char *filename)
{
	char *pos;
	int numofelements;

	pos = (char*) strrchr(filename, '.');

	if (pos)
	{
		numofelements = sizeof(mimetypes) / sizeof(MimeAssociation);

		for (int x = 0; x < numofelements; ++x)
		{
			if (wxStricmp(mimetypes[x].file_ext, pos) == 0)
				return (x);
		}
	}

	return (0); // return default mimetype  'text/plain'
}

http_request::http_request(const http::server3::request& req) : authentication_given_(false), 
                                                                error(false), 
																statuscode(0), 
																redirect(false), 
																redirect_url(""),
																client_ip_(req.client_ip) {
    put2log("requested line: " + req.method + ": " + req.uri);
	method_ = req.method;
	SplitGetReq(req.uri, path_, params_);
	for (size_t i = 0; i < req.headers.size(); ++i) {
		if (req.headers[i].name == "Host") {
			server_ip_ = req.headers[i].value.substr(0, req.headers[i].value.find_first_of(":"));
			return;
		}
	}
}
//--------------------------------------------------------------
//	OutputHTTPRedirect()
//		Writes an HTTP redirect header and body to the client.
//		Called if the user requests a directory causing the redirect
//		to directory/index.html
//--------------------------------------------------------------
void OutputHTTPRedirect(wxSocketServer* client_socket, const char *defaulturl)
{
	char headerbuffer[COMM_BUFFER_SIZE];
	char htmlbuffer[COMM_BUFFER_SIZE];

	sprintf(htmlbuffer, "<html><body><a href=\"%s\">%s</a></body></html>",
			defaulturl, defaulturl);
	sprintf(
			headerbuffer,
			"HTTP/1.0 301\r\nContent-Type: text/html\r\nContent-Length: %ld\r\nLocation: %s\r\n\r\n",
			strlen(htmlbuffer), defaulturl);

	client_socket->Write(headerbuffer, strlen(headerbuffer));
	client_socket->Write(htmlbuffer, strlen(htmlbuffer));
	client_socket->Close();
}

//--------------------------------------------------------------
//	OutputHTTPError()
//		Sends an http header and html body to the client with
//		error information.
//--------------------------------------------------------------
void OutputHTTPError(wxSocketServer* client_socket, int statuscode)
{
	char headerbuffer[COMM_BUFFER_SIZE];
	char htmlbuffer[COMM_BUFFER_SIZE];

	sprintf(htmlbuffer, "<html><body><h2>Error: %d</h2></body></html>",
			statuscode);
	sprintf(
			headerbuffer,
			"HTTP/1.0 %d\r\nContent-Type: text/html\r\nContent-Length: %ld\r\n\r\n",
			statuscode, strlen(htmlbuffer));

	client_socket->Write(headerbuffer, strlen(headerbuffer));
	client_socket->Write(htmlbuffer, strlen(htmlbuffer));
	client_socket->Close();
}

void * ProcessRequest(void* ptr_s)
{
	wxSocketServer* s = (wxSocketServer*) ptr_s;
	s->SetFlags(wxSOCKET_WAITALL);
	string buffer = "";

	std::string line = wxSocketHelper::SocketReceiveLine(s);
	if (line.empty())
	{
		return NULL;
	}
	put2log(string("requested line: ") + trim_space(line));

	http_request req;

	if (line.find("GET") == 0)
	{
		req.method_ = "GET";
	}
	else if (line.find("POST") == 0)
	{
		req.method_ = "POST";
	}

	std::string path;
	std::map<std::string, std::string> params;

	size_t posStartPath = line.find_first_not_of(" ", 3);

	SplitGetReq(line.substr(posStartPath), path, params);

	req.status_ = "202 OK";
	req.s_ = s;
	req.path_ = path;
	req.params_ = params;

	static const std::string authorization = "Authorization: Basic ";
	static const std::string accept = "Accept: ";
	static const std::string accept_language = "Accept-Language: ";
	static const std::string accept_encoding = "Accept-Encoding: ";
	static const std::string user_agent = "User-Agent: ";

	while (1)
	{
		line = wxSocketHelper::SocketReceiveLine(s);
		if (line.empty() || line.length() <= 2)
			break;

		unsigned int pos_cr_lf = line.find_first_of("\x0a\x0d");
		if (pos_cr_lf == 0)
			break;

		line = line.substr(0, pos_cr_lf);

		if (line.substr(0, authorization.size()) == authorization)
		{
			req.authentication_given_ = true;
			std::string encoded = line.substr(authorization.size());
			std::string decoded = base64_decode(encoded);

			unsigned int pos_colon = decoded.find(":");

			req.username_ = decoded.substr(0, pos_colon);
			req.password_ = decoded.substr(pos_colon + 1);
		}
		else if (line.substr(0, accept.size()) == accept)
		{
			req.accept_ = line.substr(accept.size());
		}
		else if (line.substr(0, accept_language.size()) == accept_language)
		{
			req.accept_language_ = line.substr(accept_language.size());
		}
		else if (line.substr(0, accept_encoding.size()) == accept_encoding)
		{
			req.accept_encoding_ = line.substr(accept_encoding.size());
		}
		else if (line.substr(0, user_agent.size()) == user_agent)
		{
			req.user_agent_ = line.substr(user_agent.size());
		}
	}

	std::string file_name = wwwroot;
	char *filebuffer = NULL;
	long filesize = 0;
	file_name += req.path_;
	wxFileName fileName(wxS(file_name));
	fileName.Normalize();
	file_name = fileName.GetFullPath();

	string file_name_normal = file_name;
	std::replace(file_name_normal.begin(), file_name_normal.end(), '\\', '/');
	if (wxFile::Exists(wxS(file_name)) && (file_name_normal.find(
		wwwroot) != -1))
	{
		if (req.method_ == "GET")
		{
			if (::wxStrnicmp(file_name_normal.c_str(), wwwroot.c_str(),
				wwwroot.length()) == 0) // else security violation!
			{
				wxFile file(wxS(file_name_normal));
				filebuffer = new char[file.Length() + 3];
				filesize = file.Read(filebuffer, file.Length());
				if (wxInvalidOffset == filesize)
				{
					// file error, not found?
					req.error = true;
					req.statuscode = 404;// 404 - not found
				}
			}
			else
			{
				req.error = true;
				req.statuscode = 404;// 403 - forbidden
			}
		}
		else
		{
			req.error = true;
			req.statuscode = 501; // 501 not implemented
		}

		if (req.error)
		{
			OutputHTTPError(s, req.statuscode);
		}
		else if (req.redirect)
		{
			OutputHTTPRedirect(s, req.redirect_url.c_str());
		}
		else
		{
			// send the http header and the file contents to the browser
			char sendbuffer[COMM_BUFFER_SIZE];

			strcpy(sendbuffer, "HTTP/1.0 200 OK\r\n");
			strncat(sendbuffer, "Content-Type: ", COMM_BUFFER_SIZE);
			strncat(sendbuffer,
				mimetypes[findMimeType(file_name_normal.c_str())].mime,
				COMM_BUFFER_SIZE);
			sprintf(sendbuffer + strlen(sendbuffer),
				"\r\nContent-Length: %ld\r\n", filesize);
			strncat(sendbuffer, "\r\n", COMM_BUFFER_SIZE);

			s->Write(sendbuffer, strlen(sendbuffer));
			s->Write(filebuffer, filesize);
		}
	}
	else
	{
		try {
			webserver::request_func_(&req);
		} catch (exception& e) {
			put2log(e.what());
		}
		if (req.error)
		{
			OutputHTTPError(s, req.statuscode);
		}
		else if (req.redirect)
		{
			OutputHTTPRedirect(s, req.redirect_url.c_str());
		}
		else
		{
			time_t ltime;
			time(&ltime);
			tm* gmt = gmtime(&ltime);

			static std::string const serverName = "RenesWebserver (Windows)";

			char* asctime_remove_nl = asctime(gmt);
			asctime_remove_nl[24] = 0;

			buffer = "";
			buffer += "HTTP/1.1 ";
			s->Write(buffer.c_str(), buffer.length());

			if (!req.auth_realm_.empty())
			{
				buffer = "";
				buffer += "401 Unauthorized\n";
				buffer += "WWW-Authenticate: Basic Realm=\"";
				buffer += req.auth_realm_;
				buffer += "\"\n";
				s->Write(buffer.c_str(), buffer.length());
			}
			else
			{
				buffer = "";
				buffer += (req.status_ + "\n");
				s->Write(buffer.c_str(), buffer.length());
			}
			buffer = "";
			buffer += (string("Date: ") + asctime_remove_nl + " GMT\n");
			buffer += (string("Server: ") + serverName + "\n");
			buffer += (string("Connection: close") + "\n");
			s->Write(buffer.c_str(), buffer.length());
			std::stringstream str_str;
			str_str << req.answer_.size();

			buffer = "";
			buffer += "Content-Type: text/html; charset=ISO-8859-1\n";
			buffer += "Content-Length: " + str_str.str() + "\n";
			buffer += "\n";
			buffer += req.answer_ + "\n";
			s->Write(buffer.c_str(), buffer.length());
		}
	}

	s->Close();
	delete[] filebuffer;
	return NULL;
}

class RequestThread : public wxThread
{
public:
	RequestThread(void * data) : wxThread(wxTHREAD_JOINABLE) {
		Create();
		ptr_s = data;
		cnt++;
	}
	virtual void * Entry() {
		called++;
		ProcessRequest(ptr_s);
		return NULL;
	}
	static int cnt;
	static int called;
private:
	void* ptr_s;
};

int RequestThread::cnt = 0;
int RequestThread::called = 0;

webserver::webserver(int port_to_listen)
{
	put2log("starting web server");

	in = NULL;
	char buffer[2048];
	bool success = false;
	const unsigned int port_try = 100;
	for (unsigned int deltaport = 0; deltaport <= port_try; ++deltaport) {
		wxIPV4address addr;
		addr.AnyAddress();
		addr.Service(port_to_listen + deltaport);
		in = new wxSocketServer(addr);
		if (in->Ok()) {			
			success = true;
			port_num = port_to_listen + deltaport;
			break;
		}
		delete in;
	}
	if (!success) {		
		put2log("Failed to create webserver!");
		return;
	}

	put2log("port_num = " + int2str(port_num));
	local_host_name = "http://127.0.0.1:" + int2str(port_num) + "/";
	host_name = "http://" + server_ip + ":" + int2str(port_num) + "/";
	new_port_num = port_num;	

	request_func_ = main_handler;
	while (1)
	{		
		wxSocketBase* ptr_s = in->Accept();
		if(ptr_s)
		{
			put2log(string("client from ") + wxSocketHelper::GetClientIP(ptr_s));
			put2log(string("thread created: ") + int2str(RequestThread::cnt) + string(", called ") + int2str(RequestThread::called));
			// ProcessRequest(ptr_s);
			RequestThread requestThread((void*) ptr_s);
			requestThread.Run();
			requestThread.Wait();
		}
	}
}

void webserver::MainLoop(request_func main_handler, void* app) {
	if (!in) return;
	request_func_ = main_handler;
	while (1)
	{		
		wxSocketBase* ptr_s = in->Accept();
		if(ptr_s)
		{
			put2log(string("client from ") + wxSocketHelper::GetClientIP(ptr_s));
			put2log(string("thread created: ") + int2str(RequestThread::cnt) + string(", called ") + int2str(RequestThread::called));
			// ProcessRequest(ptr_s);
			RequestThread requestThread((void*) ptr_s);
			requestThread.Run();
			requestThread.Wait();
		}
	}
}
