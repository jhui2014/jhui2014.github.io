rm(list = ls(all.names = TRUE))

source("sim-knockoffs.R")
source("analysis-knockoffs-TCGA.R")
source("sim-knockoffs.supp.R")