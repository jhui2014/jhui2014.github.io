#ifndef DRAW_BAR_H
#define DRAW_BAR_H

#include "draw_signal.h"

class draw_bar: public draw_signal
{
public:
	bool box;
	bool no_data;

	vector<string> bar_filenames;
	string chr;
	int startpos, endpos;
	double signal_width;
	bool do_window_count;
	double window_left, window_right;

	draw_bar();
	virtual string print_usage();
	virtual bool get_params(const vector<string> &params);
	virtual bool load_data();
	virtual bool prepare_data();
};

#endif //DRAW_BAR_H
