#include "display_data.h"
#include "drawCommon.h"

display_data::display_data()
{

}

display_data::display_data(http_request* r)
{
	src_filename = "";
	pic_filename = "";
	req = r;
}

bool display_data::load_from_file(string file_name)
{
	src_filename = ReadIni(file_name, "data/src_filename", wxString(""));
	pic_filename = ReadIni(file_name, "data/pic_filename", wxString(""));
	return true;
}

bool display_data::update_params()
{
	bool updated = false;

	if (req->params_.count("create_data_session") > 0)
	{
		src_filename = req->params_["data_filename"];
		updated = true;
	}

	return updated;
}

bool display_data::write_to_file(string file_name)
{
	WriteIni(file_name, "data/src_filename", src_filename, src_filename != "");
	WriteIni(file_name, "data/pic_filename", pic_filename, pic_filename != "");
	return true;
}

string display_data::get_html()
{
	html_formater my_html_formater;
	if (src_filename == "")
	{
		my_html_formater.load_from_template_file(template_path
			+ "new_data_session.html");
	}
	else
	{
		if (pic_filename == "")
		{
			pic_filename = get_random_pic_file_name();
		}
		if (!file_exists(temp_path + client_ip + pic_filename) || refresh)
		{
			draw_data my_draw;
			my_draw.data_filename = src_filename;
			my_draw.load_data();
			my_draw.prepare_data();
			my_draw.drawfile(temp_path + client_ip + pic_filename);
		}

		my_html_formater.load_from_template_file(template_path
			+ "draw_data.html");
		my_html_formater.replace_keyword("$DATA_FILE_NAME$", server_temp_path + client_ip
			+ pic_filename);
	}
	return my_html_formater.buf;
}

