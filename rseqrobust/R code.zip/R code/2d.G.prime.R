rm(list=ls())
source("rSeqRobust.R")

#######################################################################
#######################################################################
#2-d function G'

set.seed(1234)
m=100
mu=0
sd=1
lower=-5
upper=5
ngrid=1000

mu1=rnorm(m,mu,sd)
mu2=rnorm(m,mu,sd)
x=seq(lower,upper,length.out=ngrid)
y=rep(0,ngrid)

for (lambda in c(0.2, 1)) {
  for (i in 1:ngrid) {
    y[i] = G.prime(mu1,mu2,x[i],lambda)
  }
  min.d=min.G.prime(mu1,mu2,lambda)
  
  pdf(paste("2d.lambda=", lambda, ".pdf", sep=""), 6, 2.5)
  par(mar=c(4,4,1,1) + 0.1)   
  plot(x,y,type='l',xlab="d",ylab="G'(d)")
  abline(v=min.d,col=4,lty=2)
  dev.off()
}
