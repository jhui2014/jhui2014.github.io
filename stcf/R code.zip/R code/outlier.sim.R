#run simulation on robust simple linear regression

rm(list = ls())
library(plot3D)
library(MASS)
library(fit.models)
library(lattice)
library(robustbase)
library(rrcov)
library(robust)
library(expm)
library(EnvStats)
library(xtable)
source("slr.R")
source("common.R")
set.seed(1234)

n = 100 # n: Num of subjects.
m = 100 # m: Num of experiments.
L_vec = c(0, 20) # L_vec: A vector indicating leverages in the simulations. 0 indicates no additional leverages added to the outliers.
O_vec = c(5, 10, 20, 30, 45, 60) # O_vec: A vector indicating percent of outliers in the simulations.

mask.output = NULL
swamp.output = NULL
pdf("outlier.pdf", height = 6, width = 6)
par(mfcol = c(2, 2))
par(mar=c(3, 3, 1, 0) + 0.1, mgp=c(2,0.8,0))
for (L in L_vec) {
    print(paste("L =", L))
    mask.mean = NULL
    mask.sem = NULL
    swamp.mean = NULL
    swamp.sem = NULL
    for (O in (n*O_vec/100)) {
        print(paste("O =", O))
        mask = NULL
        swamp = NULL
        for (p in 1:m) {
            #Data generation:
            x = runif(n, -15, 15)
            if (L > 0) {
                x[1:O] = runif(n = O, min = L, max = L + 1) #create leverage points
            }
            gamma_data = c(rexp(O, 0.1) + 3, rep(0, n - O))
            sigma = 1
            res = rnorm(n, 0, sigma)
            b0 = 1
            b1 = 2
            y = b0 + b1 * x + gamma_data + res
            lambda = 2.5 * sigma # Assume known sigma^2=1; choose lambda=2.5*sigma as cut off for outlier detection for all methods.

            # Implement GY's method.
            GY.result = lmRob(y ~ x, control = lmRob.control(final.alg = "Adaptive"))
            out.GY = (abs(summary(GY.result)[[3]]) > lambda) #summary(GY.result)[[3]]=residual=y-y_hat.

            #Implement She's method.
            # Use estimated gamma from GY as the pilot estimate for She's method
            She.result = hard_ipod(x, y, lambda, epsilon = 1e-6, matrix(summary(GY.result)[[3]], c(n, 1)))
            out.She = (She.result[1:n] != 0) #a vector of indicators. If a case is outlying, gamma[i]=1.

            #Implement the proposed method.
            pro_result = pro_simple(x, y, rep(lambda, n))
            out.pro = (abs(y - pro_result[2] - pro_result[3] * x) > lambda)

            # Implement MM estimator.
            MM = lmRob(y ~ x, control = lmRob.control(final.alg = "MM"))
            out.MM = (abs(summary(MM)[[3]]) > lambda) #summary(MM)[[3]]=residual=y-y_hat.

            # Implement LTS estimator.
            LTS = ltsReg(x, y)
            out.LTS = (abs(summary(LTS)[[3]]) > lambda | summary(LTS)[[3]] == 0)
            # Summary(LTS)[[3]] gives the residual. 
            # In addition, for cases considered to be outliers, summary(LTS)[[3]] will be set to zero.

            result = cbind(out.MM, out.LTS, out.GY, out.She, out.pro)

            mask = rbind(mask, apply(result, 2, function(x) { sum(x[1:O] == 0) / O }))
            swamp = rbind(swamp, apply(result, 2, function(x) { sum(x[(O + 1):n] != 0) / (n - O) }))
        }
        mask.output = rbind(mask.output, as.character(c(L, O, summarize(mask * 100, digits = 1))))
        swamp.output = rbind(swamp.output, as.character(c(L, O, summarize(swamp * 100, digits = 1))))
        mask.mean = rbind(mask.mean, colMeans(mask * 100))
        mask.sem = rbind(mask.sem, colSDs(mask * 100)/sqrt(nrow(mask)))
        swamp.mean = rbind(swamp.mean, colMeans(swamp * 100))
        swamp.sem = rbind(swamp.sem, colSDs(swamp * 100)/sqrt(nrow(swamp)))
    }
  	methods = c("MM", "LTS", "GY", "IPOD", "Proposed")
    colors = c("brown", "blue", "red", "blueviolet", "black")
    k = length(methods)
    plot(1:10, type = "n", xlim = range(O_vec), ylim = c(0,100), xlab = "Percent outliers (O%)", ylab = "Percent masking (M%)", main = paste("Leverage of outliers L = ", L), font.main = 1)
    for (l in 1:k) {
        lines(x = O_vec, y = mask.mean[,l], type = "b", lty = l, col = colors[l], pch = l)
        errorBar(x = O_vec, y = mask.mean[,l], lower = mask.sem[,l], upper = mask.sem[,l], col = colors[l], pch = l, add = T, gap.size = 0.25, bar.ends.size = 0.25)
    }
    legend("topleft", lty = 1:k, col = colors, pch = 1:k, legend = methods)
    plot(1:10, type = "n", xlim = range(O_vec), ylim = c(0,100), xlab = "Percent outliers (O%)", ylab = "Percent swamping (S%)", main = paste("Leverage of outliers L = ", L), font.main = 1)
    for (l in 1:k) {
        lines(x = O_vec, y = swamp.mean[,l], type = "b", lty = l, col = colors[l], pch = l)
        errorBar(x = O_vec, y = swamp.mean[,l], lower = swamp.sem[,l], upper = swamp.sem[,l], col = colors[l], pch = l, add = T, gap.size = 0.25, bar.ends.size = 0.25)
    }
    legend("topleft", lty = 1:k, col = colors, pch = 1:k, legend = methods)
}
dev.off()

colnames(mask.output) <- c("L", "O\\%", methods)
sink(file = paste("mask.tex", sep = ""))
print(xtable(mask.output), include.rownames = F, sanitize.text.function = function(col) { sapply(col, bold) })
sink()

colnames(swamp.output) <- c("L", "O\\%", methods)
sink(file = paste("swamp.tex", sep = ""))
print(xtable(swamp.output), include.rownames = F, sanitize.text.function = function(col) { sapply(col, bold) })
sink()
