/*
 regbar.h - Header file for regbar file manipulation
 written by JIANG Hui,
 Institute for Computational and Mathematical Engineering, Stanford University
 May, 2007 -
 */

#ifndef REGBAR_H
///Define this macro to prevent from including this header file more than once.
#define REGBAR_H

#include "bar.h"

class regbar: public bar {
public:
	bool read_from_file_region(string file_name, string chr, int start,
			int end, vector<vector<bar_column> > &data);
	bool read_from_text_file(string filename);
};

inline bool is_regbar_file(string file_name) {
	if (!is_bar_file(file_name))
		return false;

	if (!file_exists(file_name))
		return false;

	FILE *file = fopen(file_name.c_str(), "rb");
	if (!file) {
		//		if (verbose) cout << "error opening bar file:" << file_name << endl;
		return false;
	}
	bar mybar;
	if (!mybar.read_from_file_header(file)) {
		fclose(file);
		return false;
	}

	if (mybar.num_col < 3 || mybar.num_col > 4) {
		fclose(file);
		return false;
	}

	if (mybar.data_type.size() < 3 || mybar.data_type[0] != DATA_INT
			|| mybar.data_type[1] != DATA_INT || mybar.data_type[2] != DATA_INT) {
		fclose(file);
		return false;
	}

	int i;
	for (i = 3; i < (int) mybar.data_type.size(); i++) {
		if (mybar.data_type[i] != DATA_FLOAT) {
			fclose(file);
			return false;
		}
	}

	fclose(file);
	return true;

}

inline bool is_regbar_text_file(string file_name) {
	if (!is_bar_text_file(file_name))
		return false;

	if (!file_exists(file_name))
		return false;

	ifstream ifs(file_name.c_str());
	string readline;

	int line_num = 0;
	while (getline(ifs, readline)) {
		if (readline == "")
			continue;
		line_num++;
		vector<string> tokens = string_tokenize(readline, " \t");
		if (tokens.size() >= 3 && is_int(tokens[1]) && is_int(tokens[2]))
			break;
		if (line_num == 2) {
			ifs.close();
			return false;
		}
	}

	ifs.close();
	return true;
}

inline bool convert_from_text_to_regbar(const string text_file_name,
		const string regbar_file_name) {
	regbar myregbar;
	if (!myregbar.read_from_text_file(text_file_name)) {
		cout << "error reading text file " << text_file_name << endl;
		return false;
	}
	if (!myregbar.write_to_file(regbar_file_name)) {
		cout << "error writing regbar file " << regbar_file_name << endl;
		return false;
	}
	return true;
}

inline bool regbar::read_from_file_region(string file_name, string chr,
		int start, int end, vector<vector<bar_column> > &data) {
	if (!is_regbar_file(file_name)) {
		cout << file_name << " is not a vaid regbar file.\n";
		return false;
	}

	FILE *file;
	int i, j;
	file = fopen(file_name.c_str(), "rb");
	if (!file) {
		cout << "error opening bar file:" << file_name << endl;
		return false;
	}
	if (verbose)
		cout << "reading bar file:" << file_name << endl;

	if (!read_from_file_header(file)) {
		cout << "reading bar file header failed.\n";
		return false;
	}
	if (data_type.size() < 3 || data_type[0] != DATA_INT || data_type[1]
			!= DATA_INT || data_type[2] != DATA_INT) {
		cout << "first or second field is not coordinate" << endl;
		return false;
	}

	//read sequences
	if (verbose)
		cout << "reading sequences\n";
	for (i = 0; i < (int) num_seq; i++) {
		if (verbose && i == 0)
			cout << "sequence " << i + 1 << endl;
		if (!read_from_file_sequence_info(file, sequences[i])) {
			cout << "error reading bar file: bad sequence info" << endl;
			return false;
		}
		if (sequences[i].name != chr) {
			if (0 != fseek(file, size_data * sequences[i].num_data, SEEK_CUR)) {
				cout << "error fseek" << endl;
				return false;
			}
		} else {
			long pos = ftell(file);
			if (pos < 0) {
				cout << "error ftell" << endl;
				return false;
			}
			int low = 0, high = sequences[i].num_data - 1, value = start, mid =
					0;
			vector<bar_column> temp_data;
			temp_data.resize(num_col);
			while (low <= high) {
				mid = (low + high) / 2;
				if (fseek(file, pos + size_data * mid, SEEK_SET)) {
					cout << "error fseek" << endl;
					return false;
				}
				if (!read_from_file_data(file, temp_data)) {
					cout << "error read data" << endl;
					return false;
				}
				if (temp_data[0].data_int > value)
					high = mid - 1;
				else if (temp_data[0].data_int < value)
					low = mid + 1;
				else
					break;
			}
			j = mid;
			if (fseek(file, pos + size_data * j, SEEK_SET)) {
				cout << "error fseek" << endl;
				return false;
			}
			if (!read_from_file_data(file, temp_data)) {
				cout << "error read data" << endl;
				return false;
			}
			j -= temp_data[2].data_int;
			if (fseek(file, pos + size_data * j, SEEK_SET)) {
				cout << "error fseek" << endl;
				return false;
			}
			if (!read_from_file_data(file, temp_data)) {
				cout << "error read data" << endl;
				return false;
			}
			while (temp_data[0].data_int <= end) {
				if (temp_data[1].data_int >= start)
					data.push_back(temp_data);
				j++;
				if (j == (int) sequences[i].num_data)
					break;
				if (!read_from_file_data(file, temp_data)) {
					cout << "error read data" << endl;
					return false;
				}
			}
			break; //skip other sequences;
		}
	}

	fclose(file);
	return true;
}

class regbar_data_struct {
public:
	string chr;
	int start, end;
	int parent;
	vector<float> intensities;
};

inline bool operator <(const regbar_data_struct &data1,
		const regbar_data_struct &data2) {
	if (data1.chr < data2.chr)
		return true;
	if (data1.chr == data2.chr && data1.start < data2.start)
		return true;
	if (data1.chr == data2.chr && data1.start == data2.start && data1.end
			< data2.end)
		return true;
	return false;
}

inline bool regbar::read_from_text_file(string filename) {
	if (!is_regbar_text_file(filename)) {
		cout << filename << " is not a vaid regbar text file.\n";
		return false;
	}

	printf("Loading text file %s.\n", filename.c_str());
	version = 1.0f;
	num_seq = 0;
	sequences.clear();
	num_parameter = 0;
	parameters.clear();

	vector<regbar_data_struct> regbar_data;
	ifstream ifs(filename.c_str());
	string readline;
	int i, j;
	int line_num = 0;
	int data_field_num = -1;
	while (getline(ifs, readline)) {
		if (readline == "")
			continue;
		line_num++;
		vector<string> tokens = string_tokenize(readline, " \t");
		if (tokens.size() < 3 || !is_int(tokens[1]) || !is_int(tokens[2])) {
			if (line_num == 1)
				continue;
			else {
				cout << "bad format in regbar text file, bad format in line: " << line_num << endl;
				return false;
			}
		}
		regbar_data_struct data1;
		data1.chr = tokens[0];
		data1.start = str2int(tokens[1]);
		data1.end = str2int(tokens[2]);
		if (data1.end < data1.start || data1.start < 0) {
			cout << "bad format in regbar text file, bad coordinate in line: " << line_num << endl;
			return false;
		}
		data1.parent = -1;
		int new_data_field_num = 0;
		for (i = 3; i < (int) tokens.size(); i++) {
			if (is_num(tokens[i])) {
				new_data_field_num++;
				data1.intensities.push_back((float) str2double(tokens[i]));
			}
		}
		if (data_field_num == -1)
			data_field_num = new_data_field_num;
		if (data_field_num != new_data_field_num) {
			cout << "bad format in regbar text file, bad number of data field in line: " << line_num << endl;
			return false;
		}
		regbar_data.push_back(data1);
	}
	printf("%d data units loaded.\n", regbar_data.size());

	num_col = data_field_num + 3;
	data_type.clear();
	data_type.push_back(DATA_INT);
	data_type.push_back(DATA_INT);
	data_type.push_back(DATA_INT);
	for (i = 0; i < data_field_num; i++)
		data_type.push_back(DATA_FLOAT);
	size_data = 4 * (data_field_num + 3);

	sort(regbar_data.begin(), regbar_data.end());
	for (i = (int) regbar_data.size() - 1; i >= 0; i--) {
		j = i;
		while (j < (int) regbar_data.size() && regbar_data[i].chr
				== regbar_data[j].chr && regbar_data[i].end
				>= regbar_data[j].start) {
			regbar_data[j].parent = j - i;
			j++;
		}
	}
	string current_chr = "";
	for (i = 0; i < (int) regbar_data.size(); i++) {
		if (regbar_data[i].chr != current_chr) {
			num_seq++;
			bar_sequence seq;
			seq.name = regbar_data[i].chr;
			seq.len_seq_name = (int) seq.name.length();
			seq.len_group_name = 0;
			seq.group_name = "";
			seq.len_version_num = 0;
			seq.version_num = "";
			seq.num_parameter = 0;
			seq.parameters.clear();
			seq.num_data = 0;
			sequences.push_back(seq);
			current_chr = regbar_data[i].chr;
		}
		vector<bar_column> column;
		column.resize(data_field_num + 3);
		column[0].data_int = regbar_data[i].start;
		column[1].data_int = regbar_data[i].end;
		column[2].data_int = regbar_data[i].parent;
		for (j = 0; j < data_field_num; j++)
			column[j + 3].data_float = regbar_data[i].intensities[j];
		sequences[num_seq - 1].data.push_back(column);
		sequences[num_seq - 1].num_data++;
	}
	printf("%d sequences loaded.\n", num_seq);
	printf("Successfully loaded input file %s.\n", filename.c_str());
	return true;
}

#endif //REGBAR_H
