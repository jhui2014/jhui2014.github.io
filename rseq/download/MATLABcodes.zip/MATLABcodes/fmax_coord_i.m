function [ X, f ] = fmax_coord_i( A, T, X, k )

epsilon = 1e-10;

[m,n] = size(A);

f = log_likelihood(A, T, X);

g = grad_log_likelihood_i(A, T, X, k);

if g > 0
    g = 1;
elseif g < 0
    g = -1;
else
    return;
end

it = 0;

max_it = 10000;

x_old = X(k);

step = 1e6;

while 1
    X(k) = x_old + step * g;
    
    if X(k) < 0
        X(k) = 0;
    end
    
    new_f = log_likelihood(A, T, X);
    
    if new_f > f
        f = new_f;
        return;
    end
    
    if step > epsilon
        step = step / 2;
    else
        break;
    end
    
    if it < max_it
        it = it + 1;
    else
        break;
    end
end

if it >= max_it
    disp('warning: maximum iteration exceeded.');
end

X(k) = x_old;