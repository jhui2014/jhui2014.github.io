#include "shared_data.h"

bool local_only;
string wwwroot;
string program_path;
string ini_filename;
string module_path;
string template_path;
string session_path;
string temp_path;
string log_filename;
string server_temp_path;
string server_ip;
string client_ip;
string local_host_name;
string host_name;
bool local_client;
int port_num;

bool new_local_only;
int new_port_num;

int max_cache_size_MB;
bool cache_genefiles;
map<string,time_t> genefile_time_cache;
map<string,genefile> genefile_cache;

string title;

string folder_to_be_opened;
