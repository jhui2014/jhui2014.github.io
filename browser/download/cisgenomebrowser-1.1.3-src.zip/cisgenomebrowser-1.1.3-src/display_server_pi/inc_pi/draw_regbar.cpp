#include "draw_regbar.h"

#include "regbar.h"
#include "chr_region.h"
#include "file_operation.h"
#include "math_utils.h"

draw_regbar::draw_regbar()
{
	top_axis = bottom_axis = true;
	left_axis = right_axis = true;

	regbar_filenames.clear();
	chr = "";
	startpos = endpos = -1;
	box = false;
	no_data = false;
}

string draw_regbar::print_usage()
{
	return "</regbar:<regbar file>>s [/color:0xXXXXXX]s </region:<chr>:<sequence start position>-<sequence end position>> [/range:<range low>-<range high>] [/size:<picture width>x<picture height>] [/axis:xxxx] [/plottype:<bar | heatmap>] [/box]\n";
}

bool draw_regbar::get_params(const vector<string> &params)
{
	bool good_options = true;
	for (int i = 0; i < (int) params.size(); i++)
	{
		string option = params[i];

		string command = "";
		string parameter = "";
		if (option[0] != '/')
		{
			good_options = false;
			break;
		}
		size_t index = option.find(":");
		if (index != string::npos)
		{
			command = option.substr(1, index - 1);
			parameter = option.substr(index + 1);
		}
		else
		{
			command = option.substr(1);
		}
		if (command == "range")
		{
			sscanf(parameter.c_str(), "%lf-%lf", &rangelow, &rangehigh);
		}
		else if (command == "bar")
		{
			regbar_filenames.push_back(parameter);
		}
		else if (command == "size")
		{
			sscanf(parameter.c_str(), "%dx%d", &size.cx, &size.cy);
			if (size.cx <= 0 || size.cy <= 0)
			{
				error_msg = "Invalid parameter. wrong picture width.\n";
				good_options = false;
				break;
			}
		}
		else if (command == "color")
		{
			PICOLORREF color;
			sscanf(parameter.c_str(), "%hX", &color);
			colors.push_back(color);
		}
		else if (command == "region")
		{
			if (!parse_region(parameter, chr, startpos, endpos))
			{
				error_msg = "Invalid parameter. wrong region.\n";
				good_options = false;
				break;
			}
		}
		else if (command == "axis")
		{
			int mask;
			sscanf(parameter.c_str(), "%d", &mask);
			top_axis = (mask >= 1000);
			mask %= 1000;
			bottom_axis = (mask >= 100);
			mask %= 100;
			left_axis = (mask >= 10);
			mask %= 10;
			right_axis = (mask >= 1);
		}
		else if (command == "plottype")
		{
			if (parameter == "bar")
			{
				plot_type = PLOT_TYPE_BAR;
			}
			else if (parameter == "heatmap")
			{
				plot_type = PLOT_TYPE_HEATMAP;
			}
			else
			{
				error_msg = "Invalid parameter. unknow plot type.\n";
				good_options = false;
				break;
			}
		}
		else if (command == "box")
		{
			box = true;
		}
		else
		{
			good_options = false;
			break;
		}
	}
	return good_options;
}

bool draw_regbar::load_data()
{
	if (startpos <= 0 || endpos <= 0 || chr == "")
	{
		error_msg = "Invalid parameter. no region information.\n";
		return false;
	}

	domainlow = startpos;
	domainhigh = endpos;

	positions.clear();
	intensities.clear();

	for (int i = 0; i < (int) regbar_filenames.size(); i++)
	{
		if (!file_exists(regbar_filenames[i]))
		{
			error_msg = "file doesn't exist.\n";
			return false;
		}

		if (!is_regbar_file(regbar_filenames[i]))
		{
			if (file_exists(regbar_filenames[i] + ".regbar")
				&& compare_file_time(regbar_filenames[i],
				regbar_filenames[i] + ".regbar") <= 0)
			{
				if (!is_regbar_file(regbar_filenames[i] + ".regbar"))
				{
					error_msg
						= "failed converting file to regbar format: file already exists and in wrong format.\n";
				}
			}
			else
			{
				if (!is_regbar_text_file(regbar_filenames[i]))
				{
					error_msg = "file is neither in regbar nor in text format.\n";
					return false;
				}
				if (!convert_from_text_to_regbar(regbar_filenames[i],
					regbar_filenames[i] + ".regbar"))
				{
					error_msg = "failed converting file to regbar format.\n";
					return false;
				}
			}
			regbar_filenames[i] = regbar_filenames[i] + ".regbar";
		}

		regbar myregbar;
		myregbar.verbose = false;
		vector<vector<bar_column> > data;
		if (!myregbar.read_from_file_region(regbar_filenames[i], chr, startpos,
			endpos, data))
		{
			error_msg = "error reading regbar file\n";
			return false;
		}
		if (myregbar.num_col < 3)
		{
			error_msg = "num_col < 3\n";
			return false;
		}
		if (myregbar.data_type[0] != DATA_INT || myregbar.data_type[1]
		!= DATA_INT || myregbar.data_type[2] != DATA_INT)
		{
			error_msg = "bad data type\n";
			return false;
		}
		int j, k;
		for (j = 3; j < (int) myregbar.num_col; j++)
		{
			if (myregbar.data_type[j] != DATA_FLOAT)
			{
				error_msg = "bad data type\n";
				return false;
			}
		}
		if (myregbar.num_col == 3)
		{
			vector<double> position;
			position.resize(data.size());
			vector<double> intensity;
			intensity.resize(data.size());
			vector<double> width;
			width.resize(data.size());
			for (k = 0; k < (int) data.size(); k++)
			{
				position[k] = (data[k][0].data_int + data[k][1].data_int) / 2.0;
				width[k] = data[k][1].data_int - data[k][0].data_int;
				intensity[k] = 1;
			}
			positions.push_back(position);
			intensities.push_back(intensity);
			widthes.push_back(width);
		}
		else
		{
			for (j = 0; j < (int) myregbar.num_col - 3; j++)
			{
				vector<double> position;
				position.resize(data.size());
				vector<double> intensity;
				intensity.resize(data.size());
				vector<double> width;
				width.resize(data.size());
				for (k = 0; k < (int) data.size(); k++)
				{
					position[k] = (data[k][0].data_int + data[k][1].data_int)
						/ 2.0;
					width[k] = data[k][1].data_int - data[k][0].data_int;
					intensity[k] = data[k][j + 3].data_float;
				}
				positions.push_back(position);
				intensities.push_back(intensity);
				widthes.push_back(width);
			}
		}
	}

	int data_size = 0;
	for (int i = 0; i < (int) positions.size(); i++)
	{
		data_size += (int) positions[i].size();
	}

	if (data_size == 0)
	{
		no_data = true;
		return true;
	}

	if (plot_type == PLOT_TYPE_HEATMAP)
	{
		//rangelow = rangehigh = 0;
		left_space = left_axis;
		right_space = right_axis;
		left_axis = right_axis = false;
	}

	return true;
}

bool draw_regbar::prepare_data()
{
	draw_signal::prepare_data();
	return true;
}
