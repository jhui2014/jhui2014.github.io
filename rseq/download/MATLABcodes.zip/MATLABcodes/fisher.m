function [ I ] = fisher( A, T, X )

epsilon = 1e-10;

[m, n] = size(A);

X_new = X + epsilon;

I = A' * diag((A * X_new).^-1) * A;