rm(list=ls())

# install.packages('VennDiagram')
library(VennDiagram)
options(java.parameters = "-Xmx1024m")
library(rJava)
require(xlsx) # what is the difference between require and library?

resultdir <- 'results/real_data/summary/'

nTags <- 20531   # number of genes

##################################################################################################
#################################### paramter set up for ADMM ####################################
out.results <- read.csv(file="results/real_data/benchmarks.csv")
out.results[,1] <- as.character(out.results[,1])
for(ii in 1:length(rownames(out.results))){out.results[ii,1] <- unlist(strsplit(out.results[ii,1], split='|', fixed=TRUE))[1]}

out.edgeR <- out.results[,1:4]
out.edgeR <- out.edgeR[order(out.edgeR$pval),]
colnames(out.edgeR) <- c("gene ID","pval","padj","log2FC")
write.xlsx2(out.edgeR, file = paste(resultdir, "benchmarks_sorted.xlsx", sep=""), sheetName = "edgeR", col.names = TRUE, row.names = FALSE)

where_top_gene.edgeR <- which(out.edgeR$pval<=0.05/nTags)
# where_top_gene.edgeR <- which(out.edgeR$padj < 0.05)
if(length(where_top_gene.edgeR)!=0) {
  ID_top_gene.edgeR <- out.edgeR[1:tail(where_top_gene.edgeR,1),1]
  # ID_top_gene.edgeR <- out.edgeR[1:50,1]
  
  out_top_gene.edgeR <- out.edgeR[1:tail(where_top_gene.edgeR,1),]
} else {
  ID_top_gene.edgeR <- NULL
  
  out_top_gene.edgeR <- NULL
}



out.DESeq2 <- out.results[,c(1,5:7)]
out.DESeq2 <- out.DESeq2[order(out.DESeq2$pval),]
colnames(out.DESeq2) <- c("gene ID","pval","padj", "log2FC")
write.xlsx2(out.DESeq2, file = paste(resultdir, "benchmarks_sorted.xlsx", sep=""), sheetName = "DESeq2", append=TRUE, col.names = TRUE, row.names = FALSE)

where_top_gene.DESeq2 <- which(out.DESeq2$pval<=0.05/nTags)
# where_top_gene.DESeq2 <- which(out.DESeq2$padj < 0.05) # < or <=?
if(length(where_top_gene.DESeq2)!=0) {
  ID_top_gene.DESeq2 <- out.DESeq2[1:tail(where_top_gene.DESeq2,1),1]
  # ID_top_gene.DESeq2 <- out.DESeq2[1:50,1]
  
  out_top_gene.DESeq2 <- out.DESeq2[1:tail(where_top_gene.DESeq2,1),]
} else {
  ID_top_gene.DESeq2 <- NULL
  
  out_top_gene.DESeq2 <- NULL
}


out.limma <- out.results[,c(1,8:10)]
out.limma <- out.limma[order(out.limma$pval),]
colnames(out.limma) <- c("gene ID","pval","padj", "log2FC")
write.xlsx2(out.limma, file = paste(resultdir, "benchmarks_sorted.xlsx", sep=""), sheetName = "limma-voom", append=TRUE, col.names = TRUE, row.names = FALSE)

where_top_gene.limma <- which(out.limma$pval<=0.05/nTags)
# where_top_gene.limma <- which(out.limma$padj < 0.05)
if(length(where_top_gene.limma)!=0) {
  ID_top_gene.limma <- out.limma[1:tail(where_top_gene.limma,1),1]
  # ID_top_gene.limma <- out.limma[1:50,1]
  
  out_top_gene.limma <- out.limma[1:tail(where_top_gene.limma,1),]
} else {
  ID_top_gene.limma <- NULL
  
  out_top_gene.limma <- NULL
}



# significance level: used for tuning parameter selction
sig_leval <- 0.01

out.results2 <- read.csv(paste("results/real_data/rSeqRobust_sigLeval=", sig_leval, ".csv", sep=""))
out.results2[,1] <- as.character(out.results2[,1])
for(ii in 1:length(rownames(out.results2))){out.results2[ii,1] <- unlist(strsplit(out.results2[ii,1], split='|', fixed=TRUE))[1]}

out.ELMSeq <- out.results2[,1:4]
out.ELMSeq <- out.ELMSeq[order(out.ELMSeq$pval),]
colnames(out.ELMSeq) <- c("gene ID","pval","padj","log2FC")
write.xlsx2(out.ELMSeq, file = paste(resultdir, "rSeqRobust_sigLeval=", sig_leval, "_sorted.xlsx", sep=""), sheetName = "ELMSeq", col.names = TRUE, row.names = FALSE)

where_top_gene.ELMSeq = which(out.ELMSeq$pval<=0.05/nTags)
# where_top_gene.ELMSeq = which(out.ELMSeq$padj < 0.05)
if(length(where_top_gene.ELMSeq)!=0) {
  ID_top_gene.ELMSeq <- out.ELMSeq[1:tail(where_top_gene.ELMSeq,1),1]
  # ID_top_gene.ELMSeq <- out.ELMSeq[1:50,1]
  
  out_top_gene.ELMSeq <- out.ELMSeq[1:tail(where_top_gene.ELMSeq,1),]
} else {
  ID_top_gene.ELMSeq <- NULL
  
  out_top_gene.ELMSeq <- NULL
}


out.rSeqRobust <- out.results2[,c(1,5:7)]
out.rSeqRobust <- out.rSeqRobust[order(out.rSeqRobust$pval),]
colnames(out.rSeqRobust) <- c("gene ID","pval","padj","log2FC")
write.xlsx2(out.rSeqRobust, file = paste(resultdir, "rSeqRobust_sigLeval=", sig_leval, "_sorted.xlsx", sep=""), sheetName = "rSeqRobust", append=TRUE, col.names = TRUE, row.names = FALSE)

where_top_gene.rSeqRobust = which(out.rSeqRobust$pval<=0.05/nTags)
# where_top_gene.rSeqRobust = which(out.rSeqRobust$padj < 0.05)
if(length(where_top_gene.rSeqRobust)!=0) {
  ID_top_gene.rSeqRobust <- out.rSeqRobust[1:tail(where_top_gene.rSeqRobust,1),1]
  # ID_top_gene.rSeqRobust <- out.rSeqRobust[1:50,1]
  
  out_top_gene.rSeqRobust <- out.rSeqRobust[1:tail(where_top_gene.rSeqRobust,1),]
} else {
  ID_top_gene.rSeqRobust <- NULL
  
  out_top_gene.rSeqRobust <- NULL
}


## ===================================================  display top genes  ===================================================
ID_top_gene_unique_wo_ELMSeq <- setdiff(ID_top_gene.rSeqRobust,union(union(ID_top_gene.edgeR,ID_top_gene.DESeq2), ID_top_gene.limma))
if(length(ID_top_gene_unique_wo_ELMSeq)!=0){
  where_top_gene_unique_wo_ELMSeq <- match(ID_top_gene_unique_wo_ELMSeq,ID_top_gene.rSeqRobust)
  # colnames(ID_top_gene_unique_wo_ELMSeq) <- "gene ID"
  write.xlsx2(out_top_gene.rSeqRobust[where_top_gene_unique_wo_ELMSeq,], file=paste(resultdir, "rSeqRobust_sigLeval=", sig_leval, "_summary.xlsx", sep=""),
              sheetName="unique_wo_ELMSeq", col.names = FALSE, row.names = FALSE)
}

append <- FALSE
ID_top_gene_unique <- setdiff(ID_top_gene.rSeqRobust, union(union(union(ID_top_gene.edgeR,ID_top_gene.DESeq2), ID_top_gene.limma),ID_top_gene.ELMSeq))
if(length(ID_top_gene_unique)!=0){
  where_top_gene_unique <- match(ID_top_gene_unique,ID_top_gene.rSeqRobust)
  # colnames(ID_top_gene_unique) <- "gene ID"
  write.xlsx2(out_top_gene.rSeqRobust[where_top_gene_unique,], file=paste(resultdir, "rSeqRobust_sigLeval=", sig_leval, "_summary.xlsx", sep=""),
              sheetName="unique", append=TRUE, col.names = FALSE, row.names = FALSE)
}

ID_top_gene_intersect <- intersect(intersect(intersect(intersect(ID_top_gene.edgeR,ID_top_gene.DESeq2), ID_top_gene.limma),ID_top_gene.ELMSeq),ID_top_gene.rSeqRobust)
if(length(ID_top_gene_intersect)!=0){
  where_top_gene_intersect <- match(ID_top_gene_intersect,ID_top_gene.rSeqRobust)
  # colnames(ID_top_gene_intersect) <- "gene ID"
  write.xlsx2(out_top_gene.rSeqRobust[where_top_gene_intersect,], file=paste(resultdir, "rSeqRobust_sigLeval=", sig_leval, "_summary.xlsx", sep=""),
              sheetName="intersect_all", append=TRUE, col.names = FALSE, row.names = FALSE)
}

ID_top_gene_intersect_wo_edgeR <- setdiff(intersect(intersect(intersect(ID_top_gene.DESeq2, ID_top_gene.limma),ID_top_gene.ELMSeq),ID_top_gene.rSeqRobust), ID_top_gene_intersect)
if(length(ID_top_gene_intersect_wo_edgeR)!=0){
  where_top_gene_intersect_wo_edgeR <- match(ID_top_gene_intersect_wo_edgeR,ID_top_gene.rSeqRobust)
  # colnames(ID_top_gene_intersect_wo_edgeR) <- "gene ID"
  write.xlsx2(out_top_gene.rSeqRobust[where_top_gene_intersect_wo_edgeR,], file=paste(resultdir, "rSeqRobust_sigLeval=", sig_leval, "_summary.xlsx", sep=""),
              sheetName="intersect_wo_edgeR", append=TRUE, col.names = FALSE, row.names = FALSE)
}


ID_top_gene_intersect_wo_DESeq2 <- setdiff(intersect(intersect(intersect(ID_top_gene.edgeR, ID_top_gene.limma),ID_top_gene.ELMSeq),ID_top_gene.rSeqRobust), ID_top_gene_intersect)
if(length(ID_top_gene_intersect_wo_DESeq2)!=0){
  where_top_gene_intersect_wo_DESeq2 <- match(ID_top_gene_intersect_wo_DESeq2,ID_top_gene.rSeqRobust)
  # colnames(ID_top_gene_intersect_wo_DESeq2) <- "gene ID"
  write.xlsx2(out_top_gene.rSeqRobust[where_top_gene_intersect_wo_DESeq2,], file=paste(resultdir, "rSeqRobust_sigLeval=", sig_leval, "_summary.xlsx", sep=""),
              sheetName="intersect_wo_DESeq2", append=TRUE, col.names = FALSE, row.names = FALSE)
}


ID_top_gene_intersect_wo_limma <- setdiff(intersect(intersect(intersect(ID_top_gene.edgeR, ID_top_gene.DESeq2),ID_top_gene.ELMSeq),ID_top_gene.rSeqRobust), ID_top_gene_intersect)
if(length(ID_top_gene_intersect_wo_limma)!=0){
  where_top_gene_intersect_wo_limma <- match(ID_top_gene_intersect_wo_limma,ID_top_gene.rSeqRobust)
  # colnames(ID_top_gene_intersect_wo_limma) <- "gene ID"
  write.xlsx2(out_top_gene.rSeqRobust[where_top_gene_intersect_wo_limma,], file=paste(resultdir, "rSeqRobust_sigLeval=", sig_leval, "_summary.xlsx", sep=""),
              sheetName="intersect_wo_limma", append=TRUE, col.names = FALSE, row.names = FALSE)
}


ID_top_gene_intersect_wo_ELMSeq <- setdiff(intersect(intersect(intersect(ID_top_gene.edgeR, ID_top_gene.DESeq2),ID_top_gene.limma),ID_top_gene.rSeqRobust), ID_top_gene_intersect)
if(length(ID_top_gene_intersect_wo_ELMSeq)!=0){
  where_top_gene_intersect_wo_ELMSeq <- match(ID_top_gene_intersect_wo_ELMSeq,ID_top_gene.rSeqRobust)
  # colnames(ID_top_gene_intersect_wo_ELMSeq) <- "gene ID"
  write.xlsx2(out_top_gene.rSeqRobust[where_top_gene_intersect_wo_ELMSeq,], file=paste(resultdir, "rSeqRobust_sigLeval=", sig_leval, "_summary.xlsx", sep=""),
              sheetName="intersect_wo_ELMSeq", append=TRUE, col.names = FALSE, row.names = FALSE)
}


ID_top_gene_intersect_wo_rSeqRobust <- setdiff(intersect(intersect(intersect(ID_top_gene.edgeR, ID_top_gene.DESeq2),ID_top_gene.limma),ID_top_gene.ELMSeq), ID_top_gene_intersect)
if(length(ID_top_gene_intersect_wo_rSeqRobust)!=0){
  where_top_gene_intersect_wo_rSeqRobust <- match(ID_top_gene_intersect_wo_rSeqRobust,ID_top_gene.edgeR)
  # colnames(ID_top_gene_intersect_wo_rSeqRobust) <- "gene ID"
  write.xlsx2(out_top_gene.edgeR[where_top_gene_intersect_wo_rSeqRobust,], file=paste(resultdir, "rSeqRobust_sigLeval=", sig_leval, "_summary.xlsx", sep=""),
              sheetName="intersect_wo_rSeqRobust", append=TRUE, col.names = FALSE, row.names = FALSE)
}


ID_top_gene_intersect_wo_ELMSeq_and_rSeqRobust <- setdiff(intersect(intersect(ID_top_gene.edgeR, ID_top_gene.DESeq2),ID_top_gene.limma), ID_top_gene_intersect)
if(length(ID_top_gene_intersect_wo_ELMSeq_and_rSeqRobust)!=0){
  where_top_gene_intersect_wo_ELMSeq_and_rSeqRobust <- match(ID_top_gene_intersect_wo_ELMSeq_and_rSeqRobust,ID_top_gene.edgeR)
  # colnames(ID_top_gene_intersect_wo_ELMSeq_and_rSeqRobust <- "gene ID"
  write.xlsx2(out_top_gene.edgeR[where_top_gene_intersect_wo_ELMSeq_and_rSeqRobust,], file=paste(resultdir, "rSeqRobust_sigLeval=", sig_leval, "_summary.xlsx", sep=""),
              sheetName="intersect_wo_ELMSeq_and_rSeqRobust", append=TRUE, col.names = FALSE, row.names = FALSE)
}


grid.newpage()
venn.plot <- draw.quintuple.venn(area1 = length(ID_top_gene.edgeR),
                                 area2 = length(ID_top_gene.DESeq2),
                                 area3 = length(ID_top_gene.limma),
                                 area4 = length(ID_top_gene.ELMSeq),
                                 area5 = length(ID_top_gene.rSeqRobust),
                                 n12 = length(intersect(ID_top_gene.edgeR,ID_top_gene.DESeq2)),
                                 n13 = length(intersect(ID_top_gene.edgeR,ID_top_gene.limma)),
                                 n14 = length(intersect(ID_top_gene.edgeR,ID_top_gene.ELMSeq)),
                                 n15 = length(intersect(ID_top_gene.edgeR,ID_top_gene.rSeqRobust)),
                                 n23 = length(intersect(ID_top_gene.DESeq2,ID_top_gene.limma)),
                                 n24 = length(intersect(ID_top_gene.DESeq2,ID_top_gene.ELMSeq)),
                                 n25 = length(intersect(ID_top_gene.DESeq2,ID_top_gene.rSeqRobust)),
                                 n34 = length(intersect(ID_top_gene.limma,ID_top_gene.ELMSeq)),
                                 n35 = length(intersect(ID_top_gene.limma,ID_top_gene.rSeqRobust)),
                                 n45 = length(intersect(ID_top_gene.ELMSeq,ID_top_gene.rSeqRobust)),
                                 n123 = length(Reduce(intersect, list(ID_top_gene.edgeR,ID_top_gene.DESeq2,ID_top_gene.limma))),
                                 n124 = length(Reduce(intersect, list(ID_top_gene.edgeR,ID_top_gene.DESeq2,ID_top_gene.ELMSeq))),
                                 n125 = length(Reduce(intersect, list(ID_top_gene.edgeR,ID_top_gene.DESeq2,ID_top_gene.rSeqRobust))),
                                 n134 = length(Reduce(intersect, list(ID_top_gene.edgeR,ID_top_gene.limma,ID_top_gene.ELMSeq))),
                                 n135 = length(Reduce(intersect, list(ID_top_gene.edgeR,ID_top_gene.limma,ID_top_gene.rSeqRobust))),
                                 n145 = length(Reduce(intersect, list(ID_top_gene.edgeR,ID_top_gene.ELMSeq,ID_top_gene.rSeqRobust))),
                                 n234 = length(Reduce(intersect, list(ID_top_gene.DESeq2,ID_top_gene.limma,ID_top_gene.ELMSeq))),
                                 n235 = length(Reduce(intersect, list(ID_top_gene.DESeq2,ID_top_gene.limma,ID_top_gene.rSeqRobust))),
                                 n245 = length(Reduce(intersect, list(ID_top_gene.DESeq2,ID_top_gene.ELMSeq,ID_top_gene.rSeqRobust))),
                                 n345 = length(Reduce(intersect, list(ID_top_gene.limma,ID_top_gene.ELMSeq,ID_top_gene.rSeqRobust))),
                                 n1234 = length(Reduce(intersect, list(ID_top_gene.edgeR,ID_top_gene.DESeq2,ID_top_gene.limma,ID_top_gene.ELMSeq))),
                                 n1235 = length(Reduce(intersect, list(ID_top_gene.edgeR,ID_top_gene.DESeq2,ID_top_gene.limma,ID_top_gene.rSeqRobust))),
                                 n1245 = length(Reduce(intersect, list(ID_top_gene.edgeR,ID_top_gene.DESeq2,ID_top_gene.ELMSeq,ID_top_gene.rSeqRobust))),
                                 n1345 = length(Reduce(intersect, list(ID_top_gene.edgeR,ID_top_gene.limma,ID_top_gene.ELMSeq,ID_top_gene.rSeqRobust))),
                                 n2345 = length(Reduce(intersect, list(ID_top_gene.DESeq2,ID_top_gene.limma,ID_top_gene.ELMSeq,ID_top_gene.rSeqRobust))),
                                 n12345 = length(Reduce(intersect, list(ID_top_gene.edgeR,ID_top_gene.DESeq2,ID_top_gene.limma,ID_top_gene.ELMSeq,ID_top_gene.rSeqRobust))),
                                 category = c("edgeR", "DESeq2", "limma-voom", "ELMSeq", "rSeqRobust"),
                                 fill = c("orange", "red", "green", "blue", "purple"),
                                 lwd = rep(1, 5),
                                 lty = "dashed",
                                 cex = 1,
                                 cat.cex = 1,
                                 cat.pos = c(0, -30, -120, 135, 30),
                                 cat.col = c("orange", "red", "green", "blue", "purple"))

pdf(paste(resultdir, "rSeqRobust_sigLeval=", sig_leval, ".pdf", sep=""))
grid.draw(venn.plot)
dev.off()