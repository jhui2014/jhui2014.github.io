#ifndef _DISPLAY_GENOME_
#define _DISPLAY_GENOME_

#include "display_type.h"
#include "inc_pi/math_utils.h"

class display_track;

class display_genome: public display_type
{
public:
	vector<display_track*> tracks;
	vector<display_track*> hided_tracks;
	string region;
	string ucsc_genome_assembly;
	int pic_width;
	int pic_margin;
	int font_size;
	bool left_axis;
	bool right_axis;
	bool ucsc_browser;
	string grid;
	vector<int> fold_track;
	interval_set intervals;
	display_genome();
	virtual ~display_genome();
	display_genome(http_request* r);
	virtual bool load_from_file(string file_name);
	virtual bool update_params();
	virtual bool write_to_file(string file_name);
	display_track* create_track(string track_type, string trackname);
	virtual string get_html();
	virtual void cleanup();
};

#endif