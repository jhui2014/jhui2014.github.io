rm(list=ls())

source("http://bioconductor.org/biocLite.R")
biocLite(c("tweeDEseqCountData", "gridExtra", "edgeR", "DESeq2", "limma", "AUC"))
library(tweeDEseqCountData)
library(gridExtra)
library(edgeR)
library(DESeq2)
library(limma)
library(AUC)

source("sim.R")
source("ADMM.mlr.R")
source("fit_mlr.R")


resultdir <- 'results/synthetic_data/'

######################################### paramter set up ########################################
nTags <- 2000#0 # number of genes
nlibs <- 200#20#7#200#   # number of samples
p <- 1        # number of features

logfc <- 2    # average log fold change

# for tuning parameter selection
sig_leval <- 0.01 

# for tuning parameter selection for ELMSeq
percentile <- 5/100
# set penalty parameter for ADMM
rho <- 0.1

# type <-  "LN"
# sigma_LN <- 0.1
type <-  "NB"
dispersion <- 0.25
############################################### End ##############################################


########################################### Simulation ###########################################
set.seed(1234)

## In the following for loops, "k" is the percentage of fold change, 
# "j" is the percentage of up - regulated genes (100 - j would be the percentage of down - regulated genes), 

AUC_output <- NULL
TIME_output <- NULL
for (k in c(1, 10, 30, 50, 70, 90)) {
  for (j in c(50, 75, 100)) {
    AUCs <- NULL
    TIMEs <- NULL
    for (it in 1:1) {
      
      X <- matrix(rnorm(nlibs*p), nrow = nlibs, ncol = p)
      # column zero centered
      X <- scale(X, center = TRUE, scale = TRUE)
      
      ############################# Synthetic data generation #############################
      pDiff <- (k/100)
      pUp <- (j/100)
      
      lib.size <- sample(2e6:3e6, nlibs, replace = TRUE)
      
      gene.length <- ceiling(2^runif(nTags, 5, 10))
      
      B <- matrix(0, nTags, p)
      
      ind <- sample(nTags, round(pDiff * nTags))
      # ind <- 1:round(pDiff * nTags)
      # ind <- (nTags - round(pDiff * nTags) + 1):nTags
      
      if(length(ind)>0 && logfc != 0 ) {
        fcDir <- sample(c(-1, 1), length(ind), prob = c(1-pUp, pUp), replace = TRUE)
        # When p>=2, the gene expression is up-regulated (or down-regulated) by all p covariates. Is this assumption valid in practice?
        B[ind, ] <- matrix(rnorm(length(ind) * p, mean = rep(logfc * fcDir, times = p), sd = 1), nrow = length(ind), ncol = p)
      }
      indDE <- as.factor(rowSums(B^2)!=0)
      
      alpha <- rnorm(nTags, 0, 1)
      d <- rnorm(nlibs, 0, 1)
      
      Lambda <- rep(gene.length / sum(gene.length), times = nlibs) * exp(rep(alpha, times = nlibs) + B %*% t(X) + rep(log(lib.size) + d, each = nTags))
      mu <- rep(lib.size, each = nTags) * Lambda
      
      if (type == "LN")  counts <- matrix(ceiling(exp(rnorm(nTags * nlibs, mean = log(mu), sd = sigma_LN))), nrow = nTags, ncol = nlibs)
      if (type == "NB")  counts <- matrix(rnbinom(nTags * nlibs, mu = mu, size = 1 / dispersion), nrow = nTags, ncol = nlibs) 
      
      counts[counts > 2147483647] <- 2147483647
      
      data_RNAseq <- new("DGEList", list(nTags = nTags, nlibs = nlibs, lib.size = lib.size, gene.length = gene.length, 
                                         pDiff = pDiff, pUp = pUp, logfc = logfc, 
                                         beta = beta, indDE = indDE, 
                                         X = X, design = model.matrix(~X), 
                                         counts = counts))
      ######################################## End ########################################
      
      time.edgeR <- system.time(p.edgeR <- edgeR_robust.pfun(counts = data_RNAseq$counts, design = data_RNAseq$design)[, 1])[3]
      time.DESeq2 <- system.time(p.DESeq2 <- DESeq2.pfun(counts = data_RNAseq$counts, X = data_RNAseq$X)[, 1])[3]
      time.limma <- system.time(p.limma <- limma_voom.pfun(counts = data_RNAseq$counts, design = data_RNAseq$design)[, 1])[3]
      
      time.ELMSeq <- system.time(p.ELMSeq <- pfun.ADMM.mlr_typeIIpenalty(data_RNAseq$counts, X, sigma_sq = NULL, percentile = percentile, rho = rho)$result[, 1])[3]
      
      time.rSeqRobust <- system.time(out.rSeqRobust <- fit_mlr.pfun(data_RNAseq$counts, X, sigma_sq = NULL, sig_leval = sig_leval)$result)[3]
      
      AUCs <- rbind(AUCs, c(auc(roc(1 - p.edgeR, data_RNAseq$indDE)), auc(roc(1 - p.DESeq2, data_RNAseq$indDE)), 
                            auc(roc(1 - p.limma, data_RNAseq$indDE)), auc(roc(1 - p.ELMSeq, data_RNAseq$indDE)), 
                            auc(roc(1 - out.rSeqRobust[, 1], data_RNAseq$indDE)), 
                            auc(roc(rowSums(as.matrix(out.rSeqRobust[, -(1:2)])^2), data_RNAseq$indDE))))
      
      TIMEs = rbind(TIMEs, c(time.edgeR, time.DESeq2, time.limma, time.ELMSeq, time.rSeqRobust))
    }
    mean.auc <- colMeans(AUCs)
    sem.auc <- apply(AUCs, 2, sd) / sqrt(dim(AUCs)[1])
    max_ind <- which.max(mean.auc)
    
    mean.auc <- round(mean.auc, 4)
    sem.auc <- round(sem.auc, 4)
    mean.auc[max_ind] <- paste(mean.auc[max_ind], "*")
    sem.auc <- paste("(", sem.auc, ")", sep = "")
    sem.auc[max_ind] <- paste(sem.auc[max_ind], "*")
    
    AUC_output <- rbind(AUC_output, as.character(c(k, j, mean.auc)))
    AUC_output <- rbind(AUC_output, c(" ", " ", sem.auc))
    
    
    mean.time <- colMeans(TIMEs)
    min_ind <- which.min(mean.time)
    
    mean.time <- round(mean.time, 4)
    mean.time[min_ind] <- paste(mean.time[min_ind], "*")
    
    TIME_output <- rbind(TIME_output, as.character(c(k, j, mean.time)))
    
    cat(paste("DE%: ", k, ", Up%: ", j, " done!\n", sep = ""))
  }
}
############################################### End ##############################################


####################################### results tabulation #######################################
bold <- function(x) {
  l <- nchar(x)
  last_char <- substr(x, l, l)
  if (last_char == "*") {
    x <- substr(x, 1, l - 2)
    paste('{\\textbf{', x, '}}', sep = '')
  } else {
    x
  }
}

if (type == "LN")  
  resultfile <- paste("nTags=", nTags, ", nlibs=", nlibs, ", p=", p, ", logfc=", logfc, ", sigma_LN=", sigma_LN, ", sigLeval=", sig_leval, ", NIter=", it, "_", type, ".tex", sep="")
if (type == "NB")  
  resultfile <- paste("nTags=", nTags, ", nlibs=", nlibs, ", p=", p, ", logfc=", logfc, ", phi=", dispersion, ", sigLeval=", sig_leval, ", NIter=", it, "_", type, ".tex", sep="")

library(xtable)
colnames(AUC_output) <- c("DE (\\%)", "Up (\\%)", "edgeR - robust", "DESeq2", "limma - voom", "ELMSeq", "rSeqRobust", "rSeqRobust (|beta|)")
sink(file = paste(resultdir, "AUC.", resultfile, sep=""))
print(xtable(AUC_output), include.rownames = F, sanitize.text.function = function(col) {sapply(col, bold)})
sink()

colnames(TIME_output) <- c("DE (\\%)", "Up (\\%)", "edgeR - robust", "DESeq2", "limma - voom", "ELMSeq", "rSeqRobust")
sink(file = paste(resultdir, "TIME.", resultfile, sep=""))
print(xtable(TIME_output), include.rownames = F, sanitize.text.function = function(col) {sapply(col, bold)})
sink()

cat("Running finished!\n")
############################################### End ##############################################