#include "draw_axis.h"

#include "type.h"
#include "string_operation.h"
#include "colormap.h"
#include "wx/dcmemory.h"
#include "wx/font.h"
#include "wxDCHelper.h"

const PICOLORREF grid_colors[6] = { 0xe0e0e0, 0xe0e0ff, 0xc8ffc8, 0xffe0e0, 0xffe0ff, 0xffffc8 };
const int num_grid_colors = sizeof(grid_colors) / sizeof(PICOLORREF);

void draw_axis::get_intervals()
{
	intervals.end_points.clear();
}

bool draw_axis::draw_contents(wxMemoryDC *pdc, const PIRect rect)
{
	if (error_msg == "")
		return true;
	else
		return false;
}

draw_axis::draw_axis()
{
	domainlow = domainhigh = rangelow = rangehigh = 0;
	left_axis = right_axis = top_axis = bottom_axis = false;
	box = false;
	left_space = right_space = top_space = bottom_space = false;
	longest_text = "100000";

	data_margin = 10;
	box_margin = 5;
	axis_tick_len = 10;
	folding_spacing = 30;
	tick_label_spacing = 10;
	click_area_len = 10;
	ruler_height = 10;

	h_grids = false;
	v_grids = true;
	grid_color = 0xd0d0d0;
	custom_grid_color = true;
	shaded_background = false;
	grid_size = 20;
	zero_line = false;

	do_folding = true;
	fast_draw = true;

	font_size = 15;
	x_label = "";
	y_label = "";
}

bool draw_axis::prepare_data()
{
	if (!draw_figure_structure::prepare_data())
		return false;

	wxBitmap bitmap(100, 100, 24);
	wxMemoryDC dc;
	dc.SelectObject(bitmap);
	dc.SetBackground(*wxWHITE_BRUSH);
	dc.Clear();

	wxFont* font1 = wxFont::New(wxSize(font_size / 2, font_size),
		wxFONTFAMILY_SWISS, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL, false,
		"Arial");
	dc.SetFont(*font1);
	PISize textsize = wxDCHelper::GetTextExtent(&dc, wxS(longest_text));

	if (intervals.end_points.empty())
		do_folding = false;

	if (top_axis)
		top_space = true;
	if (bottom_axis)
		bottom_space = true;
	if (left_axis)
		left_space = true;
	if (right_axis)
		right_space = true;

	axis_left = axis_right = axis_top = axis_bottom = data_margin + box_margin;

	if (left_space)
		axis_left = textsize.cx + data_margin + axis_tick_len;
	if (right_space)
		axis_right = textsize.cx + +data_margin + axis_tick_len;
	if (top_space)
		axis_top = textsize.cy + data_margin + axis_tick_len
		+ (do_folding ? folding_spacing : 0);
	if (bottom_space)
		axis_bottom = textsize.cy + data_margin + axis_tick_len
		+ (do_folding ? folding_spacing : 0);

	if (y_label != "")
		axis_left += textsize.cy;
	if (x_label != "")
		axis_bottom += textsize.cy;

	if (do_folding)
	{
		myfolding.configure(intervals, domainlow, domainhigh, axis_left,
			size.cx - axis_right); //suppose x_off=y_off=0
	}

	return true;
}

bool draw_axis::draw(wxMemoryDC* pdc, int x_off, int y_off)
{
	wxFont oldFont = pdc->GetFont();
	wxFont* font1 = wxFont::New(wxSize(font_size / 2, font_size),
		wxFONTFAMILY_SWISS, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL, false,
		"Arial");
	pdc->SetFont(*font1);

	if (!draw_figure_structure::draw(pdc, x_off, y_off))
	{
		delete font1;
		pdc->SetFont(oldFont);
		return false;
	}

	wxDCHelper::FillRect(pdc, PIRect(x_off, y_off, x_off + size.cx, y_off
		+ size.cy), RGB(255,255,255));

	PIRect data_rect(x_off + axis_left, y_off + axis_top, x_off + size.cx
		- axis_right, y_off + size.cy - axis_bottom);
	PIRect axis_rect(data_rect.left - data_margin, data_rect.top - data_margin,
		data_rect.right + data_margin, data_rect.bottom + data_margin);
	PIRect axis_rect_outer(axis_rect.left, axis_rect.top - (do_folding
		&& top_space ? folding_spacing : 0), axis_rect.right,
		axis_rect.bottom + (do_folding && bottom_space ? folding_spacing
		: 0));

	if (h_grids)
	{
		int x_start = axis_rect.left - (left_axis ? 0 : box_margin);
		int x_end = axis_rect.right + (right_axis ? 0 : box_margin);
		int y_pos = y_off + grid_size;
		int i = 0;
		while (y_pos <= y_off + size.cy && x_start <= x_end)
		{
			int color_index = (i * 2) % num_grid_colors;
			PICOLORREF color = custom_grid_color ? grid_color
				: grid_colors[color_index];
			i++;
			wxPen thePen(wxDCHelper::ColorFromCOLORREF(color));
			pdc->SetPen(thePen);
			if (shaded_background)
			{
				if (i % 2 == 0)
				{
					wxDCHelper::FillRect(pdc, PIRect(x_start, y_pos, x_end,
						y_pos + grid_size), mean_color(color, 0xffffff));
				}
			}
			else
			{
				pdc->DrawLine(x_start, y_pos, x_end, y_pos);
			}
			y_pos += grid_size;
		}
	}

	if (zero_line && rangelow < 0 && rangehigh > 0)
	{
		wxPen pen2(wxDCHelper::ColorFromCOLORREF(grid_color));
		pdc->SetPen(pen2);
		int zero_pos = (int) ((int64)(size.cy - axis_top - axis_bottom) * (0
			- rangelow) / (rangehigh - rangelow)) + axis_top;
		zero_pos = size.cy + axis_top - axis_bottom - zero_pos;
		pdc->DrawLine(axis_rect_outer.left, y_off + zero_pos,
			axis_rect_outer.right, y_off + zero_pos);
	}

	if (v_grids)
	{
		int y_start = axis_rect.top - (top_axis ? 0 : box_margin);
		int y_end = axis_rect.bottom + (bottom_axis ? 0 : box_margin);
		if (do_folding)
		{
			for (int i = 0; i < (int) myfolding.mapped_points.size(); i++)
			{
				int x_pos = round_double(myfolding.mapped_points[i]);
				int color_index = myfolding.begin_with_gap ? ((i + 1)
					% (num_grid_colors * 2)) / 2 : (i % (num_grid_colors
					* 2)) / 2;
				PICOLORREF color = custom_grid_color ? grid_color
					: grid_colors[color_index];
				wxPen pen2(wxDCHelper::ColorFromCOLORREF(color));
				pdc->SetPen(pen2);
				if (shaded_background)
				{
					if ((i % 2 == 1) == myfolding.begin_with_gap && i
						< (int) myfolding.mapped_points.size() - 1)
					{
						wxDCHelper::FillRect(pdc, PIRect(x_pos, y_start,
							round_double(myfolding.mapped_points[i + 1]),
							y_end), mean_color(color, 0xffffff));
					}
				}
				else
				{
					pdc->DrawLine(x_pos, y_start, x_pos, y_end);
				}
				int x_pos_on_axis = (int) ((int64)(size.cx - axis_left
					- axis_right) * (myfolding.points[i] - domainlow)
					/ (domainhigh - domainlow)) + axis_left + x_off;
				int next_x_pos_on_axis = 0;
				if (i < (int) myfolding.mapped_points.size() - 1)
					next_x_pos_on_axis = (int) ((int64)(size.cx - axis_left
					- axis_right) * (myfolding.points[i + 1]
				- domainlow) / (domainhigh - domainlow))
					+ axis_left + x_off;
				if (top_axis)
				{
					if ((i % 2 == 1) == myfolding.begin_with_gap && i
						< (int) myfolding.mapped_points.size() - 1)
					{
						wxDCHelper::FillRect(pdc, PIRect(x_pos_on_axis,
							axis_rect_outer.top, next_x_pos_on_axis,
							axis_rect_outer.top + ruler_height), color);
					}
					pdc->DrawLine(x_pos, axis_rect.top, x_pos_on_axis,
						axis_rect_outer.top + ruler_height);
				}
				if (bottom_axis)
				{
					if ((i % 2 == 1) == myfolding.begin_with_gap && i
						< (int) myfolding.mapped_points.size() - 1)
					{
						wxDCHelper::FillRect(pdc, PIRect(x_pos_on_axis,
							axis_rect_outer.bottom, next_x_pos_on_axis,
							axis_rect_outer.bottom - ruler_height), color);
					}
					pdc->DrawLine(x_pos, axis_rect.bottom, x_pos_on_axis,
						axis_rect_outer.bottom - ruler_height);
				}
			}
		}
		else
		{
			int x_pos = x_off + grid_size;
			int i = 0;
			while (x_pos <= x_off + size.cx && y_start <= y_end)
			{
				int color_index = (i % (num_grid_colors * 2)) / 2;
				PICOLORREF color = custom_grid_color ? grid_color
					: grid_colors[color_index];
				wxPen pen2(wxDCHelper::ColorFromCOLORREF(color));
				pdc->SetPen(pen2);
				i++;
				if (shaded_background)
				{
					if (i % 2 == 0)
					{
						wxDCHelper::FillRect(pdc, PIRect(x_pos, y_start, x_pos
							+ grid_size, y_end),
							mean_color(color, 0xffffff));
					}
				}
				else
				{
					pdc->DrawLine(x_pos, y_start, x_pos, y_end);
				}
				x_pos += grid_size;
			}
		}
	}

	pdc->SetPen(*wxBLACK_PEN);
	pdc->SetBrush(*wxBLACK_BRUSH);

	if (box)
	{
		pdc->DrawLine(axis_rect.left, axis_rect.top, axis_rect.right,
			axis_rect.top);
		pdc->DrawLine(axis_rect.right, axis_rect.top, axis_rect.right,
			axis_rect.bottom);
		pdc->DrawLine(axis_rect.right, axis_rect.bottom, axis_rect.left,
			axis_rect.bottom);
		pdc->DrawLine(axis_rect.left, axis_rect.bottom, axis_rect.left,
			axis_rect.top);
	}

	wxCoord textSizeX, textSizeY;

	PISize textsize = wxDCHelper::GetTextExtent(pdc, wxS(longest_text));
	int haxis_num = (size.cx - axis_left - axis_right) / (textsize.cx
		+ tick_label_spacing);
	if (haxis_num < 3)
		haxis_num = 3;
	int vaxis_num = (size.cy - axis_top - axis_bottom) / (textsize.cy
		+ tick_label_spacing);
	if (vaxis_num < 3)
		vaxis_num = 3;

	double old_cord = -1e9;
	if ((left_axis || right_axis) && fabs(rangehigh - rangelow) > epsilon)
	{
		if (left_axis)
		{
			pdc->DrawLine(axis_rect_outer.left, axis_rect_outer.top,
				axis_rect_outer.left, axis_rect_outer.bottom);
		}
		if (right_axis)
		{
			pdc->DrawLine(axis_rect_outer.right, axis_rect_outer.top,
				axis_rect_outer.right, axis_rect_outer.bottom);
		}

		double range = fabs(rangehigh - rangelow);
		double base = 0;
		while (range < 3)
		{
			base++;
			range *= 10;
		}
		while (range > 30 || range > max(
			(size.cy - axis_top - axis_bottom) / 4, 2))
		{
			base--;
			range /= 10;
		}
		double newhigh = rangehigh * pow(10.0, base), newlow = rangelow * pow(
			10.0, base);
		if (newhigh < newlow)
		{
			swap(newlow, newhigh);
		}
		int axis_gap = (int) range / vaxis_num + 1;
		if (axis_gap <= 2)
			axis_gap = axis_gap;
		else if (axis_gap <= 5)
			axis_gap = 5;
		else if (axis_gap <= 10)
			axis_gap = 10;
		else if (axis_gap <= 20)
			axis_gap = 20;
		else if (axis_gap <= 50)
			axis_gap = 50;
		else
			axis_gap = 100;
		int num_ticks = (int) floor(newhigh) - (int) ceil(newlow) + 1;
		vector<bool> draw_nums;
		draw_nums.resize(num_ticks);
		int num_draw_ticks = 0;
		int last_draw_tick = -1;
		for (int i = 0; i < num_ticks; i++)
		{
			draw_nums[i] = false;
			if (range < vaxis_num || (i + (int) ceil(newlow)) % axis_gap == 0)
			{
				draw_nums[i] = true;
				last_draw_tick = i;
				num_draw_ticks++;
			}
		}
		if (num_draw_ticks < 2)
		{
			if (last_draw_tick >= 0)
				draw_nums[last_draw_tick] = false;
			if (num_draw_ticks > 0)
			{
				draw_nums[0] = true;
			}
			if (num_ticks > 0)
			{
				draw_nums[num_ticks - 1] = true;
			}
		}
		for (int64 i = (int64) ceil(newlow); i <= (int64) floor(newhigh); i++)
		{
			double y = (double) i / pow(10.0, base);
			int cord = (int) ((int64)(size.cy - axis_top - axis_bottom) * (y
				- rangelow) / (rangehigh - rangelow)) + axis_top;
			cord = size.cy + axis_top - axis_bottom - cord;
			int axis_len = axis_tick_len / 2 - 1;
			bool draw_num = draw_nums[(int) (i - (int64) ceil(newlow))];
			if (draw_num)
				axis_len = axis_tick_len - 2;

			if (left_axis)
			{
				pdc->DrawLine(axis_rect_outer.left, y_off + cord,
					axis_rect_outer.left - axis_len, y_off + cord);
			}
			if (right_axis)
			{
				pdc->DrawLine(axis_rect_outer.right, y_off + cord,
					axis_rect_outer.right + axis_len, y_off + cord);
			}

			if (fabs(old_cord - cord) < textsize.cy)
				continue;
			if (draw_num)
				old_cord = cord;

			char buf[1024];
			if (base <= 0)
			{
				sprintf(buf, "%d", round_double(y));
			}
			else
			{
				sprintf(buf, "%g", y);
			}
			PISize text_size = wxDCHelper::GetTextExtent(pdc, wxString(buf));
			if (draw_num && left_axis)
			{
				pdc->DrawText(wxString(buf), axis_rect_outer.left
					- axis_tick_len - text_size.cx, y_off + cord
					- text_size.cy / 2);
			}
			if (draw_num && right_axis)
			{
				pdc->DrawText(wxString(buf), axis_rect_outer.right
					+ axis_tick_len, y_off + cord - text_size.cy / 2);
			}
		}
		for (int i = axis_top - click_area_len; i <= size.cy - axis_bottom; i
			+= click_area_len)
		{
			double y = rangelow + (rangehigh - rangelow) * (size.cy
				- axis_bottom - i - click_area_len / 2) / (size.cy
				- axis_top - axis_bottom);
			if (axis_left)
			{
				map_rects.push_back(PIRect(x_off, y_off + i, x_off + axis_left,
					y_off + i + click_area_len));
				map_strings.push_back(string("v_axis ") + double2str(y));
			}
			if (axis_right)
			{
				map_rects.push_back(PIRect(x_off + size.cx - axis_right, y_off
					+ i, x_off + size.cx, y_off + i + click_area_len));
				map_strings.push_back(string("v_axis ") + double2str(y));
			}
		}
	}

	//old_cord = -1e9;
	int old_end = -1;
	if ((top_axis || bottom_axis) && fabs(domainhigh - domainlow) > epsilon)
	{
		if (top_axis)
		{
			pdc->DrawLine(axis_rect_outer.left, axis_rect_outer.top,
				axis_rect_outer.right, axis_rect_outer.top);
		}
		if (bottom_axis)
		{
			pdc->DrawLine(axis_rect_outer.left, axis_rect_outer.bottom,
				axis_rect_outer.right, axis_rect_outer.bottom);
		}

		double range = fabs(domainhigh - domainlow);
		double base = 0;
		while (range < 3)
		{
			base++;
			range *= 10;
		}
		while (range > 30 || range > max(
			(size.cx - axis_left - axis_right) / 4, 2))
		{
			base--;
			range /= 10;
		}
		double newhigh = (double) (domainhigh) * pow(10.0, base), newlow =
			(double) (domainlow) * pow(10.0, base);
		if (newhigh < newlow)
		{
			swap(newlow, newhigh);
		}
		int axis_gap = (int) range / haxis_num + 1;
		if (axis_gap <= 2)
			axis_gap = axis_gap;
		else if (axis_gap <= 5)
			axis_gap = 5;
		else if (axis_gap <= 10)
			axis_gap = 10;
		else if (axis_gap <= 20)
			axis_gap = 20;
		else if (axis_gap <= 50)
			axis_gap = 50;
		else
			axis_gap = 100;
		int num_ticks = (int) floor(newhigh) - (int) ceil(newlow) + 1;
		vector<bool> draw_nums;
		draw_nums.resize(num_ticks);
		int num_draw_ticks = 0;
		int last_draw_tick = -1;
		for (int i = 0; i < num_ticks; i++)
		{
			draw_nums[i] = false;
			if (range < haxis_num || (i + (int) ceil(newlow)) % axis_gap == 0)
			{
				draw_nums[i] = true;
				last_draw_tick = i;
				num_draw_ticks++;
			}
		}
		if (num_draw_ticks < 2)
		{
			if (last_draw_tick >= 0)
				draw_nums[last_draw_tick] = false;
			draw_nums[0] = draw_nums[num_ticks - 1] = true;
			num_draw_ticks = 2;
		}
		if (do_folding && !v_grids)
		{
			for (int i = 0; i < (int) myfolding.mapped_points.size(); i++)
			{
				int x_pos = round_double(myfolding.mapped_points[i]);
				int axis_len = axis_tick_len - 2;
				if (top_axis)
				{
					pdc->DrawLine(x_pos, axis_rect_outer.top, x_pos,
						axis_rect_outer.top - axis_len);
				}
				if (bottom_axis)
				{
					pdc->DrawLine(x_pos, axis_rect_outer.bottom, x_pos,
						axis_rect_outer.bottom + axis_len);
				}

				//if (fabs(old_cord - x_pos) < textsize.cx) continue;
				//old_cord = x_pos;
				char buf[1024];
				double y = myfolding.points[i];
				if (fabs(y - round_double(y)) < epsilon)
				{
					sprintf(buf, "%d", round_double(y));
				}
				else
				{
					sprintf(buf, "%g", y);
				}
				PISize size1 = wxDCHelper::GetTextExtent(pdc, wxString(buf));
				if (x_pos - size1.cx / 2 < old_end + tick_label_spacing)
				{
					continue;
				}
				if (top_axis)
				{
					pdc->DrawText(wxString(buf), x_pos - size1.cx / 2,
						axis_rect_outer.top - axis_tick_len - size1.cy);
				}
				if (bottom_axis)
				{
					pdc->DrawText(wxString(buf), x_pos - size1.cx / 2,
						axis_rect_outer.bottom + axis_tick_len);
				}
				old_end = x_pos + size1.cx / 2;
			}
		}
		else
		{
			for (int64 i = (int64) ceil(newlow); i <= (int64) floor(newhigh); i++)
			{
				double y = (double) i / pow(10.0, base);
				int cord = (int) ((int64)(size.cx - axis_left - axis_right)
					* (y - domainlow) / (domainhigh - domainlow))
					+ axis_left;
				int axis_len = axis_tick_len / 2 - 1;
				bool draw_num = draw_nums[(int) (i - (int64) ceil(newlow))];
				if (draw_num)
					axis_len = axis_tick_len - 2;

				if (top_axis)
				{
					pdc->DrawLine(x_off + cord, axis_rect_outer.top, x_off
						+ cord, axis_rect_outer.top - axis_len);
				}
				if (bottom_axis)
				{
					pdc->DrawLine(x_off + cord, axis_rect_outer.bottom, x_off
						+ cord, axis_rect_outer.bottom + axis_len);
				}

				//if (fabs(old_cord - cord) < textsize.cx) continue;
				//if (draw_num) old_cord = cord;

				char buf[1024];
				if (base <= 0)
					sprintf(buf, "%d", round_double(y));
				else
					sprintf(buf, "%g", y);
				PISize size1 = wxDCHelper::GetTextExtent(pdc, wxString(buf));
				if (x_off + cord - size1.cx / 2 < old_end + tick_label_spacing)
					continue;
				if (draw_num && top_axis)
				{
					pdc->DrawText(wxString(buf), x_off + cord - size1.cx / 2,
						axis_rect_outer.top - axis_tick_len - size1.cy);
				}
				if (draw_num && bottom_axis)
				{
					pdc->DrawText(wxString(buf), x_off + cord - size1.cx / 2,
						axis_rect_outer.bottom + axis_tick_len);
				}
				if (draw_num)
				{
					old_end = x_off + cord + size1.cx / 2;
				}
			}
		}
		for (int i = axis_left - click_area_len; i <= size.cx - axis_right; i
			+= click_area_len)
		{
			double y = domainlow + (domainhigh - domainlow) * (i
				+ click_area_len / 2 - axis_left) / (size.cx - axis_left
				- axis_right);
			if (do_folding)
				y = myfolding.inverse_map(i + click_area_len / 2);
			if (axis_top)
			{
				map_rects.push_back(PIRect(x_off + i, y_off, x_off + i
					+ click_area_len, y_off + axis_top));
				map_strings.push_back(string("h_axis ") + double2str(y));
			}
			if (axis_bottom)
			{
				map_rects.push_back(PIRect(x_off + i, y_off + size.cy
					- axis_bottom, x_off + i + click_area_len, y_off
					+ size.cy));
				map_strings.push_back(string("h_axis ") + double2str(y));
			}
		}
	}

	pdc->SetTextBackground(*wxBLACK);

	if (x_label != "")
	{
		PISize size1 = wxDCHelper::GetTextExtent(pdc, wxS(x_label));
		pdc->DrawText(wxS(x_label), x_off + size.cx / 2 - size1.cx / 2,
			y_off + size.cy - size1.cy);
	}

	if (y_label != "")
	{
		PISize size1 = wxDCHelper::GetTextExtent(pdc, wxS(y_label));
		pdc->DrawRotatedText(wxS(y_label), wxCoord(x_off), wxCoord(y_off
			+ size.cy / 2 + size1.cx / 2), 90);
	}

	draw_contents(pdc, data_rect);

	delete font1;
	pdc->SetFont(oldFont);
	return true;
}
