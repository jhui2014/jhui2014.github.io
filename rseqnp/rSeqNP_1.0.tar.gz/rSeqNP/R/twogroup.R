#unpaired two-group data
Twogroup=function(exp_object, outcome, nperm, seed, low.exp)
{
  
  #suppressMessages(library(exactRankTests))
  iso.exp=exp_object$iso.exp
  gene.exp=exp_object$gene.exp
  
  #get the name for genes and isoforms--isoform level
  gene_name=iso.exp[,1]
  isoform_name=iso.exp[,2]
  isoform_number=iso.exp[,3]
  
  #get the gene name and isoform number--gene level
  gene.name=gene.exp[,1]
  isoform.number=gene.exp[,2]
  
  n_sample=length(outcome) #total number of samples
  n_iso=nrow(iso.exp) #total number of isoforms(transcripts) in the dataframe  
  n_gene=nrow(gene.exp) #number of genes
  n1=sum(outcome == 1)#number of samples in group 1
  n2=sum(outcome == 2)#number of samples in group 2
  
  N.iso=apply(iso.exp[,4:(n_sample+3)],2,as.numeric)#this is the expression matrix for all isoforms, without the gene and isoform names
  N.gene=apply(gene.exp[,3:(n_sample+2)],2,as.numeric)#this is the expression matrix for all genes, without the gene names
  
  #Test 1: Do the Wilcoxon test for all isoforms, returns the W statistics and p-values
  isoform.res=t(apply(N.iso,1,calculate.twogroup.WRS.test,tag=outcome))
  colnames(isoform.res)=c('WRS.stat','p.WRStest')
    
  #calculate the FDR for all isoforms based on the Wilcoxon p value
  FDR.BH_i=p.adjust(isoform.res[,2], method="BH")
  
  #calculate the average log2 fold change for isoforms between the two groups
  avg_exp1_i=rowMeans(N.iso[,outcome == 1])  #average expression level for the first group
  avg_exp2_i=rowMeans(N.iso[,outcome == 2])  #average expression level for the second group
  if.low.i = (avg_exp1_i<low.exp) | (avg_exp2_i<low.exp) #add a tag indicate whether an isoform is lowly expressed in either of the one group, then the fold change is not so meaningful
  log.FC_i=log2(avg_exp1_i/avg_exp2_i) #log2 fold change
  
  isoform.result=data.frame(gene_name,isoform_name,isoform_number,isoform.res,fdr.BH=FDR.BH_i, log.FC=log.FC_i, if.low=if.low.i)
  isoform.result=isoform.result[order(isoform.result$fdr.BH,-abs(isoform.result$WRS.stat),-abs(isoform.result$log.FC),isoform.result$gene_name,isoform.result$isoform_name),]
  #gene_name, isoform_name, isoform_number, WRS.stat, p.WRStest, fdr.BH
  #sort order: fdr.BH, -WRS.stat, gene_name  
  
  cat("Isoform differential expression test done!\n")
  
#Test 2: Do the Wilcoxon test for all genes, returns the W statistics and p-values
  gene.res=t(apply(N.gene,1,calculate.twogroup.WRS.test,tag=outcome))
  colnames(gene.res)=c('WRS.stat','p.WRStest')
  FDR.BH_g=p.adjust(gene.res[,2], method="BH")
  
  #calculate the average log2 fold change for genes between the two groups
  avg_exp1_g=rowMeans(N.gene[,outcome == 1])  #average expression level for the first group
  avg_exp2_g=rowMeans(N.gene[,outcome == 2])  #average expression level for the second group
  if.low.g = (avg_exp1_g<low.exp) | (avg_exp2_g<low.exp) #add a tag indicate whether a gene is lowly expressed in either of the one group, then the fold change is not so meaningful
  log.FC_g=log2(avg_exp1_g/avg_exp2_g)  #log 2 fold change

  gene.result=data.frame(gene.name,gene.res,fdr.BH=FDR.BH_g,log.FC=log.FC_g, if.low=if.low.g)    
  gene.result=gene.result[order(gene.result$fdr.BH,-abs(gene.result$WRS.stat),-abs(gene.result$log.FC),gene.result$gene.name),]
  #gene.name, WRS.stat, p.WRStest, fdr.BH
  #sort order: fdr.BH, -WRS.stat, gene.name  
  cat("Gene differential expression test done!\n")

#Test 3: Permutation test for differential expression and splicing of genes using GDS score
  GDS.result=GDS(isoform.info=data.frame(gene_name=isoform.result[,1], isoform_number=isoform.result[,3], Tj=isoform.result[,4]),
                 iso.exp=iso.exp, type='twoclass', outcome=outcome, nperm=nperm, seed=seed)
	
  #calculate the T.value that indicates the level of differential splicing
  theta_mat=data.frame(gene_name, avg_exp1_i, avg_exp2_i)
  gene.info=as.data.frame(table(gene_name))
  gene.info=gene.info[order(gene.info[,2],gene.info[,1]),]
  isoform.number.gds=gene.info[,2]
  gene.name=gene.info[,1]
  T.value=NA
  for (i in 1:length(gene.name))
  {
    if(isoform.number.gds[i]==1) { ##only one isoform
      T.value[i]=0
    } else {
      g_i_exp=theta_mat[theta_mat$gene_name==gene.name[i], 2:3]
      T.value[i] = 0.5*sum( abs( g_i_exp[,1]/(sum(g_i_exp[,1]))-g_i_exp[,2]/(sum(g_i_exp[,2])) ) )
    }
  }   
  T.value.mat=data.frame(gene.name, T.value) #T values with gene names
  GDS.result=join_all(list(GDS.result, T.value.mat), by='gene.name') #insert T value in the result dataframe 
  GDS.result=GDS.result[order(GDS.result$iso.num, GDS.result$p.plugin, -GDS.result$GDS, -GDS.result$T.value, GDS.result$gene.name),]

  cat("Permutation test based on GDS done!\n")

  return(list(isoform.DE.result=isoform.result,gene.DE.result=gene.result,GDS.result=GDS.result))
}

#this function calculate the Wilcoxon statistic for two groups, data is the data vector, tag is the sample tags for the two groups like C(1,1...,1,2,2...,2)
#return the Wilcoxon statistic and the p_value
calculate.twogroup.WRS.test=function(data,tag)
{
  
  n1=sum(tag == 1)#number of samples in group 1
  n2=sum(tag == 2)#number of samples in group 2
  
  mat=cbind(data,tag)
  
  y1=mat[mat[,2]==1,1]
  y2=mat[mat[,2]==2,1]
   
  #note:wilcox.test(data~y,alternative = "two.sided") will be very slow!
  
  test=wilcox.exact(y1,y2,alternative = "two.sided",exact=T)
  
  w_stat=test$statistic - n1*n2/2
  
  p_value=test$p.value
  
  if(is.na(p_value)){p_value=1}
  
  return(c(w_stat, p_value))
  
}

volcano.plot=function(result, filter=T, ...)
{
  if(filter==T)
  {
    plot(result[result$if.low==FALSE,]$log.FC, -log(result[result$if.low==FALSE, (ncol(result)-3)]), ...)
  }else if(filter==F)
  {
    plot(result$log.FC, -log(result[, (ncol(result)-3)]), ...)
  }else{ stop("The parameter filter is not specified correctly!") }
}
