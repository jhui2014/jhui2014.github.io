#ifndef DRAW_AXIS_H
#define DRAW_AXIS_H

#include "stl.h"
#include "UserDefinedType.h"
#include "draw_figure_support.h"
#include "math_utils.h"

extern const PICOLORREF grid_colors[6];
extern const int num_grid_colors;

class draw_axis: public draw_figure_structure
{
protected:
	int axis_left, axis_right, axis_top, axis_bottom;
public:
	double domainlow, domainhigh, rangelow, rangehigh;
	bool left_axis, right_axis, top_axis, bottom_axis;
	bool box;
	bool h_grids, v_grids;
	PICOLORREF grid_color;
	bool custom_grid_color;
	bool shaded_background;
	bool zero_line;
	int grid_size;
	bool left_space, right_space, top_space, bottom_space;
	string longest_text;
	int data_margin, box_margin, axis_tick_len, folding_spacing,
			tick_label_spacing, click_area_len, ruler_height;

	interval_set intervals;
	bool do_folding;
	folding myfolding;

	bool fast_draw;

	int font_size;
	string x_label, y_label;

	draw_axis();
	virtual bool prepare_data();
	virtual bool draw_contents(wxMemoryDC *pdc, const PIRect rect);
	virtual bool draw(wxMemoryDC* pdc, int x_off = 0, int y_off = 0);
	virtual void get_intervals();
};

#endif //DRAW_AXIS_H
