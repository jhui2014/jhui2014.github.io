#include "genefile.h"

gene_struct::gene_struct(const gene_struct& rhs) {	
		geneName = rhs.geneName; 
		name = rhs.name;     
		chrom = rhs.chrom;
		strand = rhs.strand;
		txStart = rhs.txStart;
		txEnd = rhs.txEnd;
		cdsStart = rhs.cdsStart;
		cdsEnd = rhs.cdsEnd;
		exons = rhs.exons;
		offset = rhs.offset;
		score = rhs.score;
		colorR = rhs.colorR;
		colorG = rhs.colorG;
		colorB = rhs.colorB;
		plugin_data = NULL;
		if (rhs.plugin_data) {
			plugin_data = rhs.plugin_data->Copy();
		}
}

inline bool genefile::read_from_bam_file(string bamFile){	
	BamReader reader;
	reader.Open(bamFile);

	// get header & reference information
	string header = reader.GetHeaderText();
	RefVector refs = reader.GetReferenceData();

	const int max_bam = 100000000;
	int cnt = 0;
	BamAlignment bam;
	map<string, int> chromToInd;
	while (reader.GetNextAlignment(bam) && cnt <= max_bam) {	
		string ch = refs[bam.RefID].RefName;
		if (chromToInd.find(ch) == chromToInd.end()) {
			sequences.push_back(gene_seq());
			num_seq = sequences.size();
			chromToInd[ch] = num_seq - 1;
			sequences[chromToInd[ch]].name = ch;
		}
		int ind = chromToInd[ch];
		sequences[ind].genes.push_back(gene_struct(bam, refs));
		sequences[ind].num_genes++;
		cnt++;
	}
	reader.Close();	
	return true;
}

bool convert_from_bam_to_gene(const string text_file_name, const string genefile_name){
	genefile mygenefile;
	if (!mygenefile.read_from_bam_file(text_file_name)) {
		cout << "error reading bam file" << endl;
		return false;
	}
	if (!mygenefile.write_to_file(genefile_name)) {
		cout << "error writing genefile " << genefile_name << endl;
		return false;
	}
	return true;
}
