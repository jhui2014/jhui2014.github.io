#include "draw_figure_support.h"
#include "wx/thread.h"
#include "wx/image.h"
#include "wxDCHelper.h"
#include "shared_func.h"


draw_figure_structure::draw_figure_structure()
{
	size = PISize(600, 150);
	error_msg = "";
}

string draw_figure_structure::print_usage()
{
	return "";
}

bool draw_figure_structure::get_params(const vector<string> &params)
{
	if (error_msg == "")
		return true;
	else
		return false;
}

bool draw_figure_structure::load_data()
{
	if (error_msg == "")
		return true;
	else
		return false;
}

bool draw_figure_structure::prepare_data()
{
	if (error_msg == "")
		return true;
	else
		return false;
}

bool draw_figure_structure::draw(wxMemoryDC* pdc, int x_off, int y_off)
{
	if (error_msg == "")
	{
		return true;
	}
	else
	{
		wxDCHelper::FillRect(pdc,PIRect(x_off, y_off, x_off + size.cx, y_off + size.cy),RGB(255,255,255));
		PISize size1 = wxDCHelper::GetTextExtent(pdc,wxS(error_msg));
		pdc->DrawText(wxS(error_msg),x_off + size.cx / 2 - size1.cx / 2, y_off + size.cy / 2 - size1.cy / 2);
		return false;
	}
}

bool draw_figure_structure::drawfile(const string pic_filename)
{
	if (size.cx < 10)
		size.cx = 10;
	if (size.cx > 4000)
		size.cx = 4000;
	if (size.cy < 10)
		size.cy = 10;
	if (size.cy > 4000)
		size.cy = 4000;

    wxMutexGuiEnter();
	wxImage img(size.cx, size.cy);
	wxBitmap bitmap = wxBitmap(img);
	wxMemoryDC dc;
	dc.SelectObject(bitmap);
	dc.SetBackground(*wxWHITE_BRUSH);
	dc.Clear();
	bool result = draw(&dc);
	dc.SelectObject(wxNullBitmap);
	wxImage img_to_save = bitmap.ConvertToImage();
	img_to_save.SaveFile(wxS(pic_filename));
	wxMutexGuiLeave();
	return result;
}
