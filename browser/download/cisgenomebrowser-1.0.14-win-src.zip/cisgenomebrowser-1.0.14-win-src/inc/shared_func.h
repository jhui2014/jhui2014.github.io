#ifndef SHARED_FUNC_H

#define SHARED_FUNC_H

#include <Windows.h>
#include <stdio.h>
#include <malloc.h>
#include <tchar.h> 
#include <wchar.h> 
#include <strsafe.h>
#include <string>
#include <vector>
#include "string_operation.h"

#define BUFSIZE MAX_PATH

inline vector<string> get_all_file_names(const string &dir){
	vector<string> file_names;
	file_names.clear();

	WIN32_FIND_DATA FindFileData;
	HANDLE hFind = INVALID_HANDLE_VALUE;
	DWORD dwError;
	LPTSTR DirSpec;
	size_t length_of_arg;
	INT retval;

	DirSpec = (LPTSTR) malloc (BUFSIZE);

	if( DirSpec == NULL )
	{
		printf( "Insufficient memory available\n" );
		retval = 1;
		goto Cleanup;
	}

	// Check that the input is not larger than allowed.
	StringCbLength(dir.c_str(), BUFSIZE, &length_of_arg);

	if (length_of_arg > (BUFSIZE - 2))
	{
		_tprintf(TEXT("Input directory is too large.\n"));
		retval = 3;
		goto Cleanup;
	}

	// Prepare string for use with FindFile functions.  First, 
	// copy the string to a buffer, then append '\*' to the 
	// directory name.
	StringCbCopyN (DirSpec, BUFSIZE, dir.c_str(), length_of_arg+1);
	StringCbCatN (DirSpec, BUFSIZE, TEXT("\\*"), 2*sizeof(TCHAR));

	// Find the first file in the directory.
	hFind = FindFirstFile(DirSpec, &FindFileData);

	if (hFind == INVALID_HANDLE_VALUE) 
	{
		_tprintf (TEXT("Invalid file handle. Error is %u.\n"), 
			GetLastError());
		retval = (-1);
	} 
	else 
	{
		file_names.push_back(FindFileData.cFileName);

		// List all the other files in the directory.
		while (FindNextFile(hFind, &FindFileData) != 0) 
		{
			file_names.push_back(FindFileData.cFileName);
		}

		dwError = GetLastError();
		FindClose(hFind);
		if (dwError != ERROR_NO_MORE_FILES) 
		{
			_tprintf (TEXT("FindNextFile error. Error is %u.\n"), 
				dwError);
			retval = (-1);
			goto Cleanup;
		}
	}
	retval  = 0;

Cleanup:
	free(DirSpec);
	return file_names;
}

inline bool clear_directory(const string dir) {
	vector<string> file_names = get_all_file_names(dir);
	for (int i=0; i < (int)file_names.size(); i++) {
		string file_name = dir+file_names[i];
		if (file_exists(file_name) && !DeleteFile(file_name.c_str())) 
			return false;
	}
	return true;
}

inline void put2log(const string message) {
	cout << trim_space(current_time()) << ": " << message << endl;
}

#endif //#ifdef SHARED_FUNC_H