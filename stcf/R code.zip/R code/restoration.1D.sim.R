#simulation of 1D signal restoration

rm(list = ls())
options(digits = 6)
library(nloptr)
library(GenSA)
library(foreach)
library(iterators)
library(hydroPSO)
source("quadratic.R")
source("quadratic.DC.R")
source("common.R")
set.seed(1234)

n = 100
x = seq(0, 1, length.out = n)
y = rep(0, n)
x0 = c(1, 12, 30, 40, 55, 62, 85, 101)
m = length(x0)
for (i in 1:(m - 1)) {
    X = seq(0, 1, length.out = (x0[i + 1] - x0[i]))
    if (i == 1) {
        Y = -5
    } else if (i == 2) {
        Y = -4 * X + 4
    } else if (i == 3) {
        Y = 5 * X ^ 2 + 5
    } else if (i == 4) {
        Y = sin(X * 10) - 5
    } else if (i == 5) {
        Y = 4
    } else if (i == 6) {
        Y = 2 * sin(X * 6) - 3
    } else if (i == 7) {
        Y = 5 * X + 4
    }
    y[x0[i]:(x0[i + 1] - 1)] = Y
}

lam = 9
weight = 4
obj_fn = function(y) {
    return(sum((y - y1) ^ 2) + weight * sum(pmin((y[2:n] - y[1:(n - 1)]) ^ 2, lam)))
}

s = 100 #experiment num
maxeval = 10000 # maximal number of function evaluations for comparative methods
tol = 1e-8
maxiter = 10000
t = 1e-5
success = NULL
dM = NULL
RMSE = NULL
time = NULL
for (j in 1:s) {
    print(paste("j =", j))
    y1 = y + rnorm(n) * 1
    if (j == 1) {
        pdf("signal.pdf", width = 6, height = 3)
        par(mfrow = c(1, 2))
        par(mar=c(3, 3, 0, 0) + 0.1, mgp=c(2,0.8,0))
        plot(x, y, type = "l", lty = 2)
        lines(x, y1, type = "l", lty = 1)
    }

    #proposed method
    temp = proc.time()
    A1 = Diagonal(n = n, x = 1)
    A2 = Matrix(0, nrow = n-1, ncol = n, sparse = T)
    A2[cbind(1:(n-1), 1:(n-1))] = sqrt(weight)
    A2[cbind(1:(n-1), 2:n)] = -sqrt(weight)
    A = as(rbind(A1, A2), "dgCMatrix")
    b = c(-y1, rep(0, n-1))
    lambda = c(rep(Inf, n), rep(weight * lam, n-1))
    result_pro = quadratic_cpp(A = A, b = b, x0 = y1, lambda = lambda, max_it = maxiter, tol = tol)
    y_pro = result_pro$par
    M_pro = obj_fn(y_pro)
    RMSE_pro = sqrt(mean((y_pro - y)^2))
    if (j == 1) {
        plot(x, y, type = "l", lty = 2)
        lines(x, y_pro, type = "l", lty = 1)
        dev.off()
    }
    time_pro = (proc.time() - temp)[3]
    
    #DC
    # A.list = NULL
    # b.list = NULL
    # for (i in 1:length(b)) {
    #     A.list = c(A.list, list(2*A[i,]%*%t(A[i,])))
    #     b.list = c(b.list, list(2*b[i]*A[i,]))
    # }
    # time_DC = system.time(result_DC <- quadratic.DC(A.list = A.list, b.list = b.list, c = b^2, lambda = lambda, x0 = y1, maxit = maxiter, tol = tol))[3]
    # y_DC = result_DC$par
    # M_DC = obj_fn(y_DC)
    # RMSE_DC = sqrt(mean((y_DC - y)^2))
    
    #iterative hard thresholding
    temp = proc.time()
    y_threshold = y1
    Phi = matrix(0, nrow = n - 1, ncol = n)
    for (i in 1:(n - 1)) {
        Phi[i, i] = -1
        Phi[i, i + 1] = 1
    }
    for (it in 1:maxiter) {
        y_threshold.old = y_threshold
        b = Phi %*% y_threshold
        a = hard.threshold(b, sqrt(lam))
        z = weight * t(Phi) %*% a
        y_threshold = solve(diag(rep(1, n)) + weight * t(Phi) %*% Phi, y1 + z)
        if (max(abs(y_threshold - y_threshold.old)) < tol) {
            break
        }
    }
    M_threshold = obj_fn(y_threshold)
    RMSE_threshold = sqrt(mean((y_threshold - y)^2))
    time_threshold = (proc.time() - temp)[3]
    
    #DIRECT
    time_direct = system.time(result_direct <- direct(obj_fn, y1-3, y1+3, control = list(xtol_rel = tol, maxeval = maxeval, stopval = -Inf, ftol_rel = 0.0, ftol_abs = 0.0, check_derivatives = F)))[3]
    y_direct = result_direct$par
    M_direct = obj_fn(y_direct)
    RMSE_direct = sqrt(mean((y_direct - y)^2))

    #StoGO
    time_stogo = system.time(result_stogo <- stogo(x0 = y1, fn = obj_fn, lower = y1-3, upper = y1+3, maxeval = maxeval, xtol_rel = tol))[3]
    y_stogo = result_stogo$par
    M_stogo = obj_fn(y_stogo)
    RMSE_stogo = sqrt(mean((y_stogo - y)^2))

    #simulating annealing
    time_SA = system.time(result_SA <- GenSA(lower = y1-3, upper = y1+3, fn = obj_fn, control = list(maxit = maxiter, max.call = maxeval, threshold.stop = NULL, max.time = NULL, nb.stop.improvement = 1e6)))[3]
    y_SA = result_SA$par
    M_SA = obj_fn(y_SA)
    RMSE_SA = sqrt(mean((y_SA - y)^2))
    
    #particle swarm
    time_PS = system.time(result_PS <- hydroPSO(fn = obj_fn, lower = y1-3, upper = y1+3, control = list(maxfn = maxeval, maxit = maxiter, reltol = tol)))[3]
    y_PS = result_PS$par
    M_PS = obj_fn(y_PS)
    RMSE_PS = sqrt(mean((y_PS - y)^2))

    M = c(M_direct, M_stogo, M_SA, M_PS, M_threshold, M_pro)
    #M = c(M_direct, M_stogo, M_SA, M_PS, M_threshold, M_DC, M_pro)
    min_M = min(M)
    success = rbind(success, sapply(M, function(x){x < min_M + t}))
    dM = rbind(dM, (M - min_M)/min_M)
    RMSE = rbind(RMSE, c(RMSE_direct, RMSE_stogo, RMSE_SA, RMSE_PS, RMSE_threshold, RMSE_pro))
    #RMSE = rbind(RMSE, c(RMSE_direct, RMSE_stogo, RMSE_SA, RMSE_PS, RMSE_threshold, RMSE_DC, RMSE_pro))
    time = rbind(time, c(time_direct, time_stogo, time_SA, time_PS, time_threshold, time_pro))
    #time = rbind(time, c(time_direct, time_stogo, time_SA, time_PS, time_threshold, time_DC, time_pro))
}

output = NULL
output = rbind(output, as.character(summarize(success * 100, digits = 1)))
output = rbind(output, as.character(summarize(dM, digits = 2)))
output = rbind(output, as.character(summarize(RMSE, digits = 2)))
output = rbind(output, as.character(summarize(time, digits = 2)))
rownames(output) = c("Success rate", "Relative loss", "RMSE", "Time")
methods = c("DIRECT", "StoGO", "SA", "PSO", "IMO/DC", "Proposed")
#methods = c("DIRECT", "StoGO", "SA", "PSO", "IMO", "DC", "Proposed")
colnames(output) <- methods
require(xtable)
sink(file = paste("restoration.1D.sim.tex", sep = ""))
print(xtable(output), include.rownames = T, sanitize.text.function = function(col) { sapply(col, bold) })
sink()
