#include "draw_signal.h"

#include "bar.h"
#include "chr_region.h"
#include "file_operation.h"
#include "math_utils.h"
#include "wx/dcmemory.h"
#include "wxDCHelper.h"

draw_signal::draw_signal()
{
	positions.clear();
	intensities.clear();
	colors.clear();
	plot_type = PLOT_TYPE_BAR;
	bar_width = dot_width = heatmap_width = -1;
	max_draw_line_distance = 0;
	always_include_zero = true;
	legends.clear();
}

bool draw_signal::prepare_data()
{
	draw_axis::prepare_data();

	int data_size = 0;
	for (int i = 0; i < (int) positions.size(); i++)
	{
		data_size += (int) positions[i].size();
	}

	if (data_size == 0)
	{
		return true;
	}

	if (fabs(rangehigh - rangelow) < epsilon)
	{
		double min_intensity = 1e20, max_intensity = -1e20;
		for (int i = 0; i < (int) intensities.size(); i++)
		{
			if (intensities[i].empty())
				continue;
			min_intensity = min(min_intensity, *(std::min_element(
				intensities[i].begin(), intensities[i].end())));
			max_intensity = max(max_intensity, *(std::max_element(
				intensities[i].begin(), intensities[i].end())));
		}
		rangelow = min_intensity;
		rangehigh = max_intensity;
		if (fabs(rangehigh - rangelow) < epsilon)
		{
			rangehigh = max(0.0, rangehigh);
			rangelow = min(0.0, rangelow);
		}

		if (fabs(rangehigh - rangelow) < epsilon)
		{
			rangehigh += epsilon;
			rangelow -= epsilon;
		}
	}

	if (always_include_zero)
	{
		if (rangelow > -epsilon)
			rangelow = -epsilon;
		if (rangehigh < epsilon)
			rangehigh = epsilon;
	}

	if (fabs(domainhigh - domainlow) < epsilon)
	{
		double min_position = 1e20, max_position = -1e20;
		for (int i = 0; i < (int) positions.size(); i++)
		{
			if (positions[i].empty())
				continue;
			min_position = min(min_position, *(std::min_element(
				positions[i].begin(), positions[i].end())));
			max_position = max(max_position, *(std::max_element(
				positions[i].begin(), positions[i].end())));
		}
		domainlow = min_position;
		domainhigh = max_position;
		if (fabs(domainhigh - domainlow) < epsilon)
		{
			domainhigh += epsilon;
			domainlow -= epsilon;
		}
	}

	//if (cm.colors.size() == 0) cm.set_colorsystem(COLOR_SYSTEM_GREEN_BLACK_RED, min(rangelow, rangehigh), max(rangelow, rangehigh), (rangelow + rangehigh) / 2);
	//if (cm.colors.size() == 0) cm.set_colorsystem(COLOR_SYSTEM_WHITE_BLACK, min(rangelow, rangehigh), max(rangelow, rangehigh));

	return true;
}

void draw_signal::get_intervals()
{
	intervals.end_points.clear();
	if (positions.size() == 0 || positions[0].size() > 1000)
		return;
	for (int j = 0; j < (int) positions.size(); j++)
	{
		for (int i = 0; i < (int) positions[j].size(); i++)
		{
			double width = 1;
			if (widthes.size() == positions.size() && widthes[j].size()
				== positions[j].size())
				width = widthes[j][i];
			intervals.union_with(interval_set(positions[j][i] - width / 2,
				positions[j][i] + width / 2));
		}
	}
}

bool draw_signal::draw_contents(wxMemoryDC *pdc, const PIRect rect)
{
	int data_size = 0;
	for (int i = 0; i < (int) positions.size(); i++)
	{
		data_size += (int) positions[i].size();
	}

	if (data_size == 0)
	{
		return true;
	}

	if (colors.size() != positions.size())
	{
		colors.resize(positions.size());
		if (plot_type != PLOT_TYPE_HEATMAP)
		{
			for (int i = 0; i < (int) colors.size(); i++)
			{
				if (i == 0)
					colors[i] = RGB(0, 0, 0);
				else if (i == 1)
					colors[i] = RGB(255, 0, 0);
				else if (i == 2)
					colors[i] = RGB(0, 255, 0);
				else if (i == 3)
					colors[i] = RGB(0, 0, 255);
				else if (i == 4)
					colors[i] = RGB(0, 255, 255);
				else if (i == 5)
					colors[i] = RGB(255, 0, 255);
				else if (i == 6)
					colors[i] = RGB(255, 255, 0);
				else
					colors[i] = RGB(rand(), rand(), rand());
			}
		}
		else
		{
			for (int i = 0; i < (int) colors.size(); i++)
			{
				colors[i] = RGB(0,0,0);
			}
		}
	}
	if (positions.size() != intensities.size() || positions.size()
		!= colors.size())
	{
		error_msg = "ERROR: inconsistent input.";
		return false;
	}

	double min_gap = 10000000;
	for (int i = 0; i < (int) positions.size(); i++)
	{
		if (positions[i].empty())
			continue;
		vector<double> pos = positions[i];
		sort(pos.begin(), pos.end());
		for (size_t i = 1; i < pos.size() - 1; i++)
			if (min_gap > pos[i + 1] - pos[i])
				min_gap = pos[i + 1] - pos[i];
	}
	int max_draw_width = round_double((double) rect.Width() * min_gap / fabs(
		domainhigh - domainlow));

	if (plot_type == PLOT_TYPE_BAR)
	{
		if (bar_width == -1)
			bar_width = max_draw_width;
		if (bar_width < 1)
			bar_width = 1;
		if (bar_width > 5 * (int) positions.size())
			bar_width = 5 * (int) positions.size();
	}
	else if (plot_type == PLOT_TYPE_DOT || plot_type == PLOT_TYPE_CIRCLE)
	{
		if (dot_width == -1)
			dot_width = max_draw_width;
		if (dot_width < 2)
			dot_width = 2;
		if (dot_width > 10)
			dot_width = 10;
	}
	else if (plot_type == PLOT_TYPE_HEATMAP)
	{
		if (heatmap_width == -1)
			heatmap_width = max_draw_width;
		if (heatmap_width < 1)
			heatmap_width = 1;
		if (heatmap_width > 20)
			heatmap_width = 20;
	}

	vector<vector<int> > heights;
	heights.resize(10000);
	for (int i = 0; i < 10000; i++)
		heights[i].clear();

	for (int j = 0; j < (int) positions.size(); j++)
	{
		if (positions[j].size() != intensities[j].size())
		{
			error_msg = "ERROR: inconsistent input.";
			return false;
		}
		wxBrush brush2(wxDCHelper::ColorFromCOLORREF(colors[j]));
		wxPen pen(wxDCHelper::ColorFromCOLORREF(colors[j]));
		pdc->SetPen(pen);
		pdc->SetBrush(brush2);
		bool draw_line = false;
		cm.set_colorsystem(COLOR_SYSTEM_WHITE_BLACK, min(rangelow, rangehigh),
			max(rangelow, rangehigh));
		cm.colors[1] = colors[j];
		int old_cord = -1;
		for (int i = 0; i < (int) positions[j].size(); i++)
		{
			if (fast_draw && positions[j].size() > 20000 && (i
				% (positions[j].size() / 10000) != 0))
				continue; // for faster display
			double intensity = intensities[j][i];
			int position = round_double((double) rect.Height() * (intensity
				- rangelow) / (rangehigh - rangelow)) + rect.top;
			position = (rect.Height() + 2 * axis_top) - position;
			int origin = round_double(rect.Height() * (0 - rangelow)
				/ (rangehigh - rangelow)) + rect.top;
			origin = (rect.Height() + 2 * axis_top) - origin;
			if (plot_type == PLOT_TYPE_BAR && position >= origin - 1
				&& position <= origin + 1)
				position = origin + 2; // why not position=origin+1?
			if (plot_type == PLOT_TYPE_BAR)
			{
				if (position < rect.top)
					position = rect.top;
				if (position > rect.bottom)
					position = rect.bottom;
				if (origin < rect.top)
					origin = rect.top;
				if (origin > rect.bottom)
					origin = rect.bottom;
				if (position >= rect.bottom - 1 && origin >= rect.bottom - 1)
					position = rect.bottom - 3;
				if (position <= rect.top + 1 && origin <= rect.top + 1)
					position = rect.top + 2;
			}
			double pos = positions[j][i];
			int cord = round_double((double) rect.Width() * (pos - domainlow)
				/ (domainhigh - domainlow)) + rect.left;
			if (do_folding)
				cord = round_double(myfolding.map(pos));
			//if (fast_draw && positions[j].size() > 10000 && cord == old_cord) continue; // for faster display
			bool do_shift = false;
			bool do_overlap = true;
			if (cord < rect.left || cord > rect.right || position < rect.top
				|| position > rect.bottom)
			{
				if (plot_type == PLOT_TYPE_LINE)
					draw_line = false;
				continue;
			}
			if (plot_type == PLOT_TYPE_LINE && i >= 1 && max_draw_line_distance
	> epsilon && fabs(positions[j][i] - positions[j][i - 1])
	> max_draw_line_distance)
	draw_line = false;
			if (plot_type == PLOT_TYPE_BAR)
			{
				int new_bar_width = bar_width;
				if (widthes.size() == positions.size() && widthes[j].size()
					== positions[j].size())
				{
					new_bar_width = round_double((double) rect.Width()
						* widthes[j][i] / (domainhigh - domainlow));
					if (new_bar_width <= 0)
						new_bar_width = 1;
				}
				int rect_left = cord + new_bar_width * j
					/ (int) positions.size() - new_bar_width / 2;
				int rect_right = cord + new_bar_width * (j + 1)
					/ (int) positions.size() - new_bar_width / 2;
				if (!do_shift)
				{
					rect_left = cord - new_bar_width / 2;
					rect_right = cord + new_bar_width - new_bar_width / 2;
				}
				if (do_folding)
				{
					do_shift = false;
					if (widthes.size() == positions.size() && widthes[j].size()
						== positions[j].size())
					{
						rect_left = round_double(myfolding.map(positions[j][i]
						- widthes[j][i] / 2));
						rect_right = round_double(myfolding.map(positions[j][i]
						+ widthes[j][i] - widthes[j][i] / 2));
					}
				}
				if (rect_right == rect_left)
					rect_right++;
				if (rect_left < rect.left)
					rect_left = rect.left;
				if (rect_right > rect.right)
					rect_right = rect.right;
				int below = -10000;
				int above = 10000;
				if (do_overlap)
				{
					for (int j = 0; j < (int) heights[cord].size(); j++)
					{
						if (heights[cord][j] <= position && heights[cord][j]
					> below)
						below = heights[cord][j];
					if (heights[cord][j] >= position && heights[cord][j]
					< above)
						above = heights[cord][j];
					}
					heights[cord].push_back(position);
				}
				PIRect draw_rect;
				if (do_overlap)
				{
					if (position > origin)
					{
						if (below < origin)
							below = origin;
						draw_rect = PIRect(rect_left, below, rect_right,
							position);
					}
					else
					{
						if (above > origin)
							above = origin;
						draw_rect = PIRect(rect_left, above, rect_right,
							position);
					}
				}
				else
				{
					draw_rect = PIRect(rect_left, origin, rect_right, position);
				}
				//use pixel or lineto for width<=2 or height <=2 later
				pdc->DrawRectangle(draw_rect.left, draw_rect.top,
					draw_rect.Width(), draw_rect.Height());
				if (positions[0].size() < 1000)
				{
					map_rects.push_back(draw_rect);
					map_strings.push_back(string("signal ") + double2str(
						intensities[j][i]) + " " + int2str(round_double(
						positions[j][i])));
				}
			}
			if (plot_type == PLOT_TYPE_DOT || plot_type == PLOT_TYPE_CIRCLE)
			{
				int new_dot_width = dot_width;
				if (widthes.size() == positions.size() && widthes[j].size()
					== positions[j].size())
				{
					new_dot_width = round_double((double) rect.Width()
						* widthes[j][i] / (domainhigh - domainlow));
					if (new_dot_width <= 1)
						new_dot_width = 2;
				}
				if (plot_type == PLOT_TYPE_DOT)
				{
					pdc->DrawEllipse(PIRect(cord - new_dot_width / 2, position
						- new_dot_width / 2, cord + new_dot_width / 2 + 1,
						position + new_dot_width / 2 + 1).TOWXRect());
				}
				else if (plot_type == PLOT_TYPE_CIRCLE)
				{
					pdc->DrawCircle(wxCoord(cord),wxCoord(position),new_dot_width / 2);
				}
			}
			if (plot_type == PLOT_TYPE_LINE)
			{
				if (!draw_line)
				{
					if (old_cord >= 0)
					{
						wxDCHelper::LineTo(pdc, old_cord, origin);
						wxDCHelper::MoveTo(pdc, cord, origin);
						wxDCHelper::LineTo(pdc, cord, position);
					}
					else
					{
						wxDCHelper::MoveTo(pdc, cord, position);
					}
					draw_line = true;
				}
				else
				{
					wxDCHelper::LineTo(pdc, cord, position);
				}
			}
			if (plot_type == PLOT_TYPE_HEATMAP)
			{
				int new_heatmap_width = heatmap_width;
				if (widthes.size() == positions.size() && widthes[j].size()
					== positions[j].size())
				{
					new_heatmap_width = round_double((double) rect.Width()
						* widthes[j][i] / (domainhigh - domainlow));
					if (new_heatmap_width <= 0)
						new_heatmap_width = 1;
				}
				PICOLORREF color = cm.get_color(intensity);
				wxBrush brush3(wxDCHelper::ColorFromCOLORREF(color));
				wxPen pen1(wxDCHelper::ColorFromCOLORREF(color));
				pdc->SetBrush(brush3);
				pdc->SetPen(pen1);
				int rect_left = cord - new_heatmap_width / 2;
				int rect_right = cord + new_heatmap_width - new_heatmap_width
					/ 2;
				if (do_folding)
				{
					if (widthes.size() == positions.size() && widthes[j].size()
						== positions[j].size())
					{
						rect_left = round_double(myfolding.map(positions[j][i]
						- widthes[j][i] / 2));
						rect_right = round_double(myfolding.map(positions[j][i]
						+ widthes[j][i] - widthes[j][i] / 2));
					}
				}
				if (rect_right == rect_left)
					rect_right++;
				if (rect_left < rect.left)
					rect_left = rect.left;
				if (rect_right > rect.right)
					rect_right = rect.right;
				pdc->DrawRectangle(rect_left, rect.top + rect.Height() * j
					/ (int) positions.size(), rect_right - rect_left,
					rect.Height() * (j + 1) / (int) positions.size());
			}
			old_cord = cord;
		}
	}

	if (!legends.empty())
	{
		if (positions.size() != legends.size())
		{
			error_msg = "ERROR: inconsistent input.";
			return false;
		}
		int width = 0, height = 0;
		for (int i = 0; i < (int) legends.size(); i++)
		{
			PISize text_size = wxDCHelper::GetTextExtent(pdc, wxS(
				legends[i]));
			width = max(width, text_size.cx);
			height = max(height, text_size.cy);
		}
		int gap = 5;
		PIRect legend_rect = PIRect(rect.right - gap * 2 - width, rect.top,
			rect.right, rect.top + gap * ((int) legends.size() + 1)
			+ height * (int) legends.size());
		wxBrush oldBrush = pdc->GetBrush();
		wxPen oldPen = pdc->GetPen();
		pdc->SetBrush(*wxWHITE_BRUSH);
		pdc->SetPen(*wxBLACK_PEN);
		pdc->DrawRectangle(legend_rect.left, legend_rect.top,
			legend_rect.Width(), legend_rect.Height());
		pdc->SetBrush(oldBrush);
		pdc->SetPen(oldPen);

		wxColor oldTextColor = pdc->GetTextForeground();
		for (int i = 0; i < (int) legends.size(); i++)
		{
			pdc->SetTextForeground(wxDCHelper::ColorFromCOLORREF(colors[i]));
			pdc->DrawText(wxS(legends[i]), legend_rect.left + gap,
				legend_rect.top + gap * (i + 1) + height * i);
		}
		pdc->SetTextForeground(oldTextColor);
	}

	return true;
}
