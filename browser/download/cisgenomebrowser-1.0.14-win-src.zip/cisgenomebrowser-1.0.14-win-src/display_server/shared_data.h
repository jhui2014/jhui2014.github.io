#ifndef _SHARED_DATA_H_
#define _SHARED_DATA_H_

#include <string>
#include "stl.h"
#include "file_operation.h"
#include "genefile.h"
//#include "mykernel.h"

//can be configure later
extern bool local_only;
extern int port_num;

extern bool new_local_only;
extern int new_port_num;

extern std::string wwwroot;
extern std::string template_path;
extern std::string session_path;
extern std::string log_filename;

extern int max_cache_size_MB;
extern bool cache_genefiles;
extern map<string, FILETIME> genefile_time_cache;
extern map<string, genefile> genefile_cache;

//future usage
extern std::string module_path;

//determined automatically
extern std::string program_path;
extern std::string ini_filename;
extern std::string temp_path;
extern std::string server_temp_path;
extern std::string local_host_name;

//change every session
extern std::string host_name;
extern std::string server_ip;
extern std::string client_ip;
extern bool local_client;

//extern MyKernel *kernel;

extern std::string title;

#endif //_SHARED_DATA_H_