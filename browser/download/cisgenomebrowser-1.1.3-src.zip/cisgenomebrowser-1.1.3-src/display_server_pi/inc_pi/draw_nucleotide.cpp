#include "draw_nucleotide.h"


#include "genefile.h"
#include "string_operation.h"
#include "file_operation.h"
#include "math_utils.h"
#include "cisgenome.h"
#include "wx/dcmemory.h"
#include "wxDCHelper.h"
draw_nucleotide::draw_nucleotide()
{
	top_axis = bottom_axis = true;
	left_space = right_space = true;

	nucleotides = "";
	file_path = "";
	chr = "";
	startpos = endpos = -1;
}

string draw_nucleotide::print_usage()
{
	return "<sequence file path> </region:<chr>:<sequence start position>-<sequence end position>> [/width:<picture width>] [/axis:xxxx]\n";
}

bool draw_nucleotide::get_params(const vector<string> &params)
{
	if (params.size() == 0)
		return false;
	file_path = params[0];

	bool good_options = true;
	for (int i = 1; i < (int) params.size(); i++)
	{
		string option = params[i];

		string command = "";
		string parameter = "";
		if (option[0] != '/')
		{
			good_options = false;
			break;
		}
		size_t index = option.find(":");
		if (index != string::npos)
		{
			command = option.substr(1, index - 1);
			parameter = option.substr(index + 1);
		}
		else
		{
			command = option.substr(1);
		}
		if (command == "width")
		{
			sscanf(parameter.c_str(), "%d", &size.cx);
			if (size.cx <= 0)
			{
				error_msg = "Invalid parameter. wrong picture width.\n";
				good_options = false;
				break;
			}
		}
		else if (command == "region")
		{
			if (!parse_region(parameter, chr, startpos, endpos))
			{
				error_msg = "Invalid parameter. wrong region.\n";
				good_options = false;
				break;
			}
		}
		else if (command == "axis")
		{
			int mask;
			sscanf(parameter.c_str(), "%d", &mask);
			top_axis = (mask >= 1000);
			mask %= 1000;
			bottom_axis = (mask >= 100);
			mask %= 100;
			left_axis = (mask >= 10);
			mask %= 10;
			right_axis = (mask >= 1);
		}
		else
		{
			good_options = false;
			break;
		}
	}
	return good_options;
}

bool draw_nucleotide::load_data()
{
	if (error_msg != "")
		return false;
	if (startpos <= 0 || endpos <= 0 || chr == "")
	{
		error_msg = "Invalid parameter. no region information.\n";
		return false;
	}

	domainlow = startpos;
	domainhigh = endpos;

	if (endpos - startpos + 1 > 1000)
		return true; //skip too long sequence to save time

	struct tagSequence *pSeq = NULL;
	char filename[1024];
	sprintf(filename, "%s%s.sq", file_path.c_str(), chr.c_str());
	if (!file_exists(filename))
	{
		error_msg = "error opening sequence file.\n";
		return false;
	}

	pSeq = Genome_Code_4bit_GetSeq(filename, startpos, endpos);
	if (pSeq == NULL)
	{
		error_msg = "error reading sequence file.\n";
		return false;
	}

	nucleotides = pSeq->m_pSequence->m_pString;

	if ((int) nucleotides.length() != endpos - startpos + 1)
	{
		error_msg = "error reading sequence file.\n";
		return false;
	}

	SequenceDelete(pSeq);

	return true;
}

bool draw_nucleotide::prepare_data()
{
	if (error_msg != "")
		return false;

	left_space = left_axis;
	right_space = right_axis;
	left_axis = right_axis = false;

	draw_axis::prepare_data();

	wxBitmap bitmap(100, 100, 24);
	wxMemoryDC dc;
	dc.SelectObject(bitmap);
	PISize textsize = wxDCHelper::GetTextExtent(&dc, wxString("W"));
	size.cy = axis_top + axis_bottom + textsize.cy;

	draw_axis::prepare_data();

	return true;
}

bool draw_nucleotide::draw_contents(wxMemoryDC *pdc, const PIRect rect)
{
	if (error_msg != "")
		return false;

	wxFont oldFont = pdc->GetFont();
	wxFont* font = wxFont::New(wxSize(8, 20), wxFONTFAMILY_SWISS,
		wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL, false, "Courier New");
	pdc->SetFont(*font);

	PISize textsize = wxDCHelper::GetTextExtent(pdc, wxString("W"));
	if (textsize.cx * (int) nucleotides.length() > rect.Width())
		goto quit;
	if ((int) nucleotides.length() != endpos - startpos + 1)
		goto quit;
	if (do_folding)
		goto quit;

	for (int i = startpos; i <= endpos; i++)
	{
		string nt = nucleotides.substr(i - startpos, 1);
		textsize = wxDCHelper::GetTextExtent(pdc, wxS(nt));
		int pos = ((i - startpos) * rect.Width()) / (endpos - startpos)
			+ rect.left;
		pdc->DrawText(wxS(nt), pos - textsize.cx / 2, rect.top);
	}

quit: delete font;
	pdc->SetFont(oldFont);
	return true;
}
