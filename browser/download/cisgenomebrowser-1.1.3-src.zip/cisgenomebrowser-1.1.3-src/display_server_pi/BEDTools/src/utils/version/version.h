#ifndef VERSION_H
#define VERSION_H

// define the version.  All tools in the 
// suite carry the same version number.
#define VERSION "2.6.1"

#endif /* VERSION_H */
