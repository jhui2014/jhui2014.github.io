#ifndef _DISPLAY_NUCLEOTIDE_
#define _DISPLAY_NUCLEOTIDE_

#include "display_track.h"

class display_nucleotide: public display_track
{
public:
	string file_path;

	display_nucleotide();
	display_nucleotide(http_request* r, string track_name,
		display_genome *g);
	virtual bool load_from_file(string file_name);
	virtual bool update_params();
	virtual bool write_to_file(string file_name);
	virtual string get_configure_html();
	virtual bool generate_pic_file(bool get_intervals = false);
	virtual string type();
};

#endif