#ifndef _USERDEFINEDTYPES_H_
#define _USERDEFINEDTYPES_H_
#include "wx/gdicmn.h"

#define wxS(s) (wxString((s).c_str(), wxConvUTF8))
typedef struct tag_CRect
{
	int left;
	int right;
	int top;
	int bottom;
	tag_CRect()
	{
		left = 0;
		right = 0;
		top = 0;
		bottom = 0;
	}
	tag_CRect(int l, int t, int r, int b)
	{
		left = l;
		right = r;
		top = t;
		bottom = b;
	}
	int Width() const
	{
		return right - left;
	}
	int Height() const
	{
		return bottom - top;
	}
	wxRect TOWXRect() const
	{
		return wxRect(left, top, Width(), Height());
	}
} PIRect;

typedef struct tag_CSize
{
	int cx;
	int cy;
	tag_CSize()
	{
		cx = 0;
		cy = 0;
	}
	tag_CSize(int x, int y)
	{
		cx = x;
		cy = y;
	}
} PISize;

#ifdef _MSC_VER
#define PICOLORREF unsigned long
#define PIDWORD unsigned long 
#define PIWORD unsigned short
#else
#define PICOLORREF unsigned long long
#define PIDWORD unsigned long long
#define PIWORD unsigned int
#endif

#define GetRValue(rgb)   ((unsigned char) (rgb))
#define GetGValue(rgb)   ((unsigned char) ((rgb) >> 8))
//#define GetGValue(rgb)   ((char) (((PIWORD) (rgb)) >> 8))
#define GetBValue(rgb)   ((unsigned char) ((rgb) >> 16))
//#define RGB(r, g ,b)  	((PICOLORREF) (((char) (r) | \
//	((PIWORD) (char)(g) << 8)) | \
//	(((PIDWORD) (char) (b)) << 16)))
#define RGB(r, g ,b)  	((PICOLORREF) ( ((PICOLORREF)(r)) | (((PICOLORREF)(g)) << 8) | (((PICOLORREF)(b)) << 16)))

#endif //_USERDEFINEDTYPES_H_
