#ifndef DRAW_BAR_H
#define DRAW_BAR_H

#include "draw_signal.h"
#include "bar.h"
#include "chr_region.h"
#include "file_operation.h"
#include "math_utils.h"

class draw_bar: public draw_signal
{
public:
	bool box;
	bool no_data;

	vector<string> bar_filenames;
	string chr;
	int startpos, endpos;
	double signal_width;
	bool do_window_count;
	double window_left, window_right;

	draw_bar();
	virtual string print_usage();
	virtual bool get_params(const vector<string> &params);
	virtual bool load_data();
	virtual bool prepare_data();
};

inline draw_bar::draw_bar(){
	top_axis = bottom_axis = true;
	left_axis = right_axis = true;

	bar_filenames.clear();
	chr = "";
	startpos = endpos = -1;
	signal_width = 0;
	box = false;
	no_data = false;

	do_window_count = false;
	window_left = window_right = 0.5;
}

inline string draw_bar::print_usage(){
	return "</bar:<bar file>>s [/color:0xXXXXXX]s </region:<chr>:<sequence start position>-<sequence end position>> [/range:<range low>-<range high>] [/size:<picture width>x<picture height>] [/axis:xxxx] [/plottype:<bar | dot | line | heatmap>] [/box] [/signal_width:width]\n";
}

inline bool draw_bar::get_params(const vector<string> &params){
	bool good_options = true;
	for (int i=0; i<(int)params.size(); i++) {
		string option = params[i];

		string command = "";
		string parameter = "";
		if (option[0] != '/') {
			good_options = false;
			break;
		}
		size_t index = option.find (":");
		if (index != string::npos ) {
			command = option.substr(1, index - 1);
			parameter = option.substr(index + 1);
		} else {
			command = option.substr(1);
		}
		if (command == "range"){
			sscanf(parameter.c_str(), "%lf-%lf", &rangelow, &rangehigh);
		} else if (command == "bar") {
			bar_filenames.push_back(parameter);
		} else if (command == "size"){
			sscanf(parameter.c_str(), "%dx%d", &size.cx, &size.cy);
			if (size.cx <=0 || size.cy <=0) {
				error_msg = "ERROR: Invalid parameter. wrong picture width.";
				good_options = false;
				break;
			}
		} else if (command == "color"){
			COLORREF color;
			sscanf(parameter.c_str(), "%x", &color);
			colors.push_back(color);
		} else if (command == "region"){
			if (!parse_region(parameter, chr, startpos, endpos)){
				error_msg = "ERROR: Invalid parameter. wrong region.";
				good_options = false;
				break;
			}
		} else if (command == "axis"){
			int mask;
			sscanf(parameter.c_str(), "%d", &mask);
			top_axis = (mask >= 1000);
			mask %= 1000;
			bottom_axis = (mask >= 100);
			mask %= 100;
			left_axis = (mask >= 10);
			mask %= 10;
			right_axis = (mask >= 1);
		} else if (command == "plottype"){
			if (parameter == "bar") {
				plot_type = PLOT_TYPE_BAR;
			} else if (parameter == "dot") {
				plot_type = PLOT_TYPE_DOT;
			} else if (parameter == "circle") {
				plot_type = PLOT_TYPE_CIRCLE;
			} else if (parameter == "line") {
				plot_type = PLOT_TYPE_LINE;
			} else if (parameter == "heatmap") {
				plot_type = PLOT_TYPE_HEATMAP;
			} else {
				error_msg = "ERROR: Invalid parameter. unknow plot type.";
				good_options = false;
				break;
			}
		} else if (command == "box"){
			box = true;
		} else if (command == "signal_width"){
			sscanf(parameter.c_str(), "%lf", &signal_width);
			if (signal_width <= epsilon) {
				error_msg = "ERROR: Invalid parameter. wrong signal_width.";
				good_options = false;
				break;
			}
		} else {
			good_options = false;
			break;
		}
	}
	return good_options;
}

inline bool draw_bar::load_data(){
	if (startpos <=0 || endpos <=0 || chr == "") {
		error_msg = "ERROR: Invalid parameter. no region information.";
		return false;
	}

	domainlow = startpos;
	domainhigh = endpos;

	positions.clear();
	intensities.clear();

/*	if (bar_filenames.size() == 0) {
		error_msg = "ERROR: no bar file provided.";
		return false;
	}*/

	for (int i=0; i<(int)bar_filenames.size(); i++) {
		if (!file_exists(bar_filenames[i])) {
			error_msg = "ERROR: file doesn't exist.";
			return false;
		}

		if (!is_bar_file(bar_filenames[i])) {
			if (file_exists(bar_filenames[i]+".bar") && compare_file_time(bar_filenames[i], bar_filenames[i]+".bar") <= 0) {
				if (!is_bar_file(bar_filenames[i]+".bar")) {
					error_msg = "ERROR: failed converting file to bar format: file already exists and in wrong format.";
					return false;
				}
			} else {
				if (!is_bar_text_file(bar_filenames[i])) {
					error_msg = "ERROR: file is neither in bar nor in correct text format.";
					return false;
				}
				if (!convert_from_text_to_bar(bar_filenames[i], bar_filenames[i]+".bar")) {
					error_msg = "ERROR: failed converting file to bar format.";
					return false;
				}
			}
			bar_filenames[i] = bar_filenames[i]+".bar";
		}

		bar mybar;
		mybar.verbose = false;
		vector<vector<bar_column> > data;
		int temp_start = startpos;
		int temp_end = endpos;
		if (do_window_count) {
			temp_start = (int)floor(startpos - window_left);
			if (temp_start < 0) temp_start = 0;
			temp_end = (int)ceil(endpos + window_right);
		}
		if (!mybar.read_from_file_region(bar_filenames[i], chr, temp_start, temp_end, data)) {
			error_msg = "ERROR: error reading bar file";
			return false;
		}
		if (mybar.num_col < 1) {
			error_msg = "ERROR: num_col < 1";
			return false;
		}
		if (mybar.data_type[0] != DATA_INT) {
			error_msg = "ERROR: bad data type";
			return false;
		}
		int j, k;
		for (j = 1; j < (int)mybar.num_col; j++) {
			if (mybar.data_type[j] != DATA_FLOAT) {
				error_msg = "ERROR: bad data type";
				return false;
			}
		}
		if (mybar.num_col == 1) {
			vector<double> position;
			position.resize(data.size());
			vector<double> intensity;
			intensity.resize(data.size());
			for (k = 0; k < (int)data.size(); k++) {
				position[k] = data[k][0].data_int;
				intensity[k] = 1;
			}
			positions.push_back(position);
			intensities.push_back(intensity);
		} else {
			for (j = 0; j < (int)mybar.num_col - 1; j++) {
				vector<double> position;
				position.resize(data.size());
				vector<double> intensity;
				intensity.resize(data.size());
				for (k = 0; k < (int)data.size(); k++) {
					position[k] = data[k][0].data_int;
					intensity[k] = data[k][j+1].data_float;
				}
				positions.push_back(position);
				intensities.push_back(intensity);
			}
		}
	}

	if (do_window_count) {
		for (int i = 0; i < (int)positions.size(); i++) {
			vector<double> old_intensities = intensities[i];
			int left = 0, right = 0, current = 0;
			double sum = 0;
			while (current < (int)positions[i].size()) {
				while (left < (int)positions[i].size() && positions[i][left] < positions[i][current] - window_left) {
					sum -= old_intensities[left];
					left++;
				}
				while (right < (int)positions[i].size() && positions[i][right] <= positions[i][current] + window_right) {
					sum += old_intensities[right];
					right++;
				}
				intensities[i][current] = sum;
				current++;
			}
		}
	}

	int data_size = 0;
	for (int i=0; i<(int)positions.size(); i++) {
		data_size += (int)positions[i].size();
	}

	if (data_size == 0) {
		no_data = true;
		return true;
	}

	//if (plot_type == PLOT_TYPE_LINE) max_draw_line_distance = 500;

	if (plot_type == PLOT_TYPE_HEATMAP) {
		//rangelow = rangehigh = 0;
		left_space = left_axis;
		right_space = right_axis;
		left_axis = right_axis = false;
	}

	return true;
}

bool draw_bar::prepare_data(){
	if (signal_width > epsilon) {
		widthes.resize(intensities.size());
		for (int i = 0; i < (int)widthes.size(); i++) {
			widthes[i].resize(intensities[i].size());
			for (int j = 0; j < (int)widthes[i].size(); j++) {
				widthes[i][j] = signal_width;
			}
		}
	} else if (signal_width < -epsilon){
		bar_width = dot_width = heatmap_width = round_double(-signal_width);
	}

	draw_signal::prepare_data();
	return true;
}

#endif //DRAW_BAR_H
