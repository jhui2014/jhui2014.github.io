#exp_object is a list that contains three elements:
#iso.exp is the isoform expression matrix 
#gene.exp is the gene expression matrix
#num_iso is contains the gene names and number of isoforms for each gene
#outcome is the quantitative outcome vector

Quantoutcome=function(exp_object, outcome, nperm, seed)
{
  iso.exp=exp_object$iso.exp
  gene.exp=exp_object$gene.exp
  
  #get the name for genes and isoforms--isoform level
  gene_name=iso.exp[,1]
  isoform_name=iso.exp[,2]
  isoform_number=iso.exp[,3]
  
  #get the gene name and isoform number--gene level
  gene.name=gene.exp[,1]
  isoform.number=gene.exp[,2]
  
  n_sample=length(outcome) #total number of samples
  n_iso=nrow(iso.exp) #total number of isoforms(transcripts) in the dataframe  
  n_gene=nrow(gene.exp) #number of genes
  
  N.iso=apply(iso.exp[,4:(n_sample+3)],2,as.numeric)#this is the expression matrix for all isoforms, without the gene and isoform names
  N.gene=apply(gene.exp[,3:(n_sample+2)],2,as.numeric)
    
  #test 1: do the Spearman's correlation test for all isoforms, returns the spearman's correlation coefficient (SCC) and p-values
  isoform.res=t(apply(N.iso,1,calculate.SCC.test,outcome=outcome))
  colnames(isoform.res)=c('SCC','p.value.SCCtest')
  
  #calculate the FDR for all isoforms based on the KW p value
  FDR.BH_i=p.adjust(isoform.res[,2], method="BH")
  
  isoform.result=data.frame(gene_name, isoform_name, isoform_number, isoform.res, fdr.BH=FDR.BH_i)
  isoform.result=isoform.result[order(isoform.result$fdr.BH,-abs(isoform.result$SCC),isoform.result$gene_name,isoform.result$isoform_name),]
  #gene_name, isoform_name, isoform_number, SCC, p.value, FDR
  #sort order: p.value, -SCC, gene_name, isoform_name
  
  cat("Isoform differential expression test done!\n")

  #test 2: do the Spearman's correlation test for all genes, returns the spearman's correlation coefficient (SCC) and p-values
  gene.res=t(apply(N.gene,1,calculate.SCC.test,outcome=outcome))
  colnames(gene.res)=c('SCC','p.value.SCCtest')
  FDR.BH_g=p.adjust(gene.res[,2], method="BH")
  gene.result=data.frame(gene.name, gene.res, fdr.BH=FDR.BH_g)
  gene.result=gene.result[order(gene.result$fdr.BH, -abs(gene.result$SCC), gene.result$gene.name),]
  
  cat("Gene differential expression test done!\n")
  
  #test 3: Permutation test for differential expression and splicing of genes using GDS score
   
  GDS.result=GDS(isoform.info=data.frame(gene_name=isoform.result[,1], isoform_number=isoform.result[,3], Tj=isoform.result[,4]),
                  iso.exp=iso.exp, type='quant', outcome=outcome, nperm=nperm, seed=seed)
  GDS.result=GDS.result[order(GDS.result$iso.num, GDS.result$p.plugin, -GDS.result$GDS, GDS.result$gene.name),]
  
  cat("Permutation test based on GDS done!\n")
     
  return(list(isoform.DE.result=isoform.result,gene.DE.result=gene.result,GDS.result=GDS.result))
}

#this function tests the significance of the Spearman's rho for quantitative outcomes, 
#data is the data vector, outcome is the quantitative outcome vector
#return the SCC and the p_value
calculate.SCC.test=function(data,outcome)
{
  
  test=cor.test(data, outcome, method='spearman')
  
  SCC=test$estimate
  p_value=test$p.value
  
  if(is.na(p_value)){p_value=1}
  
  return(c(SCC, p_value))  
}
