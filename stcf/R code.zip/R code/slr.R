#solving robust simple linear regression

library(MASS)

pro_simple = function(x, y, lambda) {
    #<Proposed method tailored to outlier detection in simple linear regression>
    #input: data x, y and a vector lambda as distances away from the means to be considered as outliers. 
    #output: Mimium of the objective function and the location estimates with the skipped mean loss.

    n = length(y)
    if (length(lambda) == 1) lambda = rep(lambda, n)
    M = 0
    loc = c(NaN, NaN)
    for (i in 1:n) {
        j = (1:n)[ - i]

        b1p1 = ((y[i] - y[j]) - (lambda[i] - lambda[j])) / (x[i] - x[j]) # The first intersection of Ci+ and Cj
        b0p1 = y[i] - lambda[i] - b1p1 * x[i]
        b1p2 = ((y[i] - y[j]) - (lambda[i] + lambda[j])) / (x[i] - x[j]) # The second intersection of Ci+ and Cj.
        b0p2 = y[i] - lambda[i] - b1p2 * x[i]

        b1n1 = ((y[i] - y[j]) + (lambda[i] + lambda[j])) / (x[i] - x[j]) # The first intersection of Ci- and Cj. 
        b0n1 = y[i] - b1n1 * x[i] + lambda[i]
        b1n2 = (y[i] - y[j] + (lambda[i] - lambda[j])) / (x[i] - x[j]) # The second intersection of Ci- and Cj.
        b0n2 = y[i] - b1n2 * x[i] + lambda[i]

        pi = cbind(c(b0p1, b0p2), c(b1p1, b1p2), j)
        ni = cbind(c(b0n1, b0n2), c(b1n1, b1n2), j)

        pt_i = rbind(pi[order(pi[, 1]),], ni[order( - ni[, 1]),]) # A vector of all, sorted intersections on Ci.

        for (round in c(T, F)) {
            s = rep(T, n)
            s[i] = round
            start = (pt_i[1, 1:2] + pt_i[2, 1:2]) / 2
            s[j] = ((y[j] - start[1] - start[2] * x[j]) ^ 2 <= lambda[j] ^ 2)
            S = sum(s)
            sum.x2 = sum(x[s] ^ 2)
            sum.y2 = sum(y[s] ^ 2)
            sum.xy = sum(x[s] * y[s])
            sum.x = sum(x[s])
            sum.y = sum(y[s])
            sum.lambda2 = sum(lambda[s] ^ 2)
            for (k in c(2:nrow(pt_i), 1)) {
                idx = pt_i[k, 3]
                s[idx] = !s[idx]
                sign = s[idx] * 2 - 1
                S = S + sign
                sum.x2 = sum.x2 + sign * x[idx] * x[idx]
                sum.y2 = sum.y2 + sign * y[idx] * y[idx]
                sum.xy = sum.xy + sign * x[idx] * y[idx]
                sum.x = sum.x + sign * x[idx]
                sum.y = sum.y + sign * y[idx]
                sum.lambda2 = sum.lambda2 + sign * lambda[idx] ^ 2

                sum.X2 = sum.x2 - sum.x ^ 2 / S
                sum.Y2 = sum.y2 - sum.y ^ 2 / S
                sum.XY = sum.xy - sum.x * sum.y / S

                obj = sum.Y2 - sum.XY ^ 2 / sum.X2 - sum.lambda2
                if (S > 1 && obj < M) {
                    M = obj
                    b1 = sum.XY / sum.X2
                    b0 = sum.y / S - b1 * sum.x / S
                    loc = c(b0, b1)
                }
            }
        }
    }
    return(c(M + sum(lambda ^ 2), loc))
}

hard_threshold = function(x, lambda = 0) {
    (abs(x) > lambda) * x
}

hard_ipod = function(x, y, lambda = 0, epsilon = 1e-6, gamma = rep(0, length(y)), threshold = hard_threshold) {
    #input: gamma is a nx1 matrix of initial shift estimates.
    #output: The gamma vector indicating the thresholded shift of each observation from the estimated mean, followed by the estimates of beta0 and beta1.  
    n = length(x)
    converged = FALSE
    X = cbind(rep(1, n), x)
    H = X %*% ginv(t(X) %*% X) %*% t(X)
    h = diag(H)
    lambda = lambda * sqrt(1 - h)
    r = y - H %*% y
    while (!converged) {
        old_gamma = gamma
        gamma = threshold(H %*% gamma + r, lambda)
        converged = max(abs(gamma - old_gamma)) < epsilon
    }
    beta = lm(y - gamma ~ x)$coefficients
    return(c(gamma, beta))
}
