#ifndef FILE_OPERATION_H
#define FILE_OPERATION_H

#include "stl.h"
#include "type.h"
#include "wx/filefn.h"
#include "wx/filename.h"
#include "wx/dir.h"
#include "UserDefinedType.h"

inline bool file_exists(const string file_name)
{
	return wxFileExists(wxS(file_name));
}

inline bool wxDeleteAllFileInDir(const string dir)
{
	wxArrayString files;
	size_t n = wxDir::GetAllFiles(wxS(dir), &files);
	for (int i = 0; i < n; i++)
	{
		wxRemoveFile(files[i]);
	}
	return true;
}

inline string get_path(const string full_pathname)
{
	size_t i = full_pathname.find_last_of("\\/");
	if (i == string::npos || i == full_pathname.length() - 1)
	{
		return full_pathname;
	}
	else
	{
		return full_pathname.substr(0, i + 1);
	}
}

inline string get_file_name(const string file_name)
{
	size_t i = file_name.find_last_of("\\");
	if (i == string::npos)
	{
		return file_name;
	}
	else if (i == file_name.length() - 1)
	{
		return "";
	}
	else
	{
		return file_name.substr(i + 1);
	}
}

inline time_t get_file_modify_time(const string file)
{
	return wxFileModificationTime(wxS(file));
}

inline bool file_changed(const string file, const time_t filetime)
{
	return (wxFileModificationTime(wxS(file)) != filetime);
}

inline time_t compare_file_time(const string file1, const string file2)
{
	return wxFileModificationTime(wxS(file1))
			- wxFileModificationTime(wxS(file2));
}

inline bool get_file_size(const string filename, int64 *file_size)
{
	wxULongLong sz = wxFileName::GetSize(wxS(filename));
	if (sz == wxInvalidSize)
	{
		*file_size = 0;
		return false;
	}
	*file_size = sz.ToULong();
	return true;
}

inline bool load_file(const string file_name, vector<string> &lines) {
	if (!file_exists(file_name)) return false;
	ifstream ifs(file_name.c_str());
	string readline;
	while (getline(ifs, readline)) {
		lines.push_back(readline);
	}
	ifs.close();
	ifs.clear();
	return true;
}

#endif // FILE_OPERATION_H
