#ifndef __GENEFILE_PLUGIN_DATA__
#define __GENEFILE_PLUGIN_DATA__

#include "serializable.h"
#include "endian.h"

// 1)radCount:int:4 bytes, only for version 3.0
// 2)read information(xN), only for version 3.0
//   rdStart:int:4 bytes
//   rdEnd:int:4 bytes
// 3)nucleotideCount:int:4 bytes, only for version 3.0
// 4)nucleotides(xN)
//   nucleotide: uchar 1 byte, only for version 3.0

class genefile_plugin_data : public serializable{
public:	
	size_t token_count() const { return 1; }
	int read_binary(FILE* file) {
		int num_read = 0, totalRead = 0, nucleCount = 0;
		if (1 != (num_read = little_endian_fread(&nucleCount, 4, 1, file))) {
			cout << "error reading gene file: nucleCount" << endl;
			return false;
		}
		totalRead += num_read;
		nucleotides.resize(nucleCount);
		for (int nucleInd = 0; nucleInd < nucleCount; ++nucleInd) {			
			if (1 != (num_read = little_endian_fread(&(nucleotides[nucleInd]), 1, 1, file))) {
				cout << "error reading gene file: nucleotides" << endl;
				return false;
			}
			totalRead += num_read;
		}
		return totalRead;
	}
	int read_text(std::vector<std::string> tokens) {	
		if (tokens.size() != token_count()) {
			return -1;
		}
		nucleotides = tokens[0];
		return 0;
	}
	int write_binary(FILE* file) const {
		int nucleCount = nucleotides.length();
		little_endian_fwrite(&nucleCount, 4, 1, file);
		little_endian_fwrite((void*)(nucleotides.c_str()), nucleotides.length(), 1, file);
		return 0;
	}
	int write_text(FILE* file) const {
		fprintf(file, "\t%s", nucleotides.c_str());
		return 0;
	}
	size_t offset() const {	
		size_t offset = 0;
		offset += 4; //nucleotideCount
		offset += nucleotides.length(); //nucleotides
		return offset;
	}	
	genefile_plugin_data* Copy() const {
		genefile_plugin_data *res = new genefile_plugin_data();
		*res = *this;
		return res;
	}	
	virtual void set(std::string str) {
		nucleotides = str;
	}
	virtual std::string to_string() const {
		return nucleotides;
	}

	string nucleotides; // Nucleotides for the read
};

#endif  // __GENEFILE_PLUGIN_DATA__
