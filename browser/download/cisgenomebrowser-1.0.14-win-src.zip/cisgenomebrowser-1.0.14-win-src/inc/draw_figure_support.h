#ifndef DRAW_FIGURE_SUPPORT_H
#define DRAW_FIGURE_SUPPORT_H

#include "stdafx.h"
#include "stl.h"
#include <atlimage.h>

class draw_figure_structure
{
public:
	string error_msg;
	CSize size;
	vector<CRect> map_rects;
	vector<string> map_strings;

	draw_figure_structure();
	virtual string print_usage(){return "";};
	virtual bool get_params(const vector<string> &params){if (error_msg == "") return true; else return false;}
	virtual bool load_data(){if (error_msg == "") return true; else return false;} //load data file
	virtual bool prepare_data(){if (error_msg == "") return true; else return false;} //process data and decide size
	virtual bool draw(CDC* pdc, int x_off = 0, int y_off = 0);
	virtual bool drawfile(const string pic_filename);
};

inline draw_figure_structure::draw_figure_structure(){
	size = CSize(600, 150);
	error_msg = "";
}

inline bool draw_figure_structure::draw(CDC* pdc, int x_off, int y_off){
	if (error_msg == "") return true; 
	else {
		CBrush brush1(RGB(255,255,255));
		pdc->FillRect(CRect(x_off, y_off, x_off + size.cx, y_off + size.cy), &brush1);
		CSize size1 = pdc->GetTextExtent(error_msg.c_str());
		pdc->TextOut(x_off + size.cx / 2 - size1.cx / 2, y_off + size.cy / 2 - size1.cy / 2, error_msg.c_str());
		return false;
	}
}

inline bool draw_figure_structure::drawfile(const string pic_filename){
	if (size.cx < 10) size.cx = 10;
	if (size.cx > 4000) size.cx = 4000;
	if (size.cy < 10) size.cy = 10;
	if (size.cy > 4000) size.cy = 4000;

	CImage image;
	image.Create(size.cx, size.cy, 24);
	CDC *pdc = CDC::FromHandle(image.GetDC());
	bool result = draw(pdc);
	image.Save(pic_filename.c_str());
	image.ReleaseDC();
	return result;
}

#endif //DRAW_FIGURE_SUPPORT_H
