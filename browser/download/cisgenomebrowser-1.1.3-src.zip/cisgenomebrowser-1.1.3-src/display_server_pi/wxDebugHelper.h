#ifndef _WXDEBUGHELPER_H_
#define _WXDEBUGHELPER_H_

#include "wx/msgdlg.h"
#include <string>
#include <iostream>
using namespace std;

class wxDebugHelper
{
public:
	static void MessageBox(string s)
	{
		wxMessageDialog dlg(NULL, wxS(s));
		dlg.ShowModal();
	}
};

#endif
