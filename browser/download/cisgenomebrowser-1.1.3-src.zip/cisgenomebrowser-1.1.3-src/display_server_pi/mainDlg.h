class MyTaskBarIcon: public wxTaskBarIcon
{
public:
#if defined(__WXCOCOA__)
	MyTaskBarIcon(wxTaskBarIconType iconType = DEFAULT_TYPE)
		:   wxTaskBarIcon(iconType)
#else
	MyTaskBarIcon()
#endif
	{}

	void OnLeftButtonDClick(wxTaskBarIconEvent&);
	void OnMenuBrowse(wxCommandEvent&);
	void OnMenuSetting(wxCommandEvent&);
	void OnMenuAbout(wxCommandEvent&);
	void OnMenuExit(wxCommandEvent&);
	virtual wxMenu *CreatePopupMenu();

	DECLARE_EVENT_TABLE()
};


// Define a new application
class MyApp: public wxApp
{
public:
	bool OnInit();
	int OnExit();    
};

static const wxCmdLineEntryDesc g_cmdLineDesc [] =
{
	{ wxCMD_LINE_SWITCH, wxT("s"), wxT("silent"), wxT("disables the GUI") },
	{ wxCMD_LINE_NONE }
};

class MyDialog: public wxDialog
{
public:
	MyDialog(wxWindow* parent, const wxWindowID id, const wxString& title,
		const wxPoint& pos, const wxSize& size, const long windowStyle = wxDEFAULT_DIALOG_STYLE);
	~MyDialog();

	void OnOK(wxCommandEvent& event);
	void OnExit(wxCommandEvent& event);
	void OnCloseWindow(wxCloseEvent& event);
	void Init(void);
	void OnCustomCommand(wxEvent& event);
    void OnTimer(wxTimerEvent& event); 

protected:
	MyTaskBarIcon   *m_taskBarIcon;
#if defined(__WXCOCOA__)
	MyTaskBarIcon   *m_dockIcon;
#endif
	wxTimer *m_timer; 

	DECLARE_EVENT_TABLE()
};
