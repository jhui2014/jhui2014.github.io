#ifndef _WXSOCKETHELPER_H_
#define _WXSOCKETHELPER_H_

#include "wx/socket.h"

class wxSocketHelper
{
public:
	static inline string SocketReceiveLine(wxSocketBase* s)
	{
		// TODO: set correct flag here
		s->SetFlags(wxSOCKET_NOWAIT);
		std::string ret = "";
		char r;
		//if (s->WaitForRead(1)) {
			int n = 0;
			while (!s->Error() && n < 10000)
			{
				s->Read(&r,1);
				ret += r;
				if (r == '\n')
				{
					break;
				}
				n++;
			}
		//}
		return ret;
	}

	static inline string GetServerIP(wxSocketBase* s)
	{
		string ret = "";
		wxIPV4address addr;
		if (s->GetLocal(addr))
		{
			ret = addr.IPAddress().c_str();
		}
		return ret;
	}

	static inline string GetClientIP(wxSocketBase* s)
	{
		string ret = "";
		wxIPV4address addr;
		if (s->GetPeer(addr))
		{
			ret = addr.IPAddress().c_str();
		}
		return ret;
	}
};

#endif
