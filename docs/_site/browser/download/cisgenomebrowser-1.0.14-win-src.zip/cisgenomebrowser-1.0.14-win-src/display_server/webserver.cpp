/*
WebServer.cpp

Copyright (C) 2003-2004 Ren?Nyffenegger

This source code is provided 'as-is', without any express or implied
warranty. In no event will the author be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this source code must not be misrepresented; you must not
claim that you wrote the original source code. If you use this source code
in a product, an acknowledgment in the product documentation would be
appreciated but is not required.

2. Altered source versions must be plainly marked as such, and must not be
misrepresented as being the original source code.

3. This notice may not be removed or altered from any source distribution.

Ren?Nyffenegger rene.nyffenegger@adp-gmbh.ch

Thanks to Tom Lynn who pointed out an error in this source code.
*/

/* 
Modified at several places by Hui Jiang to support file access.
June, 2007
*/

#include <ctime>
#include <process.h>
#include <iostream>
#include <string>
#include <map>
#include <sstream>
//<process.h>


#include "webserver.h"
#include "socket.h"
#include "UrlHelper.h"
#include "base64.h"
#include "shared_data.h"
#include "shared_func.h"
#include "file_operation.h"

webserver::request_func webserver::request_func_=0;

//--------------------------------------------------------------
// manifest constants
//--------------------------------------------------------------
#define COMM_BUFFER_SIZE 1024
#define SMALL_BUFFER_SIZE 10

struct MimeAssociation
{
	char *file_ext;
	char *mime;
};

MimeAssociation mimetypes[] = { 
	{ ".txt", "text/plain" },
	{ ".ini","text/plain" },
	{ ".html","text/html" },
	{ ".htm", "text/html" },
	{ ".gif", "image/gif" },
	{ ".jpg", "image/jpeg" }
};

//--------------------------------------------------------------
//	findMimeType()
//		Performs linear search through mimetypes array looking for
//		matching file extension returning index of mime type 
//--------------------------------------------------------------
int findMimeType(const char *filename)
{
	char *pos;
	int numofelements;

	pos = strrchr(filename,'.');

	if ( pos )
	{
		numofelements = sizeof(mimetypes) / sizeof(MimeAssociation);

		for ( int x = 0; x < numofelements; ++x )
		{
			if ( stricmp(mimetypes[x].file_ext,pos) == 0 )
				return(x);
		}
	}

	return(0);  // return default mimetype  'text/plain' 
}


//--------------------------------------------------------------
//	OutputHTTPRedirect()
//		Writes an HTTP redirect header and body to the client.
//		Called if the user requests a directory causing the redirect
//		to directory/index.html 
//--------------------------------------------------------------
void OutputHTTPRedirect(Socket client_socket, const char *defaulturl)
{
	char headerbuffer[COMM_BUFFER_SIZE];
	char htmlbuffer[COMM_BUFFER_SIZE];

	sprintf(htmlbuffer,"<html><body><a href=\"%s\">%s</a></body></html>",defaulturl,defaulturl);
	sprintf(headerbuffer,"HTTP/1.0 301\r\nContent-Type: text/html\r\nContent-Length: %ld\r\nLocation: %s\r\n\r\n",strlen(htmlbuffer),defaulturl);
	
	client_socket.SendBuf(headerbuffer,strlen(headerbuffer));
	client_socket.SendBuf(htmlbuffer,strlen(htmlbuffer));

	client_socket.Close();
}

//--------------------------------------------------------------
//	OutputHTTPError()
//		Sends an http header and html body to the client with
//		error information.
//--------------------------------------------------------------
void OutputHTTPError(Socket client_socket, int statuscode)
{
	char headerbuffer[COMM_BUFFER_SIZE];
	char htmlbuffer[COMM_BUFFER_SIZE];

	sprintf(htmlbuffer,"<html><body><h2>Error: %d</h2></body></html>",statuscode);
	sprintf(headerbuffer,"HTTP/1.0 %d\r\nContent-Type: text/html\r\nContent-Length: %ld\r\n\r\n",statuscode,strlen(htmlbuffer));

	client_socket.SendBuf(headerbuffer,strlen(headerbuffer));
	client_socket.SendBuf(htmlbuffer,strlen(htmlbuffer));

	client_socket.Close();
}

unsigned webserver::Request(void* ptr_s) {
	Socket s = *(reinterpret_cast<Socket*>(ptr_s));

	std::string line = s.ReceiveLine();
	if (line.empty()) {
		return 1;
	}

	put2log(string("requested line: ") + trim_space(line));

	http_request req;

	if (line.find("GET") == 0) {
		req.method_="GET";
	}
	else if (line.find("POST") == 0) {
		req.method_="POST";
	}

	std::string path;
	std::map<std::string, std::string> params;

	size_t posStartPath = line.find_first_not_of(" ",3);

	SplitGetReq(line.substr(posStartPath), path, params);

	req.status_ = "202 OK";
	req.s_      = &s;
	req.path_   = path;
	req.params_ = params;

	static const std::string authorization   = "Authorization: Basic ";
	static const std::string accept          = "Accept: "             ;
	static const std::string accept_language = "Accept-Language: "    ;
	static const std::string accept_encoding = "Accept-Encoding: "    ;
	static const std::string user_agent      = "User-Agent: "         ;

	while(1) {
		line=s.ReceiveLine();

		if (line.empty()) break;

		unsigned int pos_cr_lf = line.find_first_of("\x0a\x0d");
		if (pos_cr_lf == 0) break;

		line = line.substr(0,pos_cr_lf);

		if (line.substr(0, authorization.size()) == authorization) {
			req.authentication_given_ = true;
			std::string encoded = line.substr(authorization.size());
			std::string decoded = base64_decode(encoded);

			unsigned int pos_colon = decoded.find(":");

			req.username_ = decoded.substr(0, pos_colon);
			req.password_ = decoded.substr(pos_colon+1 );
		}
		else if (line.substr(0, accept.size()) == accept) {
			req.accept_ = line.substr(accept.size());
		}
		else if (line.substr(0, accept_language.size()) == accept_language) {
			req.accept_language_ = line.substr(accept_language.size());
		}
		else if (line.substr(0, accept_encoding.size()) == accept_encoding) {
			req.accept_encoding_ = line.substr(accept_encoding.size());
		}
		else if (line.substr(0, user_agent.size()) == user_agent) {
			req.user_agent_ = line.substr(user_agent.size());
		}
	}

	bool file_exist = false;

	std::string file_name = wwwroot;
	char *filebuffer = NULL;
	long filesize = 0;
	file_name += req.path_;
	char buf[MAX_PATH];
	_fullpath(buf, file_name.c_str(), MAX_PATH);
	file_name = buf;
	file_exist = file_exists(file_name);
	if (file_name.find(wwwroot) != 0) file_exist = false;
	if (file_exist) {
		if ( req.method_ == "GET" )
		{
			if ( strnicmp(file_name.c_str(),wwwroot.c_str(),wwwroot.length()) == 0 )  // else security violation!
			{

				if (!load_file(file_name, filebuffer, filesize)) {
					// file error, not found?
					req.error = true;
					req.statuscode = 404;// 404 - not found
				} 
			}
			else
			{
				req.error = true;
				req.statuscode = 404;// 403 - forbidden
			}
		}
		else
		{
			req.error = true;
			req.statuscode = 501;  // 501 not implemented
		}
	
		if (req.error) {
			OutputHTTPError(s, req.statuscode);
		} else if (req.redirect) {
			OutputHTTPRedirect(s, req.redirect_url.c_str());
		} else {
			// send the http header and the file contents to the browser
			char sendbuffer[COMM_BUFFER_SIZE];

			strcpy(sendbuffer,"HTTP/1.0 200 OK\r\n");
			strncat(sendbuffer,"Content-Type: ",COMM_BUFFER_SIZE);
			strncat(sendbuffer,mimetypes[findMimeType(file_name.c_str())].mime,COMM_BUFFER_SIZE);
			sprintf(sendbuffer+strlen(sendbuffer),"\r\nContent-Length: %ld\r\n",filesize);
			strncat(sendbuffer,"\r\n",COMM_BUFFER_SIZE);

			s.SendBuf(sendbuffer,strlen(sendbuffer));
			s.SendBuf(filebuffer,filesize);

			delete [] filebuffer;
		}	
	} else {
		request_func_(&req);
		if (req.error) {
			OutputHTTPError(s, req.statuscode);
		} else if (req.redirect) {
			OutputHTTPRedirect(s, req.redirect_url.c_str());
		} else {
			time_t ltime;
			time(&ltime);
			tm* gmt= gmtime(&ltime);

			static std::string const serverName = "RenesWebserver (Windows)";

			char* asctime_remove_nl = asctime(gmt);
			asctime_remove_nl[24] = 0;

			s.SendBytes("HTTP/1.1 ");

			if (! req.auth_realm_.empty() ) {
				s.SendLine("401 Unauthorized");
				s.SendBytes("WWW-Authenticate: Basic Realm=\"");
				s.SendBytes(req.auth_realm_);
				s.SendLine("\"");
			}
			else {
				s.SendLine(req.status_);
			}
			s.SendLine(std::string("Date: ") + asctime_remove_nl + " GMT");
			s.SendLine(std::string("Server: ") +serverName);
			s.SendLine("Connection: close");
			std::stringstream str_str;
			str_str << req.answer_.size();

			s.SendLine("Content-Type: text/html; charset=ISO-8859-1");
			s.SendLine("Content-Length: " + str_str.str());
			s.SendLine("");
			s.SendLine(req.answer_);
		}
	}

	s.Close();

	delete reinterpret_cast<Socket*>(ptr_s);

	return 0;
}

webserver::webserver(unsigned int port_to_listen, request_func r) {

	put2log("starting web server");	

	SocketServer in(port_to_listen,SOMAXCONN, BlockingSocket, local_only);

	request_func_ = r;

	while (1) {
		Socket* ptr_s=in.Accept();

		string server_ip, client_ip;
		ptr_s->getIP(server_ip, client_ip);

		put2log(string("client from ") + client_ip);

		unsigned ret;
		HANDLE hand = (HANDLE)_beginthreadex(0,0,Request,(void*) ptr_s,0,&ret);
		WaitForSingleObject(hand, INFINITE);
		CloseHandle(hand);
	}
}
