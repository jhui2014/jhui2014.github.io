#include "drawCommon.h"

#include "inc_pi//UserDefinedType.h"

string def_colors[] =
{ "black", "red", "blue", "green", "purple", "pink", "brown", "orange" };
PICOLORREF def_colorrefs[] =
{ 0x000000, 0x0000FF, 0xFF0000, 0x00FF00, 0x800080, 0xFF00FF, 0x004080,
0x4080FF };