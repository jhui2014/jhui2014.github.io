#include "wxDCHelper.h"

wxCoord wxDCHelper::oldX = 0;
wxCoord wxDCHelper::oldY = 0;