#include "display_junction.h"
#include "drawCommon.h"

display_junction::display_junction(http_request* r)
{
	if (r->params_.count("exons") > 0) {
		vector<string> strs = string_tokenize(r->params_["exons"], "_");
		assert(strs.size() == 2);
		exon1_ = strs[0];
		exon2_ = strs[1];
	}
	src_filename = r->params_["src_filename"];
	req = r;
}

bool display_junction::load_from_file(string file_name)
{
	return true;
}

bool display_junction::update_params()
{
	return true;
}

bool display_junction::write_to_file(string file_name)
{
	return true;
}

string display_junction::get_html()
{
	html_formater my_html_formater;

	if (pic_filename == "")
	{
		pic_filename = get_random_pic_file_name();
	}
	if (!file_exists(temp_path + pic_filename))
	{
		draw_junction my_draw(src_filename, exon1_, exon2_);
		my_draw.load_data();
		my_draw.prepare_data();
		my_draw.drawfile(temp_path + pic_filename);
	}

	my_html_formater.load_from_template_file(template_path + "draw_junction.html");
	my_html_formater.replace_keyword("$JUNCTION_FILE_NAME$", server_temp_path + pic_filename);

	return my_html_formater.buf;
}

