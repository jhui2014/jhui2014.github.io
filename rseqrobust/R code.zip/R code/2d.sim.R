rm(list=ls())
source("rSeqRobust.R")

#######################################################################
#######################################################################
# 2-d simulations

set.seed(1234)
m0k = c(700, 300, 100, 100)
dxk = c(0, 1, 1, 3)
for (k in 1:length(m0k)) {
  m0 = m0k[k] # null genes
  m = 1000 # total genes
  m1 = m-m0 # de genes
  n = 10 # samples per group
  d = rnorm(n*2, 0, 0.5) # sequencing depth
  x0 = rnorm(m0,-3,2) # null gene log exp
  x11 = rnorm(m1,-3,2) # de gene log exp in group 1
  x12 = x11+rnorm(m1,dxk[k],1) # de gene log exp in group 2
  x1 = c(x0,x11) # gene exp in group 1
  x2 = c(x0,x12) # gene exp in group 2
  x = matrix(c(rep(x1,n),rep(x2,n)),nrow=m,ncol=n*2) # gene exp
  x.exp = matrix(rnorm(m*n*2, x + rep(d, each=m), 0.2), nrow=m, ncol=n*2) # gene exp with biological variation and adjusted by sequencing depth
  l = exp(runif(m,5,10)) # gene length
  w = floor(runif(n*2,30000000,50000000)) # real sequencing depth
  x.count = matrix(0,m,n*2) # read counts
  for (i in 1:(n*2)) {
    x.count[,i] = rmultinom(1,w[i],exp(x.exp[,i])*l) + 1
  }
  N = apply(x.count,2,sum) # total sequenced reads
  x.cpm = (x.count) %*% diag(1/N) * 1000000 # cpm
  x.rpkm = (x.count / l * 1000) %*% diag(1/N) * 1000000 # rpkm
  x.tpm = x.rpkm %*% diag(1/apply(x.rpkm, 2, sum)) * 1000000 # tpm
  
  fit.count=fit.robust(log(x.count[,1:n]), log(x.count[,(n+1):(2*n)]))
  fit.cpm=fit.robust(log(x.cpm[,1:n]), log(x.cpm[,(n+1):(2*n)]))
  fit.rpkm=fit.robust(log(x.rpkm[,1:n]), log(x.rpkm[,(n+1):(2*n)]))
  fit.tpm=fit.robust(log(x.tpm[,1:n]), log(x.tpm[,(n+1):(2*n)]))
  
  print(norm(as.matrix(fit.rpkm$gamma2-fit.cpm$gamma2)))
  print(norm(as.matrix(fit.rpkm$gamma2-fit.tpm$gamma2)))
  print(norm(as.matrix(fit.rpkm$gamma2-fit.count$gamma2)))
  
  pdf(paste("gamma", k, ".pdf", sep=""), width=10, height=3)
  par(mar=c(4, 4, 1, 0.5)) 
  plot(fit.count$gamma2,xlab="i",ylab=expression(paste(gamma[i])))
  dev.off()
}