import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import javax.swing.*;
import javax.swing.border.*;
import java.net.*;
import netscape.javascript.JSObject;

public class FileChooser extends JApplet implements ActionListener {
  private JPanel pane = null;
  private JTextField tfFilename = null;
  private JButton butLoad = null;
  private final String BROWSE = "browse";
  private final int buttonW = 90;
  private final int buttonH = 18;
  private final int textW = 0;
  private final int textH = 0;

public void init() {
try {
    jbInit();
  } catch(Exception e) {
    e.printStackTrace();
  }
}

private void jbInit() throws Exception {
  pane = new JPanel();
  pane.setBounds(new Rectangle(0, 0, buttonW + textW, buttonH));
  pane.setLayout(null);

  // If needed, show tfFilename which will contain the full path
  tfFilename = new JTextField();
  tfFilename.setText("");
  tfFilename.setBounds(new Rectangle(0, 0, textW, textH));

  butLoad = new JButton();
  butLoad.setBounds(new Rectangle(textW, textH, buttonW, buttonH));
  butLoad.setText("Browse");
  butLoad.setActionCommand(BROWSE);
  butLoad.addActionListener(this);

  pane.add(tfFilename);
  pane.add(butLoad);

  setContentPane(pane);
}

public void actionPerformed(ActionEvent e) {
  JFileChooser chooser = new JFileChooser();
      /*
    // Note: source for ExampleFileFilter can be found in FileChooserDemo,
    // under the demo/jfc directory in the Java 2 SDK, Standard Edition.
    ExampleFileFilter filter = new ExampleFileFilter();
    filter.addExtension("jpg");
    filter.addExtension("gif");
    filter.setDescription("JPG & GIF Images");
    chooser.setFileFilter(filter);
    */
  int returnVal = chooser.showOpenDialog(this);  
  if (e.getActionCommand().equals(BROWSE)) {
    if(returnVal == JFileChooser.APPROVE_OPTION) {
    String fileName = chooser.getSelectedFile().getAbsolutePath().replace("\\", "\\\\");
    String targetIndex = getParameter("TargetIndex");
    tfFilename.setText(fileName);
	try {
	    JSObject.getWindow (this).eval ("javascript:SetFileName(" + targetIndex + ",\"" + fileName +"\")") ; 
	}
	catch  (Exception  ex) {
	    showStatus( "Error call javascript err=" + ex );
	}
       try {
        getAppletContext().showDocument
        (new URL("javascript:SetFileName(" + targetIndex + ",\"" + fileName +"\")"));
       }
	catch  (Exception  ex) {
	    showStatus( "Error call javascript err=" + ex );
	}
    }
  }
  }
}
