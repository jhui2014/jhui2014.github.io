#ifndef DRAW_FIGURE_SUPPORT_H
#define DRAW_FIGURE_SUPPORT_H

#include "stl.h"
#include "UserDefinedType.h"

class wxMemoryDC;
class draw_figure_structure
{
public:
	string error_msg;
	PISize size;
	vector<PIRect> map_rects;
	vector<string> map_strings;

	draw_figure_structure();
	virtual string print_usage();
	virtual bool get_params(const vector<string> &params);
	virtual bool load_data();
	virtual bool prepare_data();
	virtual bool draw(wxMemoryDC* pdc, int x_off = 0, int y_off = 0);
	virtual bool drawfile(const string pic_filename);
};
#endif //DRAW_FIGURE_SUPPORT_H
