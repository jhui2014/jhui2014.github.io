#ifndef _WEBSERVER_H_
#define _WEBSERVER_H_

#include <string>
#include <map>
#include "wx/thread.h"

class wxSocketServer;
class MyDialog;

namespace http {
	namespace server3 {
		class request;
	}
}

struct http_request
{
	http_request(const http::server3::request& req);
	http_request() : authentication_given_(false), error(false), statuscode(0), redirect(false), redirect_url("") {}

	wxSocketServer*			          s_;
	std::string                        method_;
	std::string                        path_;
	std::map<std::string, std::string> params_;

	std::string                        accept_;
	std::string                        accept_language_;
	std::string                        accept_encoding_;
	std::string                        user_agent_;


	/* status_: used to transmit server's error status, such as
	o  202 OK
	o  404 Not Found
	and so on */
	std::string                        status_;

	/* auth_realm_: allows to set the basic realm for an authentication,
	no need to additionally set status_ if set */
	std::string                        auth_realm_;

	std::string                        answer_;

	bool								error;
	int								statuscode;
	bool								redirect;
	std::string						redirect_url;

	/*   authentication_given_ is true when the user has entered a username and password.
	These can then be read from username_ and password_ */
	bool authentication_given_;
	std::string username_;
	std::string password_;

	std::string server_ip_;
	std::string client_ip_;
};

class webserver
{
public:
	typedef  void (*request_func) (http_request*);
	webserver(int port_to_listen);
	static request_func request_func_;
	~webserver() { delete in; }
	void MainLoop(request_func main_handler, void *app);
private:
	wxSocketServer *in;
};


//--------------------------------------------------------------
// manifest constants
//--------------------------------------------------------------
#define COMM_BUFFER_SIZE 1024
#define SMALL_BUFFER_SIZE 10

struct MimeAssociation
{
	char *file_ext;
	char *mime;
};

void * ProcessRequest(void* ptr_s);

#endif
