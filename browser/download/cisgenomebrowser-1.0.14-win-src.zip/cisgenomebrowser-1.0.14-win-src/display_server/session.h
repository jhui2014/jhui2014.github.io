#ifndef SESSION_H
#define SESSION_H

#include "Ini.h"
//#include "call_external.h"
#include "draw_data.h"
#include "draw_bar.h"
#include "draw_regbar.h"
#include "draw_conservation.h"
#include "draw_motif.h"
#include "draw_motif_html.h"
#include "draw_cel.h"
#include "draw_gene.h"
#include "draw_nucleotide.h"
#include "file_operation.h"
#include "string_operation.h"
#include "chr_region.h"
#include "math_utils.h"
#include "default_values.h"

bool get_gene_file_name(const string filename, string &gene_filename, string &error_msg) {
	gene_filename = "";
	error_msg = "";
	if (!file_exists(filename)) {
		error_msg = "ERROR: file does not exist.";
		return false;
	} else if (!is_genefile(filename)) {
		if (file_exists(filename+".genefile") && compare_file_time(filename, filename+".genefile") <= 0) {
			if (!is_genefile(filename+".genefile")) {
				error_msg = "ERROR: failed converting file to genefile format: file already exists and in wrong format.";
				return false;
			}
		} else {
			if (!is_gene_text_file(filename)) {
				error_msg = "ERROR: file is neither in genefile nor in correct text format.";
				return false;
			}
			if (!convert_from_text_to_gene(filename, filename+".genefile")) {
				error_msg = "ERROR: failed converting file to genefile format.";
				return false;
			}
		}
		gene_filename = filename+".genefile";
	} else {
		gene_filename = filename;
	}
	return true;
}

bool get_genefile_from_cache(const string filename, string &error_msg, genefile* &mygenefile){
	error_msg = "";
	mygenefile = NULL;
	if (!cache_genefiles) {
		error_msg = "ERROR:caching is not allowed";
		return false;
	} else if (!file_exists(filename)) {
		error_msg = "ERROR: file does not exist.";
		return false;
	} else if (genefile_time_cache.count(filename) == 0 || file_changed(filename, genefile_time_cache[filename])) {
		string gene_filename;
		if (!get_gene_file_name(filename, gene_filename, error_msg)) return false;
		genefile tempgenefile;
		if (!tempgenefile.read_from_file(gene_filename)) {
			error_msg = "ERROR: read genefile failed.";
			return false;
		}
		genefile_cache[filename] = tempgenefile;
		genefile_time_cache[filename] = get_file_modify_time(filename);
		mygenefile = &genefile_cache[filename];
		//check cache size and remove old ones if cache oversize
	} else {
		mygenefile = &genefile_cache[filename];
	}
	return true;
}

class session;

class display_type{
public:
	session *s;
	webserver::http_request* req;

	vector<CRect> rects;
	vector<string> hrefs;
	vector<string> titles;
	vector<string> onclicks;

	bool refresh;
	display_type():req(NULL){refresh = false;};
	display_type(webserver::http_request* r):req(r){};
	virtual ~display_type(){cleanup();};
	virtual bool load_from_file(string file_name) = 0;
	virtual bool update_params() = 0;
	virtual bool write_to_file(string file_name) = 0;
	virtual void generate_hrefs(vector<CRect> &map_rects, vector<string> &map_strings){};
	virtual string get_html() = 0;
	virtual void cleanup(){};
};

class display_data : public display_type{
public:
	string src_filename;
	string pic_filename;
	display_data(){};
	display_data(webserver::http_request* r);
	virtual bool load_from_file(string file_name);
	virtual bool update_params();
	virtual bool write_to_file(string file_name);
	virtual string get_html();
};

class display_motif : public display_type{
public:
	bool multiple_motifs;
	string src_filename;
	string pic_filename;
	display_motif(){};
	display_motif(webserver::http_request* r);
	virtual bool load_from_file(string file_name);
	virtual bool update_params();
	virtual bool write_to_file(string file_name);
	virtual string get_html();
};

class display_cel : public display_type{
public:
	string src_filename;
	string pic_filename;
	display_cel(){};
	display_cel(webserver::http_request* r);
	virtual bool load_from_file(string file_name);
	virtual bool update_params();
	virtual bool write_to_file(string file_name);
	virtual string get_html();
};

class display_genome;

class display_track : public display_type{
public:
	display_genome *genome;
	string name;
	string title;
	bool top_axis;
	bool bottom_axis;
	bool fast_draw;
	string pic_filename;
	interval_set intervals;
	bool fold;

	display_track(){};
	display_track(webserver::http_request* r, string track_name, display_genome *g);
	virtual bool load_from_file(string file_name);
	virtual bool update_params();
	virtual bool write_to_file(string file_name);
	virtual string get_html();
	virtual string get_configure_html();
	virtual bool generate_pic_file(bool get_intervals = false);
	virtual void generate_hrefs(vector<CRect> &map_rects, vector<string> &map_strings);
	virtual string type()=0;
};

class display_nucleotide : public display_track{
public:
	string file_path;

	display_nucleotide(){};
	display_nucleotide(webserver::http_request* r, string track_name, display_genome *g);
	virtual bool load_from_file(string file_name);
	virtual bool update_params();
	virtual bool write_to_file(string file_name);
	virtual string get_configure_html();
	virtual bool generate_pic_file(bool get_intervals = false);
	virtual string type(){return "display_nucleotide";}
};

class display_conservation : public display_track{
public:
	int pic_height;
	string file_path;
	string plot_type;

	display_conservation(){};
	display_conservation(webserver::http_request* r, string track_name, display_genome *g);
	virtual bool load_from_file(string file_name);
	virtual bool update_params();
	virtual bool write_to_file(string file_name);
	virtual string get_configure_html();
	virtual bool generate_pic_file(bool get_intervals = false);
	virtual string type(){return "display_conservation";}
};

class display_signal : public display_track{
public:
	int pic_height;
	vector<string> src_filenames;
	double rangelow, rangehigh;
	double signal_width;
	string plot_type;
	vector<string> colors;
	bool zero_line;
	bool always_include_zero;
	double max_draw_line_distance;
	int count_window;

	display_signal(){};
	display_signal(webserver::http_request* r, string track_name, display_genome *g);
	virtual bool load_from_file(string file_name);
	virtual bool update_params();
	virtual bool write_to_file(string file_name);
	virtual string get_configure_html();
	virtual bool generate_pic_file(bool get_intervals = false);
	virtual string type(){return "display_signal";}
};

class display_region : public display_track{
public:
	int pic_height;
	vector<string> src_filenames;
	double rangelow, rangehigh;
	string plot_type;
	vector<string> colors;
	bool zero_line;
	bool always_include_zero;

	display_region(){};
	display_region(webserver::http_request* r, string track_name, display_genome *g);
	virtual bool load_from_file(string file_name);
	virtual bool update_params();
	virtual bool write_to_file(string file_name);
	virtual string get_configure_html();
	virtual bool generate_pic_file(bool get_intervals = false);
	virtual string type(){return "display_region";}
};

class display_gene : public display_track{
public:
	string src_filename;
	bool draw_exon_num;
	bool do_caching;
	bool annotation;
	int max_height;
	int gene_font_size;

	display_gene(){};
	display_gene(webserver::http_request* r, string track_name, display_genome *g);
	virtual bool load_from_file(string file_name);
	virtual bool update_params();
	virtual bool write_to_file(string file_name);
	virtual string get_configure_html();
	virtual bool generate_pic_file(bool get_intervals = false);
	virtual string type(){return "display_gene";}
};

class display_genome : public display_type{
public:
	vector<display_track*> tracks;
	vector<display_track*> hided_tracks;
	string region;
	string ucsc_genome_assembly;
	int pic_width;
	int pic_margin;
	int font_size;
	bool left_axis;
	bool right_axis;
	bool ucsc_browser;
	string grid;
	vector<int> fold_track;
	interval_set intervals;
	display_genome(){};
	virtual ~display_genome(){cleanup();};
	display_genome(webserver::http_request* r);
	virtual bool load_from_file(string file_name);
	virtual bool update_params();
	virtual bool write_to_file(string file_name);
	display_track* create_track(string track_type, string trackname);
	virtual string get_html();
	virtual void cleanup();
};

class session{
public:
	string name;
	string type;
	int seed;
	bool seed_match;
	string password;
	display_type* display;
	webserver::http_request* req;
	bool refresh;

	session(webserver::http_request* r);
	~session(){cleanup();}
	void cleanup();
	virtual bool load_from_file(string file_name);
	void create_display();
	virtual bool update_params();
	virtual bool write_to_file(string file_name);
	virtual string get_html();
};

string get_random_session_name(){
	string session_name = string("cgb_random_session_")+get_random_string();
	while (file_exists(session_path+session_name+".ini")) session_name = string("cgb_random_session_")+get_random_string();
	return session_name;
}

string get_random_pic_file_name(){
	string pic_file_name = string("cgb_random_pic_")+get_random_string()+".gif";
	while (file_exists(temp_path + client_ip+pic_file_name)) pic_file_name = string("cgb_random_pic_")+get_random_string()+".gif";
	return pic_file_name;
}

CString toCString(const std::string& str)
{ return CString(str.c_str()); }

std::string toStdString(const CString& cstr)
{ return std::string((LPCTSTR)cstr); }

display_motif::display_motif(webserver::http_request* r){
	src_filename = "";
	pic_filename = "";
	req = r;
	multiple_motifs = default_multiple_motifs;
}

bool display_motif::load_from_file(string file_name) {
	CIni ini(file_name.c_str());
	multiple_motifs = ini.GetBool("motif", "multiple_motifs", default_multiple_motifs);
	src_filename = toStdString(ini.GetString("motif", "src_filename"));
	pic_filename = toStdString(ini.GetString("motif", "pic_filename"));
	return true;
}

bool display_motif::update_params(){
	bool updated = false;

	/*for (std::map<std::string, std::string>::const_iterator i = req->params_.begin(); i != req->params_.end(); i++) {
		if (i->first == "motif_filename") {
			src_filename = i->second;
			updated = true;
		} else if (i->first == "motif_pic_filename") {
			pic_filename = i->second;
			updated = true;
		}
	}*/

	if (req->params_.count("create_motif_session") > 0) {
		src_filename = req->params_["motif_filename"];
		multiple_motifs = (req->params_.count("multiple_motifs") > 0);
		updated = true;
	}

	return updated;
}

bool display_motif::write_to_file(string file_name) {
	CIni ini(file_name.c_str());

	if (multiple_motifs != default_multiple_motifs) 
		ini.WriteBool("motif", "multiple_motifs", multiple_motifs);
	else ini.DeleteKey("motif", "multiple_motifs");

	if (src_filename != "") 
		ini.WriteString("motif", "src_filename", src_filename.c_str());
	else ini.DeleteKey("motif", "src_filename");

	if (pic_filename != "") 
		ini.WriteString("motif", "pic_filename", pic_filename.c_str());
	else ini.DeleteKey("motif", "pic_filename");

	return true;
}

string display_motif::get_html(){
	html_formater my_html_formater;
	if (src_filename == "") {
		my_html_formater.load_from_template_file(template_path+"new_motif_session.html");
	} else if (!multiple_motifs) {
		if (pic_filename == "") {
			pic_filename = get_random_pic_file_name();
		}
/*		string command_line = string("\"") + module_path + "draw_figure.exe\" motif \"" + temp_path + client_ip + pic_filename + "\" \"" + src_filename + "\"";
		call_external(command_line);*/
		if (!file_exists(temp_path + client_ip + pic_filename) || refresh) {
			draw_motif my_draw;
			my_draw.motif_filename = src_filename;
			my_draw.load_data();
			my_draw.prepare_data();
			my_draw.drawfile(temp_path + client_ip + pic_filename);
		}

		my_html_formater.load_from_template_file(template_path+"draw_motif.html");
		my_html_formater.replace_keyword("$MOTIF_FILE_NAME$", server_temp_path + client_ip+pic_filename);
	} else { //multiple_motifs
		if (pic_filename == "") {
			pic_filename = get_random_pic_file_name();
		}
		draw_motif_html my_draw;
		my_draw.motif_filename = src_filename;
		my_draw.load_data();
		my_draw.prepare_data();
		if (!my_draw.get_html(temp_path + client_ip + pic_filename, server_temp_path + client_ip+pic_filename, my_html_formater.buf)) return error_html(my_draw.error_msg);
	}
	return my_html_formater.buf;
}

display_data::display_data(webserver::http_request* r){
	src_filename = "";
	pic_filename = "";
	req = r;
}

bool display_data::load_from_file(string file_name) {
	CIni ini(file_name.c_str());
	src_filename = toStdString(ini.GetString("data", "src_filename"));
	pic_filename = toStdString(ini.GetString("data", "pic_filename"));
	return true;
}

bool display_data::update_params(){
	bool updated = false;

	if (req->params_.count("create_data_session") > 0) {
		src_filename = req->params_["data_filename"];
		updated = true;
	}

	return updated;
}

bool display_data::write_to_file(string file_name) {
	CIni ini(file_name.c_str());

	if (src_filename != "") 
		ini.WriteString("data", "src_filename", src_filename.c_str());
	else ini.DeleteKey("data", "src_filename");

	if (pic_filename != "") 
		ini.WriteString("data", "pic_filename", pic_filename.c_str());
	else ini.DeleteKey("data", "pic_filename");

	return true;
}

string display_data::get_html(){
	html_formater my_html_formater;
	if (src_filename == "") {
		my_html_formater.load_from_template_file(template_path+"new_data_session.html");
	} else {
		if (pic_filename == "") {
			pic_filename = get_random_pic_file_name();
		}
		if (!file_exists(temp_path + client_ip + pic_filename) || refresh) {
			draw_data my_draw;
			my_draw.data_filename = src_filename;
			my_draw.load_data();
			my_draw.prepare_data();
			my_draw.drawfile(temp_path + client_ip + pic_filename);
		}

		my_html_formater.load_from_template_file(template_path+"draw_data.html");
		my_html_formater.replace_keyword("$DATA_FILE_NAME$", server_temp_path + client_ip+pic_filename);
	}
	return my_html_formater.buf;
}

//////////////////////////////////

display_cel::display_cel(webserver::http_request* r){
	src_filename = "";
	pic_filename = "";
	req = r;
}

bool display_cel::load_from_file(string file_name) {
	CIni ini(file_name.c_str());
	src_filename = toStdString(ini.GetString("cel", "src_filename"));
	pic_filename = toStdString(ini.GetString("cel", "pic_filename"));
	return true;
}

bool display_cel::update_params(){
	bool updated = false;
/*	for (std::map<std::string, std::string>::const_iterator i = req->params_.begin(); i != req->params_.end(); i++) {
		if (i->first == "cel_filename") {
			src_filename = i->second;
			updated = true;
		} else if (i->first == "cel_pic_filename") {
			pic_filename = i->second;
			updated = true;
		}
	}*/

	if (req->params_.count("create_cel_session") > 0) {
		src_filename = req->params_["cel_filename"];
		updated = true;
	}

	return updated;
}

bool display_cel::write_to_file(string file_name) {
	CIni ini(file_name.c_str());

	if (src_filename != "")
		ini.WriteString("cel", "src_filename", src_filename.c_str());
	else ini.DeleteKey("cel", "src_filename");

	if (pic_filename != "")
		ini.WriteString("cel", "pic_filename", pic_filename.c_str());
	else ini.DeleteKey("cel", "pic_filename");

	return true;
}

string display_cel::get_html(){
	html_formater my_html_formater;
	if (src_filename == "") {
		my_html_formater.load_from_template_file(template_path+"new_cel_session.html");
	} else {
		if (pic_filename == "") {
			pic_filename = get_random_pic_file_name();
		}
		if (!file_exists(temp_path + client_ip + pic_filename) || refresh) {
			//string command_line = module_path + "draw_cel.exe " + src_filename + " " + temp_path + client_ip + pic_filename;
			/*string command_line = string("\"") + module_path + "draw_figure.exe\" cel \"" + temp_path + client_ip + pic_filename + "\" \"" + src_filename + "\"";
			call_external(command_line);*/
			draw_cel my_draw;
			my_draw.cel_filename = src_filename;
			my_draw.load_data();
			my_draw.prepare_data();
			my_draw.drawfile(temp_path + client_ip + pic_filename);
		}

		my_html_formater.load_from_template_file(template_path+"draw_cel.html");
		my_html_formater.replace_keyword("$CEL_FILE_NAME$", server_temp_path + client_ip+pic_filename);
	}
	return my_html_formater.buf;
}

display_track::display_track(webserver::http_request* r, string track_name, display_genome *g){
	req = r;
	name = track_name;
	title = "";
	top_axis = false;
	bottom_axis = false;
	fast_draw = default_fast_draw;
	pic_filename = "";
	genome = g;
}

bool display_track::load_from_file(string file_name) {
	CIni ini(file_name.c_str());
	title = toStdString(ini.GetString(name.c_str(), "title"));
	top_axis = ini.GetBool(name.c_str(), "top_axis", false);
	bottom_axis = ini.GetBool(name.c_str(), "bottom_axis", false);
	fast_draw = ini.GetBool(name.c_str(), "fast_draw", default_fast_draw);
	pic_filename = toStdString(ini.GetString(name.c_str(), "pic_filename"));
	return true;
}

bool display_track::update_params(){
	if (req->params_.count("update_track") > 0) {
		title = req->params_["track_title"];
		top_axis = (req->params_.count("top_axis") > 0);
		bottom_axis = (req->params_.count("bottom_axis") > 0);
		fast_draw = (req->params_.count("fast_draw") > 0);
	} else if (req->params_.count("update_tracks") > 0) {
	} else return false;
	return true;
}

bool display_track::write_to_file(string file_name) {
	CIni ini(file_name.c_str());

	if (title != "") 
		ini.WriteString(name.c_str(), "title", title.c_str());
	else ini.DeleteKey(name.c_str(), "title");

	if (top_axis != false) 
		ini.WriteBool(name.c_str(), "top_axis", top_axis);
	else ini.DeleteKey(name.c_str(), "top_axis");

	if (bottom_axis != false) 
		ini.WriteBool(name.c_str(), "bottom_axis", bottom_axis);
	else ini.DeleteKey(name.c_str(), "bottom_axis");

	if (fast_draw != default_fast_draw)
		ini.WriteBool(name.c_str(), "fast_draw", fast_draw);
	else ini.DeleteKey(name.c_str(), "fast_draw");

	if (pic_filename != "")
		ini.WriteString(name.c_str(), "pic_filename", pic_filename.c_str());
	else ini.DeleteKey(name.c_str(), "pic_filename");

	return true;
}

void display_track::generate_hrefs(vector<CRect> &map_rects, vector<string> &map_strings){
	for (int i = 0; i < (int)map_rects.size(); i++) {
		vector<string> tokens = string_tokenize(map_strings[i]);
		if (tokens[0] == "h_axis") {
			rects.push_back(map_rects[i]);
			int center = round_double(str2double(tokens[1]));
			titles.push_back(string("position: ") + int2str(center));
			chr_region region(genome->region);
			region.move(center - (region.start + region.end) / 2);
			region.resize(1.0/3);
			//hrefs.push_back(host_name + "session?name=$SESSION_NAME$&region=" + region.get_region());
			//hrefs.push_back(string("javascript:show_coord_menu(event, ") + int2str(center) + ")");
			hrefs.push_back("#");
			onclicks.push_back(string("show_coord_menu(event, ") + int2str(center) + "); return false");
		} else if (tokens[0] == "gene") { // should go to display_gene actually
			rects.push_back(map_rects[i]);
			titles.push_back(tokens[1] + " " + tokens[2]);
			vector<string> tokens1 = string_tokenize(tokens[1], "/");
			while (tokens1.size() < 2) tokens1.push_back("");
			//hrefs.push_back(host_name + "session?name=$SESSION_NAME$&region=" + tokens[2]);
			hrefs.push_back("#");
			onclicks.push_back(string("show_gene_menu(event, '") + tokens1[1] + "','" + tokens[1] + "','" + tokens[2] + "'); return false");
		} else if (tokens[0] == "signal") {
			rects.push_back(map_rects[i]);
			titles.push_back(string("value:") + tokens[1] + " at coordinate " + tokens[2]);
			hrefs.push_back("");
		}
	}
}

string display_track::get_html(){
	string result = "";
	if (pic_filename == "") {
		pic_filename = get_random_pic_file_name();
	}
	if (!file_exists(temp_path + client_ip + pic_filename) || genome->refresh) {
		generate_pic_file();
	}
	result += map_html(string("map_") + name, rects, hrefs, titles, onclicks);
	result += image_html(server_temp_path + client_ip+pic_filename, string("map_") + name);
	return result;
}

string display_track::get_configure_html(){
	html_formater my_html_formater;
	my_html_formater.load_from_template_file(template_path + "track_config.html");
	my_html_formater.replace_keyword("$TRACK_TITLE$", title);
	my_html_formater.replace_keyword("$TOP_AXIS$", top_axis?" checked":"");
	my_html_formater.replace_keyword("$BOTTOM_AXIS$", bottom_axis?" checked":"");
	my_html_formater.replace_keyword("$FAST_DRAW$", fast_draw?" checked":"");
	my_html_formater.replace_keyword("$PIC_FILENAME$", pic_filename);
	return my_html_formater.buf;
}

bool display_track::generate_pic_file(bool get_intervals){
	if (get_intervals) {
		intervals.end_points.clear();
	} else {
		if (pic_filename == "") return false;
		string pic_file_name = temp_path + client_ip + pic_filename;
		if (file_exists(pic_file_name) && !DeleteFile(pic_file_name.c_str())) return false;
	}
	return true;
}

display_nucleotide::display_nucleotide(webserver::http_request* r, string track_name, display_genome *g) : display_track(r, track_name, g){
	file_path = "";
}

bool display_nucleotide::load_from_file(string file_name){
	display_track::load_from_file(file_name);
	CIni ini(file_name.c_str());
	file_path = toStdString(ini.GetString(name.c_str(), "file_path"));
	if (title == "") title = file_path;
	return true;
}

bool display_nucleotide::update_params(){
	if (!display_track::update_params()) return false;
	if (req->params_.count("update_track") > 0) {
		file_path = get_path(req->params_["file_path"]);
		if (title == "") title = file_path;
	} else if (req->params_.count("update_tracks") > 0) {
	} else return false;
	return true;
}

bool display_nucleotide::write_to_file(string file_name){
	display_track::write_to_file(file_name);
	CIni ini(file_name.c_str());
	ini.WriteString(name.c_str(), "type", "nucleotide");
	
	if (file_path != "") 
		ini.WriteString(name.c_str(), "file_path", file_path.c_str());
	else ini.DeleteKey(name.c_str(), "file_path");
	return true;
}

string display_nucleotide::get_configure_html(){
	html_formater my_html_formater;
	my_html_formater.load_from_template_file(template_path + "nucleotide_track_config.html");
	my_html_formater.replace_keyword("$FILE_PATH$", file_path);
	string result = my_html_formater.buf;
	my_html_formater.buf = display_track::get_configure_html();
	my_html_formater.replace_keyword("$TRACK_CONTENTS$", result);
	my_html_formater.replace_keyword("$TRACK_TYPE$", "nucleotide");
	return my_html_formater.buf;
}

bool display_nucleotide::generate_pic_file(bool get_intervals){
	if (!display_track::generate_pic_file(get_intervals)) return false;
	
	draw_nucleotide my_draw;
	my_draw.intervals = intervals;
	my_draw.file_path = file_path;
	if (!parse_region(genome->region, my_draw.chr, my_draw.startpos, my_draw.endpos)) {
		my_draw.error_msg = "bad region.";
	}

	/*if (my_draw.endpos - my_draw.startpos > 10000) {
		my_draw.error_msg = "region is too long to load and display";
		//skip long regions for faster display
	}*/

	my_draw.size.cx = genome->pic_width;
	my_draw.box_margin = genome->pic_margin / 3;
	my_draw.data_margin = genome->pic_margin * 2 / 3;
	my_draw.font_size = genome->font_size;
	my_draw.left_axis = genome->left_axis;
	my_draw.right_axis = genome->right_axis;
	if (genome->grid == "off") {
		my_draw.v_grids = false;
	} else if (genome->grid == "gray") {
		my_draw.custom_grid_color = true;
		my_draw.shaded_background = false;
	} else if (genome->grid == "gray_shaded") {
		my_draw.custom_grid_color = true;
		my_draw.shaded_background = true;
	} else if (genome->grid == "color_shaded") {
		my_draw.custom_grid_color = false;
		my_draw.shaded_background = true;
	} else if (genome->grid == "color") {
		my_draw.custom_grid_color = false;
		my_draw.shaded_background = false;
	}
	my_draw.top_axis = top_axis;
	my_draw.bottom_axis = bottom_axis;
	my_draw.fast_draw = fast_draw;
	my_draw.load_data();
	my_draw.prepare_data();
	if (get_intervals) {
		my_draw.get_intervals();
		intervals = my_draw.intervals;
	} else {
		my_draw.drawfile(temp_path + client_ip + pic_filename);
		display_track::generate_hrefs(my_draw.map_rects, my_draw.map_strings);
	}
	return true;
}

display_conservation::display_conservation(webserver::http_request* r, string track_name, display_genome *g) : display_track(r, track_name, g){
	pic_height = default_pic_height;
	file_path = "";
	plot_type = default_plot_type;
}

bool display_conservation::load_from_file(string file_name){
	display_track::load_from_file(file_name);
	CIni ini(file_name.c_str());
	pic_height = ini.GetInt(name.c_str(), "pic_height", default_pic_height);
	file_path = toStdString(ini.GetString(name.c_str(), "file_path"));
	plot_type = toStdString(ini.GetString(name.c_str(), "plot_type", default_plot_type.c_str()));
	if (title == "") title = file_path;
	return true;
}

bool display_conservation::update_params(){
	if (!display_track::update_params()) return false;
	if (req->params_.count("update_track") > 0) {
		file_path = get_path(req->params_["file_path"]);
		if (is_int(req->params_["track_height"]) && str2int(req->params_["track_height"]) >= 10 && str2int(req->params_["track_height"]) <= 4000) {
			pic_height = str2int(req->params_["track_height"]);
		}
		plot_type = req->params_["plot_type"];
		if (title == "") title = file_path;
	} else if (req->params_.count("update_tracks") > 0) {
		if (req->params_["track_height"] != "") {
			if (is_int(req->params_["track_height"]) && str2int(req->params_["track_height"]) >= 10 && str2int(req->params_["track_height"]) <= 4000) {
				pic_height = str2int(req->params_["track_height"]);
			}
		}
	} else return false;
	return true;
}

bool display_conservation::write_to_file(string file_name){
	display_track::write_to_file(file_name);
	CIni ini(file_name.c_str());
	ini.WriteString(name.c_str(), "type", "conservation");	
	
	if (pic_height != default_pic_height)
		ini.WriteInt(name.c_str(), "pic_height", pic_height);
	else ini.DeleteKey(name.c_str(), "pic_height");

	if (plot_type != default_plot_type) 
		ini.WriteString(name.c_str(), "plot_type", plot_type.c_str());
	else ini.DeleteKey(name.c_str(), "plot_type");

	if (file_path != "")
		ini.WriteString(name.c_str(), "file_path", file_path.c_str());
	else ini.DeleteKey(name.c_str(), "file_path");

	return true;
}

string display_conservation::get_configure_html(){
	html_formater my_html_formater;
	my_html_formater.load_from_template_file(template_path + "conservation_track_config.html");
	my_html_formater.replace_keyword("$FILE_PATH$", file_path);
	my_html_formater.replace_keyword("$TRACK_HEIGHT$", int2str(pic_height));
	my_html_formater.replace_keyword("$PLOT_TYPE_BAR$", plot_type=="bar"?"checked":"");
	my_html_formater.replace_keyword("$PLOT_TYPE_HEATMAP$", plot_type=="heatmap"?"checked":"");
	string result = my_html_formater.buf;
	my_html_formater.buf = display_track::get_configure_html();
	my_html_formater.replace_keyword("$TRACK_CONTENTS$", result);
	my_html_formater.replace_keyword("$TRACK_TYPE$", "conservation");
	return my_html_formater.buf;
}

bool display_conservation::generate_pic_file(bool get_intervals){
	if (!display_track::generate_pic_file(get_intervals)) return false;
	
	draw_conservation my_draw;
	my_draw.intervals = intervals;
	my_draw.file_path = file_path;

	if (!parse_region(genome->region, my_draw.chr, my_draw.startpos, my_draw.endpos)) {
		my_draw.error_msg = "bad region.";
	}

	my_draw.size.cx = genome->pic_width;
	my_draw.box_margin = genome->pic_margin / 3;
	my_draw.data_margin = genome->pic_margin * 2 / 3;
	my_draw.font_size = genome->font_size;
	my_draw.size.cy = pic_height;
	my_draw.left_axis = genome->left_axis;
	my_draw.right_axis = genome->right_axis;
	if (genome->grid == "off") {
		my_draw.v_grids = false;
	} else if (genome->grid == "gray") {
		my_draw.custom_grid_color = true;
		my_draw.shaded_background = false;
	} else if (genome->grid == "gray_shaded") {
		my_draw.custom_grid_color = true;
		my_draw.shaded_background = true;
	} else if (genome->grid == "color_shaded") {
		my_draw.custom_grid_color = false;
		my_draw.shaded_background = true;
	} else if (genome->grid == "color") {
		my_draw.custom_grid_color = false;
		my_draw.shaded_background = false;
	}
	my_draw.top_axis = top_axis;
	my_draw.bottom_axis = bottom_axis;
	my_draw.fast_draw = fast_draw;
	if (plot_type == "bar") my_draw.plot_type = PLOT_TYPE_BAR;
	else if (plot_type == "heatmap") my_draw.plot_type = PLOT_TYPE_HEATMAP;
	else return false;
	my_draw.load_data();
	my_draw.prepare_data();
	if (get_intervals) {
		my_draw.get_intervals();
		intervals = my_draw.intervals;
	} else {
		my_draw.drawfile(temp_path + client_ip + pic_filename);
		display_track::generate_hrefs(my_draw.map_rects, my_draw.map_strings);
	}
	return true;
}

display_signal::display_signal(webserver::http_request* r, string track_name, display_genome *g) : display_track(r, track_name, g){
	pic_height = default_pic_height;
	src_filenames.clear();
	colors.clear();
	plot_type = default_plot_type;
	rangelow = rangehigh = 0;
	signal_width = 0;
	zero_line = default_zero_line;
	always_include_zero = default_always_include_zero;
	max_draw_line_distance = 0;
	count_window = 0;
}

bool display_signal::load_from_file(string file_name){
	display_track::load_from_file(file_name);
	CIni ini(file_name.c_str());
	pic_height = ini.GetInt(name.c_str(), "pic_height", default_pic_height);
	rangelow = ini.GetDouble(name.c_str(), "range_low", 0);
	rangehigh = ini.GetDouble(name.c_str(), "range_high", 0);
	signal_width = ini.GetDouble(name.c_str(), "signal_width", 0);
	plot_type = toStdString(ini.GetString(name.c_str(), "plot_type", default_plot_type.c_str()));
	string src_filename = toStdString(ini.GetString(name.c_str(), "src_filename"));
	src_filenames = string_tokenize(src_filename, ",");
	string color = toStdString(ini.GetString(name.c_str(), "color"));
	colors = string_tokenize(color, ",", default_zero_line);
	zero_line = ini.GetBool(name.c_str(), "zero_line", default_zero_line);
	always_include_zero = ini.GetBool(name.c_str(), "always_include_zero", default_always_include_zero);
	max_draw_line_distance = ini.GetDouble(name.c_str(), "max_draw_line_distance", 0);
	count_window = ini.GetInt(name.c_str(), "count_window", 0);
	if (title == "" && (src_filenames.size() > 0)) title = get_file_name(src_filenames[0]);
	return true;
}

bool display_signal::update_params(){
	if (!display_track::update_params()) return false;
	if (req->params_.count("update_track") > 0) {
		int i;
		vector<string> old_src_filenames = src_filenames;
		vector<string> old_colors = colors;
		src_filenames.clear();
		colors.clear();
		for (i = 1; i <= 5; i++) {
			string src_filename = req->params_[string("src_filename")+int2str(i)];
			if (src_filename != "") { 
				src_filenames.push_back(src_filename);
				string color = req->params_[string("color")+int2str(i)];
				if (i <= (int)old_colors.size() && color == "") 
					colors.push_back(old_colors[i-1]);
				else colors.push_back(color);
			}
		}
		if (src_filenames.size() > 0) {
			for (i = 5; i < (int) old_src_filenames.size(); i++) {
				src_filenames.push_back(old_src_filenames[i]);
			}
		} else src_filenames = old_src_filenames;
		for (i = 5; i < (int) old_colors.size(); i++) {
			colors.push_back(old_colors[i]);
		}
		if (is_int(req->params_["track_height"]) && str2int(req->params_["track_height"]) >= 10 && str2int(req->params_["track_height"]) <= 4000) {
			pic_height = str2int(req->params_["track_height"]);
		}
		plot_type = req->params_["plot_type"];
		if (is_num(req->params_["range_low"])) {
			rangelow = str2double(req->params_["range_low"]);
		}
		if (is_num(req->params_["range_high"])) {
			rangehigh = str2double(req->params_["range_high"]);
		}
		if (is_num(req->params_["signal_width"]) && str2double(req->params_["signal_width"]) >= -100 && str2double(req->params_["signal_width"]) <= 1000000) {
			signal_width = str2double(req->params_["signal_width"]);
		}
		zero_line = (req->params_.count("zero_line") > 0);
		always_include_zero = (req->params_.count("always_include_zero") > 0);
		if (is_num(req->params_["max_draw_line_distance"]) && str2double(req->params_["max_draw_line_distance"]) >= 0 && str2double(req->params_["max_draw_line_distance"]) <= 1000000) {
			max_draw_line_distance = str2double(req->params_["max_draw_line_distance"]);
		}
		if (is_int(req->params_["count_window"]) && str2int(req->params_["count_window"]) >= 0 && str2int(req->params_["count_window"]) <= 100000) {
			count_window = str2int(req->params_["count_window"]);
		}
		if (title == "" && (src_filenames.size() > 0)) title = get_file_name(src_filenames[0]);
	} else if (req->params_.count("update_tracks") > 0) {
		if (req->params_["track_height"] != "") {
			if (is_int(req->params_["track_height"]) && str2int(req->params_["track_height"]) >= 10 && str2int(req->params_["track_height"]) <= 4000) {
				pic_height = str2int(req->params_["track_height"]);
			}
		}
		if (req->params_["range_low"] != "") {
			if (is_num(req->params_["range_low"])) {
				rangelow = str2double(req->params_["range_low"]);
			}
		}
		if (req->params_["range_high"] != "") {
			if (is_num(req->params_["range_high"])) {
				rangehigh = str2double(req->params_["range_high"]);
			}
		}
		if (req->params_["signal_width"] != "") {
			if (is_num(req->params_["signal_width"]) && str2double(req->params_["signal_width"]) >= -100 && str2double(req->params_["signal_width"]) <= 1000000) {
				signal_width = str2double(req->params_["signal_width"]);
			}
		}
	} else return false;
	return true;
}

bool display_signal::write_to_file(string file_name){
	display_track::write_to_file(file_name);
	CIni ini(file_name.c_str());
	ini.WriteString(name.c_str(), "type", "signal");	

	if (pic_height != default_pic_height)
		ini.WriteInt(name.c_str(), "pic_height", pic_height);
	else ini.DeleteKey(name.c_str(), "pic_height");

	if (rangelow != 0) 
		ini.WriteDouble(name.c_str(), "range_low", rangelow);
	else ini.DeleteKey(name.c_str(), "range_low");

	if (rangehigh != 0)
		ini.WriteDouble(name.c_str(), "range_high", rangehigh);
	else ini.DeleteKey(name.c_str(), "range_high");

	if (signal_width != 0)
		ini.WriteDouble(name.c_str(), "signal_width", signal_width);
	else ini.DeleteKey(name.c_str(), "signal_width");

	if (plot_type != default_plot_type) 
		ini.WriteString(name.c_str(), "plot_type", plot_type.c_str());
	else ini.DeleteKey(name.c_str(), "plot_type");

	if (zero_line != default_zero_line)
		ini.WriteBool(name.c_str(), "zero_line", zero_line);
	else ini.DeleteKey(name.c_str(), "zero_line");

	if (always_include_zero != default_always_include_zero)
		ini.WriteBool(name.c_str(), "always_include_zero", always_include_zero);
	else ini.DeleteKey(name.c_str(), "always_include_zero");

	if (max_draw_line_distance != 0) 
		ini.WriteDouble(name.c_str(), "max_draw_line_distance", max_draw_line_distance);
	else ini.DeleteKey(name.c_str(), "max_draw_line_distance");

	if (count_window != 0)
		ini.WriteInt(name.c_str(), "count_window", count_window);
	else ini.DeleteKey(name.c_str(), "count_window");

	string src_filename = "";
	for (int i=0; i<(int)src_filenames.size(); i++) {
		src_filename = src_filename + src_filenames[i];
		if (i < (int)src_filenames.size() - 1) src_filename = src_filename + ",";
	}
	if (src_filename != "")
		ini.WriteString(name.c_str(), "src_filename", src_filename.c_str());
	else ini.DeleteKey(name.c_str(), "src_filename");

	string color = "";
	for (int i=0; i<(int)colors.size(); i++) {
		color = color + colors[i];
		if (i < (int)colors.size() - 1) color = color + ",";
	}
	if (color != "")
		ini.WriteString(name.c_str(), "color", color.c_str());
	else ini.DeleteKey(name.c_str(), "color");

	return true;
}

static const string def_colors[8] = {"black", "red", "blue", "green", "purple", "pink", "brown", "orange"};
static const COLORREF def_colorrefs[8] = {0x000000, 0x0000FF, 0xFF0000, 0x00FF00, 0x800080, 0xFF00FF, 0x004080, 0x4080FF};

string display_signal::get_configure_html(){
	html_formater my_html_formater;
	my_html_formater.load_from_template_file(template_path + "signal_track_config.html");
	int i, j;
	for (i=0; i < 5; i++) {
		if (i < (int)src_filenames.size()) my_html_formater.replace_keyword(string("$SRC_FILENAME") + int2str(i+1) + "$", src_filenames[i]);
		else my_html_formater.replace_keyword(string("$SRC_FILENAME") + int2str(i+1) + "$", "");
	}
	for (i=0; i < 5; i++) {
		for (j = 0; j < 8; j++)
			if (i < (int)colors.size() && colors[i] == def_colors[j]) my_html_formater.replace_keyword(string("$COLOR") + int2str(i+1) +"_" + toupper(def_colors[j]) + "$", "selected");
			else my_html_formater.replace_keyword(string("$COLOR") + int2str(i+1) +"_" + toupper(def_colors[j]) + "$", "");
	}
	my_html_formater.replace_keyword("$TRACK_HEIGHT$", int2str(pic_height));
	my_html_formater.replace_keyword("$RANGE_LOW$", double2str(rangelow));
	my_html_formater.replace_keyword("$RANGE_HIGH$", double2str(rangehigh));
	my_html_formater.replace_keyword("$SIGNAL_WIDTH$", double2str(signal_width));
	my_html_formater.replace_keyword("$PLOT_TYPE_BAR$", plot_type=="bar"?"checked":"");
	my_html_formater.replace_keyword("$PLOT_TYPE_DOT$", plot_type=="dot"?"checked":"");
	my_html_formater.replace_keyword("$PLOT_TYPE_CIRCLE$", plot_type=="circle"?"checked":"");
	my_html_formater.replace_keyword("$PLOT_TYPE_LINE$", plot_type=="line"?"checked":"");
	my_html_formater.replace_keyword("$PLOT_TYPE_HEATMAP$", plot_type=="heatmap"?"checked":"");
	my_html_formater.replace_keyword("$ZERO_LINE$", zero_line?" checked":"");
	my_html_formater.replace_keyword("$ALWAYS_INCLUDE_ZERO$", always_include_zero?" checked":"");
	my_html_formater.replace_keyword("$MAX_DRAW_LINE_DISTANCE$", double2str(max_draw_line_distance));
	my_html_formater.replace_keyword("$COUNT_WINDOW$", int2str(count_window));
	string result = my_html_formater.buf;
	my_html_formater.buf = display_track::get_configure_html();
	my_html_formater.replace_keyword("$TRACK_CONTENTS$", result);
	my_html_formater.replace_keyword("$TRACK_TYPE$", "signal");
	return my_html_formater.buf;
}

bool display_signal::generate_pic_file(bool get_intervals){
	if (!display_track::generate_pic_file(get_intervals)) return false;
/*	string command_line = string("\"") + module_path + "draw_figure.exe\" signal \"" + temp_path + client_ip + pic_filename + "\" \"" + src_filename + "\" /region:" + genome->region + " /size:" + int2str(genome->pic_width) + "x" + int2str(pic_height) + " /axis:";
	command_line += (top_axis?"1":"0");
	command_line += (bottom_axis?"1":"0");
	command_line += (genome->left_axis?"1":"0");
	command_line += (genome->right_axis?"1":"0");
	call_external(command_line);*/
	
	draw_bar my_draw;
	my_draw.intervals = intervals;
	my_draw.bar_filenames = src_filenames;
	int i, j, k;
	my_draw.colors.clear();
	for (i = 0; i < (int)src_filenames.size(); i++) {
		bool set = false;
		if (i < (int)colors.size()) {
			for (j = 0; j < 8; j++) {
				if (def_colors[j] == colors[i]) {
					my_draw.colors.push_back(def_colorrefs[j]);
					set = true;
					break;
				}
			}
		}
		if (!set && i < (int)colors.size() && colors[i] != "") {
			COLORREF color;
			sscanf(colors[i].c_str(), "%x", &color);
			my_draw.colors.push_back(color);
			set = true;
		}
		if (!set) {
			for (j = 0; j < 8; j++) {
				bool chosen = false;
				for (k = 0; k < (int)colors.size(); k++) {
					if (def_colors[j] == colors[k]) {
						chosen = true;
						break;
					}
				}
				if (!chosen) {
					my_draw.colors.push_back(def_colorrefs[j]);
					//if (i < (int)colors.size()) colors[i] = def_colors[j];
					set = true;
					break;
				}
			}
		}
		if (!set) my_draw.colors.push_back(0);
	}

	if (!parse_region(genome->region, my_draw.chr, my_draw.startpos, my_draw.endpos)) {
		my_draw.error_msg = "bad region.";
	}
	my_draw.size.cx = genome->pic_width;
	my_draw.box_margin = genome->pic_margin / 3;
	my_draw.data_margin = genome->pic_margin * 2 / 3;
	my_draw.font_size = genome->font_size;
	my_draw.size.cy = pic_height;
	my_draw.left_axis = genome->left_axis;
	my_draw.right_axis = genome->right_axis;
	my_draw.zero_line = zero_line;
	my_draw.always_include_zero = always_include_zero;
	my_draw.max_draw_line_distance = max_draw_line_distance;
	if (count_window > 0) {
		my_draw.do_window_count = true;
		my_draw.window_left = (double)count_window/2.0;
		my_draw.window_right = (double)count_window/2.0;
	}
	if (genome->grid == "off") {
		my_draw.v_grids = false;
	} else if (genome->grid == "gray") {
		my_draw.custom_grid_color = true;
		my_draw.shaded_background = false;
	} else if (genome->grid == "gray_shaded") {
		my_draw.custom_grid_color = true;
		my_draw.shaded_background = true;
	} else if (genome->grid == "color_shaded") {
		my_draw.custom_grid_color = false;
		my_draw.shaded_background = true;
	} else if (genome->grid == "color") {
		my_draw.custom_grid_color = false;
		my_draw.shaded_background = false;
	}
	my_draw.top_axis = top_axis;
	my_draw.bottom_axis = bottom_axis;
	my_draw.fast_draw = fast_draw;
	my_draw.rangehigh = rangehigh;
	my_draw.rangelow = rangelow;
	my_draw.signal_width = signal_width;
	if (plot_type == "bar") my_draw.plot_type = PLOT_TYPE_BAR;
	else if (plot_type == "dot") my_draw.plot_type = PLOT_TYPE_DOT;
	else if (plot_type == "circle") my_draw.plot_type = PLOT_TYPE_CIRCLE;
	else if (plot_type == "line") my_draw.plot_type = PLOT_TYPE_LINE;
	else if (plot_type == "heatmap") my_draw.plot_type = PLOT_TYPE_HEATMAP;
	else return false;
	my_draw.load_data();
	my_draw.prepare_data();
	if (get_intervals) {
		my_draw.get_intervals();
		intervals = my_draw.intervals;
	} else {
		my_draw.drawfile(temp_path + client_ip + pic_filename);
		display_track::generate_hrefs(my_draw.map_rects, my_draw.map_strings);
	}

	return true;
}

display_region::display_region(webserver::http_request* r, string track_name, display_genome *g) : display_track(r, track_name, g){
	pic_height = default_pic_height;
	src_filenames.clear();
	colors.clear();
	plot_type = default_plot_type;
	rangelow = rangehigh = 0;
	zero_line = default_zero_line;
	always_include_zero = default_always_include_zero;
}

bool display_region::load_from_file(string file_name){
	display_track::load_from_file(file_name);
	CIni ini(file_name.c_str());
	pic_height = ini.GetInt(name.c_str(), "pic_height", default_pic_height);
	rangelow = ini.GetDouble(name.c_str(), "range_low", 0);
	rangehigh = ini.GetDouble(name.c_str(), "range_high", 0);
	plot_type = toStdString(ini.GetString(name.c_str(), "plot_type", default_plot_type.c_str()));
	string src_filename = toStdString(ini.GetString(name.c_str(), "src_filename"));
	src_filenames = string_tokenize(src_filename, ",");
	string color = toStdString(ini.GetString(name.c_str(), "color"));
	colors = string_tokenize(color, ",", false);
	zero_line = ini.GetBool(name.c_str(), "zero_line", default_zero_line);
	always_include_zero = ini.GetBool(name.c_str(), "always_include_zero", default_always_include_zero);
	if (title == "" && (src_filenames.size() > 0)) title = get_file_name(src_filenames[0]);
	return true;
}

bool display_region::update_params(){
	if (!display_track::update_params()) return false;
	if (req->params_.count("update_track") > 0) {
		int i;
		vector<string> old_src_filenames = src_filenames;
		vector<string> old_colors = colors;
		src_filenames.clear();
		colors.clear();
		for (i = 1; i <=5; i++) {
			string src_filename = req->params_[string("src_filename")+int2str(i)];
			if (src_filename != "") { 
				src_filenames.push_back(src_filename);
				string color = req->params_[string("color")+int2str(i)];
				if (i <= (int)old_colors.size() && color == "") 
					colors.push_back(old_colors[i-1]);
				else colors.push_back(color);
			}
		}
		if (src_filenames.size() > 0) {
			for (i = 5; i < (int) old_src_filenames.size(); i++) {
				src_filenames.push_back(old_src_filenames[i]);
			}
		} else src_filenames = old_src_filenames;
		for (i = 5; i < (int) old_colors.size(); i++) {
			colors.push_back(old_colors[i]);
		}
		if (is_int(req->params_["track_height"]) && str2int(req->params_["track_height"]) >= 10 && str2int(req->params_["track_height"]) <= 4000) {
			pic_height = str2int(req->params_["track_height"]);
		}
		plot_type = req->params_["plot_type"];
		if (is_num(req->params_["range_low"])) {
			rangelow = str2double(req->params_["range_low"]);
		}
		if (is_num(req->params_["range_high"])) {
			rangehigh = str2double(req->params_["range_high"]);
		}
		zero_line = (req->params_.count("zero_line") > 0);
		always_include_zero = (req->params_.count("always_include_zero") > 0);
		if (title == "" && (src_filenames.size() > 0)) title = get_file_name(src_filenames[0]);
	} else if (req->params_.count("update_tracks") > 0) {
		if (req->params_["track_height"] != "") {
			if (is_int(req->params_["track_height"]) && str2int(req->params_["track_height"]) >= 10 && str2int(req->params_["track_height"]) <= 4000) {
				pic_height = str2int(req->params_["track_height"]);
			}
		}
		if (req->params_["range_low"] != "") {
			if (is_num(req->params_["range_low"])) {
				rangelow = str2double(req->params_["range_low"]);
			}
		}
		if (req->params_["range_high"] != "") {
			if (is_num(req->params_["range_high"])) {
				rangehigh = str2double(req->params_["range_high"]);
			}
		}
	} else return false;
	return true;
}

bool display_region::write_to_file(string file_name){
	display_track::write_to_file(file_name);
	CIni ini(file_name.c_str());
	ini.WriteString(name.c_str(), "type", "region");

	if (pic_height != default_pic_height)
		ini.WriteInt(name.c_str(), "pic_height", pic_height);
	else ini.DeleteKey(name.c_str(), "pic_height");

	if (rangelow != 0) 
		ini.WriteDouble(name.c_str(), "range_low", rangelow);
	else ini.DeleteKey(name.c_str(), "range_low");

	if (rangehigh != 0)
		ini.WriteDouble(name.c_str(), "range_high", rangehigh);
	else ini.DeleteKey(name.c_str(), "range_high");

	if (plot_type != default_plot_type) 
		ini.WriteString(name.c_str(), "plot_type", plot_type.c_str());
	else ini.DeleteKey(name.c_str(), "plot_type");

	if (zero_line != default_zero_line)
		ini.WriteBool(name.c_str(), "zero_line", zero_line);
	else ini.DeleteKey(name.c_str(), "zero_line");

	if (always_include_zero != default_always_include_zero)
		ini.WriteBool(name.c_str(), "always_include_zero", always_include_zero);
	else ini.DeleteKey(name.c_str(), "always_include_zero");

	string src_filename = "";
	for (int i=0; i<(int)src_filenames.size(); i++) {
		src_filename = src_filename + src_filenames[i];
		if (i < (int)src_filenames.size() - 1) src_filename = src_filename + ",";
	}
	if (src_filename != "")
		ini.WriteString(name.c_str(), "src_filename", src_filename.c_str());
	else ini.DeleteKey(name.c_str(), "src_filename");

	string color = "";
	for (int i=0; i<(int)colors.size(); i++) {
		color = color + colors[i];
		if (i < (int)colors.size() - 1) color = color + ",";
	}
	if (color != "")
		ini.WriteString(name.c_str(), "color", color.c_str());
	else ini.DeleteKey(name.c_str(), "color");

	return true;
}

string display_region::get_configure_html(){
	html_formater my_html_formater;
	my_html_formater.load_from_template_file(template_path + "region_track_config.html");
	int i, j;
	for (i=0; i < 5; i++) {
		if (i < (int)src_filenames.size()) my_html_formater.replace_keyword(string("$SRC_FILENAME") + int2str(i+1) + "$", src_filenames[i]);
		else my_html_formater.replace_keyword(string("$SRC_FILENAME") + int2str(i+1) + "$", "");
	}
	for (i=0; i < 5; i++) {
		for (j = 0; j < 8; j++)
			if (i < (int)colors.size() && colors[i] == def_colors[j]) my_html_formater.replace_keyword(string("$COLOR") + int2str(i+1) +"_" + toupper(def_colors[j]) + "$", "selected");
			else my_html_formater.replace_keyword(string("$COLOR") + int2str(i+1) +"_" + toupper(def_colors[j]) + "$", "");
	}
	my_html_formater.replace_keyword("$TRACK_HEIGHT$", int2str(pic_height));
	my_html_formater.replace_keyword("$RANGE_LOW$", double2str(rangelow));
	my_html_formater.replace_keyword("$RANGE_HIGH$", double2str(rangehigh));
	my_html_formater.replace_keyword("$PLOT_TYPE_BAR$", plot_type=="bar"?"checked":"");
	my_html_formater.replace_keyword("$PLOT_TYPE_HEATMAP$", plot_type=="heatmap"?"checked":"");
	my_html_formater.replace_keyword("$ZERO_LINE$", zero_line?" checked":"");
	my_html_formater.replace_keyword("$ALWAYS_INCLUDE_ZERO$", always_include_zero?" checked":"");
	string result = my_html_formater.buf;
	my_html_formater.buf = display_track::get_configure_html();
	my_html_formater.replace_keyword("$TRACK_CONTENTS$", result);
	my_html_formater.replace_keyword("$TRACK_TYPE$", "region");
	return my_html_formater.buf;
}

bool display_region::generate_pic_file(bool get_intervals){
	if (!display_track::generate_pic_file(get_intervals)) return false;
	
	draw_regbar my_draw;
	my_draw.intervals = intervals;
	my_draw.regbar_filenames = src_filenames;
	int i, j, k;
	my_draw.colors.clear();
	for (i = 0; i < (int)src_filenames.size(); i++) {
		bool set = false;
		if (i < (int)colors.size()) {
			for (j = 0; j < 8; j++) {
				if (def_colors[j] == colors[i]) {
					my_draw.colors.push_back(def_colorrefs[j]);
					set = true;
					break;
				}
			}
		}
		if (!set && i < (int)colors.size() && colors[i] != "") {
			COLORREF color;
			sscanf(colors[i].c_str(), "%x", &color);
			my_draw.colors.push_back(color);
			set = true;
		}
		if (!set) {
			for (j = 0; j < 8; j++) {
				bool chosen = false;
				for (k = 0; k < (int)colors.size(); k++) {
					if (def_colors[j] == colors[k]) {
						chosen = true;
						break;
					}
				}
				if (!chosen) {
					my_draw.colors.push_back(def_colorrefs[j]);
					//if (i < (int)colors.size()) colors[i] = def_colors[j];
					set = true;
					break;
				}
			}
		}
		if (!set) my_draw.colors.push_back(0);
	}

	if (!parse_region(genome->region, my_draw.chr, my_draw.startpos, my_draw.endpos)) {
		my_draw.error_msg = "bad region.";
	}
	my_draw.size.cx = genome->pic_width;
	my_draw.box_margin = genome->pic_margin / 3;
	my_draw.data_margin = genome->pic_margin * 2 / 3;
	my_draw.font_size = genome->font_size;
	my_draw.size.cy = pic_height;
	my_draw.left_axis = genome->left_axis;
	my_draw.right_axis = genome->right_axis;
	my_draw.zero_line = zero_line;
	my_draw.always_include_zero = always_include_zero;
	if (genome->grid == "off") {
		my_draw.v_grids = false;
	} else if (genome->grid == "gray") {
		my_draw.custom_grid_color = true;
		my_draw.shaded_background = false;
	} else if (genome->grid == "gray_shaded") {
		my_draw.custom_grid_color = true;
		my_draw.shaded_background = true;
	} else if (genome->grid == "color_shaded") {
		my_draw.custom_grid_color = false;
		my_draw.shaded_background = true;
	} else if (genome->grid == "color") {
		my_draw.custom_grid_color = false;
		my_draw.shaded_background = false;
	}
	my_draw.top_axis = top_axis;
	my_draw.bottom_axis = bottom_axis;
	my_draw.fast_draw = fast_draw;
	my_draw.rangehigh = rangehigh;
	my_draw.rangelow = rangelow;
	if (plot_type == "bar") my_draw.plot_type = PLOT_TYPE_BAR;
	else if (plot_type == "heatmap") my_draw.plot_type = PLOT_TYPE_HEATMAP;
	else return false;
	my_draw.load_data();
	my_draw.prepare_data();
	if (get_intervals) {
		my_draw.get_intervals();
		intervals = my_draw.intervals;
	} else {
		my_draw.drawfile(temp_path + client_ip + pic_filename);
		display_track::generate_hrefs(my_draw.map_rects, my_draw.map_strings);
	}

	return true;
}

display_gene::display_gene(webserver::http_request* r, string track_name, display_genome *g) : display_track(r, track_name, g){
	src_filename = "";
	draw_exon_num = default_draw_exon_num;
	do_caching = default_do_caching;
	annotation = default_annotation;
	max_height = default_max_height;
	gene_font_size = default_gene_font_size;
}

bool display_gene::load_from_file(string file_name){
	display_track::load_from_file(file_name);
	CIni ini(file_name.c_str());
	src_filename = toStdString(ini.GetString(name.c_str(), "src_filename"));
	draw_exon_num = ini.GetBool(name.c_str(), "draw_exon_num", default_draw_exon_num);
	do_caching = ini.GetBool(name.c_str(), "do_caching", default_do_caching);
	annotation = ini.GetBool(name.c_str(), "annotation", default_annotation);
	max_height = ini.GetInt(name.c_str(), "max_height", default_max_height);
	gene_font_size = ini.GetInt(name.c_str(), "gene_font_size", gene_font_size);
	if (title == "") title = get_file_name(src_filename);
	return true;
}

bool display_gene::update_params(){
	if (!display_track::update_params()) return false;
	if (req->params_.count("update_track") > 0) {
		if (req->params_.count("src_filename") > 0) src_filename = req->params_["src_filename"];
		draw_exon_num = (req->params_.count("draw_exon_num") > 0);
		do_caching = (req->params_.count("do_caching") > 0);
		annotation = (req->params_.count("annotation") > 0);
		if (is_int(req->params_["max_height"]) && str2int(req->params_["max_height"]) >= 10 && str2int(req->params_["max_height"]) <= 10000) {
			max_height = str2int(req->params_["max_height"]);
		}
		if (is_int(req->params_["gene_font_size"]) && str2int(req->params_["gene_font_size"]) >= 0 && str2int(req->params_["gene_font_size"]) <= 30) {
			gene_font_size = str2int(req->params_["gene_font_size"]);
		}
		if (title == "") title = get_file_name(src_filename);
	} else if (req->params_.count("update_tracks") > 0) {
	} else return false;
	return true;
}

bool display_gene::write_to_file(string file_name){
	display_track::write_to_file(file_name);
	CIni ini(file_name.c_str());
	ini.WriteString(name.c_str(), "type", "gene");	

	if (src_filename != "")
		ini.WriteString(name.c_str(), "src_filename", src_filename.c_str());
	else ini.DeleteKey(name.c_str(), "src_filename");

	if (draw_exon_num != default_draw_exon_num)
		ini.WriteBool(name.c_str(), "draw_exon_num", draw_exon_num);
	else ini.DeleteKey(name.c_str(), "draw_exon_num");

	if (do_caching != default_do_caching)
		ini.WriteBool(name.c_str(), "do_caching", do_caching);
	else ini.DeleteKey(name.c_str(), "do_caching");

	if (annotation != default_annotation)
		ini.WriteBool(name.c_str(), "annotation", annotation);
	else ini.DeleteKey(name.c_str(), "annotation");

	if (max_height != default_max_height)
		ini.WriteInt(name.c_str(), "max_height", max_height);
	else ini.DeleteKey(name.c_str(), "max_height");

	if (gene_font_size != default_gene_font_size)
		ini.WriteInt(name.c_str(), "gene_font_size", gene_font_size);
	else ini.DeleteKey(name.c_str(), "gene_font_size");

	return true;
}

string display_gene::get_configure_html(){
	html_formater my_html_formater;
	my_html_formater.load_from_template_file(template_path + "gene_track_config.html");
	my_html_formater.replace_keyword("$SRC_FILENAME$", src_filename);
	string result = my_html_formater.buf;
	my_html_formater.buf = display_track::get_configure_html();
	my_html_formater.replace_keyword("$TRACK_CONTENTS$", result);
	my_html_formater.replace_keyword("$TRACK_TYPE$", "gene");
	my_html_formater.replace_keyword("$DRAW_EXON_NUM$", draw_exon_num?" checked":"");
	my_html_formater.replace_keyword("$DO_CACHING$", do_caching?" checked":"");
	my_html_formater.replace_keyword("$ANNOTATION$", annotation?" checked":"");
	my_html_formater.replace_keyword("$MAX_HEIGHT$", int2str(max_height));
	my_html_formater.replace_keyword("$GENE_FONT_SIZE$", int2str(gene_font_size));
	return my_html_formater.buf;
}

bool display_gene::generate_pic_file(bool get_intervals){
	if (!display_track::generate_pic_file(get_intervals)) return false;
	/*string command_line = module_path + "draw_intensity.exe " + src_filename + " " + temp_path + client_ip + pic_filename + " /gene /region:" + genome->region + " /size:" + int2str(genome->pic_width) + "x100" + " /axis:";
	command_line += (genome->left_axis?"1":"0");
	command_line += (genome->right_axis?"1":"0");
	command_line += (top_axis?"1":"0");
	command_line += (bottom_axis?"1":"0");*/
	/*string command_line = string("\"") + module_path + "draw_figure.exe\" gene \"" + temp_path + client_ip + pic_filename + "\" \"" + src_filename + "\" /region:" + genome->region + " /width:" + int2str(genome->pic_width) + " /axis:";
	command_line += (top_axis?"1":"0");
	command_line += (bottom_axis?"1":"0");
	command_line += (genome->left_axis?"1":"0");
	command_line += (genome->right_axis?"1":"0");
	call_external(command_line);*/
	draw_gene my_draw;
	my_draw.intervals = intervals;
	if (!parse_region(genome->region, my_draw.chr, my_draw.startpos, my_draw.endpos)) {
		my_draw.error_msg = "bad region.";
	}
	if (cache_genefiles && do_caching) {
		genefile* tempgenefile = NULL;
		if (get_genefile_from_cache(src_filename, my_draw.error_msg, tempgenefile)) {
			tempgenefile->search_by_region(my_draw.chr, my_draw.startpos, my_draw.endpos, my_draw.genes);
		}
		my_draw.gene_filename = "";
	} else {
		get_gene_file_name(src_filename, my_draw.gene_filename, my_draw.error_msg);
	}
	my_draw.draw_exon_num = draw_exon_num;
	my_draw.size.cx = genome->pic_width;
	my_draw.max_height = max_height;
	my_draw.box_margin = genome->pic_margin / 3;
	my_draw.data_margin = genome->pic_margin * 2 / 3;
	my_draw.font_size = genome->font_size;
	my_draw.gene_font_size = gene_font_size;
	my_draw.left_axis = genome->left_axis;
	my_draw.right_axis = genome->right_axis;
	if (genome->grid == "off") {
		my_draw.v_grids = false;
	} else if (genome->grid == "gray") {
		my_draw.custom_grid_color = true;
		my_draw.shaded_background = false;
	} else if (genome->grid == "gray_shaded") {
		my_draw.custom_grid_color = true;
		my_draw.shaded_background = true;
	} else if (genome->grid == "color_shaded") {
		my_draw.custom_grid_color = false;
		my_draw.shaded_background = true;
	} else if (genome->grid == "color") {
		my_draw.custom_grid_color = false;
		my_draw.shaded_background = false;
	}
	my_draw.top_axis = top_axis;
	my_draw.bottom_axis = bottom_axis;
	my_draw.fast_draw = fast_draw;
	my_draw.load_data();
	my_draw.prepare_data();
	if (get_intervals) {
		my_draw.get_intervals();
		intervals = my_draw.intervals;
	} else {
		my_draw.drawfile(temp_path + client_ip + pic_filename);
		display_track::generate_hrefs(my_draw.map_rects, my_draw.map_strings);
	}

	return true;
}

display_genome::display_genome(webserver::http_request* r){
	req = r;
	tracks.clear();
	hided_tracks.clear();
	region = default_genome;
	ucsc_genome_assembly = "";
	pic_width = default_pic_width;
	pic_margin = default_pic_margin;
	font_size = default_font_size;
	grid = default_grid;
	fold_track.clear();
	left_axis = true;
	right_axis = true;
	ucsc_browser = false;
}

void display_genome::cleanup(){
	for (int i = 0; i < (int)tracks.size(); i++){
		delete tracks[i];
	}
	tracks.clear();
	for (int i = 0; i < (int)hided_tracks.size(); i++){
		delete hided_tracks[i];
	}
	hided_tracks.clear();
}

display_track* display_genome::create_track(string track_type, string trackname) {
	if (track_type == "gene") {
		return new display_gene(req, trackname, this);
	} else if (track_type == "signal") {
		return new display_signal(req, trackname, this);
	} else if (track_type == "conservation") {
		return new display_conservation(req, trackname, this);
	} else if (track_type == "region") {
		return new display_region(req, trackname, this);
	} else if (track_type == "nucleotide") {
		return new display_nucleotide(req, trackname, this);
	} else {
		return NULL;
	}
}

bool display_genome::load_from_file(string file_name){
	cleanup();
	CIni ini(file_name.c_str());
	int num_tracks = ini.GetInt("genome", "num_tracks", 0);
	tracks.resize(num_tracks);
	int num_hided_tracks = ini.GetInt("genome", "num_hided_tracks", 0);
	hided_tracks.resize(num_hided_tracks);
	region = toStdString(ini.GetString("genome", "region", default_genome.c_str()));
	chr_region my_region(region);
	my_region.correct();
	region = my_region.get_region();
	ucsc_genome_assembly = toStdString(ini.GetString("genome", "ucsc_genome_assembly", ""));
	pic_width = ini.GetInt("genome", "pic_width", default_pic_width);
	pic_margin = ini.GetInt("genome", "pic_margin", default_pic_margin);
	font_size = ini.GetInt("genome", "font_size", default_font_size);
	left_axis = ini.GetBool("genome", "left_axis", true);
	right_axis = ini.GetBool("genome", "right_axis", true);
	ucsc_browser = ini.GetBool("genome", "ucsc_browser", false);
	grid = toStdString(ini.GetString("genome", "grid", default_grid.c_str()));
	fold_track = str2int_vec(toStdString(ini.GetString("genome", "fold", "")));
	for (int i = 0; i < (int)tracks.size(); i++) {
		string trackname = string("track") + int2str(i+1);
		string track_type = toStdString(ini.GetString(trackname.c_str(), "type"));
		tracks[i] = create_track(track_type, trackname);
		if (NULL == tracks[i]) return false;
		tracks[i]->load_from_file(file_name);
	}
	for (int i = 0; i < (int)hided_tracks.size(); i++) {
		string trackname = string("hided_track") + int2str(i+1);
		string track_type = toStdString(ini.GetString(trackname.c_str(), "type"));
		hided_tracks[i] = create_track(track_type, trackname);
		if (NULL == hided_tracks[i]) return false;
		hided_tracks[i]->load_from_file(file_name);
	}
	return true;
}

bool display_genome::update_params(){
	return true;
}

bool display_genome::write_to_file(string file_name){
	CIni ini(file_name.c_str());

	if (tracks.size() > 0)
		ini.WriteInt("genome", "num_tracks", (int)tracks.size());
	else ini.DeleteKey("genome", "num_tracks");

	if (hided_tracks.size() > 0)
		ini.WriteInt("genome", "num_hided_tracks", (int)hided_tracks.size());
	else ini.DeleteKey("genome", "num_hided_tracks");

	if (region != "")
		ini.WriteString("genome", "region", region.c_str());
	else ini.DeleteKey("genome", "region");
	
	if (ucsc_genome_assembly != "")
		ini.WriteString("genome", "ucsc_genome_assembly", ucsc_genome_assembly.c_str());
	else ini.DeleteKey("genome", "ucsc_genome_assembly");

	if (pic_width != default_pic_width)
		ini.WriteInt("genome", "pic_width", pic_width);
	else ini.DeleteKey("genome", "pic_width");

	if (pic_margin != default_pic_margin)
		ini.WriteInt("genome", "pic_margin", pic_margin);
	else ini.DeleteKey("genome", "pic_margin");

	if (font_size != default_font_size)
		ini.WriteInt("genome", "font_size", font_size);
	else ini.DeleteKey("genome", "font_size");

	if (left_axis != true) 
		ini.WriteBool("genome", "left_axis", left_axis);
	else ini.DeleteKey("genome", "left_axis");

	if (right_axis != true) 
		ini.WriteBool("genome", "right_axis", right_axis);
	else ini.DeleteKey("genome", "right_axis");

	if (ucsc_browser != false)
		ini.WriteBool("genome", "ucsc_browser", ucsc_browser);
	else ini.DeleteKey("genome", "ucsc_browser");

	if (grid != default_grid)
		ini.WriteString("genome", "grid", grid.c_str());
	else ini.DeleteKey("genome", "grid");

	if (!fold_track.empty())
		ini.WriteString("genome", "fold", int_vec2str(fold_track).c_str());
	else ini.DeleteKey("genome", "fold");

	for (int i = 0; i < (int)tracks.size(); i++) {
		tracks[i]->name = string("track") + int2str(i+1);
		tracks[i]->write_to_file(file_name);
	}

	for (int i = 0; i < (int)hided_tracks.size(); i++) {
		hided_tracks[i]->name = string("hided_track") + int2str(i+1);
		hided_tracks[i]->write_to_file(file_name);
	}

	return true;
}

string display_genome::get_html(){
	int i;
	html_formater my_html_formater;

	bool updated = true; //always update pictures to regenerate map areas
	string old_region = region;

	s->seed--; //dangerous operations

	if (req->params_.count("region") > 0) {
		region = trim_space(req->params_["region"]);
	}

	if (is_region(region)) {
		chr_region my_region(region);
		if (req->params_.count("moveleft") > 0) my_region.move(-.1);
		if (req->params_.count("moveleft2") > 0) my_region.move(-.5);
		if (req->params_.count("moveleft3") > 0) my_region.move(-.9);
		if (req->params_.count("moveright") > 0) my_region.move(.1);
		if (req->params_.count("moveright2") > 0) my_region.move(.5);
		if (req->params_.count("moveright3") > 0) my_region.move(.9);
		if (req->params_.count("center") > 0) my_region.move(str2int(req->params_["center"])-(my_region.start + my_region.end)/2);
		if (req->params_.count("zoomin1_5") > 0) my_region.resize(1.0/1.5);
		if (req->params_.count("zoomin3") > 0) my_region.resize(1.0/3);
		if (req->params_.count("zoomin10") > 0) my_region.resize(.1);
		if (req->params_.count("zoominbase") > 0) my_region.resize((double)(pic_width-100)/15/my_region.length());
		if (req->params_.count("zoomout1_5") > 0) my_region.resize(1.5);
		if (req->params_.count("zoomout3") > 0) my_region.resize(3.0);
		if (req->params_.count("zoomout10") > 0) my_region.resize(10.0);
		if (req->params_.count("show10M") > 0) my_region.resize(10000000);
		if (req->params_.count("show1M") > 0) my_region.resize(1000000);
		if (req->params_.count("show100K") > 0) my_region.resize(100000);
		if (req->params_.count("show10K") > 0) my_region.resize(10000);
		if (req->params_.count("refresh") > 0) updated = true;
//		if (req->params_.count("submit") > 0) ;
//		if (req->params_.count("goto") > 0) ;

		my_region.correct();
		region = my_region.get_region();
		if (old_region != region) updated = true;
		if (req->params_.count("leftaxis") > 0) {
			left_axis = !left_axis;
			updated = true;
		} else if (req->params_.count("rightaxis") > 0) {
			right_axis = !right_axis;
			updated = true;
		} else if (req->params_.count("ucsc_browser") > 0) {
			ucsc_browser = ! ucsc_browser;
		} else if (req->params_.count("grid") > 0) {
			if (grid == "gray") grid = "color";
			else if (grid == "color") grid = "gray_shaded";
			else if (grid == "gray_shaded") grid = "color_shaded";
			else if (grid == "color_shaded") grid = "off";
			else if (grid == "off") grid = "gray";
			updated = true;
		} 

		if (req->params_.count("ucsc_genome_assembly") > 0) { //should always be true
			ucsc_genome_assembly = req->params_["ucsc_genome_assembly"];
		} 

		if (req->params_.count("ucsc") > 0) {
			if (ucsc_genome_assembly == "") {
				return error_html("You should specify a genome assembly for UCSC genome browser first.");
			} else {
				string link = string("http://genome.ucsc.edu/cgi-bin/hgTracks?db=") + ucsc_genome_assembly + "&position=" + region;
				return redirect_html(link);
			}
		}

		if (req->params_.count("track_width") > 0) { //should always be true
			if (!is_int(req->params_["track_width"]) || str2int(req->params_["track_width"]) < 40 || str2int(req->params_["track_width"]) > 4000) {
				return error_html("Picture width must be integer between 40 and 4000.");
			} else if (pic_width != str2int(req->params_["track_width"])) {
				pic_width = str2int(req->params_["track_width"]);
				updated = true;
			}
		} 
		
		if (req->params_.count("pic_margin") > 0) { //should always be true
			if (!is_int(req->params_["pic_margin"]) || str2int(req->params_["pic_margin"]) < 4 || str2int(req->params_["pic_margin"]) > 40) {
				return error_html("Picture margin must be integer between 4 and 40.");
			} else if (pic_margin != str2int(req->params_["pic_margin"])) {
				pic_margin = str2int(req->params_["pic_margin"]);
				updated = true;
			}
		} 

		if (req->params_.count("font_size") > 0) { //should always be true
			if (!is_int(req->params_["font_size"]) || str2int(req->params_["font_size"]) < 4 || str2int(req->params_["font_size"]) > 40) {
				return error_html("Font size must be integer between 4 and 40.");
			} else if (font_size != str2int(req->params_["font_size"])) {
				font_size = str2int(req->params_["font_size"]);
				updated = true;
			}
		} 

		if (req->params_.count("fold_track") > 0) { //should always be true
			if (int_vec2str(fold_track) != req->params_["fold_track"]) {
				vector<int> temp = str2int_vec(req->params_["fold_track"]);
				for (int i = 0; i < (int)temp.size(); i++) {
					if (temp[i] < 1 || temp[i] > (int)tracks.size()) {
						return error_html("Illegal track numbers for folding.");
					}
				}

				fold_track = str2int_vec(req->params_["fold_track"]);
				updated = true;
			}
		}

		vector<int> track_selected;
		track_selected.clear();
		for (i = 1; i <= (int)tracks.size(); i++) {
			if (req->params_.count(string("track_selected_") + int2str(i)) > 0) {
				track_selected.push_back(i);
			}
		}

		if (track_selected.empty() && (req->params_.count("trackdelete") + req->params_.count("trackmoveup") + req->params_.count("trackmovedown") + req->params_.count("tracktotop") + req->params_.count("tracktobottom") + req->params_.count("trackconfigure") > 0)) {
			return error_html("Must select a track first.");
		}

		for (i = 0; i < (int)tracks.size(); i++) tracks[i]->fold = false;
		for (i = 0; i < (int)fold_track.size(); i++) tracks[fold_track[i]-1]->fold = true;

		if (req->params_.count("trackdelete") > 0){
			if (local_client) {
				s->seed++;
				for (i = (int)track_selected.size() - 1; i >= 0; i--) { //must do in reverse order
					delete[] tracks[track_selected[i]-1];
					tracks.erase(tracks.begin() + track_selected[i] - 1);
				}
			} else {
				return error_html(string("Remote user can not do this."));
			}
		} else if (req->params_.count("trackhide") > 0 && track_selected.size() > 0) {
			s->seed++;
			int n = (int)hided_tracks.size();
			for (i = (int)track_selected.size() - 1; i >= 0; i--) { //must do in reverse order
				hided_tracks.insert(hided_tracks.begin() + n, tracks[track_selected[i]-1]);
				tracks.erase(tracks.begin() + track_selected[i] - 1);
			}
		} else if (req->params_.count("trackmoveup") > 0){
			s->seed++;
			for (i = 0; i < (int)track_selected.size(); i++) { //must do in ascending order
				if (track_selected[i] > i + 1) {
					display_track* temp_track = tracks[track_selected[i]-1];		
					tracks[track_selected[i]-1] = tracks[track_selected[i]-2];
					tracks[track_selected[i]-2] = temp_track;
				}
			}
		} else if (req->params_.count("trackmovedown") > 0) {
			s->seed++;
			for (i = (int)track_selected.size() - 1; i >= 0; i--) { //must do in reverse order
				if (track_selected[i] < (int)tracks.size() - (int)track_selected.size() + i + 1) {
					display_track* temp_track = tracks[track_selected[i]-1];
					tracks[track_selected[i]-1] = tracks[track_selected[i]];
					tracks[track_selected[i]] = temp_track;
				}
			}
		} else if (req->params_.count("tracktotop") > 0){
			s->seed++;
			for (i = 0; i < (int)track_selected.size(); i++) { //must do in ascending order
				if (track_selected[i]>i+1) {
					display_track* temp_track = tracks[track_selected[i]-1];
					tracks.erase(tracks.begin() + track_selected[i] - 1);
					tracks.insert(tracks.begin() + i, temp_track);
				}
			}
		} else if (req->params_.count("tracktobottom") > 0){
			s->seed++;
			for (i = 0; i < (int)track_selected.size(); i++) { //must do in ascending order
				display_track* temp_track = tracks[track_selected[i]-1-i];
				tracks.erase(tracks.begin() + track_selected[i] - 1 - i);
				tracks.push_back(temp_track);
			}
 		} 
		
		fold_track.clear();
		for (i = 0; i < (int)tracks.size(); i++) {
			if (tracks[i]->fold) fold_track.push_back(i+1);
		}

		if (req->params_.count("fold") > 0){
			fold_track = track_selected;
			updated = true;
 		} else if (req->params_.count("update_track") > 0) {
			int track_num = str2int(req->params_["track_num"]);
			if (track_num < 1 || track_num > (int)tracks.size() + 1) return error_html("Wrong track number.");
			tracks[track_num-1]->update_params();
			updated = true;
			//tracks[track_num-1]->generate_pic_file();
		} else if (req->params_.count("update_tracks") > 0) {
			vector<int> track_nums = str2int_vec(req->params_["track_num"]);
			for (i = 0; i < (int)track_nums.size(); i++) {
				if (track_nums[i] < 1 || track_nums[i] > (int)tracks.size() + 1) return error_html("Wrong track number.");
				tracks[track_nums[i]-1]->update_params();
				updated = true;
				//tracks[track_nums[i]-1]->generate_pic_file();
			}
		} else if (req->params_.count("unhide_track") > 0) {
			s->seed++;
			int n = (int)tracks.size();
			for (i = (int)hided_tracks.size() - 1; i >= 0; i--) { //must do in reverse order
				if (req->params_.count(string("unhide_track_selected_") + int2str(i+1)) > 0) {
					tracks.insert(tracks.begin() + n, hided_tracks[i]);
					hided_tracks.erase(hided_tracks.begin() + i);
				}
			}
		}

		if (req->params_.count("trackadd") > 0) {
			if (local_client) {
				my_html_formater.load_from_template_file(template_path+"new_track.html");
				my_html_formater.replace_keyword("$TRACK_NUM$", int2str((int)tracks.size()+1));
			} else {
				return error_html(string("Remote user can not do this."));
			}
		} else if (req->params_.count("trackhide") > 0 && track_selected.size() == 0) {
			s->seed++;
			my_html_formater.load_from_template_file(template_path+"unhide_track.html");
			if (hided_tracks.size() >= 1) {
				vector<vector<string> > table;
				table.resize(hided_tracks.size());
				for (i = 0; i < (int)table.size(); i++) {
					table[i].push_back(string("$UNHIDE_TRACK")+int2str(i+1)+"_SELECT$");
					table[i].push_back(string("$UNHIDE_TRACK")+int2str(i+1)+"_TITLE$");
				}
				my_html_formater.replace_keyword("$UNHIDE_TRACKS$", table_html(table, 0));
				for (i = 0; i < (int)hided_tracks.size(); i++) {
					my_html_formater.replace_keyword(string("$UNHIDE_TRACK")+int2str(i+1)+"_SELECT$", check_box_html(string("unhide_track_selected_") + int2str(i+1)));
					my_html_formater.replace_keyword(string("$UNHIDE_TRACK")+int2str(i+1)+"_TITLE$", hided_tracks[i]->title);
				}
			} else {
				my_html_formater.replace_keyword("$UNHIDE_TRACKS$", "There is no track hided.");
			}
		} else if (req->params_.count("trackconfigure") > 0) {
			if (track_selected.size() == 1) {
				my_html_formater.buf = tracks[track_selected[0]-1]->get_configure_html();
				my_html_formater.replace_keyword("$TRACK_NUM$", int2str(track_selected[0]));
			} else if (track_selected.size() > 1) {
				my_html_formater.load_from_template_file(template_path + "configure_multiple_tracks.html");
				my_html_formater.replace_keyword("$TRACK_NUM$", int_vec2str(track_selected));
				my_html_formater.replace_keyword("$TRACK_HEIGHT$", "");
				my_html_formater.replace_keyword("$RANGE_LOW$", "");
				my_html_formater.replace_keyword("$RANGE_HIGH$", "");
				my_html_formater.replace_keyword("$SIGNAL_WIDTH$", "");
				//return error_html("Can only configure one track at one time..");
			} else { // track_selected.size() == 0
				return error_html("Must select at least one track.");
			}
		} else if (req->params_.count("create_track_type") > 0) {
			s->seed++;
			int track_num = str2int(req->params_["track_num"]);
			if (track_num != (int)tracks.size() + 1) return error_html("Wrong track number.");
			string track_name = string("track") + int2str(track_num);
			string track_type = req->params_["track_type"];
			display_track* track = create_track(track_type, track_name);
			if (NULL == track) return error_html("Wrong track type.");
			tracks.push_back(track);
			my_html_formater.buf = tracks[track_num-1]->get_configure_html();
			my_html_formater.replace_keyword("$TRACK_NUM$", int2str(track_num));		
		} else {
			intervals.end_points.clear();
			for (i = 0; i < (int)fold_track.size(); i++) {
				if (fold_track[i] < 1 || fold_track[i] > (int)tracks.size()) return error_html("bad fold tracks");
				tracks[fold_track[i]-1]->generate_pic_file(true);
				intervals.union_with(tracks[fold_track[i]-1]->intervals);
			}
//			intervals.end_points.clear();
			for (i = 0; i < (int)tracks.size(); i++) {
				tracks[i]->intervals = intervals;
			}

			if (updated) {
				for (i = 0; i < (int)tracks.size(); i++) {
					tracks[i]->generate_pic_file();
				}
			}

			my_html_formater.load_from_template_file(template_path+"genome.html");
			if (!is_region(region)) {
				return error_html("Bad Region.");
			}
			chr_region my_region(region);
			my_html_formater.replace_keyword("$GENOME_REGION$", region);
			my_html_formater.replace_keyword("$CHR$", my_region.chr);
			my_html_formater.replace_keyword("$LEN$", int2str(my_region.length()));
			my_html_formater.replace_keyword("$START$", int2str(my_region.start));
			my_html_formater.replace_keyword("$END$", int2str(my_region.end));
			my_html_formater.replace_keyword("$UCSC_GENOME_ASSEMBLY$", ucsc_genome_assembly);
			my_html_formater.replace_keyword("$GENOME_REGION_LENGTH$", int2str(my_region.length()));
			my_html_formater.replace_keyword("$TRACK_WIDTH$", int2str(pic_width));
			my_html_formater.replace_keyword("$PIC_MARGIN$", int2str(pic_margin));
			my_html_formater.replace_keyword("$FONT_SIZE$", int2str(font_size));
			my_html_formater.replace_keyword("$LEFT_AXIS$", left_axis?"on":"off");
			my_html_formater.replace_keyword("$RIGHT_AXIS$", right_axis?"on":"off");
			if (ucsc_browser) {
				if (ucsc_genome_assembly == "") {
					ucsc_browser = false;
					return error_html("You should specify a genome assembly for UCSC genome browser first.");
				} else {
					string link = string("http://genome.ucsc.edu/cgi-bin/hgTracks?db=") + ucsc_genome_assembly + "&position=" + region;
					string iframe = "<iframe src=\"" + link + "\" width=\"100%\" height=\"100%\"></iframe>";
					my_html_formater.replace_keyword("$UCSC_BROWSER_FRAME$", iframe);
				}
			} else {
				my_html_formater.replace_keyword("$UCSC_BROWSER_FRAME$", "");
			}
			my_html_formater.replace_keyword("$UCSC_BROWSER$", ucsc_browser?"on":"off");
			my_html_formater.replace_keyword("$GRID$", grid);
			//my_html_formater.replace_keyword("$FOLD$", fold_track.empty()? "fold" : "unfold");
			my_html_formater.replace_keyword("$FOLD_TRACK$", int_vec2str(fold_track));
			if (tracks.size() > 0) {
				vector<vector<string> > table;
				table.resize(tracks.size()+2);
				for (i = 0; i < (int)table.size(); i++) {
					table[i].push_back(string("$GENOME_TRACK")+int2str(i)+"_SELECT$");
					table[i].push_back(string("$GENOME_TRACK")+int2str(i)+"_TITLE$");
					table[i].push_back(string("$GENOME_TRACK")+int2str(i)+"_PIC$");
				}
				my_html_formater.replace_keyword("$GENOME_TRACKS$", table_html(table, 0));
				for (i = 0; i < (int)tracks.size(); i++) {
					my_html_formater.replace_keyword(string("$GENOME_TRACK")+int2str(i+1)+"_SELECT$", check_box_html(string("track_selected_") + int2str(i+1)));
					my_html_formater.replace_keyword(string("$GENOME_TRACK")+int2str(i+1)+"_TITLE$", tracks[i]->title);
					my_html_formater.replace_keyword(string("$GENOME_TRACK")+int2str(i+1)+"_PIC$", tracks[i]->get_html());
				}
				display_signal temp_track(req, "track_top_axis", this);
				temp_track.intervals = intervals;
				temp_track.top_axis = true;
				temp_track.bottom_axis = false;
				temp_track.fast_draw = true;
				temp_track.src_filenames.clear();
				temp_track.pic_filename = "top_axis.gif";
				temp_track.pic_height = fold_track.empty()?font_size + 15:font_size+45;
				temp_track.generate_pic_file();
				my_html_formater.replace_keyword(string("$GENOME_TRACK")+int2str(0)+"_SELECT$", "");
				my_html_formater.replace_keyword(string("$GENOME_TRACK")+int2str(0)+"_TITLE$", "");
				my_html_formater.replace_keyword(string("$GENOME_TRACK")+int2str(0)+"_PIC$", temp_track.get_html());
				temp_track.name = "track_bottom_axis";
				temp_track.top_axis = false;
				temp_track.bottom_axis = true;
				temp_track.fast_draw = true;
				temp_track.src_filenames.clear();
				temp_track.pic_filename = "bottom_axis.gif";
				temp_track.generate_pic_file();
				my_html_formater.replace_keyword(string("$GENOME_TRACK")+int2str((int)tracks.size()+1)+"_SELECT$", "");
				my_html_formater.replace_keyword(string("$GENOME_TRACK")+int2str((int)tracks.size()+1)+"_TITLE$", "");
				my_html_formater.replace_keyword(string("$GENOME_TRACK")+int2str((int)tracks.size()+1)+"_PIC$", temp_track.get_html());
			} else {
				my_html_formater.replace_keyword("$GENOME_TRACKS$", "");
			}
		}
	} else { //if is_region(region, chr, start, end)
		vector<int> track_selected;
		track_selected.clear();
		for (i = 1; i <= (int)tracks.size(); i++) {
			if (req->params_.count(string("track_selected_") + int2str(i)) > 0) {
				track_selected.push_back(i);
			}
		}

		vector<gene_struct> genes;
		genes.clear();
		if (trim_space(region) != "") {
			for (i = 0; i < (int)tracks.size(); i++) {
				if (tracks[i]->type() != "display_gene") continue;
				if (!((display_gene*)tracks[i])->annotation) continue;
				if (!track_selected.empty() && find(track_selected.begin(), track_selected.end(), i + 1) == track_selected.end()) continue;
				if (cache_genefiles && ((display_gene*)tracks[i])->do_caching) {
					genefile *mygenefile;
					string error_msg;
					if (!get_genefile_from_cache(((display_gene*)(tracks[i]))->src_filename, error_msg, mygenefile)) {
						return error_html(error_msg);
					}
					if (!mygenefile->search_by_name(region, genes)) {
						return error_html("error reading genefile.");
					}
				} else {
					genefile mygenefile;
					string genefilename, error_msg;
					if (!get_gene_file_name(((display_gene*)(tracks[i]))->src_filename, genefilename, error_msg)) {
						return error_html(error_msg);
					}
					if (!mygenefile.read_from_file_gene_name(genefilename, region, genes)) {
						return error_html("error reading genefile.");
					}
				}
			}
		}
		if (genes.size() == 0) {
			string error_message;
			if (trim_space(region) == "") error_message = "Region or gene name needed.";
			else error_message = string("Region or gene not found: ") + region;
			if (is_region(old_region)) region = old_region;
			else region = "chr1:5001000-5002000";
			return error_html(error_message);
		}
		vector<vector<string> > table;
		table.resize(genes.size());
		for (i = 0; i < (int)table.size(); i++) {
			string new_region = genes[i].chrom + ":" + int2str(genes[i].txStart) + "-" + int2str(genes[i].txEnd);
			string url = host_name + "session?name=$SESSION_NAME$&region=" + new_region;
			string text = genes[i].geneName + " (" + genes[i].name + ") at " + new_region;
			table[i].push_back(link_html(url, text));
		}
		my_html_formater.buf = table_html(table, 1);
	}

	my_html_formater.replace_keyword("$REGION$", region);
	return my_html_formater.buf;
}

void session::cleanup(){
	if (display != NULL) {
		delete display;
		display = NULL;
	}
}

session::session(webserver::http_request* r){
	name = "";
	type = "";
	seed = 0;
	seed_match = true;
	password = "";
	display = NULL;
	req = r;
	refresh = false;

	name = r->params_["name"];

	if (r->params_.count("create_session") > 0) {
		name = r->params_["session_name"];
		if (name == "") name = r->params_["name"];
		if (name == "") {
			name = get_random_session_name();
		}
	}

	if (name == "") {
		if (r->params_["session_name"] == "") {
			r->answer_ = error_html("Session does not exists.");
			return;
		} else {
			name = r->params_["session_name"];
		}
	}

	string file_name = session_path+name+".ini";

	if (file_exists(file_name)) {
		if (!load_from_file(file_name)) {
			r->answer_ = error_html(string("Fail loading session ")+name);
			return;
		} 
	} else if (!local_client) {
		r->answer_ = error_html(string("Remote user can not do this."));
		return;
	}

	seed_match = true;
	if (r->params_.count("seed") > 0) {
		if (seed != str2int(r->params_["seed"])) {
			seed_match = false;
			CIni ini(file_name.c_str());
			ini.WriteBool("session", "refresh", true);
			r->answer_ = redirect_html(host_name + "session?name=" + name);
			return;
		}
	}
	seed++;
	/*bool updated = */update_params();

/*	if (updated) {
		r->answer_ = redirect_html(host_name+"session?name="+name);
	} else {
		r->answer_ = get_html();
	}*/

	r->answer_ = get_html();
	refresh = false;

	if (req->params_.count("reload_session_ini_file") > 0){
		CIni ini(file_name.c_str());
		ini.WriteBool("session", "refresh", true);
		r->answer_ = redirect_html(host_name + "session?name=" + name);
		return;
	}

	if (!write_to_file(file_name)) {
		r->answer_ = error_html(string("Fail writing session ")+name);
		return;
	} 

	if (req->params_.count("open_session_ini_file") > 0){
		string session_ini_filename = session_path + name + ".ini";
		if (local_client) ShellExecute(NULL, "open", session_ini_filename.c_str(), NULL, NULL, SW_SHOWNORMAL);
		else {
			r->answer_ = redirect_html(host_name + "sessions/" + name + ".ini");
			//r->answer_ = error_html(string("Remote user can not do this."));
			return;
		}
	}
	
	if (req->params_.count("open_session_folder") > 0){
		if (local_client) ShellExecute(NULL, "open", session_path.c_str(), NULL, NULL, SW_SHOWNORMAL);
		else {
			r->answer_ = error_html(string("Remote client can not do this."));
			return;
		}
	}

	return;
}

void session::create_display(){
	cleanup();
	if (type == "motif") {
		display = new display_motif(req);
	} else if (type == "cel") {
		display = new display_cel(req);
	} else if (type == "data") {
		display = new display_data(req);
	} else if (type == "genome") {
		display = new display_genome(req);
	}
	if (display != NULL) display->refresh = refresh;
	if (display != NULL) display->s = this;
}

bool session::load_from_file(string file_name){
	CIni ini(file_name.c_str());
	type = toStdString(ini.GetString("session", "type"));
	seed = ini.GetInt("session", "seed", 0);
	refresh = ini.GetBool("session", "refresh", false);
	create_display();
	if (display != NULL) 
		return display->load_from_file(file_name);
	else 
		return true;
}

bool session::update_params(){
	bool updated = false;

	if (req->params_.count("create_session_type") > 0) {
		type = req->params_["type"];
		create_display();
		updated = true;
	}
/*
	for (std::map<std::string, std::string>::const_iterator i = req->params_.begin(); i != req->params_.end(); i++) {
		if (i->first == "type") {
			type = i->second;
			updated = true;
		}
	}*/

	if (display != NULL) updated |= display->update_params();
	return updated;
}

bool session::write_to_file(string file_name){
	if (file_exists(file_name)) DeleteFile(file_name.c_str());
	CIni ini(file_name.c_str());
	
	if (type != "")
		ini.WriteString("session", "type", type.c_str());
	else ini.DeleteKey("session", "type");

	if (seed != 0) 
		ini.WriteInt("session", "seed", seed);
	else ini.DeleteKey("session", "seed");

	if (refresh != false)
		ini.WriteBool("session", "refresh", refresh);
	else ini.DeleteKey("session", "refresh");

	if (display != NULL) 
		return display->write_to_file(file_name);
	else 
		return true;
}

string session::get_html(){
	string result;

	if (type == "") {
		html_formater my_html_formater;
		my_html_formater.load_from_template_file(template_path+"new_session.html");
		result = my_html_formater.buf;
	} else if (display == NULL) {
		result = error_html("Internal Error: No Display.");
	} else {
		result = display->get_html();
	}
	html_formater my_html_formater;
	my_html_formater.load_from_template_file(template_path+"session.html");
	my_html_formater.replace_keyword("$SESSION_CONTENTS$", result);
	my_html_formater.replace_keyword("$SESSION_NAME$", name);
	my_html_formater.replace_keyword("$HOSTNAME$", host_name);
	my_html_formater.replace_keyword("$SESSION_SEED$", int2str(seed));
	my_html_formater.replace_keyword("$REMOTE_HIDDEN$", local_client?"":" disabled ");
	title = name + " - CisGenome Browser";
	//my_html_formater.replace_keyword("$REMOTE_HIDDEN$", local_client?"":" type=\"hidden\" ");
	//my_html_formater.replace_keyword("$REMOTE_HIDDEN$", local_client?"":" style=\"width: 0px;height: 0px;border: none\" ");	
	result = my_html_formater.buf;
	return result;
}

#endif //#define SESSION_H