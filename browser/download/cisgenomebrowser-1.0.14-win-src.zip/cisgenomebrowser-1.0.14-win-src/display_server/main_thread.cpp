#include "stdafx.h"

#include "webserver.h"
#include "Socket.h"
#include "main_thread.h"
#include "html_formater.h"
#include "shared_data.h"
#include "session.h"
//#include "call_external.h"
#include "shared_func.h"
#include "ini.h"

vector<string> get_session_names(){
	vector<string> session_names;
	session_names.clear();
	vector<string> file_names = get_all_file_names(session_path);
	int i;
	for (i = 0; i < (int)file_names.size(); i++) {
		//hide all session beginning with '_'
		if (file_names[i].length() > 4 && tolower(file_names[i].substr(file_names[i].length()-4)) == ".ini" && file_names[i][0] != '_') {
			session_names.push_back(file_names[i].substr(0, file_names[i].length()-4));
		}
	}
	return session_names;
}

void main_handler(webserver::http_request* r) {

	int seed = (int)time(NULL);
	srand(seed);
	rand();
	rand();

	r->s_->getIP(server_ip, client_ip);
	local_client = (client_ip == server_ip);
	//local_client = (server_ip == "127.0.0.1");
	//local_client = (client_ip == "127.0.0.1");
	//local_client = (server_ip == server_ip);
	host_name = string("http://") + server_ip + ":" + int2str(port_num) + "/";

	title = "";

	if (r->path_ == "/" || r->path_== "/index.html") {
		html_formater my_html_formater;
		my_html_formater.load_from_template_file(template_path+"index.html");
		vector<string> session_names = get_session_names();
		session_names.insert(session_names.begin(), "");
		my_html_formater.replace_keyword("$LOAD_SESSION$", drop_down_list_html("name", session_names, session_names));
		r->answer_ = my_html_formater.buf;
	} else if (r->path_ == "/session") {
		session mysession(r);
	} else if (r->path_ == "/dir") {
		if (local_client) {
			ShellExecute(NULL, "open", program_path.c_str(), NULL, NULL, SW_SHOWNORMAL);
			r->answer_ = redirect_html(host_name);
		} else {
			r->answer_ = error_html("Remote user can not do this.");
		}
	} else if (r->path_ == "/log") {
		if (local_client) {			
			r->answer_ = redirect_html(host_name + "temp/" + log_filename);
		} else {
			r->answer_ = error_html("Remote user can not do this.");
		}
	} else if (r->path_ == "/setting") {
		if (local_client) {
			html_formater my_html_formater;
			my_html_formater.load_from_template_file(template_path+"setting.html");
			my_html_formater.replace_keyword("$PORT_NUM$", int2str(new_port_num));
			my_html_formater.replace_keyword("$LOCAL_ONLY$", new_local_only?" checked":"");
			r->answer_ = my_html_formater.buf;
		} else {
			r->answer_ = error_html("Remote user can not do this.");
		}
	} else if (r->path_ == "/update_setting") {
		if (local_client) {
			r->answer_ = redirect_html(host_name);
			if (r->params_.count("update_setting") > 0) {
				bool temp_local_only = (r->params_.count("local_only") > 0);
				int temp_port_num = str2int(r->params_["port_num"]);
				if (!is_int(r->params_["port_num"]) || temp_port_num < 1024 || temp_port_num > 65535) {
					r->answer_ = error_html("port number must be between 1024 and 65535.");
				} else {
					CIni ini(ini_filename.c_str());
					if (temp_port_num != new_port_num) {
						new_port_num = temp_port_num;
						if (new_port_num != default_port_num)
							ini.WriteInt("browser", "port_num", new_port_num);
						else ini.DeleteKey("browser", "port_num");
					}
					if (temp_local_only != new_local_only) {
						new_local_only = temp_local_only;
						if (new_local_only != default_local_only)
							ini.WriteBool("browser", "local_only", new_local_only);
						else ini.DeleteKey("browser", "local_only");
					}
				}
			}
		} else {
			r->answer_ = error_html("Remote user can not do this.");
		}
	} else if (r->path_ == "/clear") {
		if (local_client) {
			if (!clear_directory(session_path)) {
				r->answer_ = error_html("Failed when clearing the session directory.");
			}
			if (!clear_directory(temp_path)) {
				r->answer_ = error_html("Failed when clearing the temporary directory.");
			}
			r->answer_ = redirect_html(host_name);
		} else {
			r->answer_ = error_html("Remote user can not do this.");
		}
	} else {
		r->answer_ = error_html("Requested page does not exist.");
	}
	html_formater my_html_formater;
	my_html_formater.load_from_template_file(template_path+"template.html");
	my_html_formater.replace_keyword("$CONTENTS$", r->answer_);
	if (title == "") title = "CisGenome Browser";
	my_html_formater.replace_keyword("$TITLE$", title);
	r->answer_ = my_html_formater.buf;
}

typedef struct _MyData1 {
	int val1;
	int val2;
} MYDATA1, *PMYDATA1;

DWORD WINAPI ThreadProc1( LPVOID lpParam ) {

	HANDLE hStdout;
	PMYDATA1 pData;

	hStdout = GetStdHandle(STD_OUTPUT_HANDLE);
	if( hStdout == INVALID_HANDLE_VALUE )
		return 1;

	// Cast the parameter to the correct data type.

	pData = (PMYDATA1)lpParam;

	// Free the memory allocated by the caller for the thread 
	// data structure.

	HeapFree(GetProcessHeap(), 0, pData);

	webserver(port_num, main_handler);
	return 0; 
}

HANDLE hThread;

void startup(){

	int seed = (int)time(NULL);
	srand(seed);
	rand();
	rand();

	//determine program configurations
	char strExePath [MAX_PATH];
	GetModuleFileName (NULL, strExePath, MAX_PATH);
	program_path = get_path(strExePath);


	ini_filename = program_path + "cgb.ini";

	CIni ini(ini_filename.c_str());

	wwwroot = toStdString(ini.GetString("browser", "wwwroot"));
	if (wwwroot == "") wwwroot = program_path + "wwwroot\\";

	module_path = toStdString(ini.GetString("browser", "module_path"));
	if (module_path == "") module_path = program_path;

	template_path = toStdString(ini.GetString("browser", "template_path"));
	if (template_path == "") template_path = wwwroot+"templates\\";

	session_path = toStdString(ini.GetString("browser", "session_path"));
	if (session_path == "") session_path = wwwroot+"sessions\\";

	temp_path = wwwroot+"temp\\";

	server_temp_path = "temp/";

	log_filename = toStdString(ini.GetString("browser", "log_filename"));
	if (log_filename == "") log_filename = string("log_") + get_time_string() + "_" + get_random_string() + ".txt";

	port_num = ini.GetInt("browser", "port_num", default_port_num);

	local_only = ini.GetBool("browser", "local_only", default_local_only);

	new_local_only = local_only;
	new_port_num = port_num;

	//AllocConsole();
	freopen((temp_path+log_filename).c_str(), "wt", stdout);

	put2log("start cisgenome browser");
	put2log("initialize random seed");
	put2log("initialize program parameters");
	put2log(string("program_path = ") + program_path);
	put2log(string("ini_filename = ") + ini_filename);
	put2log(string("wwwroot = ") + wwwroot);
	put2log(string("module_path = ") + module_path);
	put2log(string("template_path = ") + template_path);
	put2log(string("session_path = ") + session_path);
	put2log(string("temp_path = ") + temp_path);
	put2log(string("server_temp_path = ") + server_temp_path);
	put2log(string("log_filename = ") + log_filename);
	put2log(string("port_num = ") + int2str(port_num));
	put2log(string("local_only = ") + int2str(local_only));

	server_ip = "127.0.0.1";
	client_ip = "";
	local_client = true;

	local_host_name = string("http://127.0.0.1:") + int2str(port_num) + "/";
	host_name = string("http://") + server_ip + ":" + int2str(port_num) + "/";

	max_cache_size_MB = ini.GetInt("browser", "max_cache_size", 256);

	put2log(string("max_cache_size_MB = ") + int2str(max_cache_size_MB));

	cache_genefiles = ini.GetBool("browser", "cache_genefiles", true);

	put2log(string("cache_genefiles = ") + int2str(cache_genefiles));

	genefile_cache.clear();
	genefile_time_cache.clear();

	//start web server in a separate thread
	PMYDATA1 pData;
	DWORD dwThreadId;
	// Create worker thread.

	// Allocate memory for thread data.

	pData = (PMYDATA1) HeapAlloc(GetProcessHeap(),
		HEAP_ZERO_MEMORY, sizeof(MYDATA1));

	if( pData == NULL )
		ExitProcess(2);

	// Generate unique data for each thread.

	pData->val1 = 0;
	pData->val2 = 100;

	hThread = CreateThread( 
		NULL,              // default security attributes
		0,                 // use default stack size  
		ThreadProc1,        // thread function 
		pData,             // argument to thread function 
		0,                 // use default creation flags 
		&dwThreadId);   // returns the thread identifier 

	// Check the return value for success. 

	if (hThread == NULL) 
	{
		put2log("starting webserver thread failed");		
		ExitProcess(1);
	}
	put2log("starting webserver thread succeeded");		
}

void cleanup(){
	/*kernel->stop_kernel();
	delete kernel;
	kernel = NULL;*/

	put2log("cleaning up");

	put2log("terminating web server thread");

	TerminateThread(hThread, 1);
	// Wait until thread has terminated.

	WaitForSingleObject(hThread, INFINITE);

	// Close thread handle upon completion.

	CloseHandle(hThread);

	put2log("close log file handle");

	fclose(stdout);
	//FreeConsole();
}