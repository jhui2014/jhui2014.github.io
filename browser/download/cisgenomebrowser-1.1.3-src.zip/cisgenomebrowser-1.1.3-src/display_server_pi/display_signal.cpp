#include "display_signal.h"
#include "drawCommon.h"
#include "display_genome.h"

display_signal::display_signal(http_request* r, string track_name,
							   display_genome *g) :
display_track(r, track_name, g)
{
	pic_height = default_pic_height;
	src_filenames.clear();
	colors.clear();
	plot_type = default_plot_type;
	rangelow = rangehigh = 0;
	signal_width = 0;
	zero_line = default_zero_line;
	always_include_zero = default_always_include_zero;
	max_draw_line_distance = 0;
	count_window = 0;
}

bool display_signal::load_from_file(string file_name)
{
	display_track::load_from_file(file_name);
	pic_height = ReadIni(file_name, name + "/pic_height", default_pic_height);
	rangelow = ReadIni(file_name, name + "/range_low", 0);
	rangehigh = ReadIni(file_name, name + "/range_high", 0);
	signal_width = ReadIni(file_name, name + "/signal_width", 0);
	plot_type = ReadIni(file_name, name + "/plot_type", wxS(
		default_plot_type));
	string src_filename = ReadIni(file_name, name + "/src_filename", wxString(
		"")).c_str();
	src_filenames = string_tokenize(src_filename, ",");
	string color = ReadIni(file_name, name + "/color", wxString("")).c_str();
	colors = string_tokenize(color, ",", default_zero_line);
	zero_line = ReadIni(file_name, name + "/zero_line", default_zero_line);
	always_include_zero = ReadIni(file_name, name + "/always_include_zero",
		default_always_include_zero);
	max_draw_line_distance = ReadIni(file_name, name
		+ "/max_draw_line_distance", 0);
	count_window = ReadIni(file_name, name + "/count_window", 0);
	if (title == "" && (src_filenames.size() > 0))
	{
		title = get_file_name(src_filenames[0]);
	}
	return true;
}

bool display_signal::update_params()
{
	if (!display_track::update_params())
		return false;
	if (req->params_.count("update_track") > 0)
	{
		int i;
		vector<string> old_src_filenames = src_filenames;
		vector<string> old_colors = colors;
		src_filenames.clear();
		colors.clear();
		for (i = 1; i <= 5; i++)
		{
			string src_filename = req->params_[string("src_filename")
				+ int2str(i)];
			if (src_filename != "")
			{
				src_filenames.push_back(src_filename);
				string color = req->params_[string("color") + int2str(i)];
				if (i <= (int) old_colors.size() && color == "")
					colors.push_back(old_colors[i - 1]);
				else
					colors.push_back(color);
			}
		}
		if (src_filenames.size() > 0) {
			for (i = 5; i < (int) old_src_filenames.size(); i++) {
				src_filenames.push_back(old_src_filenames[i]);
			}
		} else {
			src_filenames = old_src_filenames;
		}
		for (i = 5; i < (int) old_colors.size(); i++)
		{
			colors.push_back(old_colors[i]);
		}
		if (is_int(req->params_["track_height"]) && str2int(
			req->params_["track_height"]) >= 10 && str2int(
			req->params_["track_height"]) <= 4000)
		{
			pic_height = str2int(req->params_["track_height"]);
		}
		plot_type = req->params_["plot_type"];
		if (is_num(req->params_["range_low"]))
		{
			rangelow = str2double(req->params_["range_low"]);
		}
		if (is_num(req->params_["range_high"]))
		{
			rangehigh = str2double(req->params_["range_high"]);
		}
		if (is_num(req->params_["signal_width"]) && str2double(
			req->params_["signal_width"]) >= -100 && str2double(
			req->params_["signal_width"]) <= 1000000)
		{
			signal_width = str2double(req->params_["signal_width"]);
		}
		zero_line = (req->params_.count("zero_line") > 0);
		always_include_zero = (req->params_.count("always_include_zero") > 0);
		if (is_num(req->params_["max_draw_line_distance"]) && str2double(
			req->params_["max_draw_line_distance"]) >= 0 && str2double(
			req->params_["max_draw_line_distance"]) <= 1000000)
		{
			max_draw_line_distance = str2double(
				req->params_["max_draw_line_distance"]);
		}
		if (is_int(req->params_["count_window"]) && str2int(
			req->params_["count_window"]) >= 0 && str2int(
			req->params_["count_window"]) <= 100000)
		{
			count_window = str2int(req->params_["count_window"]);
		}
		if (title == "" && (src_filenames.size() > 0))
			title = get_file_name(src_filenames[0]);
	}
	else if (req->params_.count("update_tracks") > 0)
	{
		if (req->params_["track_height"] != "")
		{
			if (is_int(req->params_["track_height"]) && str2int(
				req->params_["track_height"]) >= 10 && str2int(
				req->params_["track_height"]) <= 4000)
			{
				pic_height = str2int(req->params_["track_height"]);
			}
		}
		if (req->params_["range_low"] != "")
		{
			if (is_num(req->params_["range_low"]))
			{
				rangelow = str2double(req->params_["range_low"]);
			}
		}
		if (req->params_["range_high"] != "")
		{
			if (is_num(req->params_["range_high"]))
			{
				rangehigh = str2double(req->params_["range_high"]);
			}
		}
		if (req->params_["signal_width"] != "")
		{
			if (is_num(req->params_["signal_width"]) && str2double(
				req->params_["signal_width"]) >= -100 && str2double(
				req->params_["signal_width"]) <= 1000000)
			{
				signal_width = str2double(req->params_["signal_width"]);
			}
		}
	}
	else
		return false;
	return true;
}

bool display_signal::write_to_file(string file_name)
{
	display_track::write_to_file(file_name);
	WriteIni(file_name, name + "/type", "signal", true);
	WriteIni(file_name, name + "/pic_height", pic_height, pic_height
		!= default_pic_height);
	WriteIni(file_name, name + "/range_low", rangelow, rangelow != 0);
	WriteIni(file_name, name + "/range_high", rangehigh, rangehigh != 0);
	WriteIni(file_name, name + "/signal_width", signal_width, signal_width != 0);
	WriteIni(file_name, name + "/plot_type", plot_type, plot_type
		!= default_plot_type);
	WriteIni(file_name, name + "/zero_line", zero_line, zero_line
		!= default_zero_line);
	WriteIni(file_name, name + "/always_include_zero", always_include_zero,
		always_include_zero != default_always_include_zero);
	WriteIni(file_name, name + "/max_draw_line_distance",
		max_draw_line_distance, max_draw_line_distance != 0);
	WriteIni(file_name, name + "/count_window", count_window, count_window != 0);
	string src_filename = "";
	for (int i = 0; i < (int) src_filenames.size(); i++)
	{
		src_filename = src_filename + src_filenames[i];
		if (i < (int) src_filenames.size() - 1)
			src_filename = src_filename + ",";
	}
	WriteIni(file_name, name + "/src_filename", src_filename, src_filename
		!= "");
	string color = "";
	for (int i = 0; i < (int) colors.size(); i++)
	{
		color = color + colors[i];
		if (i < (int) colors.size() - 1)
			color = color + ",";
	}
	WriteIni(file_name, name + "/color", color, color != "");
	return true;
}

string display_signal::get_configure_html()
{
	html_formater my_html_formater;
	my_html_formater.load_from_template_file(template_path
		+ "signal_track_config.html");
	int i, j;
	for (i = 0; i < 5; i++)
	{
		if (i < (int) src_filenames.size())
			my_html_formater.replace_keyword(string("$SRC_FILENAME") + int2str(
			i + 1) + "$", src_filenames[i]);
		else
			my_html_formater.replace_keyword(string("$SRC_FILENAME") + int2str(
			i + 1) + "$", "");
	}
	for (i = 0; i < 5; i++)
	{
		for (j = 0; j < 8; j++)
			if (i < (int) colors.size() && colors[i] == def_colors[j])
				my_html_formater.replace_keyword(string("$COLOR") + int2str(i
				+ 1) + "_" + toupper(def_colors[j]) + "$", "selected");
			else
				my_html_formater.replace_keyword(string("$COLOR") + int2str(i
				+ 1) + "_" + toupper(def_colors[j]) + "$", "");
	}
	my_html_formater.replace_keyword("$TRACK_HEIGHT$", int2str(pic_height));
	my_html_formater.replace_keyword("$RANGE_LOW$", double2str(rangelow));
	my_html_formater.replace_keyword("$RANGE_HIGH$", double2str(rangehigh));
	my_html_formater.replace_keyword("$SIGNAL_WIDTH$", double2str(signal_width));
	my_html_formater.replace_keyword("$PLOT_TYPE_BAR$",
		plot_type == "bar" ? "checked" : "");
	my_html_formater.replace_keyword("$PLOT_TYPE_DOT$",
		plot_type == "dot" ? "checked" : "");
	my_html_formater.replace_keyword("$PLOT_TYPE_CIRCLE$", plot_type
		== "circle" ? "checked" : "");
	my_html_formater.replace_keyword("$PLOT_TYPE_LINE$",
		plot_type == "line" ? "checked" : "");
	my_html_formater.replace_keyword("$PLOT_TYPE_HEATMAP$", plot_type
		== "heatmap" ? "checked" : "");
	my_html_formater.replace_keyword("$ZERO_LINE$", zero_line ? " checked" : "");
	my_html_formater.replace_keyword("$ALWAYS_INCLUDE_ZERO$",
		always_include_zero ? " checked" : "");
	my_html_formater.replace_keyword("$MAX_DRAW_LINE_DISTANCE$", double2str(
		max_draw_line_distance));
	my_html_formater.replace_keyword("$COUNT_WINDOW$", int2str(count_window));
	string result = my_html_formater.buf;
	my_html_formater.buf = display_track::get_configure_html();
	my_html_formater.replace_keyword("$TRACK_CONTENTS$", result);
	my_html_formater.replace_keyword("$TRACK_TYPE$", "signal");
	return my_html_formater.buf;
}

bool display_signal::generate_pic_file(bool get_intervals)
{
	if (!display_track::generate_pic_file(get_intervals))
		return false;
	/*	string command_line = string("\"") + module_path + "draw_figure.exe\" signal \"" + temp_path + pic_filename + "\" \"" + src_filename + "\" /region:" + genome->region + " /size:" + int2str(genome->pic_width) + "x" + int2str(pic_height) + " /axis:";
	command_line += (top_axis?"1":"0");
	command_line += (bottom_axis?"1":"0");
	command_line += (genome->left_axis?"1":"0");
	command_line += (genome->right_axis?"1":"0");
	call_external(command_line);*/

	draw_bar my_draw;
	my_draw.intervals = intervals;
	my_draw.bar_filenames = src_filenames;
	int i, j, k;
	my_draw.colors.clear();
	for (i = 0; i < (int) src_filenames.size(); i++)
	{
		bool set = false;
		if (i < (int) colors.size())
		{
			for (j = 0; j < 8; j++)
			{
				if (def_colors[j] == colors[i])
				{
					my_draw.colors.push_back(def_colorrefs[j]);
					set = true;
					break;
				}
			}
		}
		if (!set && i < (int) colors.size() && colors[i] != "")
		{
			PICOLORREF color;
			sscanf(colors[i].c_str(), "%x", &color);
			my_draw.colors.push_back(color);
			set = true;
		}
		if (!set)
		{
			for (j = 0; j < 8; j++)
			{
				bool chosen = false;
				for (k = 0; k < (int) colors.size(); k++)
				{
					if (def_colors[j] == colors[k])
					{
						chosen = true;
						break;
					}
				}
				if (!chosen)
				{
					my_draw.colors.push_back(def_colorrefs[j]);
					//if (i < (int)colors.size()) colors[i] = def_colors[j];
					set = true;
					break;
				}
			}
		}
		if (!set)
			my_draw.colors.push_back(0);
	}

	if (!parse_region(genome->region, my_draw.chr, my_draw.startpos,
		my_draw.endpos))
	{
		my_draw.error_msg = "bad region.";
	}
	my_draw.size.cx = genome->pic_width;
	my_draw.box_margin = genome->pic_margin / 3;
	my_draw.data_margin = genome->pic_margin * 2 / 3;
	my_draw.font_size = genome->font_size;
	my_draw.size.cy = pic_height;
	my_draw.left_axis = genome->left_axis;
	my_draw.right_axis = genome->right_axis;
	my_draw.zero_line = zero_line;
	my_draw.always_include_zero = always_include_zero;
	my_draw.max_draw_line_distance = max_draw_line_distance;
	if (count_window > 0)
	{
		my_draw.do_window_count = true;
		my_draw.window_left = (double) count_window / 2.0;
		my_draw.window_right = (double) count_window / 2.0;
	}
	if (genome->grid == "off")
	{
		my_draw.v_grids = false;
	}
	else if (genome->grid == "gray")
	{
		my_draw.custom_grid_color = true;
		my_draw.shaded_background = false;
	}
	else if (genome->grid == "gray_shaded")
	{
		my_draw.custom_grid_color = true;
		my_draw.shaded_background = true;
	}
	else if (genome->grid == "color_shaded")
	{
		my_draw.custom_grid_color = false;
		my_draw.shaded_background = true;
	}
	else if (genome->grid == "color")
	{
		my_draw.custom_grid_color = false;
		my_draw.shaded_background = false;
	}
	my_draw.top_axis = top_axis;
	my_draw.bottom_axis = bottom_axis;
	my_draw.fast_draw = fast_draw;
	my_draw.rangehigh = rangehigh;
	my_draw.rangelow = rangelow;
	my_draw.signal_width = signal_width;
	if (plot_type == "bar")
		my_draw.plot_type = PLOT_TYPE_BAR;
	else if (plot_type == "dot")
		my_draw.plot_type = PLOT_TYPE_DOT;
	else if (plot_type == "circle")
		my_draw.plot_type = PLOT_TYPE_CIRCLE;
	else if (plot_type == "line")
		my_draw.plot_type = PLOT_TYPE_LINE;
	else if (plot_type == "heatmap")
		my_draw.plot_type = PLOT_TYPE_HEATMAP;
	else
		return false;
	my_draw.load_data();
	my_draw.prepare_data();
	if (get_intervals)
	{
		my_draw.get_intervals();
		intervals = my_draw.intervals;
	}
	else
	{
		my_draw.drawfile(temp_path + client_ip + pic_filename);
		display_track::generate_hrefs(my_draw.map_rects, my_draw.map_strings);
	}

	return true;
}


