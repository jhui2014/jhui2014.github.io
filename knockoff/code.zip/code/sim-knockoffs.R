rm(list = ls(all.names = TRUE))

### Load library and source files 
library(MASS)
library(knockoff)
library(mboost)
library(survival)
library(glmnet)

source("selection.R")
source("sis.R")
source("cumsum_rev.R")
source("sis.surv.R")
source("ddloglik.R")
source("mboost.varimp.R")
source("lasso_coef_diff.R")

beta.sample <- function(p, k, amplitude){
    # beta's
    nonzero = sample(p, k)
    beta = rep(0,p)
    beta[nonzero] = amplitude * sample(c(1,-1), k, replace = T)
    return(beta)
}

X.sample <- function(n, p, rho) {
    ### Design matrix X
    ### AR(1) Covariance matrix
    mu = rep(0,p)
    Sigma = diag(p)
    for (a in 1:p){for(b in 1:p) Sigma[a,b]=rho^abs(a-b)}
    return(mvrnorm(n, mu=rep(0,p), Sigma=Sigma))
}

y.sample <- function(method = c("linear","nonlinear","survival"), X, beta) {
    n = nrow(X)
    if (method == "linear") {
        ### Response Y---linear in beta
        return(X %*% beta + rnorm(n))
    } else if (method == "nonlinear") {
        ### Response Y---nonlinear in X 
        return(X^2 %*% beta + rnorm(n))
    } else if (method == "survival") {
        ### Response Y---nonlinear in X 
        lambdaT = .002 # baseline hazard
        lambdaC = .004  # hazard of censoring
        T1 = rweibull(n, shape=1, scale=lambdaT*exp(X^2 %*% beta))   # true event time
        C = rweibull(n, shape=1, scale=lambdaC)   #censoring time
        time = pmin(T1,C)  #observed time is min of censored and true
        event = (time==T1)   # set to 1 if event is observed
        y = Surv(time, event)
    } else {
        stop("error: unknown method")
    }
}

fdp <- function(selected, beta) {
    sum(beta[selected] == 0) / max(1, length(selected))
}

power <- function(selected, beta) {
    sum(beta[selected] != 0) / sum(beta != 0)
}

make.plot = function(file.name, data, pch, col, lty, x, xlab, ylab, hline, q, legend, legend.texts, ylim) {
    ### Generate FDP plots
    pdf(file.name, width = 5, height = 5)
    par(mar=c(4.1,4.1,1.1,1.1))
    for (i in 1:length(data)) {
        x1 = jitter(x, amount = 0.005)
        sd = pmax(1e-2, apply(data[[i]], 1, sd)/sqrt(ncol(data[[i]])))
        if (i == 1) {
            plot(x1, rowMeans(data[[i]]), type="b", pch=pch[i], col=col[i], lty=lty[i], xlab=xlab, ylab=ylab, ylim = ylim)
        } else {
            lines(x1, rowMeans(data[[i]]), type="b", pch=pch[i], col=col[i], lty=lty[i], xlab=xlab, ylab=ylab)
        }
        arrows(x1, rowMeans(data[[i]])-sd, x1, rowMeans(data[[i]])+sd, code=3, length=0.02, angle = 90, col=col[i])
    }
    if (hline) {
        abline(h=q, lty=3)
    }
    if (legend != "") {
        legend(legend, legend.texts, col=col, pch=pch, lty=lty)
    }
    dev.off()
}

sim.knockoffs = function(method = "linear", rand.seed = 12345, 
                         n = 300, p = 2000, k = 10, amplitude = seq(0.2,1,0.2), q = 0.2, nIterations = 30, 
                         rho = 0.3, legend.fig = "FDP", legend = "topleft") {
    set.seed(rand.seed)
    start.time = Sys.time()
    
    temp.list = list()
    for (i in 1:3) {
        temp.list = c(temp.list, list(matrix(0, length(amplitude), nIterations)))
    }
    fdp.list = temp.list
    power.list = temp.list
    
    print(method)
    
    for (amp in 1:length(amplitude)){
        print(amplitude[amp])
        for(iter in 1:nIterations){
            print(iter)
            ### simulate data
            beta = beta.sample(p = p, k = k, amplitude = amplitude[amp])
            X = X.sample(n = n, p = p, rho = rho)
            y = y.sample(method = method, X = X, beta = beta)
            
            if (method == "linear" || method == "nonlinear") {
                #knock + mboost
                selected_mboost = selection(X, y, q = q, knockoff.method = "asdp")
                
                #knockoff + LCD
                selected_LCD = selection(X, y, q = q, stat="LCD",knockoff.method = "asdp")
                
                #lasso + CV
                result_lasso_CV = cv.glmnet(X, y, standardize=F, family="gaussian", alpha=1, nfolds=5, intercept=F)
                myCoefs = coef(result_lasso_CV, s="lambda.min")
                selected_lasso_CV = which(myCoefs != 0)-1
            } else if (method == "survival") {
                #knock + mboost
                selected_mboost=selection(X, y, q = q, family = CoxPH(), knockoff.method = "asdp")
                
                #knockoff + LCD
                selected_LCD=selection(X, y, q = q, family = CoxPH(), stat="LCD",knockoff.method = "asdp")
                
                #lasso + CV
                result_lasso_CV=cv.glmnet(X, y, standardize=F, family="cox", alpha=1, nfolds=5)
                myCoefs = coef(result_lasso_CV, s="lambda.min")
                selected_lasso_CV = which(myCoefs != 0)
            } else {
                stop("error: unknown method")
            }
            
            selected.list = list(selected_mboost, selected_LCD, selected_lasso_CV)
            for (i in 1:3) {
                fdp.list[[i]][amp, iter] = fdp(selected = selected.list[[i]], beta = beta)
                power.list[[i]][amp, iter] = power(selected = selected.list[[i]], beta = beta)
            }
        }
    }
    
    end.time = Sys.time()
    time.taken = end.time - start.time
    print(time.taken)
    
    ### Generate FDP plots
    make.plot(file.name = paste("Figure-FDP-", method, ".pdf", sep=""), data = fdp.list, pch = c(0,2,16), 
              col = c("red","black","blue"), lty = c(1,2,4), x = amplitude, xlab = "Amplitude", ylab = "FDP", 
              ylim = c(0,1), hline = T, q = q, legend = ifelse(legend.fig == "FDP", legend, ""), 
              legend.texts = c("Knockoff + mboost","Knockoff + LCD","Lasso + CV"))
    
    ### Generate power plot
    make.plot(file.name = paste("Figure-Power-", method, ".pdf", sep=""), data = power.list, pch = c(0,2,16), 
              col = c("red","black","blue"), lty = c(1,2,4), x = amplitude, xlab = "Amplitude", ylab = "Power", 
              ylim = c(0,1), hline = F, q = q, legend = ifelse(legend.fig == "power", legend, ""), 
              legend.texts = c("Knockoff + mboost","Knockoff + LCD","Lasso + CV"))
    
    ### save files 
    save.image(file = paste("sim-knockoffs-", method, ".RData", sep=""))
}

sim.knockoffs(method = "linear", legend.fig = "power", legend = "bottomright")
sim.knockoffs(method = "nonlinear", legend.fig = "FDP", legend = "topright")
sim.knockoffs(method = "survival", legend.fig = "power", legend = "topright")
