function [CI, BOUND, MEAN] = weighted_hist(X, Y, draw_plot)

[xx, I] = sort(X);
yy = Y(I);
temp_sum = 0;
for i=1:length(Y)
    temp_sum = temp_sum + yy(i);
    yy(i) = temp_sum;
end

BOUND = [xx(min(find(yy>.001))) - 1e-6, xx(min(find(yy>.999))) + 1e-6];
len = BOUND(2) - BOUND(1);
BOUND(1) = max(0, BOUND(1) - len / 10);
BOUND(2) = BOUND(2) + len / 10;
CI = [xx(min(find(yy>.025))), xx(min(find(yy>.975)))];
MEAN = X*Y';

if draw_plot
    N_MESH = 20;

    XX = linspace(BOUND(1), BOUND(2), N_MESH + 1);
    YY = zeros(1,N_MESH + 1);
    for k=1:length(Y)
        index = round((X(k) - BOUND(1)) * N_MESH / (BOUND(2)-BOUND(1))) + 1;
        index = max(1, index);
        index = min(N_MESH+1, index);
        YY(index) = YY(index) + Y(k);
    end
    bar(XX, YY, 1);
    hold on
    plot([CI(1), CI(1)], [0, max(YY)], 'r-.')
    plot([CI(2), CI(2)], [0, max(YY)], 'r-.')
end