library(MASS)

# This is the main function. "counts" is the input matrix m*n, where m is the number
# of genes and n is the number of samples. "group" is the group vector. For example, 
# if there are 5 genes, two groups and 4 samples in each group, then "counts" would 
# be a 5*8 matrix and "group" is a two-level factor, for example 
# as.factor(c(0,0,0,0,1,1,1,1)). "take.log" is the indicator of 
# whether take log on the counts. If "take.log" is true, then "log.add" is added to 
# the counts input to handle zero counts. If "three" is true, the "group" should be 
# a three-level factor, for example as.factor(c(0,0,0,0,1,1,1,1,2,2,2,2)).

fit_mlr.pfun <- function(counts, X, sigma_sq = NULL, sig_leval = 0.01, log.add = 1) {
  
  if (min(counts)==0) 
    Y <- log(counts + log.add) # log.add may take 0 after more genes are filtered out based on Pearson correlation test
  else
    Y <- log(counts)
  
  m <- nrow(Y)
  n <- ncol(Y)
  
  if (is.null(sigma_sq))
  {
    # 1. Estimate noise variance
    sigma_sq <- noise_variance_esti.mlr(X, Y, 0.000001)
  }
  
  
  # 2. Center X to zero column mean
  X_tilde <- scale(X, center = TRUE, scale = FALSE)
  
  # Center Y to have zero means across both rows and columns
  mean_y_over_j <- rowMeans(Y)
  # weighted_mean_y_over_i <- colSums(diag(1 / sigma_sq) %*% Y) / sum(1 / sigma_sq)
  weighted_mean_y_over_i <- colSums((1 / sigma_sq) * Y) / sum(1 / sigma_sq)
  weighted_mean_y_over_ij <- mean(weighted_mean_y_over_i)
  Y_tilde <- Y - mean_y_over_j - rep(weighted_mean_y_over_i,  each = m) + weighted_mean_y_over_ij
  
  # 3. Tuning parameter selection
  p <- ncol(X_tilde)
  alpha <- p / 2 * qchisq(1-sig_leval, p)
  
  # 4. p-dimensional search
  if (p==1) {
    min.delta <- min.G.prime(X_tilde, Y_tilde, alpha, sigma_sq)
    # lower <- min(- Y_tilde %*% X_tilde / sum(X_tilde^2) - sqrt(2*sigma_sq*alpha/sum(X_tilde^2)))
    # upper <- max(- Y_tilde %*% X_tilde / sum(X_tilde^2) + sqrt(2*sigma_sq*alpha/sum(X_tilde^2)))
    # # min.delta <- optim(rep(0,p), G.fun, X = X_tilde, Y = Y_tilde, alpha = alpha, sigma_sq = sigma_sq, method = "Brent", lower = lower, upper = upper)$par
    # min.delta <- optimize(G.fun, X = X_tilde, Y = Y_tilde, alpha = alpha, sigma_sq = sigma_sq, lower = lower, upper = upper)$minimum
  } else {
    # When p>=2, the optim function may return a local solution instead of a global one, 
    # and exhaustive search on a multidimensional grid may have to be used instead for obtaining accurate global solution.
    min.delta <- optim(rep(0,p), G.fun, X = X_tilde, Y = Y_tilde, alpha = alpha, sigma_sq = sigma_sq, method = "Nelder-Mead")$par
  }
  
  B_esti <- t(solve(t(X_tilde) %*% X_tilde) %*% t(X_tilde) %*% t(Y_tilde) + min.delta)
  B_esti[colSums((X_tilde %*% t(B_esti))^2) < 2*sigma_sq*alpha, ] <- 0
  
  mean_beta_esti <- wmean(B_esti, 1 / sigma_sq)
  beta0_esti <- mean_y_over_j + weighted_mean_y_over_i[1] - weighted_mean_y_over_ij - sum(X_tilde[1, ] * mean_beta_esti)
  d_esti <- (weighted_mean_y_over_i - weighted_mean_y_over_i[1]) - as.numeric((X_tilde - rep(X_tilde[1, ], each = n)) %*% mean_beta_esti)
  
  # 5. Recover the original parameter space:
  beta0_esti <- beta0_esti - as.numeric(B_esti %*% as.matrix(colMeans(X)))
  
  # 6. Calculate p values and adjusted p values
  p.value = rep(0, m)
  
  for (i in 1:m) {
    yi <- Y[i, ] - d_esti
    fit <- lm(yi ~ X)
    p.value[i] <- anova(fit)[1, 5]
  }
  
  p.adj <- p.adjust(p.value, "BH")
  
  result <- cbind(pval = p.value, padj = p.adj, B = B_esti)
  rownames(result) <- rownames(counts) # need to complete
  colnames(result) <- c("pval", "padj", paste('beta_', 1:p, sep = ""))
  
  return (list(result = result,  d = d_esti))
  
}


noise_variance_esti.mlr <- function (X, Y, epsilon = 1e-3, MAX_ITER = 10000, shrinkage = TRUE) {
  
  m <- nrow(Y)
  n <- ncol(Y)
  p <- ncol(X)
  
  # Center X to zero column mean
  X_tilde <- scale(X, center = TRUE, scale = FALSE)
  
  sigma_sq <- rep(1, m)
  B <- matrix(0, m, p)
  delta_0 <- wmean(B, 1 / sigma_sq)
  
  for (k in 1:MAX_ITER) {
    
    mean_y_over_j <- rowMeans(Y)
    # weighted_mean_y_over_i <- colSums(diag(1 / sigma_sq) %*% Y) / sum(1 / sigma_sq)
    weighted_mean_y_over_i <- colSums((1 / sigma_sq) * Y) / sum(1 / sigma_sq)
    weighted_mean_y_over_ij <- mean(weighted_mean_y_over_i)
    Y_tilde <- Y - mean_y_over_j - rep(weighted_mean_y_over_i, each = m) + weighted_mean_y_over_ij
    
    # Compute B
    for (i in 1:m) {
      B[i, ] <- (Y_tilde[i, ] %*% X_tilde) %*% solve(t(X_tilde) %*% X_tilde) + delta_0
    }
    
    # Compute noise variance
    sigma_sq_old <- sigma_sq
    sigma_sq <- 1 / (n - p - 1) * rowSums((Y_tilde - sweep(B, 2, delta_0) %*% t(X_tilde))^2)
    
    # Compute weighted mean of B
    delta_0 <- wmean(B, 1 / sigma_sq)
    
    if (sqrt(sum((sigma_sq - sigma_sq_old)^2)) / sqrt(sum(sigma_sq_old^2)) < epsilon)
      break
  }
  
  if (shrinkage) {
    sigma_sq.mean <- mean(sigma_sq)
    
    w <- (2 / (n - p - 1)) / (1 + 2 / (n - p - 1)) * (m - 1) * (1 / m + sigma_sq.mean^2 / sum((sigma_sq - sigma_sq.mean)^2))
    if (w > 1) w <- 1
    
    sigma_sq.new <- (1 - w) * sigma_sq + w * sigma_sq.mean
    
    return(sigma_sq.new)}
  
  else
    return(sigma_sq)
  
}


# wmean <- function(B, weight) {
#   delta_0 <- colSums(diag(weight) %*% B) / sum(weight)
#   # delta_0 <- colSums(B / sigma_sq) / sum(1 / sigma_sq)
#   return(delta_0)
# }

wmean <- function(B, weight){
  delta_0 <- colSums(weight * B) / sum(weight)
  return(delta_0)
}

#G function
G.fun <- function(delta, X, Y, alpha, sigma_sq = 1) {
  sum(pmin(1/2/sigma_sq*colSums((X %*% (solve(t(X) %*% X) %*% t(X) %*% t(Y)+ delta))^2), alpha))
}

# For two-group compariosn
# sequential scanning algorithm for min.delta using L0 distance with quadratic kernel and variable lambda and sigma_sq
min.G.prime <- function(x_tilde, Y_tilde, alpha = 0, sigma_sq = 1) {
  xdoty <- -Y_tilde %*% x_tilde / sum(x_tilde^2)
  lambda <- sqrt(2*sigma_sq*alpha / sum(x_tilde^2))
  m <- length(xdoty)
  if (length(lambda)==1) lambda <- rep(lambda, m)
  if (length(sigma_sq)==1) sigma_sq <- rep(sigma_sq, m)
  weights <- 1/sigma_sq
  xl <- xdoty - lambda
  xu <- xdoty + lambda
  end.pts <- c(xl, xu)
  pts.idx <- rep(1:m, 2)
  s <- sort(end.pts, index.return=T)
  end.pts <- s$x
  pts.idx <- pts.idx[s$ix]
  included <- rep(F, m)
  w.sum <- 0
  wsum.xdoty <- 0
  wsum.xdoty2 <- 0
  wsum.lambda2 <- 0
  min.delta <- 0
  min.f <- Inf
  np <- 0
  for (i in 1:(2*m-1)) {
    p <- pts.idx[i]
    if (included[p]) {
      np <- np - 1
      included[p] <- F
      w.sum <- w.sum - weights[p]
      wsum.xdoty <- wsum.xdoty - weights[p] * xdoty[p]
      wsum.xdoty2 <- wsum.xdoty2 - weights[p] * xdoty[p]^2
      wsum.lambda2 <- wsum.lambda2 - weights[p] * lambda[p]^2
    } else {
      np <- np + 1
      included[p] <- T
      w.sum <- w.sum + weights[p]
      wsum.xdoty <- wsum.xdoty + weights[p] * xdoty[p]
      wsum.xdoty2 <- wsum.xdoty2 + weights[p] * xdoty[p]^2
      wsum.lambda2 <- wsum.lambda2 + weights[p] * lambda[p]^2
    }
    if (np > 0) {
      delta <- wsum.xdoty / w.sum
      if (delta >= end.pts[i] && delta <= end.pts[i+1]) {
        f <- wsum.xdoty2 - w.sum * delta^2 - wsum.lambda2 
        if (f < min.f) {
          min.f <- f
          min.delta <- delta
        }        
      }
    }
  }
  min.delta
}