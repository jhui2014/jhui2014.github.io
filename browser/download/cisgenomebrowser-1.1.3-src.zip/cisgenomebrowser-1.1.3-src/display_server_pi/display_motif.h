#ifndef _DISPLAY_MOTIF_
#define _DISPLAY_MOTIF_

#include "display_type.h"
struct http_request;

class display_motif: public display_type
{
public:
	bool multiple_motifs;
	string src_filename;
	string pic_filename;
	display_motif();
	display_motif(http_request* r);
	virtual bool load_from_file(string file_name);
	virtual bool update_params();
	virtual bool write_to_file(string file_name);
	virtual string get_html();
};
#endif