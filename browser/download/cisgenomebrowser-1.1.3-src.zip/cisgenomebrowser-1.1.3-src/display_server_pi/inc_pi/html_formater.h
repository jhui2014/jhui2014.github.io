/*
file_formater.h - Header file for generic html formater
written by JIANG Hui,
Institute for Computational and Mathematical Engineering, Stanford University
May, 2007 -
*/

#ifndef HTML_FORMATER_H
///Define this macro to prevent from including this header file more than once.
#define HTML_FORMATER_H

#include "file_formater.h"
#include "UserDefinedType.h"

inline string link_html(const string url, const string text) {
	string result = "";
	result += "<a href=\"";
	result += url;
	result += "\">";
	result += text;
	result += "</a>";
	return result;
}

inline string error_html(const string err_msg){
	string result = "";
	result += "<h1>CisGenome Browser - Error: ";
	result += err_msg;
	result += "</h1>";
	return result;
}

inline string redirect_html(const string url){
	string result = "";
	result += "<html><head><title>CisGenome Browser</title><META HTTP-EQUIV=\"Refresh\" CONTENT=\"0; URL=";
	result += url;
	result += "\"></head><body>If your browser doesn't automatically redirect to its new location, click <a href=\"";
	result += url;
	result += "\">here</a></body></html>";
	return result;
}

inline string map_html(const string map, vector<PIRect> rects, vector<string> hrefs, vector<string> titles, vector<string> onclicks) {
	string result = "";
	result += string("<map name=") + map + ">\n";
	for (int i = 0; i < (int)rects.size(); i++) {
		result += string("<area shape=rect coords=\"") + int2str(rects[i].left) + "," + int2str(rects[i].top) + "," + int2str(rects[i].right) + "," + int2str(rects[i].bottom) + "\"";
		if ((int)hrefs.size() >= i+1 && hrefs[i] != "") result += string(" href=\"") + hrefs[i] + "\"";
		if ((int)titles.size() >= i+1 && titles[i] != "") result += " title=\"" + titles[i] + "\"";
		if ((int)onclicks.size() >= i+1 && onclicks[i] != "") result += " onclick=\"" + onclicks[i] + "\"";
		result += ">\n";
	}
	result += "</map>\n";
	return result;
}

inline string image_html(const string pic_filename, const string map = ""){
	string result = "";
	result += "<image src=\"";
	result += pic_filename;
	result += "\" border=0";
	if (map != "") {
		result += " usemap=#";
		result += map;
	}
	result += ">";
	return result;
}

inline string table_html(vector<vector<string> > &texts, int border = 1){
	string result = "";
	result += "<table cellspacing=\"0\" cellpadding=\"0\" border=\"";
	result += int2str(border);
	result += "\">\n";
	int i, j;
	for (i = 0; i < (int)texts.size(); i++) {
		result += "<tr>\n";
		for (j = 0; j < (int)texts[i].size(); j++) {
			result += "<td>";
			result += texts[i][j];
			result += "</td>\n";
		}
		result += "</tr>\n";
	}
	result += "</table>\n";
	return result;
}

inline string radio_group_html(const string name, const string values, const string texts){
	string result = "";
	result += "<input type=\"radio\" name=\"";
	result += name;
	result += "\" value=\"";
	result += values;
	result += "\">";
	result += texts;
	result += "\n";
	return result;
}

inline string check_box_html(const string name, const string text = "", const string value = ""){
	string result = "";
	result += "<INPUT TYPE=CHECKBOX NAME=\"";
	result += name;
	if (value != "") {
		result += "\" VALUE=\"";
		result += value;
	}
	result += "\">";
	result += text;
	return result;
}

inline string drop_down_list_html(const string name, vector<string> &values, vector<string> &texts){
	string result = "";
	result += "<SELECT NAME=\""+name+"\">\n";
	int i;
	for (i = 0; i < (int)values.size(); i++) {
		result += "<OPTION VALUE=\""+values[i]+"\">"+texts[i] +"\n";
	}
	result += "</SELECT>\n";
	return result;
}

class html_formater:public file_formater{
public:
	html_formater();
	~html_formater();
};

inline html_formater::html_formater(){
}

inline html_formater::~html_formater(){
}

#endif //HTML_FORMATER_H
