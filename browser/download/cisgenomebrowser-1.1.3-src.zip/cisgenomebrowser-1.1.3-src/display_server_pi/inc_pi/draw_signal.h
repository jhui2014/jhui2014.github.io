#ifndef DRAW_SIGNAL_H
#define DRAW_SIGNAL_H

#include "draw_axis.h"
#include "stl.h"
#include "colormap.h"
#include "UserDefinedType.h"

#define PLOT_TYPE_BAR 0
#define PLOT_TYPE_DOT 1
#define PLOT_TYPE_LINE 2
#define PLOT_TYPE_HEATMAP 3
#define PLOT_TYPE_CIRCLE 4

class draw_signal: public draw_axis
{
public:
	int plot_type; //0: bar; 1: dot; 2: line; 3: heatmap
	vector<vector<double> > positions;
	vector<vector<double> > widthes;
	vector<vector<double> > intensities;
	vector<PICOLORREF> colors;
	int bar_width;
	int dot_width;
	int heatmap_width;
	double max_draw_line_distance;
	bool always_include_zero;
	colormap cm;
	vector<string> legends;

	draw_signal();
	virtual bool prepare_data();
	virtual bool draw_contents(wxMemoryDC *pdc, const PIRect rect);
	virtual void get_intervals();
};

#endif //DRAW_SIGNAL_H
