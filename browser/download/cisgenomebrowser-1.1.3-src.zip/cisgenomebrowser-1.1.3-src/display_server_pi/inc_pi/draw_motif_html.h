#ifndef DRAW_MOTIF_HTML_H
#define DRAW_MOTIF_HTML_H

#include "draw_figure_support.h"

class draw_motif_html: public draw_figure_structure
{
public:
	string motif_filename;
	bool left_axis, right_axis, top_axis, bottom_axis;

	draw_motif_html();
	virtual string print_usage();
	virtual bool get_params(const vector<string> &params);
	virtual bool drawfile(const string pic_filename_prefix);
	bool get_html(const string pic_filename_prefix,
			const string link_filename_prefix, string &html);
};

#endif //DRAW_MOTIF_HTML_H
