#ifndef _DISPLAY_TYPE_
#define _DISPLAY_TYPE_

#include "inc_pi/stl.h"
#include "inc_pi/UserDefinedType.h"
class session;
struct http_request;

class display_type
{
public:
	session *s;
	http_request* req;
	vector<PIRect> rects;
	vector<string> hrefs;
	vector<string> titles;
	vector<string> onclicks;

	bool refresh;
	display_type();
	display_type(http_request* r);
	virtual ~display_type();
	virtual bool load_from_file(string file_name) = 0;
	virtual bool update_params() = 0;
	virtual bool write_to_file(string file_name) = 0;
	virtual void generate_hrefs(vector<PIRect> &map_rects,vector<string> &map_strings);
	virtual string get_html() = 0;
	virtual void cleanup();
};

#endif