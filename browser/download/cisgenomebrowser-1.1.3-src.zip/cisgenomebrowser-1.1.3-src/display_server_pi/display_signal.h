#ifndef _DISPLAY_SIGNAL_
#define _DISPLAY_SIGNAL_

#include "display_track.h"
struct http_request;

class display_signal: public display_track
{
public:
	int pic_height;
	vector<string> src_filenames;
	double rangelow, rangehigh;
	double signal_width;
	string plot_type;
	vector<string> colors;
	bool zero_line;
	bool always_include_zero;
	double max_draw_line_distance;
	int count_window;

	display_signal()
	{
	}
	display_signal(http_request* r, string track_name,
		display_genome *g);
	virtual bool load_from_file(string file_name);
	virtual bool update_params();
	virtual bool write_to_file(string file_name);
	virtual string get_configure_html();
	virtual bool generate_pic_file(bool get_intervals = false);
	virtual string type()
	{
		return "display_signal";
	}
};



#endif