#ifndef COLORMAP_H
#define COLORMAP_H

#include <windows.h>

#define COLOR_SYSTEM_BLACK_WHITE 0
#define COLOR_SYSTEM_WHITE_BLACK 1
#define COLOR_SYSTEM_GREEN_BLACK_RED 2

class colormap{
public:
	vector<double> values;
	vector<COLORREF> colors;

	colormap(){values.clear(); colors.clear();}
	void set_colorsystem(int cs, double minimum, double maximum, double median = 0){
		values.clear();
		colors.clear();
		if (cs == COLOR_SYSTEM_BLACK_WHITE) {
			values.push_back(minimum);
			values.push_back(maximum);
			colors.push_back(RGB(0,0,0));
			colors.push_back(RGB(255,255,255));
		} else if (cs == COLOR_SYSTEM_WHITE_BLACK) {
			values.push_back(minimum);
			values.push_back(maximum);			
			colors.push_back(RGB(255,255,255));
			colors.push_back(RGB(0,0,0));
		} else if (cs == COLOR_SYSTEM_GREEN_BLACK_RED) {
			if (median > maximum || median < minimum) median = (maximum + minimum) / 2;
			values.push_back(minimum);
			values.push_back(median);
			values.push_back(maximum);			
			colors.push_back(RGB(0,255,0));
			colors.push_back(RGB(0,0,0));
			colors.push_back(RGB(255,0,0));
		} else return;
	}

	COLORREF get_color(double d) {
		if (colors.size() != values.size()) return RGB(0,0,0);
		for (int i=0; i < (int)colors.size() - 1; i++) {
			if (d >= values[i] && d <= values[i + 1]) {
				int R0 = GetRValue(colors[i]);
				int G0 = GetGValue(colors[i]);
				int B0 = GetBValue(colors[i]);
				int R1 = GetRValue(colors[i+1]);
				int G1 = GetGValue(colors[i+1]);
				int B1 = GetBValue(colors[i+1]);
				int R2 = (int)((R0 * (values[i+1]-d) + R1 * (d-values[i])) / (values[i+1] - values[i]));
				if (R2 < 0) R2 = 0;
				if (R2 > 255) R2 = 255;
				int G2 = (int)((G0 * (values[i+1]-d) + G1 * (d-values[i])) / (values[i+1] - values[i]));
				if (G2 < 0) G2 = 0;
				if (G2 > 255) G2 = 255;
				int B2 = (int)((B0 * (values[i+1]-d) + B1 * (d-values[i])) / (values[i+1] - values[i]));
				if (B2 < 0) B2 = 0;
				if (B2 > 255) B2 = 255;
				return RGB(R2, G2, B2);
			}
		}
		if (d < values[0]) return colors[0];
		if (d > values[(int)values.size()-1]) return colors[(int)colors.size()-1];
		return RGB(0,0,0);
	}
};

COLORREF mean_color(COLORREF color1, COLORREF color2) {
	colormap mycolormap;
	mycolormap.colors.push_back(color1);
	mycolormap.colors.push_back(color2);
	mycolormap.values.push_back(0);
	mycolormap.values.push_back(1);
	return mycolormap.get_color(0.5);
}

#endif //COLORMAP_H
