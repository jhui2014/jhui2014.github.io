#solve for mu and d from matrix x with possibly unknown heteroscedastic variance, d[1] is always 0
solve.1group <- function(x, sigma = NULL){
  m = dim(x)[1]
  n = dim(x)[2]
  if (length(sigma)==1) sigma = rep(sigma, m)
  if (is.null(sigma)) {
    sigma2 = rep(1, m)
  } else {
    sigma2 = sigma^2
  }
  
  d = colSums((x-rep(x[,1],n))/rep(sigma2,n))/sum(1/sigma2)
  mu = rowMeans(x-rep(d,each=m))
  
  if (is.null(sigma)) {
    it = 0
    mat_it = 25
    while (it < mat_it) {
      it = it + 1
      old_res = x-rep(mu,n)-rep(d,each=m)
      sigma2 = rowSums(old_res^2)/(n-1)
      mu = rowMeans(x-rep(d,each=m))
      d = colSums((x-rep(mu,n))/rep(sigma2,n))/sum(1/sigma2)
      mu = mu + d[1]
      d = d - d[1]
      res = x-rep(mu,n)-rep(d,each=m)
      if (sum(abs(res-old_res))< 1e-6) {
        break
      }
    }
  }
  list(mu=mu,d=d,sigma=sqrt(sigma2))
}

#G' function for 2-d
G.prime <- function(mu1, mu2, d = 0, lambda = 0, sigma = 1) {
  sum(1/sigma^2*pmin((mu2-mu1-d)^2, lambda^2))
}

#G function
G.fun <- function(mu, n, d = 0, alpha = 0, sigma = 1) {
  m = dim(mu)[1]
  S = dim(mu)[2]
  nn = sum(n)
  if (length(d)==1) d = rep(d, S)
  mu = mu - rep(d, each=m)
  sum(pmin(1/2/sigma^2*(rowSums(rep(n,each=m)*mu^2) - 1/nn*rowSums(rep(n,each=m)*mu)^2), alpha))
}

# For two-group compariosn, grid search method. 
## calculate d that minimizes G'(d) in two groups
min.G.prime.grid<-function(mu1, mu2, lower, upper, lambda = 0, sigma = 1, ngrid = 1000){
  d=seq(lower,upper,length.out=ngrid)
  min.d = 0
  min.f = Inf
  for (i in 1:ngrid){
    f = G.prime(mu1,mu2,d=d[i],lambda=lambda,sigma=sigma)
    if (f < min.f) {
      min.f = f
      min.d = d[i]
    }
  }
  min.d
}

# For two-group compariosn
# sequential scanning algorithm for min.d using L0 distance with quadratic kernel and variable lambda and sigma
min.G.prime <- function(mu1, mu2, lambda = 0, sigma = 1) {
  x = mu2 - mu1
  m = length(x)
  if (length(lambda)==1) lambda = rep(lambda, m)
  if (length(sigma)==1) sigma = rep(sigma, m)
  weights = 1/sigma^2
  xl = x - lambda
  xu = x + lambda
  end.pts = c(xl, xu)
  pts.idx = rep(1:m, 2)
  s = sort(end.pts, index.return=T)
  end.pts = s$x
  pts.idx = pts.idx[s$ix]
  included = rep(F, m)
  w.sum = 0
  wx.sum = 0
  wx2.sum = 0
  wlambda2.sum = 0
  min.d = 0
  min.f = Inf
  np = 0
  for (i in 1:(2*m-1)) {
    p = pts.idx[i]
    if (included[p]) {
      np = np - 1
      included[p] = F
      w.sum = w.sum - weights[p]
      wx.sum = wx.sum - weights[p] * x[p]
      wx2.sum = wx2.sum - weights[p] * x[p]^2
      wlambda2.sum = wlambda2.sum - weights[p] * lambda[p]^2
    } else {
      np = np + 1
      included[p] = T
      w.sum = w.sum + weights[p]
      wx.sum = wx.sum + weights[p] * x[p]
      wx2.sum = wx2.sum + weights[p] * x[p]^2
      wlambda2.sum = wlambda2.sum + weights[p] * lambda[p]^2
    }
    if (np > 0) {
      d = wx.sum / w.sum
      if (d >= end.pts[i] && d <= end.pts[i+1]) {
        f = wx2.sum - w.sum * d^2 - wlambda2.sum 
        if (f < min.f) {
          min.f = f
          min.d = d
        }        
      }
    }
  }
  min.d
}

# For three-group comparison, grid search method. 
## calculate d2 d3 that minimize G(d) in three groups
min.G.fun.3<-function(mu1, mu2, mu3, n1, n2, n3, lower = -5, upper = -5, alpha = 0, sigma = 1, ngrid = 200){
  d2=seq(lower,upper,length.out=ngrid)
  d3=seq(lower,upper,length.out=ngrid)
  n<-n1+n2+n3
  min.d2 = 0
  min.d3 = 0
  min.f = Inf
  mu = matrix(c(mu1,mu2,mu3), length(mu1))
  
  for (i in 1:ngrid){
    for (j in 1:ngrid){
      f<-G.fun(mu, c(n1,n2,n3), c(0, d2[i],d3[j]), alpha=alpha, sigma=sigma)
      if (f < min.f) {
        min.f = f
        min.d2 = d2[i]
        min.d3 = d3[j]
      }
    }
  }
  list(min.d2,min.d3)
}

## 2-d or 3-d fitting with known sigma
fit.simple <- function(x1, x2, x3 = NULL, alpha = 0, lambda = 0, sigma = 1) {
  three = (!is.null(x3))
  m = dim(x1)[1]
  n1 = dim(x1)[2]
  n2 = dim(x2)[2]
  if (three) n3 = dim(x3)[2] else n3 = 0
  n = n1 + n2 +n3
  
  fit1 = solve.1group(x1, sigma=sigma)
  mu1 = fit1$mu
  d1 = fit1$d
  fit2 = solve.1group(x2, sigma=sigma)
  mu2 = fit2$mu
  d2 = fit2$d
  if (three) {
    fit3 = solve.1group(x3, sigma=sigma)
    mu3 = fit3$mu
    d3 = fit3$d
  } else {
    mu3 = NULL
    d3 = NULL
  }
  
  if (three) {
    output = min.G.fun.3(mu1, mu2, mu3, n1, n2, n3, alpha=alpha, sigma=sigma)
    min.d2 = output[[1]]
    min.d3 = output[[2]]
    d = c(d1, d2+mind.d2, d3+mind.d3)
  } else {
    min.d2 = min.G.prime(mu1, mu2, lambda=lambda, sigma)
    min.d3 = NULL
    d = c(d1, d2+min.d2)
  }
  
  gamma2 = mu2-mu1-min.d2
  if (three) gamma3 = mu3-mu1-min.d3 else gamma3 = NULL
  mu = mu1
  
  if (three) {
    g = n1*mu1^2+n2*(mu2-min.d2)^2+n3*(mu3-min.d3)^2-1/n*(n1*mu1+n2*(mu2-min.d2)+n3*(mu3-min.d3))^2
    mu[g<alpha] = (1/n*(n1*mu1+n2*(mu2-min.d2)+n3*(mu3-min.d3)))[g<alpha]
    gamma2[g<alpha]=0
    gamma3[g<alpha]=0
  } else {
    mu[abs(gamma2) < lambda] = ((mu1 * n1 + (mu2 - min.d2) * n2) / n)[abs(gamma2) < lambda]
    gamma2[abs(gamma2) < lambda] = 0
  }
  
  list(mu = mu, mu1 = mu1, mu2 = mu2, mu3 = mu3, d = d, d1 = d1, d2 = d2, d3 = d3, min.d2=min.d2, min.d3 = min.d3, gamma2 = gamma2, gamma3 = gamma3, sigma = sigma)
}

#2-d or 3-d fitting with unknown sigma
fit.robust <- function(x1, x2, x3 = NULL, ave.w = "default") {
  three = (!is.null(x3))
  m = dim(x1)[1]
  n1 = dim(x1)[2]
  n2 = dim(x2)[2]
  if (three) n3 = dim(x3)[2] else n3 = 0
  n = n1 + n2 + n3
  
  fit1 = solve.1group(x1)
  mu1 = fit1$mu
  d1 = fit1$d
  var1=fit1$sigma^2
  
  fit2 = solve.1group(x2)
  mu2 = fit2$mu
  d2 = fit2$d
  var2=fit2$sigma^2
  
  if (three){
    fit3 = solve.1group(x3)
    mu3 = fit3$mu
    d3=fit3$d
    var3=fit3$sigma^2
  }

  if (three) {
    var <- ((n1-1)*var1+(n2-1)*var2+(n3-1)*var3)/(n-3)
  } else {
    var <- ((n1-1)*var1+(n2-1)*var2)/(n-2)
  }
  
  if (three) S = 3 else S = 2
  
  var.mean = mean(var)
  if (is.character(ave.w)){
    ave.w = (2/(n-S))/(1+2/(n-S))*(m-1)/m + 1/(1+2/(n-S))*(2/(n-S))*var.mean^2*(m-1)/sum((var-var.mean)^2)
    if (ave.w > 1) ave.w = 1
  }
  var.new = ave.w * var.mean + (1-ave.w) * var
  
  if (three){
    df1 = 2
    df2 = n-3
    sigma = sqrt(var.new)
    alpha = qf(0.99, 2, n-3)
    fit = fit.simple(x1, x2, x3, alpha = alpha, sigma = sigma)
  } else {   
    sigma = sqrt(var.new)
    lambda = qt(0.995, n-2)*sigma*sqrt(1/n1+1/n2)
    fit = fit.simple(x1, x2, lambda = lambda, sigma = sigma)
  }
}

# This is the main function. "counts" is the input matrix m*n, where m is the number
# of genes and n is the number of samples. "group" is the group vector. For example, 
# if there are 5 genes, two groups and 4 samples in each group, then "counts" would 
# be a 5*8 matrix and "group" is a two-level factor, for example 
# as.factor(c(0,0,0,0,1,1,1,1)). "take.log" is the indicator of 
# whether take log on the counts. If "take.log" is true, then "log.add" is added to 
# the counts input to handle zero counts. If "three" is true, the "group" should be 
# a three-level factor, for example as.factor(c(0,0,0,0,1,1,1,1,2,2,2,2)).

rSeqRobust.pfun <- function(counts,group,take.log=TRUE,log.add=1,adjust="BH",ave.w="default"){  
  ## Generate group index
  three=FALSE
  group<-as.factor(group)
  if (length(levels(group))==3) three=TRUE
  if (!three) {
    levels(group)<-c(0,1)
  } else {
    levels(group)<-c(0,1,2)
  }
  group<-as.numeric(as.character(group))
  
  counts<-as.matrix(counts)
  m<-dim(counts)[1]
  n<-dim(counts)[2]
  grp1<-group==0
  grp2<-group==1
  if (three) grp3<-group==2
  n1=sum(grp1)
  n2=sum(grp2)
  if (three) n3=sum(grp3)
  
  ## Check counts table and group index
  if (sum(counts<0)>0) stop ("Counts table should only contain none negative numbers.")
  #if (!sum(counts%%1)==0) stop ("Counts table should only contain intergers.")
  if (length(group)!=n) stop ("The dimension of counts table does not match the group argument")
  if (is.na(match(adjust,c("BH","bonferroni","holm","hochberg","hommel")))) stop("The method for calculating adjused p values should be one of BH, bonferroni, holm, hochberg or hommel")
  if ((is.character(ave.w)&(is.na(match(ave.w,"default")==1)))) stop ("Weight has to be either default or a number between zero and one.")
  if (is.double(ave.w)&((ave.w>1)|(ave.w<0))) stop ("Weight has to be either default or a number between zero and one.")

  if (take.log){
    x1<-log(counts[,grp1]+log.add)
    x2<-log(counts[,grp2]+log.add)
    if (three) x3<-log(counts[,grp3]) else x3 = NULL
    x = log(counts+log.add)
  } else {
    x1<-counts[,grp1]
    x2<-counts[,grp2]  
    if (three) x3<-counts[,grp3] else x3 = NULL
    x = counts
  }
  
  fit = fit.robust(x1, x2, x3, ave.w)
  
  # calculate pvalues and adjusted pvalues

  p.value = rep(0, m)
  for (i in 1:m){
    if (three) {
      m1=fit$mu1[i]
      m2=fit$mu2[i]-fit$min.d2
      m3=fit$mu3[i]-fit$min.d3
      mm=(n1*m1+n2*m2+n3*m3)/n
      f=(n1*(m1-mm)^2+n2*(m2-mm)^2+n3*(m3-mm)^2)/fit$sigma[i]^2/2
      df1=2
      df2=n-3
      p.value[i]=1-pf(f.stat,df1=df1,df2=df2)
    } else {
      t=(fit$mu2[i] - fit$mu1[i] - fit$min.d2)/fit$sigma[i]/sqrt(1/n1+1/n2)
      df=n-2
      p.value[i]=2*pt(-abs(t),df=df)
    }
  }
  
  p.adj = p.adjust(p.value,adjust)
  p<-cbind(pval=p.value,padj=p.adj)
  rownames(p)<-rownames(counts)
  colnames(p)<-c("pval","padj")

  if (three){
    fold.2v1<-exp(fit$mu2 - fit$mu1 - fit$min.d2)
    fold.3v1<-exp(fit$mu3 - fit$mu1 - fit$min.d3)
    out<-cbind(p,fold.2v1,fold.3v1)
  } else {
    fold.2v1<-exp(fit$mu2 - fit$mu1 - fit$min.d2)
    out<-cbind(p,fold.2v1)
  }
  out
}
