#simulation of random 2D quadratic functions

rm(list = ls())
options(digits = 6)
library(nloptr)
library(GenSA)
library(foreach)
library(iterators)
library(hydroPSO)
library(EnvStats)
source("twoD.R")
source("quadratic.2D.R")
source("Filled.contour3.R")
source("common.R")
source("quadratic.DC.R")
set.seed(1234)

obj_fn = function(x) {
    return(sum(pmin(quadratic_val(data, 1:m, x), lambda)))
}

random.quadratic.function = function(m, c_factor) {
    #Data generation:
    theta = runif(m, min = 0, max = pi) # rotation
    a = runif(m, min = 0.01, max = 0.5) / c_factor # a,b: axis lengths
    b = runif(m, min = 0.01, max = 0.5)
    z = -runif(m, min = 1, max = 10) # height
    u = runif(m, min = 0, max = 1) # center
    v = runif(m, min = 0, max = 1)

    A = cos(theta) ^ 2 / a ^ 2 + sin(theta) ^ 2 / b ^ 2
    B = -2 * cos(theta) * sin(theta) / a ^ 2 + 2 * cos(theta) * sin(theta) / b ^ 2
    C = cos(theta) ^ 2 / b ^ 2 + sin(theta) ^ 2 / a ^ 2
    D = -2 * u * cos(theta) ^ 2 / a ^ 2 + 2 * v * cos(theta) * sin(theta) / a ^ 2 -
        2 * v * cos(theta) * sin(theta) / b ^ 2 - 2 * u * sin(theta) ^ 2 / b ^ 2
    E = -2 * v * cos(theta) ^ 2 / b ^ 2 + 2 * u * cos(theta) * sin(theta) / a ^ 2 -
        2 * u * cos(theta) * sin(theta) / b ^ 2 - 2 * v * sin(theta) ^ 2 / a ^ 2
    H = z + u ^ 2 * cos(theta) ^ 2 / a ^ 2 + v ^ 2 * cos(theta) ^ 2 / b ^ 2 -
        2 * u * v * cos(theta) * sin(theta) / a ^ 2 +
        2 * u * v * cos(theta) * sin(theta) / b ^ 2 + u ^ 2 * sin(theta) ^ 2 / b ^ 2 +
        v ^ 2 * sin(theta) ^ 2 / a ^ 2
    return(cbind(A, B / 2, C, D, E, H))
}

m = 50 #num of functions 
C = c(1, 5, 10) #C: the parameter controlling sharpness of random quadratic functions; the larger the steeper the functions.
lambda = rep(0, m)

pdf("C.pdf", width = 6, height = 2)
par(mfrow = c(1, 3))
par(mar=c(2, 2, 1, 0) + 0.1, mgp=c(2,0.8,0))
for (c_factor in C) {
    data = random.quadratic.function(m, c_factor)
    grid.search(obj_fn, contour.plot = T, main = paste("C = ", c_factor), font.main = 1)
}
dev.off()

s = 100 #experiment num
maxeval = 10000 # maximal number of function evaluations for comparative methods
tol = 1e-8
maxiter = 10000
t = 1e-5
success.output = NULL
time.output = NULL
success.mean = NULL
success.sem = NULL
for (c_factor in C) {
    success = NULL
    time = NULL
    for (q in 1:s) {
        print(paste("q =", q))

        data = random.quadratic.function(m, c_factor)
        lambda = rep(0, m)
        
        # #grid search
        # time_grid = system.time(result_grid <- grid.search(obj_fn))[3]
        # loc_grid = result_grid$par
        # M_grid = obj_fn(loc_grid)
        
        #DC
        A.list = NULL
        b.list = NULL
        for (i in 1:m) {
            A.list = c(A.list, list(matrix(2*c(data[i,1], data[i,2], data[i,2], data[i,3]), 2, 2)))
            b.list = c(b.list, list(data[i,4:5]))
        }
        time_DC = system.time(result_DC <- quadratic.DC(A.list = A.list, b.list = b.list, c = data[,6], x0 = rep(0.5, 2), maxit = maxiter, tol = tol))[3]
        loc_DC = result_DC$par
        M_DC = obj_fn(loc_DC)

        #proposed method
        time_pro = system.time(result_pro <- quadratic.2D(data))[3]
        loc_pro = result_pro$par
        M_pro = obj_fn(loc_pro)

        #DIRECT
        time_direct = system.time(result_direct <- direct(obj_fn, rep(0, 2), rep(1, 2), control = list(xtol_rel = tol, maxeval = maxeval, stopval = -Inf, ftol_rel = 0.0, ftol_abs = 0.0, check_derivatives = F)))[3]
        loc_direct = result_direct$par
        M_direct = obj_fn(loc_direct)

        #StoGO
        time_stogo = system.time(result_stogo <- stogo(x0 = rep(0.5, 2), fn = obj_fn, lower = rep(0, 2), upper = rep(1, 2), maxeval = maxeval, xtol_rel = tol))[3]
        loc_stogo = result_stogo$par
        M_stogo = obj_fn(loc_stogo)
        
        #simulating annealing
        time_SA = system.time(result_SA <- GenSA(lower = rep(0, 2), upper = rep(1, 2), fn = obj_fn, control = list(maxit = maxiter, max.call = maxeval, threshold.stop = NULL, max.time = NULL, nb.stop.improvement = 1e6)))[3]
        loc_SA = result_SA$par
        M_SA = obj_fn(loc_SA)

        #particle swarm
        time_PS = system.time(result_PS <- hydroPSO(fn = obj_fn, lower = c(0, 0), upper = c(1, 1), control = list(maxfn = maxeval, maxit = maxiter, reltol = tol)))[3]
        loc_PS = result_PS$par
        M_PS = obj_fn(loc_PS)

        #M = c(M_grid, M_direct, M_stogo, M_SA, M_PS, M_pro)
        #M = c(M_direct, M_stogo, M_SA, M_PS, M_pro)
        M = c(M_direct, M_stogo, M_SA, M_PS, M_DC, M_pro)
        min_M = min(M)
        success = rbind(success, sapply(M, function(x){x < min_M + t}))
        #time = rbind(time, c(time_grid, time_direct, time_stogo, time_SA, time_PS, time_pro))
        #time = rbind(time, c(time_direct, time_stogo, time_SA, time_PS, time_pro))
        time = rbind(time, c(time_direct, time_stogo, time_SA, time_PS, time_DC, time_pro))
    }
    success.output = rbind(success.output, as.character(c(c_factor, summarize(success * 100, digits = 1))))
    time.output = rbind(time.output, as.character(c(c_factor, summarize(time, digits = 2))))
    success.mean = rbind(success.mean, colMeans(success * 100))
    success.sem = rbind(success.sem, colSDs(success * 100)/sqrt(nrow(success)))
}

#methods = c("Grid search", "DIRECT", "StoGO", "SA", "PSO", "Proposed")
methods = c("DIRECT", "StoGO", "SA", "PSO", "Proposed")
methods = c("DIRECT", "StoGO", "SA", "PSO", "DC", "Proposed")

pdf("quadratic.2D.pdf", height = 6, width = 6)
par(mar=c(3, 3, 0, 0) + 0.5, mgp=c(2,0.8,0))
colors = c("brown", "blue", "red", "blueviolet", "darkgreen", "black")
k = length(methods)
plot(1:10, type = "n", xlim = range(C), ylim = c(0,100), xlab = "C", ylab = "Percent success")
for (l in 1:k) {
  lines(x = C, y = success.mean[,l], type = "b", lty = l, col = colors[l], pch = l)
  errorBar(x = C, y = success.mean[,l], lower = success.sem[,l], upper = success.sem[,l], col = colors[l], pch = l, add = T, gap.size = 0.25, bar.ends.size = 0.25)
}
legend("bottomleft", lty = 1:k, col = colors, pch = 1:k, legend = methods)
dev.off()

colnames(success.output) <- c("C", methods)
require(xtable)
sink(file = paste("quadratic.2D.sim.success.tex", sep = ""))
print(xtable(success.output), include.rownames = F, sanitize.text.function = function(col) { sapply(col, bold) })
sink()

colnames(time.output) <- c("C", methods)
require(xtable)
sink(file = paste("quadratic.2D.sim.time.tex", sep = ""))
print(xtable(time.output), include.rownames = F, sanitize.text.function = function(col) { sapply(col, bold) })
sink()
