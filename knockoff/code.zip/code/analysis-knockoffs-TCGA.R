rm(list = ls(all.names = TRUE))
set.seed(1234)
###Loading library and source files
library(knockoff)
library(mboost)
library(MASS)
source("mboost.varimp.R")
source("selection.R")
source("sis.R")

###Load dataset
load("TCGA_melanoma_20190122.RData")
rownames(id_name) = id_name[,1]
rownames(expr) = paste(rownames(expr), id_name[rownames(expr),2], sep="|")
colnames(expr)
colnames(clinical_dat)
ID=as.character(colnames(expr))
Y=clinical_dat[order(ID),64]
z=t(expr)

z=as.matrix(z)
mean.z = colMeans(z)
z = z[,mean.z > 1]
z = log(z+1)

###Preselection through correlations
cor.p.values = apply(z, 2, function(x) { cor.test(x, Y)$p.value})
cor.p.values[is.na(cor.p.values)] = 1
cor.q.values = p.adjust(cor.p.values, method = "BH")
selected.genes = (cor.q.values < 0.2)

znew=z[, selected.genes]
dim(znew)

### Knock-offs 
result = selection(znew, Y, q=.2, knockoff.method = "asdp")
result 
colnames(znew[,result], do.NULL = TRUE, prefix = "col")

#lasso + CV
library(glmnet)
result_lasso_CV=cv.glmnet(znew, Y, alpha=1, nfolds=5)
myCoefs = coef(result_lasso_CV, s="lambda.min")
myCoefs = myCoefs[-1,,drop = F]
selected_lasso_CV = which(myCoefs != 0)
#colnames(znew[, selected_lasso_CV])
length(selected_lasso_CV)
length(intersect(result, selected_lasso_CV))
colnames(znew[, intersect(result, selected_lasso_CV)])
colnames(znew[, setdiff(result, selected_lasso_CV)])

#simulation
K = 10
m = ncol(z)
n = nrow(z)
p = 500
znew1 = z[,sample(m, p)]
true.gene = sample(p, K)
true.beta = runif(K, 1, 5) * sample(c(-1,1), K, replace = T)
beta = rep(0, p)
beta[true.gene] = true.beta
Y1 = znew1 %*% beta
#library(Hmisc)
Y2 = as.factor(cut2(Y1, median(Y1)))
result1 = selection(znew1, Y2, family = Binomial(), q=.2, knockoff.method = "asdp", screen = F)
TP = length(intersect(true.gene, result1))
print(length(result1))
print(paste("power = ", TP/K))
print(paste("FDP = ", 1 - TP/length(result1)))

save.image(file = "analysis-knockoffs-TCGA.RData")
load(file = "analysis-knockoffs-TCGA.RData")
