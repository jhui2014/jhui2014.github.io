#ifndef _WXDCHELPER_H_
#define _WXDCHELPER_H_

#include "UserDefinedType.h"
#include "wx/dcmemory.h"

class wxDCHelper
{
public:
	static PICOLORREF GetPixel(wxMemoryDC* pdc, wxCoord x, wxCoord y)
	{
		wxColor color;
		pdc->GetPixel(x, y, &color);
		return ColorFromWXColor(color);
	}
	static wxCoord oldX;
	static wxCoord oldY;
	static void MoveTo(wxMemoryDC* pdc, wxCoord x, wxCoord y)
	{
		oldX = x;
		oldY = y;
	}
	static void LineTo(wxMemoryDC* pdc, wxCoord x, wxCoord y)
	{
		pdc->DrawLine(oldX, oldY, x, y);
		oldX = x;
		oldY = y;
	}
	static void FillRect(wxMemoryDC* pdc, PIRect rc)
	{
		pdc->DrawRectangle(rc.TOWXRect());
	}

	static void FillRect(wxMemoryDC* pdc, PIRect rc, PICOLORREF color)
	{
		wxBrush brush(wxDCHelper::ColorFromCOLORREF(color));
		wxPen pen(wxDCHelper::ColorFromCOLORREF(color));
		wxBrush oldBrush = pdc->GetBrush();
		wxPen oldPen = pdc->GetPen();
		pdc->SetBrush(brush);
		pdc->SetPen(pen);
		wxDCHelper::FillRect(pdc,rc);
		pdc->SetPen(oldPen);
		pdc->SetBrush(oldBrush);
	}

	static wxColor ColorFromCOLORREF(PICOLORREF c)
	{
		return wxColor(GetRValue(c), GetGValue(c), GetBValue(c));
	}

	static PICOLORREF ColorFromWXColor(wxColor c)
	{
		return RGB(c.Red(), c.Green(), c.Blue());
	}

	static PISize GetTextExtent(wxMemoryDC* pdc, wxString str)
	{
		wxCoord textSizeX, textSizeY;
		pdc->GetTextExtent(str, &textSizeX, &textSizeY);
		return PISize(textSizeX,textSizeY);
	}
};

#endif
