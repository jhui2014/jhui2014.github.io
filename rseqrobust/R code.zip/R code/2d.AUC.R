rm(list = ls())
source("rSeqRobust.R")

#######################################################################
#######################################################################
#2-d AUC tables

#source("http://bioconductor.org/biocLite.R")
#biocLite("tweeDEseqCountData")
library(tweeDEseqCountData)
library(gridExtra)
library(edgeR)
library(DESeq2)
library(limma)
library(AUC)
source("sim.R")

############################# Simulation #####################################
## In the following for loops, "type" is the type of simualtion, "f" is the average fold change, "k" is the percentage of 
## fold change, "j" is the percentage of up-regulated genes (100-j would be the percentage of down-regulated genes), 
## "out" is the percentage of outliers. When "real_data" is true, the counts would range from 10^0 or 10^1 to 10^5 or 10^6. 
## When "real_data" is false, the simulation would be your simulation. 


############################# Load real dataset ###################################
dataset <- getDataset(counts = pickrell)

for (type in c("LN", "NB")) {
    ## type could be "LN" or "NB"
    AUC_output = NULL
    TIME_output = NULL
    n_repeat = 10
    f = 3
    for (nSamp in c(4, 6, 8, 12, 24)) {
        for (k in c(30, 70)) {
            for (j in c(50, 70, 90)) {
                for (out in c(0)) {
                    set.seed(1234)
                    result = NULL
                    time = NULL
                    for (it in 1:n_repeat) {
                        ###### set up group #############
                        grp = as.factor(rep(0:1, each = nSamp / 2))
                        ######### Data preparation #############################
                        data_2 <- Sim(type = type, dataset = dataset, nTags = 1000,
                        group = grp, verbose = TRUE, add.outlier = F,
                        outlierMech = "S", pOutlier = (out / 100), drop.extreme.dispersion = 0.1, pDiff = (k / 100),
                        pUp = (j / 100), foldDiff = f)
                        nTags <- 1000
                        DE_indicator <- rep(0, nTags)
                        DE_indicator[data_2$indDE] <- 1
                        DE_indicator <- as.factor(DE_indicator)

                        time.edgeR = system.time(p.edgeR <- edgeR_robust.pfun(data_2$counts, data_2$group, data_2$design)[, 1])[3]
                        time.DESeq2 = system.time(p.DESeq2 <- DESeq2.pfun(data_2$counts, data_2$group, data_2$design)[, 1])[3]
                        time.limma = system.time(p.limma <- limma_voom.pfun(data_2$counts, data_2$group, data_2$design)[, 1])[3]
                        time.rSeqRobust = system.time(p.rSeqRobust <- rSeqRobust.pfun(data_2$counts, data_2$group)[, 1])[3]

                        time = rbind(time, c(time.edgeR, time.DESeq2, time.limma, time.rSeqRobust))
                        result = rbind(result, c(auc(roc(1 - p.edgeR, DE_indicator)), auc(roc(1 - p.DESeq2, DE_indicator)), auc(roc(1 - p.limma, DE_indicator)), auc(roc(1 - p.rSeqRobust, DE_indicator))))
                    }

                    mean.auc = colMeans(result)
                    sem.auc = apply(result, 2, sd) / sqrt(dim(result)[1])
                    max_ind = which.max(mean.auc)
                    mean.auc = format(round(mean.auc, 3), nsmall = 3)
                    sem.auc = format(round(sem.auc, 3), nsmall = 3)
                    #mean.auc[max_ind] <- paste(mean.auc[max_ind], "*")
                    sem.auc = paste("{\\tiny(", sem.auc, ")}", sep = "")
                    sem.auc[max_ind] <- paste(sem.auc[max_ind], "*")

                    mean.time = colMeans(time)
                    sem.time = apply(time, 2, sd) / sqrt(dim(time)[1])
                    min_ind = which.min(mean.time)
                    mean.time = format(round(mean.time, 3), nsmall = 3)
                    sem.time = format(round(sem.time, 3), nsmall = 3)
                    #mean.time[min_ind] <- paste(mean.time[min_ind], "*")
                    sem.time = paste("{\\tiny(", sem.time, ")}", sep = "")
                    sem.time[min_ind] <- paste(sem.time[min_ind], "*")

                    AUC_output = rbind(AUC_output, as.character(c(nSamp, k, j, paste(mean.auc, sem.auc))))
#                    AUC_output = rbind(AUC_output, c(" ", " ", " ", sem.auc))

                    TIME_output = rbind(TIME_output, as.character(c(nSamp, k, j, paste(mean.time, sem.time))))
#                    TIME_output = rbind(TIME_output, c(" ", " ", " ", sem.time))
                }
            }
        }
    }

    bold <- function(x) {
        l = nchar(x)
        last_char = substr(x, l, l)
        if (last_char == "*") {
            x = substr(x, 1, l - 2)
            paste('{\\textbf{', x, '}}', sep = '')
        } else {
            x
        }
    }

    colnames(AUC_output) <- c("$n$", "DE\\%", "Up\\%", "edgeR-robust", "DESeq2", "limma-voom", "rSeqRobust")
    library(xtable)
    sink(file = paste("AUC.", type, ".tex", sep = ""))
    print(xtable(AUC_output), include.rownames = F, sanitize.text.function = function(col) { sapply(col, bold) })
    sink()

    colnames(TIME_output) <- c("$n$", "DE\\%", "Up\\%", "edgeR-robust", "DESeq2", "limma-voom", "rSeqRobust")
    library(xtable)
    sink(file = paste("TIME.", type, ".tex", sep = ""))
    print(xtable(TIME_output), include.rownames = F, sanitize.text.function = function(col) { sapply(col, bold) })
    sink()
}
