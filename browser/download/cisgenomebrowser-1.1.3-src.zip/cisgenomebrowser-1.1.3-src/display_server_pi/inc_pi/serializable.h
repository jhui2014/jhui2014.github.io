#ifndef __SERIALIZABLE_H__
#define __SERIALIZABLE_H__

#include <string>
#include <vector>

class serializable {
public:
	virtual size_t token_count() const = 0;
	virtual int read_binary(FILE* file) = 0;
	virtual int read_text(std::vector<std::string> tokens) = 0;
	virtual int write_binary(FILE* file) const = 0;
	virtual int write_text(FILE* file) const = 0;
	virtual size_t offset() const = 0;
	virtual serializable* Copy() const = 0;
	virtual ~serializable() {}

	virtual void set(std::string str) = 0;
	virtual std::string to_string() const = 0;
};

#endif  // __SERIALIZABLE_H__
