#include "session.h"
#include "drawCommon.h"
#include "display_motif.h"
#include "display_gene.h"
#include "display_signal.h"
#include "display_conservation.h"
#include "display_region.h"
#include "display_nucleotide.h"
#include "display_data.h"
#include "display_cel.h"
#include "display_genome.h"
#include "display_junction.h"

session::~session()
{
	cleanup();
}

void session::cleanup()
{
	if (display != NULL)
	{
		delete display;
		display = NULL;
	}
}

session::session(http_request* r)
{
	name = "";
	type = "";
	seed = 0;
	seed_match = true;
	password = "";
	display = NULL;
	req = r;
	refresh = false;

	name = r->params_["name"];

	if (r->params_.count("create_session") > 0)
	{
		name = r->params_["session_name"];
		if (name == "")
			name = r->params_["name"];
		if (name == "")
		{
			name = get_random_session_name();
		}
	}

	if (name == "")
	{
		if (r->params_["session_name"] == "")
		{
			r->answer_ = error_html("Session does not exists.");
			return;
		}
		else
		{
			name = r->params_["session_name"];
		}
	}

	string file_name = session_path + name + ".ini";

	if (file_exists(file_name))
	{
		if (!load_from_file(file_name))
		{
			r->answer_ = error_html(string("Fail loading session ") + name);
			return;
		}
	}
	else if (!local_client)
	{
		r->answer_ = error_html(string("Remote user can not do this."));
		return;
	}
	
	if (r->params_.count("exons") > 0) {
		display_junction disp_junction(r);
		r->answer_ = disp_junction.get_html();
		return;
	}

	seed_match = true;
	if (r->params_.count("seed") > 0)
	{
		if (seed != str2int(r->params_["seed"]))
		{
			seed_match = false;
			WriteIni(file_name, "session/refresh", true, true);
			r->answer_ = redirect_html(host_name + "session?name=" + name);
			return;
		}
	}
	seed++;
	/*bool updated = */
	update_params();

	/*	if (updated) {
	r->answer_ = redirect_html(host_name+"session?name="+name);
	} else {
	r->answer_ = get_html();
	}*/

	r->answer_ = get_html();
	refresh = false;

	if (req->params_.count("reload_session_ini_file") > 0)
	{
		WriteIni(file_name, "session/refresh", true, true);
		r->answer_ = redirect_html(host_name + "session?name=" + name);
		return;
	}

	if (!write_to_file(file_name))
	{
		r->answer_ = error_html(string("Fail writing session ") + name);
		return;
	}

	if (req->params_.count("open_session_ini_file") > 0)
	{
		string session_ini_filename = session_path + name + ".ini";
		if (local_client)
		{
			folder_to_be_opened = session_ini_filename;
		}
		else
		{
			r->answer_ = redirect_html(host_name + "sessions/" + name + ".ini");
			return;
		}
	}

	if (req->params_.count("open_session_folder") > 0)
	{
		if (local_client)
		{
			folder_to_be_opened = session_path;
		}
		else
		{
			r->answer_ = error_html(string("Remote client can not do this."));
			return;
		}
	}

	return;
}

void session::create_display()
{
	cleanup();
	if (type == "motif")
	{
		display = new display_motif(req);
	}
	else if (type == "cel")
	{
		display = new display_cel(req);
	}
	else if (type == "data")
	{
		display = new display_data(req);
	}
	else if (type == "genome")
	{
		display = new display_genome(req);		
	}
	if (display != NULL)
		display->refresh = refresh;
	if (display != NULL)
		display->s = this;
}

bool session::load_from_file(string file_name)
{
	type = ReadIni(file_name, "session/type", wxString(""));
	seed = ReadIni(file_name, "session/seed", 0);
	refresh = ReadIni(file_name, "session/refresh", false);
	create_display();
	if (display != NULL)
	{
		return display->load_from_file(file_name);
	}
	return true;
}

bool session::update_params()
{
	bool updated = false;

	if (req->params_.count("create_session_type") > 0)
	{
		type = req->params_["type"];
		create_display();
		updated = true;
	}
	if (display != NULL)
		updated |= display->update_params();
	return updated;
}

bool session::write_to_file(string file_name)
{
	if (file_exists(file_name))
	{
		wxRemoveFile(wxS(file_name));
	}
	WriteIni(file_name, "session/type", type, type != "");
	WriteIni(file_name, "session/seed", seed, seed != 0);
	WriteIni(file_name, "session/refresh", refresh, refresh != false);
	if (display != NULL)
	{
		return display->write_to_file(file_name);
	}
	return true;
}

string session::get_html()
{
	string result;

	if (type == "")
	{
		html_formater my_html_formater;
		my_html_formater.load_from_template_file(template_path
			+ "new_session.html");
		result = my_html_formater.buf;
	}
	else if (display == NULL)
	{
		result = error_html("Internal Error: No Display.");
	}
	else
	{
		result = display->get_html();
	}
	html_formater my_html_formater;
	my_html_formater.load_from_template_file(template_path + "session.html");
	my_html_formater.replace_keyword("$SESSION_CONTENTS$", result);
	my_html_formater.replace_keyword("$SESSION_NAME$", name);
	my_html_formater.replace_keyword("$HOSTNAME$", host_name);
	my_html_formater.replace_keyword("$SESSION_SEED$", int2str(seed));
	my_html_formater.replace_keyword("$REMOTE_HIDDEN$", local_client ? ""
		: " disabled ");
	title = name + " - CisGenome Browser";
	//my_html_formater.replace_keyword("$REMOTE_HIDDEN$", local_client?"":" type=\"hidden\" ");
	//my_html_formater.replace_keyword("$REMOTE_HIDDEN$", local_client?"":" style=\"width: 0px;height: 0px;border: none\" ");
	result = my_html_formater.buf;
	return result;
}
