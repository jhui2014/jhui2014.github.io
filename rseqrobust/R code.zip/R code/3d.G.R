rm(list=ls())
source("rSeqRobust.R")

#######################################################################
#######################################################################
# 3-d function G

## Visualize d2 and d3 that minimize function f(d)
set.seed(1234)
m=100
mu=0
sd=1
ngrid=400
ni=10
lower=-5
upper=5

mu1 = rnorm(m, mu, sd)
mu2 = rnorm(m, mu, sd)
mu3 = rnorm(m, mu, sd)
mu = matrix(c(mu1,mu2,mu3), m)

x=seq(lower,upper,length.out=ngrid)
y=seq(lower,upper,length.out=ngrid)
z=matrix(NA,ngrid,ngrid)

for (alpha in c(1, 5)) {
  for (i in 1:ngrid) {
    for (j in 1:ngrid){
      z[i,j] = G.fun(mu, rep(ni, 3), c(0, x[i], y[j]), alpha)
    }
  }
  
  library(gplots)
  library(fields)
  pdf(paste("3d.alpha=", alpha, ".pdf", sep=""), 6, 5)
  par(mar=c(4,4,1,1) + 0.1)
  
  image.plot(x,y,z,xlab="d2",ylab="d3",col=colorpanel(7, "grey20","white"))
  contour(x,y,z,add=TRUE,nlevels=5)
  
  output=min.G.fun.3(mu1, mu2, mu3, ni, ni, ni, lower=lower, upper=upper, alpha=alpha, ngrid=ngrid)
  d2.min=output[[1]]
  d3.min=output[[2]]
  segments(lower,d3.min,upper,d3.min,lty=2,col=4)
  segments(d2.min,lower,d2.min,upper,lty=2,col=4)
  dev.off()
}