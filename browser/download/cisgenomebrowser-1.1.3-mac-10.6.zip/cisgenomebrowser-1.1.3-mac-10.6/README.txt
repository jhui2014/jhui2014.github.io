README for CisGenome Browser: A Light-Weight Stand-Alone Genome Browser
http://biogibbs.stanford.edu/~jiangh/browser/
Hui Jiang (jiangh at stanford dot edu)

For updates, see http://biogibbs.stanford.edu/~jiangh/browser/

For launching or compiling the program, see
http://biogibbs.stanford.edu/~jiangh/browser/getting_started/index.html

For usage information, see http://biogibbs.stanford.edu/~jiangh/browser/README.html
