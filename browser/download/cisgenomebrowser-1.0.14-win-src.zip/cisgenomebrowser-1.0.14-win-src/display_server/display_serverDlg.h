// display_serverDlg.h : header file
//

#pragma once

#include "SystemTray.h"

// Cdisplay_serverDlg dialog
class Cdisplay_serverDlg : public CDialog
{
// Construction
public:
	Cdisplay_serverDlg(CWnd* pParent = NULL);	// standard constructor
	virtual ~Cdisplay_serverDlg();
	void SetupTaskBarButton();
	void SetupTrayIcon();

// Dialog Data
	enum { IDD = IDD_DISPLAY_SERVER_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;
	bool bMinimized_;
	CSystemTray* pTrayIcon_;
	int nTrayNotificationMsg_;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	LRESULT Cdisplay_serverDlg::OnMyMessage(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnSystrayRestore();
	afx_msg void OnSystrayExit();
	afx_msg void OnBnClickedOk();
	afx_msg void OnWindowPosChanging(WINDOWPOS* lpwndpos);
	afx_msg void OnClose();
	afx_msg void OnSystrayBrowse();
	afx_msg void OnSystraySetting();
	afx_msg void OnSystrayAbout();
};
