#ifndef CISGENOME_H
///Define this macro to prevent from including this header file more than once.
#define CISGENOME_H

#include "cisgenome_cfiles/MatrixLib.h"
#include "cisgenome_cfiles/StringLib.h"
#include "cisgenome_cfiles/TilingArrayLib.h"
#include "cisgenome_cfiles/AffyLib.h"
#include "cisgenome_cfiles/GenomeLib.h"
#include "cisgenome_cfiles/SequenceLib.h"

#endif // CISGENOME_H
