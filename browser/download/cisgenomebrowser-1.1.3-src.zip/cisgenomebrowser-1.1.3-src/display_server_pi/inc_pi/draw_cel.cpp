#include "draw_cel.h"

#include "cisgenome.h"
#include "wx/dcmemory.h"
#include "wxDCHelper.h"

draw_cel::draw_cel()
{
	pdata.clear();
	cel_filename = "";
}

string draw_cel::print_usage()
{
	return "<CEL file name>\n";
}

bool draw_cel::get_params(const vector<string> &params)
{
	if (!draw_figure_structure::get_params(params))
		return false;
	if (params.size() != 1)
		return false;
	cel_filename = params[0];
	return true;
}

bool draw_cel::load_data()
{
	if (!draw_figure_structure::load_data())
		return false;

	struct tagCELData *pCELData;
	struct BYTEMATRIX *pMask;

	char filename[1024];
	strcpy(filename, cel_filename.c_str());
	if (NULL == (pCELData = TileMapv2_LoadCEL(filename)))
	{
		error_msg = string("ERROR: Failed to open CEL file ") + cel_filename;
		return false;
	}
	size.cx = pCELData->nCols;
	size.cy = pCELData->nRows;
	int N = size.cx * size.cy;
	pdata = vector<double> (pCELData->pIntensity->pMatElement,
		pCELData->pIntensity->pMatElement + N);
	pMask = TileMapv2_GetMask(pCELData, 1, 1, 1);
	masks = vector<char> (pMask->pMatElement, pMask->pMatElement + N);
	DestroyByteMatrix(pMask);
	Affy_CELData_Destroy(&pCELData);

	return true;
}

bool draw_cel::draw(wxMemoryDC* pdc, int x_off, int y_off)
{
	if (!draw_figure_structure::draw(pdc, x_off, y_off))
		return false;
	int i, j;
	//mark outliers;
	int N = size.cx * size.cy;
	double minimum = 1e20, maximum = -1e20;
	double mean = 0, stddev = 0;
	for (i = 0; i < N; i++)
		mean += pdata[i];
	mean /= N;
	for (i = 0; i < N; i++)
		stddev += (pdata[i] - mean) * (pdata[i] - mean);
	stddev /= N;
	stddev = sqrt(stddev);
	for (i = 0; i < N; i++)
	{
		//if (masks[i]) continue;
		if (pdata[i] > mean + stddev * 3 || pdata[i] < mean - stddev * 3)
			continue;
		if (pdata[i] < minimum)
			minimum = pdata[i];
		if (pdata[i] > maximum)
			maximum = pdata[i];
	}
	cm.set_colorsystem(COLOR_SYSTEM_BLACK_WHITE, minimum, maximum);

	//histogram equalization
	vector<double> pdata1 = pdata;
	sort(pdata1.begin(), pdata1.end());
	double seperators[255];
	for (i = 0; i < 255; i++)
		seperators[i] = pdata1[(i + 1) * N / 256];
	for (i = 0; i < size.cx; i++)
		for (j = 0; j < size.cy; j++)
		{
			int nidx = j * size.cx + i;
			double value = pdata[nidx];
			if (value > mean + stddev * 3 || value < mean - stddev * 3)
				continue;
			//if (masks[nidx]) continue;
			int left = -1, right = 255;
			while (left < right - 1)
			{
				int middle = (left + right) / 2;
				if (value < seperators[middle])
					right = middle;
				else
					left = middle;
			}
			pdata[nidx] = right;
		}
		cm.set_colorsystem(COLOR_SYSTEM_BLACK_WHITE, 0, 512);

		for (i = 0; i < size.cx; i++)
			for (j = 0; j < size.cy; j++)
			{
				int nidx = j * size.cx + i;
				//if (masks[nidx]) pdc->SetPixel(x_off + i, y_off + j, RBG(255,255,255));
				double value = pdata[nidx];
				wxPen pen(wxDCHelper::ColorFromCOLORREF(cm.get_color(value)));
				pdc->SetPen(pen);
				pdc->DrawPoint(wxCoord(x_off + i), wxCoord(y_off + j));
			}
			return true;
}
