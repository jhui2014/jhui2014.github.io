function [] = compute(genename);

filename = 'C:\work\Stanford\research\Wong\mypapers\Isoform Abundance Estimation\alter_splicing_paper\brain.OUT.2.matlab.new';

fid = fopen(filename);

if strcmp(genename,'all')        
    output_filename = [filename, '.out'];
    fid1 = fopen(output_filename,'w');
    output_filename_gene = [filename, '.gene'];
    fid_gene = fopen(output_filename_gene,'w');
    output_filename_iso = [filename, '.iso'];
    fid_iso = fopen(output_filename_iso,'w');
end

NN = fscanf(fid,'%f', 1);
read_len = fscanf(fid,'%f', 1);
while(1)
    name = fscanf(fid,'%s',1);
    if (strcmp(name,'')) 
        break;
    end
    m = fscanf(fid,'%d',1);
    n = fscanf(fid,'%d',1);
    trans = cell(1,n);
    for i=1:n
        trans{i} = fscanf(fid,'%s',1);
    end
    L = fscanf(fid,'%f',m)';
    N = fscanf(fid,'%f',m)';
    if m>1
        L1 = fscanf(fid,'%f',m*(m-1)/2)';
        N1 = fscanf(fid,'%f',m*(m-1)/2)';
    else
        L1 = [];
        N1 = [];
    end
    A = fscanf(fid,'%d',m*n);
    A = reshape(A,m,n);
 
    if strcmp(genename,'all') | strcmp(name,genename)       
        X_opt = -1;
        
        if n > 1
            if m > 1
                if sum(N) >= 10
                    if strcmp(genename,'all')
                        [X_opt, GENE, CI_GENE, MEAN, CI, C_IS]=iso_opt(A,L,L1,N,N1,NN,read_len,name,0);
                    else
                        iso_opt(A,L,L1,N,N1,NN,read_len,name,1);
                    end
                end
            else
                disp(sprintf('warning: m==1 & n>1 for gene %s.', name));
            end
        end
            
        if m>1 & n==1
            error(sprintf('m>1 & n==1 for gene %s.', name));
        end
            
        if X_opt < 0
            N = sum(N);
            L = sum(L);
            X_opt = N / ((L - read_len) / 1e3) / (NN / 1e6);
            GENE = X_opt;
            MEAN = X_opt;
            p = N / NN;
            CI = (p + [-1, 1] * 1.96 * sqrt(p * (1-p) / NN)) / (L - read_len) * 1e9;
            CI_GENE = CI;
            C_IS = p * (1-p) / NN / (L-read_len)^2 * 1e18;
        end
        
        if strcmp(genename,'all')
            fprintf(fid1, '%s\t%f\t%f\t%f\t%f\n', name, sum(X_opt), GENE, CI_GENE(1), CI_GENE(2));
            fprintf(fid_gene, '%s\t%f\t%f\t%f\t%f\t%d\t%d\t%d\n', name, sum(X_opt), GENE, CI_GENE(1), CI_GENE(2), m, n, sum(L));
            if length(MEAN) == length(trans)
                for i=1:length(MEAN)
                    fprintf(fid1, '%s\t%f\t%f\t%f\t%f\n', trans{i}, X_opt(i), MEAN(i), CI(i,1), CI(i,2));
                    fprintf(fid_iso, '%s\t%f\t%f\t%f\t%f\t%s\n', trans{i}, X_opt(i), MEAN(i), CI(i,1), CI(i,2), name);
                end
                for i=1:length(MEAN)
                    for j=1:length(MEAN)
                        fprintf(fid1, '%f\t', C_IS(i,j));
                    end
                    fprintf(fid1,'\n');
                end
            end            
        else
            X_opt
            p
            CI
            C_IS
        end
    else
        continue;
    end    
end

fclose(fid);

if strcmp(genename,'all')        
    fclose(fid1);
    fclose(fid_gene);
    fclose(fid_iso);
end
