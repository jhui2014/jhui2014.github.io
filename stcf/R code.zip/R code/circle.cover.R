source("twoD.R")
source("common.R")

#data is a matrix of nx3
#each element of data contains the center and radius (x,y,r) of a circle

#call back function for TwoD
circle_shift = function(data, lambda) {
    return(data)
}

#call back function for TwoD
circle_val = function(data, i, x) {
    return(ifelse(in_circle(data[i,], x), -1, 0))
}

#call back function for TwoD
circle_min = function(data_s, modifier, suff_stat = NULL) {
    if (any(is.element(modifier[modifier > 0], suff_stat))) {
        stop("error")
    }
    suff_stat = union(suff_stat, modifier[modifier > 0])
    if (!all(is.element(-modifier[modifier < 0], suff_stat))) {
        stop("error")
    }
    suff_stat = setdiff(suff_stat, - modifier[modifier < 0])
    return(list(par = suff_stat, value = -length(suff_stat), suff_stat = suff_stat))
}

#call back function for TwoD
#finding intersection points of two circles
circle_intersect = function(data_s, i, j) {
    d = distance(data_s[i,1:2], data_s[j,1:2])
    if (d > data_s[i,3] + data_s[j,3]) {
      return(NULL)
    }
    a = (data_s[i,3]^2-data_s[j,3]^2+d^2)/(2*d)
    h=sqrt(data_s[i,3]^2-a^2)
    z = data_s[i,1:2]+a*(data_s[j,1:2]-data_s[i,1:2])/d
    w = z+h*(c(data_s[j,2]-data_s[i,2], data_s[i,1]-data_s[j,1]))/d
    t = z+h*(c(data_s[i,2]-data_s[j,2], data_s[j,1]-data_s[i,1]))/d
    return(rbind(w,t))
}

#finding intersection convex polygon of many circles
circle_intersection = function(circles) {
  n = nrow(circles)
  polygon = NULL
  if (n < 2) {
    return(NULL)
  }
  for (i in 1:(n-1)) {
    for (j in (i+1):n) {
      pts = circle_intersect(circles, i, j)
      if (is.null(pts)) {
        next
      }
      valid = T
      for (k in 1:nrow(pts)) {
        for (l in setdiff(1:n, c(i,j))) {
          if (!in_circle(circles[l,],pts[k,])) {
            valid = F
            break
          }
        }
        if (valid) {
          polygon = rbind(polygon, pts[k,])
        }
      }
    }
  }
  return(polygon)
}

#call back function for TwoD
circle_radius = function(data_s, i, center, theta) {
    v = c(cos(theta), sin(theta))
    dcenter = center - data_s[i,1:2]
    a = 1
    b = 2*sum(v * dcenter)
    c = sum(dcenter^2) - data_s[i,3]^2
    r = (- b + sqrt(b ^ 2 - 4 * a * c)) / (2 * a)
    return(r)
}

#call back function for TwoD
circle_point = function(data_s, i) {
  return(data_s[i,1:2])
}

#main function
circle_cover = function(data) {
    sol = twoD(data, g_shift = circle_shift, g_val = circle_val, g_min = circle_min, g_intersect = circle_intersect, g_radius = circle_radius, g_point = circle_point)
    if (length(sol$par) == 1) {
      return(list(par = data[sol$par[1],1:2], value = sol$value))
    }
    polygon = circle_intersection(data[sol$par,])
    return(list(par = polygon_center(polygon), value = sol$value))
}

#main function
circle_cover_points = function(radius, points) {
    points = matrix(points, ncol = 2)
    m = nrow(points)
    data = matrix(0, m, 3)
    for (i in 1:m) {
        data[i,] = c(points[i,1], points[i,2], radius)
    }
    return(circle_cover(data))
}
