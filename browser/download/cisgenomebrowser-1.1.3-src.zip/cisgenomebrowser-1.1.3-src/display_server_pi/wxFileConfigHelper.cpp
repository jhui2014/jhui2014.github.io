#include "wxFileConfigHelper.h"

void WriteIni(string file_name, string path, string value, bool condition) {
	wxFileConfig ini(wxEmptyString,wxEmptyString,wxS(file_name),wxEmptyString, wxCONFIG_USE_LOCAL_FILE | wxCONFIG_USE_NO_ESCAPE_CHARACTERS);
	if (condition) {
		ini.Write(wxS(path),wxS(value));
	} else {
		ini.DeleteEntry(wxS(path));
	}
}