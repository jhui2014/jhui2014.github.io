#include "display_motif.h"
#include "drawCommon.h"

display_motif::display_motif()
{

}

display_motif::display_motif(http_request* r)
{
	src_filename = "";
	pic_filename = "";
	req = r;
	multiple_motifs = default_multiple_motifs;
}

bool display_motif::load_from_file(string file_name)
{
	src_filename = ReadIni(file_name, "motif/src_filename", wxString(""));
	pic_filename = ReadIni(file_name, "motif/pic_filename", wxString(""));
	multiple_motifs = ReadIni(file_name, "motif/multiple_motifs",
		default_multiple_motifs);
	return true;
}

bool display_motif::update_params()
{
	bool updated = false;

	/*for (std::map<std::string, std::string>::const_iterator i = req->params_.begin(); i != req->params_.end(); i++) {
	if (i->first == "motif_filename") {
	src_filename = i->second;
	updated = true;
	} else if (i->first == "motif_pic_filename") {
	pic_filename = i->second;
	updated = true;
	}
	}*/

	if (req->params_.count("create_motif_session") > 0)
	{
		src_filename = req->params_["motif_filename"];
		multiple_motifs = (req->params_.count("multiple_motifs") > 0);
		updated = true;
	}

	return updated;
}

bool display_motif::write_to_file(string file_name)
{
	WriteIni(file_name, "motif/multiple_motifs", multiple_motifs,
		multiple_motifs != default_multiple_motifs);
	WriteIni(file_name, "motif/src_filename", src_filename, src_filename != "");
	WriteIni(file_name, "motif/pic_filename", pic_filename, pic_filename != "");
	return true;
}

string display_motif::get_html()
{
	html_formater my_html_formater;
	if (src_filename == "")
	{
		my_html_formater.load_from_template_file(template_path
			+ "new_motif_session.html");
	}
	else if (!multiple_motifs)
	{
		if (pic_filename == "")
		{
			pic_filename = get_random_pic_file_name();
		}
		/*		string command_line = string("\"") + module_path + "draw_figure.exe\" motif \"" + temp_path + pic_filename + "\" \"" + src_filename + "\"";
		call_external(command_line);*/
		if (!file_exists(temp_path + client_ip + pic_filename) || refresh)
		{
			draw_motif my_draw;
			my_draw.motif_filename = src_filename;
			my_draw.load_data();
			my_draw.prepare_data();
			my_draw.drawfile(temp_path + client_ip + pic_filename);
		}

		my_html_formater.load_from_template_file(template_path
			+ "draw_motif.html");
		my_html_formater.replace_keyword("$MOTIF_FILE_NAME$", server_temp_path + client_ip + pic_filename);
	}
	else
	{ //multiple_motifs
		if (pic_filename == "")
		{
			pic_filename = get_random_pic_file_name();
		}
		draw_motif_html my_draw;
		my_draw.motif_filename = src_filename;
		my_draw.load_data();
		my_draw.prepare_data();
		if (!my_draw.get_html(temp_path + client_ip + pic_filename, server_temp_path + client_ip + pic_filename, my_html_formater.buf))
			return error_html(my_draw.error_msg);
	}
	return my_html_formater.buf;
}

