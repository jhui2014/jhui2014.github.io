#include "stdlib.h"
#include "stdio.h"
#include "string.h"
#include "math.h"
#include "limits.h"
#include "time.h"

#include "StringLib.h"
#include "MatrixLib.h"
#include "RandomLib.h"
#include "MathLib.h"
#include "MotifLib.h"
#include "SequenceLib.h"
#include "GenomeLib.h"
#include "MicroarrayLib.h"
#include "AffyLib.h"
#include "WorkLib.h"

int menu_refflex_getmultiortholog(int argv, char **argc);

int main(int argv, char **argc)
{
	int nLen;
	int nseed;

	/* init rand */
	srand( (unsigned)time( NULL ) );
	if(strcmp(OS_SYSTEM, "WINDOWS") == 0)
	{
		nseed = (int)(rand()*1000/RAND_MAX);
	}
	else
	{
		nseed = rand()%1000;
	}
	rand_u_init(nseed);


	/* ---- */
	/* menu */
	/* ---- */
	menu_refflex_getmultiortholog(argv, argc);

	/* exit */
	exit(EXIT_SUCCESS);
}

int menu_refflex_getmultiortholog(int argv, char **argc)
{
	/* define */
	char strTargetPath[LINE_LENGTH];
	char strOutPath[LINE_LENGTH];
	char strParamPath[LINE_LENGTH];	
	int nColumn = 0;

	int nResult;
	int iOK;
	int cOK;
	int dOK;
	int oOK;
	int ni;

	/* ------------------------------- */
	/*    refflex_getmultiortholog     */
	/* -i target list                  */
	/* -c starting column (0-based)    */
	/* -d database info                */
	/* -o output                       */
	/* ------------------------------- */
	if(argv < 1)
	{
		printf("Error: parameter wrong!\n");
		exit(EXIT_FAILURE);
	}
	else if(argv == 1)
	{
		printf("/* ----------------------------- */\n");
		printf("    refflex_getmultiortholog      \n");
		printf(" -i path of target list           \n");
		printf(" -c starting column (0-based)     \n");
		printf("    the column where a UCSC refGene format record starts, e.g. NM_xxxxxx ...\n");
		printf("    default = 0                   \n");
		printf(" -d database infomation           \n");
		printf(" -o path for saving retrieved orthologs \n");
		printf(" example: \n");
		printf("    getrefgenemultiortholog -i testrefgene.txt -c 6 -d orthologsetting.txt -o testortho\n");
		printf("/* ----------------------------- */\n");
		exit(EXIT_SUCCESS);
	}

	iOK = 0;
	cOK = 0;
	dOK = 0;
	oOK = 0;
	
	ni = 1;
	while(ni < argv)
	{
		if(strcmp(argc[ni], "-i") == 0)
		{
			ni++;
			strcpy(strTargetPath, argc[ni]);
			iOK = 1;
		}
		else if(strcmp(argc[ni], "-c") == 0)
		{
			ni++;
			nColumn = atoi(argc[ni]);
			cOK = 1;
		}
		else if(strcmp(argc[ni], "-d") == 0)
		{
			ni++;
			strcpy(strParamPath, argc[ni]);
			dOK = 1;
		}
		else if(strcmp(argc[ni], "-o") == 0)
		{
			ni++;
			strcpy(strOutPath, argc[ni]);
			oOK = 1;
		}
		else 
		{
			printf("Error: unknown parameters!\n");
			exit(EXIT_FAILURE);
		}

		ni++;
	}

	

	if((iOK == 0) || (dOK == 0) || (oOK == 0))
	{
		printf("Error: Input Parameter not correct!\n");
		exit(EXIT_FAILURE);
	}
	else
	{
		nResult = RefFlex_GetMultiOrtholog_Main(strTargetPath, nColumn, strParamPath, strOutPath);
	}

	/* return */
	return nResult;
}
