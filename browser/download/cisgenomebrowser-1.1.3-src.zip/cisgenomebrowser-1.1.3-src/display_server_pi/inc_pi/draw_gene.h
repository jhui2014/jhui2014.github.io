#ifndef DRAW_GENE_H
#define DRAW_GENE_H

#include "draw_signal.h"
#include "stl.h"
#include "UserDefinedType.h"

class wxMemoryDC;
class gene_struct;

class draw_gene: public draw_signal
{
private:
	vector<int> line_ends, gene_lines, gene_text_starts, gene_starts, gene_ends;
	int line_height;
	bool no_data;
public:
	vector<gene_struct> genes;
	string gene_filename;
	string chr;
	int startpos, endpos;
	bool draw_exon_num;
	int exon_height;
	int gene_height;
	int line_gap;
	int arrow_height;
	int gene_gap;	
	
	int gene_font_size;
	bool draw_gene_name;
	int max_height;	
	bool draw_gene_density;

	draw_gene();
	virtual string print_usage();
	virtual bool get_params(const vector<string> &params);
	virtual bool load_data();
	virtual bool prepare_data();
	virtual bool draw_contents(wxMemoryDC *pdc, const PIRect rect);
	virtual void get_intervals();
};

#endif //DRAW_GENE_H
