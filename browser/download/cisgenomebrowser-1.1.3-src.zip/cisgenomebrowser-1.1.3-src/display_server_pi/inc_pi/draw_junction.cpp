#include "draw_junction.h"
#include "genefile.h"
#include "string_operation.h"
#include "math_utils.h"
#include "wx/dcmemory.h"
#include "wx/image.h"
#include "wxDCHelper.h"
#include "../shared_data.h"
#include "../drawCommon.h"

draw_junction::draw_junction(const string& data_file_name, const string& exon1, const string& exon2)
{
	data_file_name_ = data_file_name;

	vector<string> strs1 = string_tokenize(exon1, ":-");
	vector<string> strs2 = string_tokenize(exon2, ":-");
	assert(strs1.size() == 3);
	assert(strs2.size() == 3);
	assert(strs1[0] == strs2[0]);
	chr_ = strs1[0];
	int s1 = str2int(strs1[1]), e1 = str2int(strs1[2]);
	int s2 = str2int(strs2[1]), e2 = str2int(strs2[2]);
	startpos_[0] = min(s1, s2);
	startpos_[1] = max(s1, s2);
	endpos_[0] = min(e1, e2);
	endpos_[1] = max(e1, e2);

	left_axis = right_axis = false;
	bottom_axis = top_axis = false;
	box = false;
	domainlow = 2700000;
	domainhigh = 2700080;

	h_grids = false;
	v_grids = false;
}

string draw_junction::print_usage() {
	return "Not implemented";
}

bool draw_junction::get_params(const vector<string> &params) {
	return true;
}

bool draw_junction::load_data() {
	/*
	assert(cache_genefiles);
	genefile* tempgenefile = NULL;
	if (get_genefile_from_cache(data_file_name_, error_msg, tempgenefile))
	{
		tempgenefile->build_interval_lists();
		for (int i = 0; i < 2; ++i) {
			vector<gene_struct> gene;
			tempgenefile->search_by_region(chr_, startpos_[i], endpos_[i], gene);
		}
	}
	*/
	GenerateFakeData();
	// TODO:
	size.cx = 1650;
	size.cy = 420;
	return true;
}

bool draw_junction::prepare_data() {
	if (!draw_figure_structure::prepare_data())
		return false;	
	return draw_axis::prepare_data();
}

bool draw_junction::draw_contents(wxMemoryDC *pdc, const PIRect rect) {
	/*
	if (!draw_axis::draw_contents(pdc, rect))
	return false;
	*/
	
	wxFont oldFont = pdc->GetFont();
	wxFont* font = wxFont::New(wxSize(8, 20), wxFONTFAMILY_SWISS, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL, false, "Courier New");
	pdc->SetFont(*font);

	const int margin = 50;	
	PISize textsize = wxDCHelper::GetTextExtent(pdc, wxString("W"));
	int letter_sizex = textsize.cx, letter_sizey = textsize.cy;

	NucleotideSource ns;
	for (int i = 0; i < 2; ++i) {
		int xoffset = i * (margin + letter_sizex * (endpos_[0] - startpos_[0])), yoffset = 0;
		string nt = ns.GetNucleotides(chr_, startpos_[i], endpos_[i], false);
		for (int k = 0; k < nt.length(); ++k) {
			pdc->SetTextForeground(ns.GetNucleotideColor(nt[k], startpos_[i]+k));
			pdc->DrawText(wxS(nt.substr(k,1)), xoffset + k * letter_sizex, yoffset);
		}
		yoffset += (letter_sizey + 20);
		for (int j = 0; j < genes_[i].size(); ++j) {
			nt = ns.GetNucleotides(chr_, genes_[i][j].txStart, genes_[i][j].txEnd, true);
			for (int k = 0; k < nt.length(); ++k) {
				pdc->SetTextForeground(ns.GetNucleotideColor(nt[k], genes_[i][j].txStart+k));
				pdc->DrawText(wxS(nt.substr(k,1)), xoffset + (genes_[i][j].txStart - startpos_[i] + k) * letter_sizex, yoffset);
			}
			yoffset += letter_sizey;
		}
	}
	delete font;
	pdc->SetFont(oldFont);
	return true;
}
