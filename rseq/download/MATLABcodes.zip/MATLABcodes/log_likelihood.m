function [ f ] = log_likelihood( A, T, X )

epsilon = 1e-10;

X_new = X + epsilon;

f = - sum(A*X_new) + T * log(A*X_new);