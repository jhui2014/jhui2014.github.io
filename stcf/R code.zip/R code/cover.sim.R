#simulation on convex shape placement

rm(list = ls())
source("convex.polygon.cover.R")
source("common.R")
source("circle.cover.R")
set.seed(1234)

pdf("cover.pdf", width = 6, height = 2)
par(mfrow = c(1, 3))
par(mar=c(3, 3, 0, 0) + 0.1, mgp=c(2,0.8,0))

for (shape in c("circle", "square", "hexagon")) {
    n = 30
    points = matrix(runif(n * 2), ncol = 2)
    plot(
        points,
        pch = 20,
        xlim = c(0, 1),
        ylim = c(0, 1),
        ann = F
    )
    if (shape == "circle") {
        radius = 0.3
        sol = circle_cover_points(radius, points)
        draw_circle(c(sol$par, radius))
    } else {
        if (shape == "square") {
            polygon = polygon_centering(matrix(c(0, 0, 1, 1, 0, 1, 1, 0) / 2, ncol = 2))
        } else if (shape == "diamond") {
            polygon = polygon_centering(matrix(c(0, 1, 0, -1, -1, 0, 1, 0) / 3, ncol = 2))
        } else if (shape == "hexagon") {
            polygon = polygon_centering(matrix(c(
                0, 0, 0.5, 1, 1, 0.5, 0, 1, 1.5, 1, 0,-0.5
            ) /
                3, ncol = 2))
        }
        sol = convex_polygon_cover_points(polygon, points)
        p = polygon + rep(sol$par, each = nrow(polygon))
        draw_polygon(p)
    }
}

dev.off()
