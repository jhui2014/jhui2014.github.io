#ifndef DRAW_REGBAR_H
#define DRAW_REGBAR_H

#include "draw_signal.h"

class draw_regbar: public draw_signal
{
public:
	bool box;
	bool no_data;

	vector<string> regbar_filenames;
	string chr;
	int startpos, endpos;

	draw_regbar();
	virtual string print_usage();
	virtual bool get_params(const vector<string> &params);
	virtual bool load_data();
	virtual bool prepare_data();
};

#endif //DRAW_REGBAR_H
