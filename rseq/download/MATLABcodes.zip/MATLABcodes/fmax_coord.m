function [ X, f ] = fmax_coord( A, T, X )

epsilon = 1e-10;

[m,n] = size(A);

f = log_likelihood(A, T, X);

it = 0;

max_it = 10000;

while 1
    for i=1:n
        X = fmax_coord_i(A, T, X, i);
    end
    
    new_f = log_likelihood(A, T, X);
    
    if abs(new_f - f) < epsilon
        f = new_f;
        return;
    end    
    
    f = new_f;
    
    if it < max_it
        it = it + 1;
    else 
        break;
    end
end

if it >= max_it
    disp('warning: maximum iteration exceeded.');
end