#include "display_type.h"

display_type::display_type() : req(NULL)
{
	refresh = false;
}

display_type::display_type(http_request* r) :req(r)
{
}

display_type::~display_type()
{
	cleanup();
}

void display_type::generate_hrefs(vector<PIRect> &map_rects,vector<string> &map_strings)
{
}

void display_type::cleanup()
{
}
