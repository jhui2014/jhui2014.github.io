#ifndef _DISPLAY_TRACK_
#define _DISPLAY_TRACK_

#include "display_type.h"
#include "inc_pi/stl.h"
#include "inc_pi/UserDefinedType.h"
#include "inc_pi/math_utils.h"

class display_genome;
struct http_request;

class display_track: public display_type
{
public:
	display_genome *genome;
	string name;
	string title;
	bool top_axis;
	bool bottom_axis;
	bool fast_draw;
	string pic_filename;
	interval_set intervals;
	bool fold;

	display_track();
	display_track(http_request* r, string track_name,
		display_genome *g);
	virtual bool load_from_file(string file_name);
	virtual bool update_params();
	virtual bool write_to_file(string file_name);
	virtual string get_html();
	virtual string get_configure_html();
	virtual bool generate_pic_file(bool get_intervals = false);
	virtual void generate_hrefs(vector<PIRect> &map_rects,
		vector<string> &map_strings);
	virtual string type()=0;
};

#endif