#ifndef _MAIN_THREAD_H_
#define _MAIN_THREAD_H_

class webserver;
class http_request;

void startup();
void WebServerMainLoop(webserver* server, void *app);
void main_handler(http_request* r);
void cleanup();

#endif
