#minimized sum of truncated quadratic functions in 1D
#each summand is weight[i] * min((x - mu[i])^2, lambda[i])
#if specified using coef, then each summand is min(coef[i,1] * x^2 + coef[i,2] * x + coef[i,3], lambda[i])

quadratic.1D = function(coef = NULL, mu = NULL, lambda = Inf, weights = 1) {
    if (!is.null(coef)) {
        a = coef[, 1]
        b = coef[, 2]
        c = coef[, 3]
        weights = a
        mu = -b / (2 * a)
        offset = c - mu^2 * a
        lambda = (lambda - offset) / a
        offset = sum(offset)
    } else {
        offset = 0
    }
    m = length(mu)
    if (length(lambda) == 1) lambda = rep(lambda, m)
    if (length(weights) == 1) weights = rep(weights, m)
    untruncated = (lambda == Inf)
    truncated = (lambda != Inf & lambda > 0)
    mu.l = mu[truncated] - sqrt(lambda[truncated])
    mu.u = mu[truncated] + sqrt(lambda[truncated])
    end.pts = c(mu.l, mu.u)
    pts.idx = rep(which(truncated), 2)
    s = sort(end.pts, index.return = T)
    pts.idx = pts.idx[s$ix]
    included = untruncated
    w.sum = sum(weights[included])
    w.mu.sum = sum(weights[included] * mu[included])
    w.mu2.sum = sum(weights[included] * mu[included]^2)
    w.lambda.sum = sum(weights[!untruncated] * lambda[!untruncated])
    par = ifelse(w.sum > 0, w.mu.sum / w.sum, 0)
    value = w.mu2.sum - w.sum * par ^ 2 + w.lambda.sum
    for (p in pts.idx) {
        included[p] = !included[p]
        sign = included[p] * 2 - 1
        w.sum = w.sum + sign * weights[p]
        w.mu.sum = w.mu.sum + sign * weights[p] * mu[p]
        w.mu2.sum = w.mu2.sum + sign * weights[p] * mu[p] ^ 2
        w.lambda.sum = w.lambda.sum - sign * weights[p] * lambda[p]
        if (w.sum > 0) {
            x = w.mu.sum / w.sum
            f = w.mu2.sum - w.sum * x ^ 2 + w.lambda.sum
            if (f < value) {
                value = f
                par = x
            }
        }
    }
    return(list(par = par, value = value + offset))
}

obj.value.quadratic.1D <- function(x, coef = NULL, mu = NULL, lambda = Inf, weights = 1) {
    if (!is.null(coef)) {
        a = coef[, 1]
        b = coef[, 2]
        c = coef[, 3]
        return(sum(pmin(a*x^2+b*x+c, lambda)))
    } else {
        return(sum(weights * pmin((x - mu) ^ 2, lambda)))
    }
}

test.quadratic.1D = function() {
    m = 100
    ngrid = 1000
    n.Inf = 5
    mu = rnorm(m)
    x = seq(-3, 3, length.out = ngrid)
    y = rep(0, ngrid)
    lambda = runif(m, -0.05, 0.1)
    weights = runif(m)
    lambda[1:n.Inf] = Inf
    weights[1:n.Inf] = 0.01
    for (i in 1:ngrid) {
        y[i] = obj.value.quadratic.1D(x[i], mu = mu, lambda = lambda, weights = weights)
    }
    sol = quadratic.1D(mu = mu, lambda = lambda, weights = weights)
    print(sol)
    par(mar = c(4, 4, 1, 1) + 0.1)
    plot(x, y, type = 'l', xlab = "d", ylab = "G'(d)")
    abline(v = sol$par, col = 4, lty = 2)

    a = runif(m)
    a[1:n.Inf] = 0.01
    b = rnorm(m) * 2 * a
    c = rnorm(m)
    lambda = runif(m, -0.05, 0.1) * a + c - b^2/4/a
    lambda[1:n.Inf] = Inf
    for (i in 1:ngrid) {
        y[i] = obj.value.quadratic.1D(x[i], coef = cbind(a,b,c), lambda = lambda)
    }
    sol = quadratic.1D(coef = cbind(a, b, c), lambda = lambda)
    print(sol)
    par(mar = c(4, 4, 1, 1) + 0.1)
    plot(x, y, type = 'l', xlab = "d", ylab = "G'(d)")
    abline(v = sol$par, col = 4, lty = 2)
}

#test.quadratic.1D()