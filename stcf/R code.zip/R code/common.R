#common utility functions

cart_polar = function(x) {
  #input: x is a nx2 matrix of Cartesian coordinate. 
  #output: a nx2 matrix of radiuses and angles.
  x = matrix(x, ncol = 2)
  r = sqrt(rowSums(x ^ 2))
  theta = acos(x[, 1] / r)
  theta[x[, 2] < 0] = 2 * pi - theta[x[, 2] < 0]
  theta[r == 0] = 0
  return(cbind(r, theta))
}

polar_cart = function(p) {
  #input: p is a nx2 matrix of radius and angles.
  #output: a nx2 matrix of Cartesian coordinate.
  p = matrix(p, ncol = 2)
  x = p[,1] * cos(p[,2])
  y = p[,1] * sin(p[,2])
  return(cbind(x, y))
}


in_range = function(x, interval) {
  return(x >= interval[1] && x <= interval[2])
}

distance = function(x, y) {
  return(sqrt(sum((x - y) ^ 2)))
}

line_intersection = function(x1, x2, y1, y2) {
  A = cbind(x2 - x1, y1 - y2)
  if (abs(det(A)) < 1e-6) {
    return(NULL)
  }
  scale = solve(A, y1 - x1)
  position = x1 + scale[1] * (x2 - x1)
  return(list(position = position, scale = scale))
}

in_polygon = function(polygon, x) {
  n = nrow(polygon)
  theta = 0
  for (i in 1:n) {
    j = (i %% n) + 1
    theta_i = cart_polar(polygon[i,] - x)[2]
    theta_j = cart_polar(polygon[j,] - x)[2]
    dtheta = theta_i - theta_j
    while (dtheta > pi) {
      dtheta = dtheta - 2 * pi
    }
    while (dtheta < -pi) {
      dtheta = dtheta + 2 * pi
    }
    theta = theta + dtheta
  }
  return(abs(theta) > pi)
}

polygon_centering = function(polygon) {
  if (is.null(polygon)) {
    return(NULL)
  } else {
    return(polygon - rep(polygon_center(polygon), each = nrow(polygon)))
  }
}

polygon_center = function(polygon) {
  if (is.null(polygon)) {
    return(NULL)
  } else {
    return(colMeans(polygon))
  }
}


#tailor a convex polygon by line x1 -> x2, choose the side where y is on
tailor_convex_polygon = function(polygon, x1, x2, y) {
  result = NULL
  n = nrow(polygon)
  for (i in 1:n) {
    x = line_intersection(x1, x2, y, polygon[i,])
    if (is.null(x) || !in_range(x$scale[2], c(0, 1))) {
      result = rbind(result, polygon[i,])
    }
    j = (i %% n) + 1
    x = line_intersection(x1, x2, polygon[i,], polygon[j,])
    if (!is.null(x) && in_range(x$scale[2], c(0, 1))) {
      result = rbind(result, x$position)
    }
  }
  return(unique(result))
}

#find the convex intersection of two convex polygons
convex_polygon_intersection = function(polygon_1, polygon_2) {
  if (is.null(polygon_1)) {
    return(polygon_2)
  }
  if (is.null(polygon_2)) {
    return(polygon_1)
  }
  result = polygon_1
  n = nrow(polygon_2)
  for (i in 1:n) {
    if (is.null(result) || nrow(result) == 0) {
      return(NULL)
    }
    j = (i %% n) + 1
    k = (j %% n) + 1
    result = tailor_convex_polygon(result, polygon_2[i,], polygon_2[j,], polygon_2[k,])
  }
  return(result)
}

in_circle = function(circle, x) {
  return (distance(x, circle[1:2]) <= circle[3])
}

draw_polygon = function(polygon, ...) {
  lines(rbind(polygon, polygon[1,]), ...)
}

draw_circle = function(circle,n=100, ...) {
  theta = seq(0,pi*2,length.out = n)
  polygon=rep(circle[1:2], each=n) + circle[3] * cbind(cos(theta), sin(theta))
  draw_polygon(polygon, ...)
}

hard.threshold = function(x, lambda) {
  x[abs(x) < lambda] = 0
  return(x)
}


summarize = function(result, mark.min = NULL, tiny.sem = F, digits = 0) {
    mean.result = colMeans(result)
    sem.result = apply(result, 2, sd) / sqrt(dim(result)[1])
    if (is.null(mark.min)) {
        mark.ind = NULL
    } else if (mark.min) {
        mark.ind = (mean.result == min(mean.result))
    } else {
        mark.ind = (mean.result == max(mean.result))
    }
    mean.result = format(round(mean.result, digits), nsmall = digits)
    sem.result = format(round(sem.result, digits), nsmall = digits)
    sem.result = paste("(", sem.result, ")", sep = "")
    if (tiny.sem) {
        sem.result = paste("{\\tiny", sem.result, "}", sep = "")
    }
    if (!is.null(mark.ind)) {
        sem.result[mark.ind] <- paste(sem.result[mark.ind], "*")
    }
    return(paste(mean.result, sem.result))
}

bold <- function(x) {
    l = nchar(x)
    last_char = substr(x, l, l)
    if (last_char == "*") {
        x = substr(x, 1, l - 2)
        paste('{\\textbf{', x, '}}', sep = '')
    } else {
        x
    }
}

gaussian.blur = function(z, kernel.size = 5){
    n = nrow(z)
    kernel = matrix(0, kernel.size, kernel.size)
    for (i in 1:kernel.size) {
        for (j in 1:kernel.size) {
            kernel[i,j] = dnorm(i-(kernel.size+1)/2) * dnorm(j-(kernel.size+1)/2)
        }
    }
    kernel = kernel / sum(kernel)
    z1 = matrix(0, n+kernel.size-1, n+kernel.size-1)
    z1[((kernel.size+1)/2):(n+(kernel.size-1)/2), ((kernel.size+1)/2):(n+(kernel.size-1)/2)] = z
    z2 = matrix(0, n, n)
    for (i in 1:n) {
        for (j in 1:n) {
            z2[i,j] = sum(kernel * z1[i:(i+kernel.size-1), j:(j+kernel.size-1)])
        }
    }
    return(z2)
}

rowSDs = function(x) {
	return(apply(x, 1, sd))
}

colSDs = function(x) {
	return(apply(x, 2, sd))
}

grid.search = function(f, xrange = c(0,1), yrange = c(0,1), xgridnum = 100, ygridnum = 100, contour.plot = F, ...) {
    x = seq(xrange[1], xrange[2], length.out = xgridnum)
    y = seq(yrange[1], yrange[2], length.out = ygridnum)
    z = matrix(rep(NA, xgridnum * ygridnum), c(ygridnum, xgridnum))
    
    value = Inf
    par = NULL
    for (i in 1:xgridnum) {
        for (j in 1:ygridnum) {
            z[i, j] = f(c(x[i], y[j]))
            if (z[i, j] < value) {
                value = z[i, j]
                par = c(x[i],y[j])
            }
        }
    }
    #####################Contour plot
    if (contour.plot) {
        require(grDevices)
        filled.contour3(x = x, y = y, z = z, color = terrain.colors, xlim = xrange, ylim = yrange, asp = 1, ...)
        points(x = par[1], y = par[2], pch = 3)
    }
    return(list(par = par, value = value))
}