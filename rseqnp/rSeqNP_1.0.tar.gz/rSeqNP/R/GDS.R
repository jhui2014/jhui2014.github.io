GROUP_CUT=100 
#We require the number of each group of genes that have the same number of isoforms should be at least 100.
#We pool less<100 genes together

#Calculate the GDS and the associated p-values and FDR
GDS=function(isoform.info, iso.exp, type, outcome, gamma=NULL, nperm, seed)
#isoform.info contains the gene_name, isoform_number (both in isoform level format) and the T statistic
#gene.info contains the gene.name and isoform.number (both in gene level format)
#isoform.exp is the isoform expression matrix (exp_object$iso.exp)
#type tells the study design; outcome is the outcome vector; gamma is censored status vector (survival only)
#nperm is the number of permutations
{
#1.calculate the GDS (Sums of square of T) from data
  #first need to sort isoform result again to match the gene.exp dataframe
  #sort order: isoform_number, gene_name
  cat("Begin the permutation test based on GDS score.\n")
  isoform.info=isoform.info[order(isoform.info$isoform_number,isoform.info$gene_name),]
  Tj=isoform.info$Tj #need to change name
  Tj_sq=Tj^2 #calculate the square of the statistic
  temp=data.frame(gene.name=isoform.info[,1],Tj_sq) #bind the gene name and the square together
  GDS_data=ddply(temp, .(gene.name),summarise,GDS=sum(Tj_sq)) #sum up T_sq by gene name
  
  gene.name=as.character((isoform.info[,1]))
  gene.info=as.data.frame(table(gene.name))
  gene.info=data.frame(gene.name=gene.info[,1],isoform.number=gene.info[,2])
  GDS_data=merge(gene.info[,1:2], GDS_data, by='gene.name') #merge with the isoform.number for each gene
  GDS_data=GDS_data[order(GDS_data$isoform.number,GDS_data$gene.name),] #here need to sort to match iso.exp

#2. group the genes by their number of isoforms
  isoform_number=isoform.info$isoform_number #isoform number vector--isoform level
  isoform.number=gene.info$isoform.number #isoform number vector--gene level  
  n_iso=nrow(isoform.info) #total number of isoforms  
  n_gene=nrow(gene.info) #total number of genes
  n_sample=length(outcome)
  
  table_iso=as.data.frame(table(isoform_number)) #contain the levels of isoform number--long format, associate with isoform names
  colnames(table_iso)=c('isoform.number', 'isoform.count')

  table_gene=as.data.frame(table(isoform.number)) #contain the levels of isoform number--short format, associate with gene names
  colnames(table_gene)[2]='gene.count'

  iso_count_table=merge(table_iso, table_gene, by='isoform.number')
  iso_count_table$isoform.number=as.numeric(as.character(iso_count_table$isoform.number))
  iso_count_table=iso_count_table[order(iso_count_table$isoform.number),]
  #print(iso_count_table)  

  iso_count_level=dim(iso_count_table)[1]
  #print(iso_count_level)  

  cut_index=which(iso_count_table$gene.count<GROUP_CUT)[1] #get the first index where the number of genes in the group < 100
  #print(cut_index)

  if( (!is.na(cut_index))&&(cut_index<iso_count_level) )
  {
    
    cat(paste('Genes that contain greater or equal to ', iso_count_table$isoform.number[cut_index], ' isoforms will be pooled together in the permutation test.\n',sep=''))  
    #sum up the groups with less than 100 genes 
    com_iso_count=colSums(iso_count_table[(cut_index:iso_count_level),2:3])
    com_iso_count=c(isoform.number=iso_count_table[cut_index,1], com_iso_count)
        
    #this is the new isoform count table
    iso_count_new=rbind(iso_count_table[1:(cut_index-1),],com_iso_count)
    
  }else #if all groups have number of genes greater than 100
  {
    cut_index=iso_count_level
    iso_count_new=iso_count_table
  }
  
  #print(cut_index)
  cum_iso=c(0, cumsum(iso_count_new$isoform.count))
  cum_gene=c(0, cumsum(iso_count_new$gene.count))

  iso_count_cum=data.frame(isoform.number=c(0,iso_count_new[,1]), cum_iso, cum_gene)

#3. estimate the FDR and p-values using permutation  

  result_P=NULL #contains the result for permutation plug-in method

  for(i in 1:cut_index)
  {
    if( (cut_index<iso_count_level) && (i==cut_index) )
	  { 
	    cat(paste('Testing genes with equal to or more than ', iso_count_new$isoform.number[i], ' isoforms.\n',sep=''))
	  } else 
	  {
	    cat(paste('Testing genes with ', iso_count_new$isoform.number[i], ' isoforms.\n',sep=''))
	  }
	
    perm_by_group=ceiling(nperm/iso_count_new$gene.count[i]) #this is the actual number of permutations for each group of genes that have the same number of isoform
    iso_bin=iso.exp[((1+iso_count_cum$cum_iso[i]):iso_count_cum$cum_iso[i+1]),] #this is the isoform expression matrix (data) for genes with i isoforms 
    GDS_bin=GDS_data[((1+iso_count_cum$cum_gene[i]):iso_count_cum$cum_gene[i+1]),] #this is the GDS for genes with i isoforms
    
	  set.seed(seed)
	
	  #do the permutations
	  if (type == 'twoclass')
    { 
      #Wilcoxon rank sum (WRS) statistic	
      perm_index=NPS.Permu.Ind.Mat(outcome,perm_by_group,twoclass=T)
      T_perm=calculate.WRS.stat(iso_bin[,4:(n_sample+3)], perm_index)
    } else if (type == 'twopaired')
    {    
	  #Wilcoxon signed rank (WSR) statistic
      perm_index=NPS.Permu.Ind.Mat(outcome,perm_by_group,twoclass=T, paired=T)
      T_perm=calculate.WSR.stat(iso_bin[,4:(n_sample+3)], perm_index)    
    } else if (type == 'quant')
    { 
      #Spearman's correlation coefficient (SCC) statistic	
      perm_index=NPS.Permu.Ind.Mat(outcome, perm_by_group)
      T_perm=calculate.SCC.stat(iso_bin[,4:(n_sample+3)], outcome, perm_index)    
    } else if (type == 'survi')
    {    
	  #Cox model's score test for survival outcome
      perm_index=NPS.Permu.Ind.Mat(outcome, perm_by_group)
      T_perm=calculate.CS.stat(data=iso_bin[,4:(n_sample+3)], time=outcome, censor=gamma, perm_index=perm_index)    
    } else
    {
	  #KW test for multi-group data
      perm_index=NPS.Permu.Ind.Mat(outcome, perm_by_group[i])
      T_perm=calculate.KW.stat(iso_bin[,4:(n_sample+3)], outcome, perm_index)    
    }
    
    #compute the sums of squares of the permuted statistics
	  T_sq_perm=(T_perm)^2
    T_sq_perm=data.frame(gene_name=iso_bin[,1],T_sq_perm)
    GDS_perm=ddply(T_sq_perm, "gene_name", numcolwise(sum))
    GDS_perm=GDS_perm[order(GDS_perm$gene_name),]
  
    #Using permutation plug-in method to estimate p value and FDR 
    GDS_n=as.numeric(GDS_bin[,3])
    np.obj=list(tt=GDS_n, ttstar0=apply(GDS_perm[,-1],2,as.numeric))
    FDR_res=rSeqNP.FDR.Table(np.obj,dim(GDS_perm)[1])
   
    if( (cut_index<iso_count_level) && (i==cut_index) )
    {
      temp=paste(iso_count_new$isoform.number[i],'>=',sep='')
      result_P=rbind(result_P,FDR.Sum(GDS_bin[,1],FDR_res,temp))
    } else
    {
      result_P=rbind(result_P,FDR.Sum(GDS_bin[,1],FDR_res,iso_count_new$isoform.number[i]))
    }
    
  }

   result_P=result_P[order(result_P$iso.num, result_P$p.plugin, result_P$GDS, result_P$gene.name),]

   return(result_P)
}
