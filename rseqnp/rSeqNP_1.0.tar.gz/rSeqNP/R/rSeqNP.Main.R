#The main function of rSeqNP
rSeqNP.Main=function(exp_object, type, outcome, gamma=NULL, nperm=1e6, seed=100, exp.mean=0.5, low.exp=0.5)
{
  #may need to add a few lines to check arguments
  
  time_st <- proc.time()
  options(warn=-1)
  #library(plyr)
  
  result <- NULL
   
  iso.exp=rSeqNP.Filter(exp_object$iso.exp, exp.mean, feature='isoform')

  gene.exp=rSeqNP.Filter(exp_object$gene.exp, exp.mean, feature='gene')

  #re-organize the filtered expression matrix
  #give the column names of the expression matrix, in case the user does not name them consistently
  colnames(iso.exp)[1:3]=c('gene_name','isoform_name','isoform_number')
  colnames(gene.exp)[1:2]=c('gene.name','isoform.number')
  
  #isoform exp:
  gene_name=as.character(iso.exp[,1])
  gene_info=as.data.frame(table(gene_name)) #get the isoforms numbers for each gene

  iso.exp=merge(iso.exp, gene_info, by='gene_name')
  iso.exp=data.frame(gene_name=iso.exp[,1], isoform_name=iso.exp[,2], isoform_number=iso.exp$Freq, iso.exp[,4:ncol(iso.exp)])
  iso.exp=iso.exp[order(iso.exp$isoform_number, iso.exp$gene_name),]
  
  #gene exp:
  gene.name=as.character(gene.exp[,1])
  gene.info=as.data.frame(table(gene.name)) #get the isoforms numbers for each gene
  gene.exp=merge(gene.exp, gene.info, by='gene.name')
  gene.exp=data.frame(gene.name=gene.exp[,1], isoform.number=gene.exp$Freq, gene.exp[,3:ncol(gene.exp)])
  gene.exp=gene.exp[order(gene.exp$isoform.number, gene.exp$gene.name),]
  
  exp_object=list(iso.exp=iso.exp, gene.exp=gene.exp)
    
  if (type == 'twoclass')
  {
    
    cat("This is unpaired two group comparison.\n")
    result = Twogroup(exp_object, outcome, nperm, seed, low.exp)
      
  } else if (type == 'twopaired')
  {
    
    cat("This is paired two group comparison.\n")
    result = Twopaired(exp_object, outcome, nperm, seed, low.exp)
    
  } else if (type == 'quant')
  {
    
    cat("This is quantitative outcome data.\n")
    result = Quantoutcome(exp_object, outcome, nperm, seed)
    
  } else if (type == 'survi')
  {
    
    cat("This is survival outcome data.\n")
    result = Survi(exp_object, outcome, gamma, nperm, seed)
    
  } else if (type == 'multiclass')
  {
    cat("This is multi-group comparison.\n")
    result = Multigroup(exp_object, outcome, nperm, seed)
  } else { ##type argument is not correctly specified
    
    cat("\"type\" argument is not correctly specified! Check argument.")
  }
  
  options(warn=0)
  time_ed <- proc.time()
  cat('Running time is:\n')
  print(time_ed - time_st)
  
  return(result)
    
}

############################################################
#		Filter genes or isoforms with too small expressions
############################################################
rSeqNP.Filter <- function(dat, exp.mean, feature)
{
    if(feature=='isoform') ## input is isoform expression matrix
    {
	    n_sample=ncol(dat)-3
	    N=apply(dat[,4:(n_sample+3)],2,as.numeric) #This is the expression data, pure numbers
	    keep = (rowMeans(N) >= exp.mean) #index for effective data
	    cat(paste( length(keep)-sum(keep), ' isoforms has been filtered because their expression levels are too low.\n', sep=''))	    
	  } else{
	    n_sample=ncol(dat)-2
	    N=apply(dat[,3:(n_sample+2)],2,as.numeric) #This is the expression data, pure numbers
	    keep = (rowMeans(N) >= exp.mean) #index for effective data
	    cat(paste( length(keep)-sum(keep), ' genes has been filtered because their expression levels are too low.\n', sep=''))	    
	  }
	
    return(dat[keep,])
}
