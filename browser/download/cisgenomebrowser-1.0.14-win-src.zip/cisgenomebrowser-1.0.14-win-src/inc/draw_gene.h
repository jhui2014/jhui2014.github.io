#ifndef DRAW_GENE_H
#define DRAW_GENE_H

#include "draw_signal.h"
#include "genefile.h"
#include "string_operation.h"
#include "file_operation.h"
#include "math_utils.h"
#include <atlimage.h>

class draw_gene: public draw_signal
{
private:
	vector<int> line_ends, gene_lines, gene_text_starts, gene_starts, gene_ends;
	int line_height;
	bool no_data;
public:
	vector<gene_struct> genes;
	string gene_filename;
	string chr;
	int startpos, endpos;
	bool draw_exon_num;
	int exon_height;
	int gene_height;
	int line_gap;
	int arrow_height;
	int gene_gap;

	int gene_font_size;
	bool draw_gene_name;
	int max_height;
	bool draw_gene_density;

	draw_gene();
	virtual string print_usage();
	virtual bool get_params(const vector<string> &params);
	virtual bool load_data();
	virtual bool prepare_data();
	virtual bool draw_contents(CDC *pdc, const CRect rect);
	virtual void get_intervals();
};

inline draw_gene::draw_gene(){
	top_axis = bottom_axis = true;
	left_space = right_space = true;

	gene_filename = "";
	chr = "";
	startpos = endpos = -1;
	line_ends.clear();
	gene_lines.clear();
	gene_text_starts.clear();
	gene_starts.clear();
	gene_ends.clear();
	line_height = 0;
	genes.clear();
	no_data = false;
	draw_exon_num = true;
	exon_height = 20;
	gene_height = 20;
	line_gap = 5;
	arrow_height = 10;
	gene_gap = 10;

    gene_font_size = font_size;
	draw_gene_name = true;
	max_height = 400;
	draw_gene_density = false;
}

inline string draw_gene::print_usage(){
	return "<gene file> </region:<chr>:<sequence start position>-<sequence end position>> [/width:<picture width>] [/axis:xxxx]\n";
}

inline bool draw_gene::get_params(const vector<string> &params){
	if (params.size() == 0) return false;
	gene_filename = params[0];

	bool good_options = true;
	for (int i=1; i<(int)params.size(); i++) {
		string option = params[i];

		string command = "";
		string parameter = "";
		if (option[0] != '/') {
			good_options = false;
			break;
		}
		size_t index = option.find (":");
		if (index != string::npos ) {
			command = option.substr(1, index - 1);
			parameter = option.substr(index + 1);
		} else {
			command = option.substr(1);
		}
		if (command == "width"){
			sscanf(parameter.c_str(), "%d", &size.cx);
			if (size.cx <=0) {
				error_msg = "ERROR: Invalid parameter. wrong picture width.";
				good_options = false;
				break;
			}
		} else if (command == "region"){
			if (!parse_region(parameter, chr, startpos, endpos)){
				error_msg = "ERROR: Invalid parameter. wrong region.";
				good_options = false;
				break;
			}
		} else if (command == "axis"){
			int mask;
			sscanf(parameter.c_str(), "%d", &mask);
			top_axis = (mask >= 1000);
			mask %= 1000;
			bottom_axis = (mask >= 100);
			mask %= 100;
			left_axis = (mask >= 10);
			mask %= 10;
			right_axis = (mask >= 1);
		} else {
			good_options = false;
			break;
		}
	}
	return good_options;
}

inline bool draw_gene::load_data(){
	if (error_msg != "") return false;

	if (startpos <=0 || endpos <=0 || chr == "") {
		error_msg = "ERROR: Invalid parameter. no region information.";
		return false;
	}

/*	if (!is_genefile(gene_filename)) {
		if (file_exists(gene_filename+".genefile") && compare_file_time(gene_filename, gene_filename+".genefile") <= 0) {
			if (!is_genefile(gene_filename+".genefile")) {
				error_msg = "ERROR: failed converting file to genefile format: file already exists and in wrong format.";
			}
		} else {
			if (!is_gene_text_file(gene_filename)) {
				error_msg = "ERROR: file is neither in genefile nor in correct text format.";
				return false;
			}
			if (!convert_from_text_to_gene(gene_filename, gene_filename+".genefile")) {
				error_msg = "ERROR: failed converting file to genefile format.";
				return false;
			}
		}
		gene_filename = gene_filename+".genefile";
	} */

	if (gene_filename != "") {
		genefile mygenefile;
		if (!mygenefile.read_from_file_region(gene_filename, chr, startpos, endpos, genes)){
			error_msg = "ERROR: Failed to load gene info file.";
			return false;
		}
	}

	domainlow = startpos;
	domainhigh = endpos;

	return true;
}

inline bool draw_gene::prepare_data(){
	if (error_msg != "") return false;

	left_space = left_axis;
	right_space = right_axis;
	draw_axis::prepare_data();

	if (gene_font_size == 0) {
		gene_font_size = font_size;
	}

redo:
	draw_gene_name = (gene_font_size >= 8);
	CImage image1;
	image1.Create(100,100,24);
	CDC* pdc1 = CDC::FromHandle(image1.GetDC());
	CFont font1;
	VERIFY(font1.CreateFont(
	gene_font_size,                       // nHeight
	gene_font_size / 2,                         // nWidth
	0,                         // nEscapement
	0,                         // nOrientation
	FW_NORMAL,                 // nWeight
	FALSE,                     // bItalic
	FALSE,                     // bUnderline
	0,                         // cStrikeOut
	ANSI_CHARSET,              // nCharSet
	OUT_DEFAULT_PRECIS,        // nOutPrecision
	CLIP_DEFAULT_PRECIS,       // nClipPrecision
	DEFAULT_QUALITY,           // nQuality
	DEFAULT_PITCH | FF_SWISS,  // nPitchAndFamily
	"Arial"));                 // lpszFacename

	pdc1->SelectObject(&font1);

	CSize textsize= pdc1->GetTextExtent("10000.00000");
	if (!draw_gene_name) {
		textsize.cx = textsize.cy = 0;
	}

	exon_height = gene_font_size * 5 / 4;
	gene_height = arrow_height = gene_font_size * 2 / 3;
	line_gap = gene_font_size / 4;

	line_height = max(textsize.cy, exon_height) + line_gap;
	line_ends.clear();
	gene_lines.clear();
	gene_starts.clear();
	gene_text_starts.clear();
	gene_ends.clear();
	for (size_t i=0; i<genes.size(); i++) {
		int gene_start = (int)(((__int64)(genes[i].txStart - startpos)) * (size.cx - axis_left - axis_right) / (endpos - startpos));
		int gene_len = (int)(((__int64)(genes[i].txEnd - genes[i].txStart)) * (size.cx - axis_left - axis_right) / (endpos - startpos));
		if (do_folding) {
			gene_start = round_double(myfolding.map(genes[i].txStart)) - axis_left;
			gene_len = round_double(myfolding.map(genes[i].txEnd))  - axis_left - gene_start;
		}
		if (gene_len == 0) gene_len = 1;
		int gene_end = gene_start + gene_len;

		if (gene_start < -axis_left) gene_start = -axis_left;
		if (gene_start > size.cx - axis_left) gene_start = size.cx - axis_left;
		if (gene_end < -axis_left) gene_end = -axis_left;
		if (gene_end > size.cx - axis_left) gene_end = size.cx - axis_left;

		string genename = genes[i].geneName;
		if (genename == "") genename = genes[i].name;
		CSize size1 = pdc1->GetTextExtent(genename.c_str());
		if (!draw_gene_name) {
			size1.cx = size1.cy = 0;
		}
		int gene_text_start = gene_start - size1.cx - gene_gap;

		gene_starts.push_back(gene_start);
		gene_text_starts.push_back(gene_text_start);
		gene_ends.push_back(gene_end);
		int j = 0;
		while (j < (int)line_ends.size()) {
			if (line_ends[j] < gene_text_start) break;
			j++;
		}
		gene_lines.push_back(j);
		if (j < (int)line_ends.size()) {
			line_ends[j] = gene_end;
		} else {
			line_ends.push_back(gene_end);
		}
	}
	size.cy = axis_top + axis_bottom + line_height * (int)line_ends.size() + line_gap;

	image1.ReleaseDC();
	
	//don't draw when there are too many genes
	if (size.cy > max_height) {
		if (gene_font_size > 4) {
			gene_font_size--;
			goto redo;
		} else if (fast_draw) {
			size.cy = 100;
			draw_gene_density = true;
			if (startpos < 0 || startpos > endpos) {
				error_msg = "wrong region";
				return false;
			}
			vector<int> pos;
			vector<int> den;
			pos.resize(endpos - startpos);
			den.resize(endpos - startpos);
			for (int i = startpos; i < endpos; i++) {
				pos[i - startpos] = i;
				den[i - startpos] = 0;
			}
			for (int j = 0; j < (int)genes.size(); j++) {
				for (int k = 0; k < (int)genes[j].exons.size(); k++) {
					for (int l = genes[j].exons[k].first; l < genes[j].exons[k].second; l++) {
						if (l >= startpos && l < endpos) {
							den[l - startpos] = den[l - startpos] + 1;
						}
					}
				}
			}
			int len = 0;
			for (int i = startpos; i < endpos; i++) {
				if (den[i - startpos] > 0) {
					len++;
				}
			}

			positions.resize(1);
			positions[0].resize(len);
			intensities.resize(1);
			intensities[0].resize(len);
			int index = 0;
			for (int i = startpos; i < endpos; i++) {
				if (den[i - startpos] > 0) {
					positions[0][index] = pos[i - startpos];
					intensities[0][index] = den[i - startpos];
					index++;
				}
			}
		} else if (size.cy >= 10000) {
			size.cy = 100;
			error_msg = "too many genes in the region to display";
			return false;
		}  
	}

	if (draw_gene_density) {
		draw_signal::prepare_data();
	} else {
		left_axis = right_axis = false;
		draw_axis::prepare_data();
	}

	return true;
}

inline void draw_gene::get_intervals(){
	intervals.end_points.clear();
	for (int i = 0; i < (int)genes.size(); i++) {
		for (int j = 0; j < (int)genes[i].exons.size(); j++) {			
			intervals.union_with(interval_set(genes[i].exons[j].first, genes[i].exons[j].second));
		}
	}
}

inline bool draw_gene::draw_contents(CDC *pdc, const CRect rect){

	if (draw_gene_density) {
		return draw_signal::draw_contents(pdc, rect);
	}

	CFont font1;
	VERIFY(font1.CreateFont(
	gene_font_size,                       // nHeight
	gene_font_size / 2,                         // nWidth
	0,                         // nEscapement
	0,                         // nOrientation
	FW_NORMAL,                 // nWeight
	FALSE,                     // bItalic
	FALSE,                     // bUnderline
	0,                         // cStrikeOut
	ANSI_CHARSET,              // nCharSet
	OUT_DEFAULT_PRECIS,        // nOutPrecision
	CLIP_DEFAULT_PRECIS,       // nClipPrecision
	DEFAULT_QUALITY,           // nQuality
	DEFAULT_PITCH | FF_SWISS,  // nPitchAndFamily
	"Arial"));                 // lpszFacename

	pdc->SelectObject(&font1);

	CSize textsize= pdc->GetTextExtent("10000.00000");

	for (int i=0; i<(int)genes.size(); i++) {
		bool draw_name = draw_gene_name;
		int gene_type = 0; // 0: gene, 1: single reads, 2: paired reads
		int paired_link = 0;

		if (genes[i].cdsStart == -1) { // single reads
			draw_name = false;
			gene_type = 1;
		} else if (genes[i].cdsStart == -2) { // paired reads
			draw_name = false;
			gene_type = 2;
			paired_link = genes[i].cdsEnd;
		} else { // gene structure
			if (!(0 <= genes[i].txStart && genes[i].txStart <= genes[i].cdsStart && genes[i].cdsStart <= genes[i].cdsEnd && genes[i].cdsEnd <= genes[i].txEnd)) {
				error_msg = string("inconsistent gene structure, gene: ") + genes[i].name;
				return false;
			}
		}

		if (!draw_name) {
			textsize.cx = 0;
			textsize.cy = 0;
		}

		COLORREF color = RGB(genes[i].colorR, genes[i].colorG, genes[i].colorB);
		CBrush brush(color);
		CPen pen(PS_SOLID, 1, color);
		pdc->SelectObject(brush);
		pdc->SelectObject(pen);
		pdc->SetTextColor(color);

		int y = rect.top + line_height * gene_lines[i] + line_gap + (line_height - line_gap) / 2;
		
		pdc->MoveTo(gene_starts[i] + rect.left, y);
		pdc->LineTo(gene_ends[i] + rect.left, y);

		if (draw_gene_name) {
			for (int j=gene_starts[i] + rect.left; j<gene_ends[i] + rect.left - arrow_height / 2; j += arrow_height) {
				if (!genes[i].strand) {
					pdc->MoveTo(j + arrow_height / 2, y - arrow_height / 2);
					pdc->LineTo(j, y);
					pdc->LineTo(j + arrow_height / 2, y + arrow_height / 2);
				} else {
					pdc->MoveTo(j, y - arrow_height / 2);
					pdc->LineTo(j + arrow_height / 2, y);
					pdc->LineTo(j, y + arrow_height / 2);
				}
			}
		}

		map_rects.insert(map_rects.begin(), CRect(gene_starts[i] + rect.left, y - exon_height / 2, gene_ends[i] + rect.left, y + exon_height / 2)); // must use insert instead of push_back to keep correct order
		map_strings.insert(map_strings.begin(), string("gene ") + genes[i].geneName + "/" + genes[i].name + " " + genes[i].chrom + ":" + int2str(genes[i].txStart) + "-" + int2str(genes[i].txEnd));
		for (int j = 0; j < (int)genes[i].exons.size(); j++) {
			int a = genes[i].exons[j].first, b = genes[i].exons[j].second;
			int height = gene_height;
			if (gene_type > 0 || gene_type == 0 && a >= genes[i].cdsStart && b <= genes[i].cdsEnd) height = exon_height;
			int x1 = (int)(__int64(a - startpos) * rect.Width() / (endpos - startpos)) + rect.left;
			int x2 = (int)(__int64(b - startpos) * rect.Width() / (endpos - startpos)) + rect.left;
			if (do_folding) {
				x1 = round_double(myfolding.map(a));
				x2 = round_double(myfolding.map(b));
			}
			if (x1 == x2) x2 = x1 + 1;
			if (x1 < 0) x1 = 0;
			if (x1 > size.cx) x1 = size.cx;
			if (x2 < 0) x2 = 0;
			if (x2 > size.cx) x2 = size.cx;
			pdc->Rectangle(CRect(x1, y - height / 2, x2, y + height / 2));
//			int old_x1 = x1, old_x2 = x2;
			map_rects.insert(map_rects.begin(), CRect(x1, y - exon_height / 2, x2, y + exon_height / 2));
			map_strings.insert(map_strings.begin(), string("gene ") + genes[i].geneName + "/" + genes[i].name + "/exon" + int2str(j + 1) + " " + genes[i].chrom + ":" + int2str(a) + "-" + int2str(b));
			if (gene_type == 0 && height == gene_height) {
				if (a < genes[i].cdsStart) a = genes[i].cdsStart;
				if (b > genes[i].cdsEnd) b = genes[i].cdsEnd;
				if (a < b) {
					height = exon_height;
					x1 = (int)(__int64(a - startpos) * rect.Width() / (endpos - startpos)) + rect.left;
					x2 = (int)(__int64(b - startpos) * rect.Width() / (endpos - startpos)) + rect.left;
					if (do_folding) {
						x1 = round_double(myfolding.map(a));
						x2 = round_double(myfolding.map(b));
					}
					if (x1 == x2) x2 = x1 + 1;
					if (x1 < 0) x1 = 0;
					if (x1 > size.cx) x1 = size.cx;
					if (x2 < 0) x2 = 0;
					if (x2 > size.cx) x2 = size.cx;
					pdc->Rectangle(CRect(x1, y - height / 2, x2, y + height / 2));
				}
			}
			if (draw_name && draw_exon_num) {
				int num_exon = j + 1;
				if (!genes[i].strand) {
					num_exon = (int)genes[i].exons.size() + 1 - num_exon;
				}
				string exon_num = int2str(num_exon);
				CSize size2 = pdc->GetTextExtent(exon_num.c_str());
				if (height == exon_height && x2 - x1 > size2.cx) {
				// if (old_x2 - old_x1 > size2.cx) {
					pdc->SetTextColor(RGB(255,255,255));
					pdc->SetBkMode(TRANSPARENT);
					pdc->TextOut((x1+x2)/2 - size2.cx/2, y - size2.cy/2, exon_num.c_str());
					pdc->SetTextColor(color);
					pdc->SetBkMode(OPAQUE);
				}
			}
		}

		if (gene_type == 2) { // paired reads
			if ((int)genes[i].exons.size() < paired_link + 2) {
				error_msg = string("inconsistent paired read, read: ") + genes[i].name;
				return false;
			}
			int a = genes[i].exons[paired_link].second, b = genes[i].exons[paired_link + 1].first;
			int x1 = (int)(__int64(a - startpos) * rect.Width() / (endpos - startpos)) + rect.left;
			int x2 = (int)(__int64(b - startpos) * rect.Width() / (endpos - startpos)) + rect.left;
			if (do_folding) {
				x1 = round_double(myfolding.map(a));
				x2 = round_double(myfolding.map(b));
			}
			if (x1 == x2) x2 = x1 + 1;
			if (x1 < 0) x1 = 0;
			if (x1 > size.cx) x1 = size.cx;
			if (x2 < 0) x2 = 0;
			if (x2 > size.cx) x2 = size.cx;

			if (x1 < x2) {
				int height = exon_height;
				CBrush brush1(RGB(255,255,255));
				pdc->FillRect(CRect(x1, y - height / 2, x2, y + height / 2), &brush1);
			} 

			pdc->MoveTo(x1, y);
			CPen pen1(PS_DOT, 1, color);
			pdc->SelectObject(pen1);
			pdc->LineTo(x2, y);
			CPen pen2(PS_SOLID, 1, color);
			pdc->SelectObject(pen2);
		}

		if (draw_name) {
			CBrush brush1(RGB(255,255,255));
			CRect temprect;
			temprect.left = max(rect.left - axis_left + gene_gap, gene_text_starts[i] + rect.left + gene_gap / 2);
			temprect.right = temprect.left + gene_starts[i] - gene_text_starts[i] - gene_gap;
			temprect.top = y - textsize.cy / 2;
			temprect.bottom = y + textsize.cy / 2;
			pdc->FillRect(temprect, &brush1);
	/*		pdc->SetBkMode(TRANSPARENT);
			if (temprect.left == rect.left - axis_left + gene_gap) {
				pdc->SetTextColor(RGB(128,128,128));
			}*/
			string genename = genes[i].geneName;
			if (trim_space(genename) == "") genename = genes[i].name;
			if (trim_space(genename) != "") pdc->TextOut(temprect.left, y - textsize.cy / 2, genename.c_str());
	/*		pdc->SetTextColor(RGB(0,0,0));
			pdc->SetBkMode(OPAQUE);*/
			map_rects.insert(map_rects.begin(), temprect);
			map_strings.insert(map_strings.begin(), string("gene ") + genes[i].geneName + "/" + genes[i].name + " " + genes[i].chrom + ":" + int2str(genes[i].txStart) + "-" + int2str(genes[i].txEnd));
		}
	}

	CBrush brush(RGB(0, 0, 0));
	CPen pen(PS_SOLID, 1, RGB(0, 0, 0));
	pdc->SelectObject(brush);
	pdc->SelectObject(pen);
	pdc->SetTextColor(RGB(0, 0, 0));

	return true;
}

#endif //DRAW_GENE_H
