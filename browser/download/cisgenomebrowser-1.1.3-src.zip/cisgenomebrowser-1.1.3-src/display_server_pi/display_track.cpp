#include "display_track.h"
#include "display_gene.h"
#include "drawCommon.h"
#include "display_genome.h"
#include <typeinfo>

display_track::display_track()
{

}

display_track::display_track(http_request* r, string track_name,
							 display_genome *g)
{
	req = r;
	name = track_name;
	title = "";
	top_axis = false;
	bottom_axis = false;
	fast_draw = default_fast_draw;
	pic_filename = "";
	genome = g;
}

bool display_track::load_from_file(string file_name)
{
	title = ReadIni(file_name, name + "/title", wxString(""));
	top_axis = ReadIni(file_name, name + "/top_axis", false);
	bottom_axis = ReadIni(file_name, name + "/bottom_axis", false);
	fast_draw = ReadIni(file_name, name + "/fast_draw", default_fast_draw);
	pic_filename = ReadIni(file_name, name + "/pic_filename", wxString(""));
	return true;
}

bool display_track::update_params()
{
	if (req->params_.count("update_track") > 0)
	{
		title = req->params_["track_title"];
		top_axis = (req->params_.count("top_axis") > 0);
		bottom_axis = (req->params_.count("bottom_axis") > 0);
		fast_draw = (req->params_.count("fast_draw") > 0);
	}
	else if (req->params_.count("update_tracks") > 0)
	{
	}
	else
		return false;
	return true;
}

bool display_track::write_to_file(string file_name)
{
	WriteIni(file_name, name + "/title", title, title != "");
	WriteIni(file_name, name + "/top_axis", top_axis, top_axis != false);
	WriteIni(file_name, name + "/bottom_axis", bottom_axis, bottom_axis
		!= false);
	WriteIni(file_name, name + "/fast_draw", fast_draw, fast_draw
		!= default_fast_draw);
	WriteIni(file_name, name + "/pic_filename", pic_filename, pic_filename
		!= "");
	return true;
}

class ExonPairs {
public:
	static string ExonsString(const vector<string>& map_strings, int index) {
		string res; 
		if (map_strings.size() > 0 && map_strings[0].find("gene ") != string::npos && map_strings.size()%4 == 0) {
			vector<string> tok1 = string_tokenize(map_strings[index/4*4+2]);
			vector<string> tok2 = string_tokenize(map_strings[index/4*4+1]);
			return ",'" + tok1[2] + "_" + tok2[2] + "'";

		}
		return res;
	}
};

static string GeneDataFileName(display_track *disp) {
	string res;
	if (typeid(*disp) == typeid(display_gene)) {
		res = ",'" + ((display_gene*)disp)->src_filename + "'";
	}
	return res;
}

void display_track::generate_hrefs(vector<PIRect> &map_rects,
								   vector<string> &map_strings)
{
	for (int i = 0; i < (int) map_rects.size(); i++)
	{
		vector<string> tokens = string_tokenize(map_strings[i]);
		if (tokens[0] == "h_axis")
		{
			rects.push_back(map_rects[i]);
			int center = round_double(str2double(tokens[1]));
			titles.push_back(string("position: ") + int2str(center));
			chr_region region(genome->region);
			region.move(center - (region.start + region.end) / 2);
			region.resize(1.0 / 3);
			//hrefs.push_back(host_name + "session?name=$SESSION_NAME$&region=" + region.get_region());
			//hrefs.push_back(string("javascript:show_coord_menu(event, ") + int2str(center) + ")");
			hrefs.push_back("#");
			onclicks.push_back(string("show_coord_menu(event, ") + int2str(
				center) + "); return false");
		}
		else if (tokens[0] == "gene")
		{ // should go to display_gene actually
			rects.push_back(map_rects[i]);
			titles.push_back(tokens[1] + " " + tokens[2]);
			vector<string> tokens1 = string_tokenize(tokens[1], "/");
			while (tokens1.size() < 2) tokens1.push_back("");
			//hrefs.push_back(host_name + "session?name=$SESSION_NAME$&region=" + tokens[2]);
			hrefs.push_back("#");
			onclicks.push_back(string("show_gene_menu(event, '") + tokens1[1]
			+ "','" + tokens[1] + "','" + tokens[2]
			+ "'" + ExonPairs::ExonsString(map_strings, i) + GeneDataFileName(this) + "); return false");
		}
		else if (tokens[0] == "signal")
		{
			rects.push_back(map_rects[i]);
			titles.push_back(string("value:") + tokens[1] + " at coordinate "
				+ tokens[2]);
			hrefs.push_back("");
		}
	}
}

string display_track::get_html()
{
	string result = "";
	if (pic_filename == "")
	{
		pic_filename = get_random_pic_file_name();
	}
	if (!file_exists(temp_path + client_ip + pic_filename) || genome->refresh)
	{
		generate_pic_file();
	}
	result += map_html(string("map_") + name, rects, hrefs, titles, onclicks);
	result
		+= image_html(server_temp_path + client_ip + pic_filename, string("map_")
		+ name);
	return result;
}

string display_track::get_configure_html()
{
	html_formater my_html_formater;
	my_html_formater.load_from_template_file(template_path
		+ "track_config.html");
	my_html_formater.replace_keyword("$TRACK_TITLE$", title);
	my_html_formater.replace_keyword("$TOP_AXIS$", top_axis ? " checked" : "");
	my_html_formater.replace_keyword("$BOTTOM_AXIS$", bottom_axis ? " checked"
		: "");
	my_html_formater.replace_keyword("$FAST_DRAW$", fast_draw ? " checked" : "");
	my_html_formater.replace_keyword("$PIC_FILENAME$", pic_filename);
	return my_html_formater.buf;
}

bool display_track::generate_pic_file(bool get_intervals)
{
	if (get_intervals)
	{
		intervals.end_points.clear();
	}
	else
	{
		if (pic_filename == "")
			return false;
		string pic_file_name = temp_path + client_ip + pic_filename;
		if (file_exists(pic_file_name) && !wxRemoveFile(wxS(pic_file_name)))
			return false;
	}
	return true;
}

