#include "display_nucleotide.h"
#include "drawCommon.h"
#include "display_genome.h"

display_nucleotide::display_nucleotide()
{

}

display_nucleotide::display_nucleotide(http_request* r,
									   string track_name, display_genome *g) :
display_track(r, track_name, g)
{
	file_path = "";
}

bool display_nucleotide::load_from_file(string file_name)
{
	display_track::load_from_file(file_name);
	file_path = ReadIni(file_name, name + "/file_path", wxString(""));
	if (title == "")
	{
		title = file_path;
	}
	return true;
}

bool display_nucleotide::update_params()
{
	if (!display_track::update_params())
		return false;
	if (req->params_.count("update_track") > 0)
	{
		file_path = get_path(req->params_["file_path"]);
		if (title == "")
			title = file_path;
	}
	else if (req->params_.count("update_tracks") > 0)
	{
	}
	else
		return false;
	return true;
}

bool display_nucleotide::write_to_file(string file_name)
{
	display_track::write_to_file(file_name);
	WriteIni(file_name, name + "/type", "nucleotide", true);
	WriteIni(file_name, name + "/file_path", file_path, file_path != "");
	return true;
}

string display_nucleotide::get_configure_html()
{
	html_formater my_html_formater;
	my_html_formater.load_from_template_file(template_path
		+ "nucleotide_track_config.html");
	my_html_formater.replace_keyword("$FILE_PATH$", file_path);
	string result = my_html_formater.buf;
	my_html_formater.buf = display_track::get_configure_html();
	my_html_formater.replace_keyword("$TRACK_CONTENTS$", result);
	my_html_formater.replace_keyword("$TRACK_TYPE$", "nucleotide");
	return my_html_formater.buf;
}

bool display_nucleotide::generate_pic_file(bool get_intervals)
{
	if (!display_track::generate_pic_file(get_intervals))
		return false;

	draw_nucleotide my_draw;
	my_draw.intervals = intervals;
	my_draw.file_path = file_path;
	if (!parse_region(genome->region, my_draw.chr, my_draw.startpos,
		my_draw.endpos))
	{
		my_draw.error_msg = "bad region.";
	}

	/*if (my_draw.endpos - my_draw.startpos > 10000) {
	my_draw.error_msg = "region is too long to load and display";
	//skip long regions for faster display
	}*/

	my_draw.size.cx = genome->pic_width;
	my_draw.box_margin = genome->pic_margin / 3;
	my_draw.data_margin = genome->pic_margin * 2 / 3;
	my_draw.font_size = genome->font_size;
	my_draw.left_axis = genome->left_axis;
	my_draw.right_axis = genome->right_axis;
	if (genome->grid == "off")
	{
		my_draw.v_grids = false;
	}
	else if (genome->grid == "gray")
	{
		my_draw.custom_grid_color = true;
		my_draw.shaded_background = false;
	}
	else if (genome->grid == "gray_shaded")
	{
		my_draw.custom_grid_color = true;
		my_draw.shaded_background = true;
	}
	else if (genome->grid == "color_shaded")
	{
		my_draw.custom_grid_color = false;
		my_draw.shaded_background = true;
	}
	else if (genome->grid == "color")
	{
		my_draw.custom_grid_color = false;
		my_draw.shaded_background = false;
	}
	my_draw.top_axis = top_axis;
	my_draw.bottom_axis = bottom_axis;
	my_draw.fast_draw = fast_draw;
	my_draw.load_data();
	my_draw.prepare_data();
	if (get_intervals)
	{
		my_draw.get_intervals();
		intervals = my_draw.intervals;
	}
	else
	{
		my_draw.drawfile(temp_path + client_ip + pic_filename);
		display_track::generate_hrefs(my_draw.map_rects, my_draw.map_strings);
	}
	return true;
}

string display_nucleotide::type()
{
	return "display_nucleotide";
}