rm(list=ls())

# source("http://bioconductor.org/biocLite.R")
# biocLite(c("tweeDEseqCountData", "gridExtra", "edgeR", "DESeq2", "limma", "AUC"))
library(tweeDEseqCountData)
library(gridExtra)
library(edgeR)
library(DESeq2)
library(limma)
library(AUC)

source("sim.R")
source("ADMM.mlr.R")
source("fit_mlr.R")


################################## read and preprocess real data #################################
datadir <- 'PSA_data/'
resultdir <- 'results/real_data/'

data.exp <- read.csv(paste(datadir, 'exp.csv', sep = ""), header = T)

counts <- as.matrix(data.exp[,  - 1])
rownames(counts) <- data.exp[, 1]

cutoff <- 0

counts <- counts[rowMeans(counts) >= (cutoff * mean(counts)), ]

nTags <- nrow(counts)   # number of genes
nlibs <- ncol(counts)   # number of samples

data.PSA_preop <- read.csv(paste(datadir, 'PSA_preop.csv', sep = ""), header = T)
x <- as.matrix(log2(data.PSA_preop$PSA_preop))
############################################### End ##############################################


################################# Algorithms to be compared with #################################
design <- model.matrix(~x)

out.edgeR <- edgeR_robust.pfun(counts = counts, design = design)
out.DESeq2 <- DESeq2.pfun(counts = round(counts), X = x)
out.limma <- limma_voom.pfun(counts = counts, design = design)

results <- cbind(out.edgeR, out.DESeq2, out.limma)
rownames(results) <- rownames(counts)

write.csv(results, paste(resultdir, "benchmarks.csv", sep = ""), row.names = T, quote = F)
############################################### End ##############################################


######################################## Proposed Algorithm #######################################
set.seed(1234)


sig_leval <- 0.01
log.add <- 1e-3 * min(counts[counts > 0])

out.ELMSeq <- pfun.ADMM.mlr_typeIIpenalty(counts, x, sigma_sq = NULL, percentile = sig_leval, rho = 0.1, log.add = log.add)

out.lr <- fit_mlr.pfun(counts, x, sigma_sq = NULL, sig_leval = sig_leval, log.add = log.add)

################################ Output, save and display results ################################
p.value <- out.lr$result[, 1]
# padj <- out.lr$result[, 2]
beta_esti <- out.lr$result[, 3]

pdf(paste(resultdir, "beta_sigLeval=", sig_leval, ".pdf", sep=""))
par(mar=c(4, 4, 1, 0.5))
plot(beta_esti, xlab="i", ylab=expression(paste(beta[i])), type = "h", col = "blue")
dev.off()

pdf(paste(resultdir, "pval_sigLeval=", sig_leval, ".pdf", sep=""))
par(mar=c(4, 4, 1, 0.5))
plot( -log10(p.value), xlab="i", ylab=expression(paste( -log[10](p[i]))), type = "h", col = "blue")
dev.off()

write.csv(cbind(out.ELMSeq$result, out.lr$result), paste(resultdir, "rSeqRobust_sigLeval=", sig_leval, ".csv", sep=""), row.names=T, quote=F)
############################################### End ##############################################