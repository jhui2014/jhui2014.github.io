#ifndef DEFAULT_VALUES_H
#define DEFAULT_VALUES_H

//DISPLAY_MOTIF
const bool default_multiple_motifs = false;

//DISPLAY_CEL

//DISPLAY_TRACK
const bool default_fast_draw = true;

//display_conservation
const int default_pic_height = 100;
const string default_plot_type = "bar";

//display_signal
const bool default_zero_line = false;
const bool default_always_include_zero = true;

//display_gene
const bool default_draw_exon_num = false;
const bool default_do_caching = false;
const bool default_annotation = true;
const int default_max_height = 400;
const int default_gene_font_size = 0;

//display_genome
const string default_genome = "chr1:5001000-5002000";
const int default_pic_width = 800;
const int default_pic_margin = 15;
const int default_font_size = 15;
const string default_grid = "gray";

//session

//global
const int default_port_num = 32123;
const int default_local_only = true;

#endif //#define DEFAULT_VALUES_H