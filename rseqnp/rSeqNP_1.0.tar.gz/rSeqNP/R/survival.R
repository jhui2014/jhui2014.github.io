SMALL.VAL <- 1e-8

#For survival outcomes
Survi=function(exp_object, outcome, gamma, nperm, seed)
{

  iso.exp=exp_object$iso.exp
  gene.exp=exp_object$gene.exp
  
  #get the name for genes and isoforms--isoform level
  gene_name=iso.exp[,1]
  isoform_name=iso.exp[,2]
  isoform_number=iso.exp[,3]
  
  #get the gene name and isoform number--gene level
  gene.name=gene.exp[,1]
  isoform.number=gene.exp[,2]
  
  n_sample=length(outcome) #total number of samples
  n_iso=nrow(iso.exp) #total number of isoforms(transcripts) in the dataframe  
  n_gene=nrow(gene.exp) #number of genes
  
  N.iso=apply(iso.exp[,4:(n_sample+3)],2,as.numeric)#this is the expression matrix for all isoforms, without the gene and isoform names
  N.gene=apply(gene.exp[,3:(n_sample+2)],2,as.numeric)
  
  #test 1: do the score test for all isoforms, return the score statistic and the p values
  ranks_iso=apply(N.iso,1,rank,ties.method="random")
  isoform.res=calculate.CS.test(ranks_iso, outcome, gamma)
  
  colnames(isoform.res)=c('score.stat','p.value.survi')
  
  #calculate the FDR for all isoforms based on the Wilcoxon p value
  iso.FDR=p.adjust(isoform.res[,2], method="BH")
  
  isoform.result=data.frame(gene_name,isoform_name,isoform_number,isoform.res,iso.FDR)
  isoform.result=isoform.result[order(isoform.result[,5],-isoform.result[,4],isoform.result[,1]),]
  #gene_name, isoform_name, isoform_number, score.stat, p.value, FDR
  #sort order: p.value, -score.stat, gene_name
  print("Isoform differential expression test done!")
  
  #test 2: do the score test for all genes, return the score statistic and the p values
  ranks_gene=apply(N.gene,1,rank,ties.method="random")
  gene.DE.res=calculate.CS.test(ranks_gene, outcome, gamma)
  colnames(gene.DE.res)=c('score.stat','p.value.survi')
  gene.FDR=p.adjust(gene.DE.res[,2], method="BH")
  gene.DE.result=data.frame(gene.name,gene.DE.res,gene.FDR)
  gene.DE.result=gene.DE.result[order(gene.DE.result[,3],-gene.DE.result[,2],gene.DE.result[,1]),]
  
  print("Gene differential expression test done!")
  
  #test 3: Permutation test for differential expression and splicing of genes using GDS score
   GDS.result=GDS(isoform.info=data.frame(gene_name=isoform.result[,1], isoform_number=isoform.result[,3], Tj=isoform.result[,4]),
                    iso.exp=iso.exp, type='survi', outcome=outcome, gamma=gamma, nperm=nperm, seed=seed)
   GDS_c=GDS.result[[1]]
   GDS_p=GDS.result[[2]]
  
   print("Permutation test based on GDS done!")
  
  return(list(isoform.result=isoform.result,gene.DE.result=gene.DE.result,GDS_c.result=GDS_c, GDS_p.result=GDS_p, test=GDS.result$test))
}

############################################################
#  		Calculate the survival statistics
############################################################
calculate.CS.test <- function(mu, y, gamma)
#mu is the fitted values (can be a matrix); y is the survival time vector; gamma is the censored status vector 
{
  # find the index matrix
  Dn <- sum(gamma == 1)
  Dset <- c(1 : ncol(mu))[gamma == 1]		# the set of observed
  ind <- matrix(0, ncol(mu), Dn)
  
  # get the matrix
  for (i in 1 : Dn)
  {
    ind[y > y[Dset[i]] - 1e-8, i] <- 1 / sum(y > y[Dset[i]] - 1e-8)
  }
  ind.sums <- rowSums(ind)
  x.ind <- mu %*% ind
  
  # get the derivatives
  dev1 <- mu %*% (gamma - ind.sums)
  dev2 <- (mu * mu) %*% ind.sums - rowSums(x.ind * x.ind)
  
  score <- dev1 / (sqrt(-dev2) + SMALL.VAL)
  
  score_sq=score^2
  p_value=1-pchisq(score_sq, df=1)
  
  if(is.na(p_value)) {p_value=1}
  
  res=cbind(score, p_value)  
  return(res)  
}
