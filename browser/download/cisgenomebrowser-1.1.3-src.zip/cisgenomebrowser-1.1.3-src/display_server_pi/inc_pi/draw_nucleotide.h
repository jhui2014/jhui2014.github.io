#ifndef DRAW_NUCLEOTIDE_H
#define DRAW_NUCLEOTIDE_H

#include "draw_axis.h"
class wxMemoryDC;

class draw_nucleotide: public draw_axis
{
public:
	string nucleotides;

	string file_path;
	string chr;
	int startpos, endpos;

	draw_nucleotide();
	virtual string print_usage();
	virtual bool get_params(const vector<string> &params);
	virtual bool load_data();
	virtual bool prepare_data();
	virtual bool draw_contents(wxMemoryDC *pdc, const PIRect rect);
};


#endif //DRAW_NUCLEOTIDE_H
