source("twoD.R")
source("common.R")

#data is a list
#each element of data contains the coordinates (x,y) in a matrix of nx2 of all the vertices of a convex polygon, 
#with vertices ordered either clockwise or anticlockwise

#call back function for TwoD
polygon_shift = function(data, lambda) {
    return(data)
}

#call back function for TwoD
polygon_val = function(data, i, x) {
    return(ifelse(in_polygon(data[[i]], x), -1, 0))
}

#call back function for TwoD
polygon_min = function(data_s, modifier, suff_stat = NULL) {
    if (any(is.element(modifier[modifier > 0], suff_stat))) {
        stop("error")
    }
    suff_stat = union(suff_stat, modifier[modifier > 0])
    if (!all(is.element(-modifier[modifier < 0], suff_stat))) {
        stop("error")
    }
    suff_stat = setdiff(suff_stat, - modifier[modifier < 0])
    return(list(par = suff_stat, value = -length(suff_stat), suff_stat = suff_stat))
}

#call back function for TwoD
#finding intersection points of two polygon
polygon_intersect = function(data_s, i, j) {
    n = nrow(data_s[[i]])
    m = nrow(data_s[[j]])
    result = NULL
    for (i1 in 1:n) {
        i2 = (i1 %% n) + 1
        for (j1 in 1:m) {
            j2 = (j1 %% m) + 1
            x = line_intersection(data_s[[i]][i1,], data_s[[i]][i2,], data_s[[j]][j1,], data_s[[j]][j2,])
            if (!is.null(x) && in_range(x$scale[1], c(0, 1)) && in_range(x$scale[2], c(0, 1))) {
                result = rbind(result, x$position)
            }
        }
    }
    return(unique(result))
}

#call back function for TwoD
polygon_radius = function(data_s, i, center, theta) {
    n = nrow(data_s[[i]])
    for (j in 1:n) {
        k = (j %% n) + 1
        x = line_intersection(center, center + c(cos(theta), sin(theta)), data_s[[i]][j,], data_s[[i]][k,])
        if (!is.null(x) && in_range(x$scale[1], c(0, Inf)) && in_range(x$scale[2], c(0, 1))) {
            return(x$scale[1])
        }
    }
}

#call back function for TwoD
polygon_point = function(data_s, i) {
    return(polygon_center(data_s[[i]]))
}

#main function
convex_polygon_cover = function(data) {
    sol = twoD(data, g_shift = polygon_shift, g_val = polygon_val, g_min = polygon_min, g_intersect = polygon_intersect, g_radius = polygon_radius, g_point = polygon_point)
    intersection = NULL
    for (i in sol$par) {
      intersection = convex_polygon_intersection(intersection, data[[i]])
    }
    return(list(par = polygon_center(intersection), value = sol$value))
}

#main function
convex_polygon_cover_points = function(polygon, points) {
    polygon = matrix(polygon, ncol = 2)
    points = matrix(points, ncol = 2)
    n = nrow(polygon)
    m = nrow(points)
    polygon = polygon - rep(polygon_center(polygon), each = n)
    data = as.list(1:m)
    for (i in 1:m) {
        data[[i]] = rep(points[i,], each = n) - polygon
    }
    return(convex_polygon_cover(data))
}
