#ifndef DRAW_MOTIF_H
#define DRAW_MOTIF_H

#include "draw_axis.h"
#include "string_operation.h"
#include "math_utils.h"
#include <atlimage.h>

class draw_motif: public draw_axis
{
public:
	string motif_filename;
	vector<vector<pair<double, int> > > weights;
	int startpos, endpos;

	draw_motif();
	virtual string print_usage();
	virtual bool get_params(const vector<string> &params);
	virtual bool load_data();
	virtual bool prepare_data();
	virtual bool draw_contents(CDC *pdc, const CRect rect);
};

const static string letters[4] = {"A", "C", "G", "T"};
const static COLORREF colors[4] = {RGB(0, 213, 0), RGB(0, 0, 192), RGB(255, 170, 0), RGB(213, 0, 0)};

inline draw_motif::draw_motif(){
	left_axis = right_axis = bottom_axis = true;
	box = true;
	rangelow = 0;
	rangehigh = 2;

	motif_filename = "";
	weights.clear();
	startpos = endpos = -1;

	h_grids = false;
	v_grids = false;
}

inline string draw_motif::print_usage(){
	return "<input motif file name> [/pos:<sequence start position>-<sequence end position>] [/size:<picture width>x<picture height>] [/axis:xxxx]\n";
}

inline bool draw_motif::get_params(const vector<string> &params){
	if (!draw_figure_structure::get_params(params)) return false;
	if (params.size() == 0) return false;
	motif_filename = params[0];

	bool good_options = true;
	for (int i=1; i<(int)params.size(); i++) {
		string option = params[i];

		string command = "";
		string parameter = "";
		if (option[0] != '/') {
			good_options = false;
			break;
		}
		size_t index = option.find (":");
		if (index != string::npos ) {
			command = option.substr(1, index - 1);
			parameter = option.substr(index + 1);
		} else {
			command = option.substr(1);
		}
		if (command == "size"){
			sscanf(parameter.c_str(), "%dx%d", &size.cx, &size.cy);
			if (size.cx <=0 || size.cy <=0) {
				error_msg = "ERROR: Invalid parameter. wrong picture size.";
				good_options = false;
				break;
			}
		} else if (command == "pos"){
			sscanf(parameter.c_str(), "%d-%d", &startpos, &endpos);
			if (startpos <0 || startpos >= endpos) {
				error_msg = "ERROR: Invalid parameter. wrong domain.";
				good_options = false;
				break;
			}
		} else if (command == "axis"){
			int mask;
			sscanf(parameter.c_str(), "%d", &mask);
			top_axis = (mask >= 1000);
			mask %= 1000;
			bottom_axis = (mask >= 100);
			mask %= 100;
			left_axis = (mask >= 10);
			mask %= 10;
			right_axis = (mask >= 1);
		} else {
			good_options = false;
			break;
		}
	}
	return good_options;
}

inline bool draw_motif::load_data(){
	if (!draw_figure_structure::load_data()) return false;
	FILE *file = fopen(motif_filename.c_str(), "rt");
	if (NULL == file) {
		error_msg = "ERROR: Error open motif file";
		return false;
	}

//read motif matrix
	for (int i=0; i<(int)weights.size(); i++) weights[i].clear();
	weights.clear();
	while (!feof(file)){
		char buf[1025];
		buf[0] = 0;
		fgets(buf, 1024, file);
		double w[4];
		if (4 != sscanf(buf, " %lf %lf %lf %lf", w, w+1, w+2, w+3)) break;
		vector<pair<double, int> > ww;
		ww.clear();
		for (int i=0; i<4; i++) {
			//fix later
			//w[i] -= .49;
			ww.push_back(pair<double, int>(w[i], i));
		}
		weights.push_back(ww);
	}
	if (weights.size() == 0) {
		error_msg = "ERROR: no motif information found.";
		fclose(file);
		return false;
	}

	fclose(file);

	return true;
}

inline bool draw_motif::prepare_data(){
	if (!draw_figure_structure::prepare_data()) return false;
	if (startpos == -1 && endpos == -1) {
		startpos = 1;
		endpos = startpos + (int)weights.size() - 1;
	}

	if (endpos - startpos + 1 != (int)weights.size()) {
		error_msg = "ERROR: Invalid parameter. wrong sequence coordinates.";
		return false;
	}

	domainlow = startpos - 0.5;
	domainhigh = endpos + 0.5;
	
	return draw_axis::prepare_data();
}

inline bool draw_motif::draw_contents(CDC *pdc, const CRect rect){
	if (!draw_axis::draw_contents(pdc, rect)) return false;
	CImage image1;
	image1.Create(800,200,24);
	CDC* pdc1 = CDC::FromHandle(image1.GetDC());
	CSize letter_sizes[4];
	CRect letter_rects[4];

	int sizex = rect.Width();
	int sizey = rect.Height();
	
	for (int i=0; i<4; i++) {
		pdc1->SetTextColor(colors[i]);
		CFont font;
		VERIFY(font.CreateFont(
		160,                       // nHeight
		60,                         // nWidth
		0,                         // nEscapement
		0,                         // nOrientation
		FW_NORMAL,                 // nWeight
		FALSE,                     // bItalic
		FALSE,                     // bUnderline
		0,                         // cStrikeOut
		ANSI_CHARSET,              // nCharSet
		OUT_DEFAULT_PRECIS,        // nOutPrecision
		CLIP_DEFAULT_PRECIS,       // nClipPrecision
		DEFAULT_QUALITY,           // nQuality
		DEFAULT_PITCH | FF_SWISS,  // nPitchAndFamily
		"Arial"));                 // lpszFacename
		CFont* def_font = pdc1->SelectObject(&font);
		pdc1->TextOut(i * 200, 0, letters[i].c_str());
		letter_sizes[i] = pdc1->GetTextExtent(letters[i].c_str());
		pdc1->SelectObject(def_font);

		// Done with the font.  Delete the font object.
		font.DeleteObject();
		CRect rect1 = CRect(i * 200, 0, i * 200 + letter_sizes[i].cx - 1, letter_sizes[i].cy - 1);
		COLORREF white = RGB(255, 255, 255);
		int j;
		while (rect1.top < rect1.bottom) {
			for (j=rect1.left; j<rect1.right; j++) {
				if (white != pdc1->GetPixel(j, rect1.top)) break;
			}
			if (j == rect1.right) rect1.top++; else break;
		}
		while (rect1.top < rect1.bottom) {
			for (j=rect1.left; j<rect1.right; j++) {
				if (white != pdc1->GetPixel(j, rect1.bottom)) break;
			}
			if (j == rect1.right) rect1.bottom--; else break;
		}
		while (rect1.left < rect1.right) {
			for (j=rect1.top; j<rect1.bottom; j++) {
				if (white != pdc1->GetPixel(rect1.left, j)) break;
			}
			if (j == rect1.bottom) rect1.left++; else break;
		}
		while (rect1.left < rect1.right) {
			for (j=rect1.top; j<rect1.bottom; j++) {
				if (white != pdc1->GetPixel(rect1.right, j)) break;
			}
			if (j == rect1.bottom) rect1.right--; else break;
		}
		letter_rects[i] = rect1;
	}

	for (int i=startpos; i<=endpos; i++) {
		int index = i - startpos;
		sort(weights[index].begin(), weights[index].end());
		double sum = 0;
		for (int j=0; j<4; j++)
			sum += weights[index][j].first;
		double entropy = 2;
		for (int j=0; j<4; j++) {
			double p = weights[index][j].first / sum;
			entropy +=  p * log(p) / log(double(2.0));
		}
		int baseline = sizey;
		for (int j=0; j<4; j++) {
			int letterheight = (int)(entropy * sizey / 2 * weights[index][j].first / sum);
			int l = (int)(((__int64)(sizex) * index / (endpos - startpos + 1))) + 1;
			int r = (int)(((__int64)(sizex) * (index + 1) / (endpos - startpos + 1))) - 1;
			int letter = weights[index][j].second;
			pdc->StretchBlt(rect.left + l, rect.top + baseline - letterheight - 1, r - l, letterheight - 2, pdc1, letter_rects[letter].left, letter_rects[letter].top, letter_rects[letter].Width(), letter_rects[letter].Height(), SRCCOPY);
			baseline -= letterheight;
		}
	}

	image1.ReleaseDC();
	return true;
}

#endif //DRAW_MOTIF_H
