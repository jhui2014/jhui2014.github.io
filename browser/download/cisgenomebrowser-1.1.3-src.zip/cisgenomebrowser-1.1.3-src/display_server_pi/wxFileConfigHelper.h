#ifndef _WXFILECONFIGHELPER_H_
#define _WXFILECONFIGHELPER_H_
#include "wx/fileconf.h"
#include "inc_pi/UserDefinedType.h"
#include <string>
#include <algorithm>
#include <typeinfo>
using std::string;

template <class T>
struct ReadIniOp {
	static inline T Op(T val) { return val;}
};

template <>
struct ReadIniOp<std::string> {
	static inline std::string Op(std::string val) {
		replace(val.begin(), val.end(), '\\', '/');
		return val;
	}
};

template <>
struct ReadIniOp<wxString> {
	static inline wxString Op(wxString val) {
		val.Replace(wxT("\\"), wxT("/"));
		return val;
	}
};

template <class T>
T ReadIni(string file_name, string path, T defaultValue)
{
	wxFileConfig ini(wxEmptyString,wxEmptyString,wxS(file_name),wxEmptyString, wxCONFIG_USE_LOCAL_FILE | wxCONFIG_USE_NO_ESCAPE_CHARACTERS);
	T val;
	ini.Read(wxS(path),&val,defaultValue);
	return ReadIniOp<T>::Op(val);
}

extern void WriteIni(string file_name, string path, string value, bool condition);

template <class T>
void WriteIni(string file_name, string path, T value, bool condition)
{
	wxFileConfig ini(wxEmptyString,wxEmptyString,wxS(file_name),wxEmptyString, wxCONFIG_USE_LOCAL_FILE | wxCONFIG_USE_NO_ESCAPE_CHARACTERS);
	if (condition) {
		ini.Write(wxS(path),value);
	} else {
		ini.DeleteEntry(wxS(path));
	}
}

#endif
