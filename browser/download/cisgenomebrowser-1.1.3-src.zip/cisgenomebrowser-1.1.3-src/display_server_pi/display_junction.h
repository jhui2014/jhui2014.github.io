#ifndef _DISPLAY_JUNCTION_
#define _DISPLAY_JUNCTION_

#include "display_type.h"
struct http_request;

class display_junction: public display_type
{
public:
	string src_filename;
	string pic_filename;
	display_junction(http_request* r);
	virtual bool load_from_file(string file_name);
	virtual bool update_params();
	virtual bool write_to_file(string file_name);
	virtual string get_html();
private:
	string exon1_, exon2_;

};
#endif  // _DISPLAY_JUNCTION_