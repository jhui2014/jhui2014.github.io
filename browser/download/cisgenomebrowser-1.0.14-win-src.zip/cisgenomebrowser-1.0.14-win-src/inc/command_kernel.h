_COMMAND_KERNEL_H_
#define _COMMAND_KERNEL_H_

//#define VERBOSE

#define PROMPT "kdowerlkasjdlfweiord" //must be lower case
#define PROMPT_LEN 20

#include <windows.h>
#include <strsafe.h>
#include <tlhelp32.h>
#include "command_kernel.h"

typedef void(*OUTPUT_FUNC)(LPCTSTR);

#define WM_KERNEL (WM_USER+1)

#define MSG_INPUT 1
#define MSG_OUTPUT 2
#define MSG_STOP 3
#define MSG_IDLE 4
#define MSG_BUSY 5

class Command_Kernel{
public:
	bool started;
	bool idle;
	OUTPUT_FUNC outputf;
	HWND hwnd;
	HANDLE hThread;
	DWORD dwThreadId;
	LPTSTR* command_buf;
	int num_cmd;

	Command_Kernel();
	virtual ~Command_Kernel();
	virtual void set_callback(OUTPUT_FUNC output_func, HWND h_wnd);
	virtual void start_kernel();
	virtual void stop_kernel();
	virtual void restart_kernel();
	virtual void run_command(LPCTSTR command_line);
	virtual bool is_idle();
	virtual bool is_busy();
	virtual void process_message(UINT Msg,WPARAM wParam,LPARAM lParam);
	virtual void dispatch_output(LPCTSTR output);
	virtual void dispatch_cmd(LPCTSTR cmd);
	virtual void process_one_cmd();
};

#define bzero(a) memset(a,0,sizeof(a)) //easier -- shortcut

inline static bool IsWinNT()  //check if we're running NT
{
	OSVERSIONINFO osv;
	osv.dwOSVersionInfoSize = sizeof(osv);
	GetVersionEx(&osv);
	return (osv.dwPlatformId == VER_PLATFORM_WIN32_NT);
}

inline static void ErrorMessage(char *str)  //display detailed error info
{
	LPVOID msg;
	TCHAR* p;
	DWORD eNum;
	eNum = GetLastError( );
	FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		eNum,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
		(LPTSTR) &msg,
		0,
		NULL
		);
	char buf[1024];

	// Trim the end of the line and terminate it with a null
	p = (LPTSTR)msg;
	while( ( *p > 31 ) || ( *p == 9 ) )
		++p;
	do { *p-- = 0; } while( ( p >= msg ) &&
							( ( *p == '.' ) || ( *p < 33 ) ) );

	StringCchPrintf(buf, 1024, "\n  WARNING: %s failed with error %d (%s)", str, eNum, msg);
	MessageBox(NULL, buf, NULL, 0);
	LocalFree(msg);
}

inline static BOOL GetChildProcessIds(DWORD parent, DWORD* &childs, int &num)
{
  HANDLE hProcessSnap;
  PROCESSENTRY32 pe32;

  childs = NULL;
  num = 0;

  // Take a snapshot of all processes in the system.
  hProcessSnap = CreateToolhelp32Snapshot( TH32CS_SNAPPROCESS, 0 );
  if( hProcessSnap == INVALID_HANDLE_VALUE )
  {
    ErrorMessage( "CreateToolhelp32Snapshot (of processes)" );
    return( FALSE );
  }

  // Set the size of the structure before using it.
  pe32.dwSize = sizeof( PROCESSENTRY32 );

  // Retrieve information about the first process,
  // and exit if unsuccessful
  if( !Process32First( hProcessSnap, &pe32 ) )
  {
    ErrorMessage( "Process32First" );  // Show cause of failure
    CloseHandle( hProcessSnap );     // Must clean up the snapshot object!
    return( FALSE );
  }

  // Now walk the snapshot of processes, and
  // display information about each process in turn
  do
  {
	  if (pe32.th32ParentProcessID == parent) {
		  int new_num = num + 1;
		  DWORD* new_childs = new DWORD[new_num];
		  if (num > 0) {
			  memcpy(new_childs, childs, num * sizeof(DWORD));
			  delete[] childs;
			  childs = NULL;
		  }
		  new_childs[new_num-1] = pe32.th32ProcessID;
		  childs = new_childs;
		  num = new_num;
	  }
  } while( Process32Next( hProcessSnap, &pe32 ) );

  CloseHandle( hProcessSnap );
  return( TRUE );
}

inline static void terminate_childs(DWORD parent){
		//check for childs
		DWORD* childs;
		int child_num;
		if (!GetChildProcessIds(parent, childs, child_num)) {
			ErrorMessage("get child process failed");
		}
		if (child_num > 0){
			for (int i=0; i<child_num; i++) {
				terminate_childs(childs[i]);
				HANDLE hProcess;
				hProcess = OpenProcess( PROCESS_ALL_ACCESS, FALSE, childs[i]);
				if( hProcess == NULL ) {
					ErrorMessage( "OpenProcess" );
					continue;
				}
				TerminateProcess(hProcess, 4);
				CloseHandle(hProcess);
			}
			if (child_num > 0) delete[] childs;
		}
}

typedef struct _MyData {
    HWND hwnd;
} MYDATA, *PMYDATA;

inline static DWORD WINAPI ThreadProc( LPVOID lpParam ) 
{ 
	STARTUPINFO si;
	SECURITY_ATTRIBUTES sa;
	SECURITY_DESCRIPTOR sd;               //security information for pipes
	PROCESS_INFORMATION pi;
	HANDLE newstdin,newstdout,read_stdout,write_stdin;  //pipe handles
	unsigned long exitcode=0;  //process exit code
	TCHAR buf[1024];
	unsigned long bread;
	unsigned long avail;   //bytes available
	LPTSTR output = NULL;
	int output_len = 0;

	PMYDATA pData;

    // Cast the parameter to the correct data type.
    pData = (PMYDATA)lpParam;

	bool idle = true;
	//send idle msg
	if (!PostMessage(pData->hwnd, WM_KERNEL, MSG_IDLE, 0)){
		ErrorMessage("send output failed");
	}

	if (IsWinNT())        //initialize security descriptor (Windows NT)
	{
		InitializeSecurityDescriptor(&sd,SECURITY_DESCRIPTOR_REVISION);
		SetSecurityDescriptorDacl(&sd, true, NULL, false);
		sa.lpSecurityDescriptor = &sd;
	}
	else sa.lpSecurityDescriptor = NULL;
	sa.nLength = sizeof(SECURITY_ATTRIBUTES);
	sa.bInheritHandle = true;         //allow inheritable handles

	if (!CreatePipe(&newstdin,&write_stdin,&sa,0))   //create stdin pipe
	{
		ErrorMessage("CreatePipe");
		return 2;
	}
	if (!CreatePipe(&read_stdout,&newstdout,&sa,0))  //create stdout pipe
	{
		ErrorMessage("CreatePipe");
		CloseHandle(newstdin);
		CloseHandle(write_stdin);
		return 2;
	}

	GetStartupInfo(&si);      //set startupinfo for the spawned process
	/*
	The dwFlags member tells CreateProcess how to make the process.
	STARTF_USESTDHANDLES validates the hStd* members. STARTF_USESHOWWINDOW
	validates the wShowWindow member.
	*/
	si.dwFlags = STARTF_USESTDHANDLES|STARTF_USESHOWWINDOW;
	si.wShowWindow = SW_HIDE;
	si.hStdOutput = newstdout;
	si.hStdError = newstdout;     //set the new handles for the child process
	si.hStdInput = newstdin;

	if (!CreateProcess(NULL,"cmd",NULL,NULL,TRUE,CREATE_NEW_CONSOLE,NULL,NULL,&si,&pi))
	{
		ErrorMessage("CreateProcess");		
		CloseHandle(newstdin);
		CloseHandle(newstdout);
		CloseHandle(read_stdout);
		CloseHandle(write_stdin);
		return 3;		
	}

	bzero(buf);	
	bool stopping = false;

	while(!stopping) {
		//FlushFileBuffers(read_stdout);
		GetExitCodeProcess(pi.hProcess,&exitcode);      //while the process is running
		if (exitcode != STILL_ACTIVE) break;
		//check if there's input
		MSG msg;  
		// Remove any messages that may be in the queue. If the 
		// queue contains any input messages, handle the message.
		
		while (PeekMessage(&msg, NULL,  0, 0, PM_REMOVE)) 
		{ 
			switch(msg.message) 
			{ 
				case WM_KERNEL:
					if (msg.wParam == MSG_INPUT) {
						LPTSTR input = (LPTSTR)msg.lParam;
						size_t input_len;
						if (FAILED(StringCchLength(input, 1024, &input_len))) { //input too long
							ErrorMessage("Input too long");
							break;
						}
//						WriteFile(write_stdin,"cmd /c \"",8,&bread,NULL); //send it to stdin
						WriteFile(write_stdin,input,(DWORD)input_len,&bread,NULL); //send it to stdin
//						WriteFile(write_stdin,"\"\r\n", 3,&bread,NULL); //send it to stdin
						//Sleep(50); // should wait for process to come up
						idle = false;

						// Free the memory allocated by the caller for the input.
						HeapFree(GetProcessHeap(), 0, input);
					} else if (msg.wParam == MSG_STOP){
						terminate_childs(pi.dwProcessId);
						WriteFile(write_stdin,"exit\r\n\r\n",8,&bread,NULL); //send it to stdin
						stopping = true;
					} else {
						ErrorMessage("Invalid Message");
					}
					break;
				default:
					ErrorMessage("Invalid Message");
					break;
			} 
		} 		

		//check if there's output
		PeekNamedPipe(read_stdout,buf,1023,&bread,&avail,NULL);
		if (bread != 0)
		{
			bzero(buf);
			if (avail > 1023)
			{
				while (bread >= 1023)
				{
					ReadFile(read_stdout,buf,1023,&bread,NULL);  //read the stdout pipe
					int new_len = output_len + bread;
					LPTSTR new_output = new TCHAR[new_len+1];
					if (NULL == output) StringCchPrintf(new_output, new_len+1, "%s", buf);
					else {
						StringCchPrintf(new_output, new_len+1, "%s%s",output, buf);
						delete[] output;
						output = NULL;
					}
					bzero(buf);
					output = new_output;
					output_len = new_len;
				}
			}
			else {
				ReadFile(read_stdout,buf,1023,&bread,NULL);
				int new_len = output_len + bread;
				char* new_output = new char[new_len+1];
				if (NULL == output) StringCchPrintf(new_output, new_len+1,"%s", buf);
				else {
					StringCchPrintf(new_output, new_len+1, "%s%s",output, buf);
					delete[] output;
					output = NULL;
				}
				bzero(buf);
				output = new_output;
				output_len = new_len;
			}
		}
		
		if (output != NULL) {
			// Allocate memory for output.
			LPTSTR output_str = (LPTSTR) HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, output_len+1);
			memcpy(output_str, output, output_len+1);
			//send output
			if (!PostMessage(pData->hwnd, WM_KERNEL, MSG_OUTPUT, (LPARAM)(output_str))){
				ErrorMessage("send output failed");
			}

			//check for idle
			DWORD* childs;
			int child_num;
			if (!GetChildProcessIds(pi.dwProcessId, childs, child_num)) {
				ErrorMessage("get child process failed");
			}
			if (0 == child_num && !idle){
				if (output_len >= PROMPT_LEN && strcmp(output + output_len - PROMPT_LEN, PROMPT) == 0) {
					idle = true;
					if (!PostMessage(pData->hwnd, WM_KERNEL, MSG_IDLE, 0)){
						ErrorMessage("send output failed");
					}
				}
			} else if (child_num > 0 && idle){
				idle = false;
				if (!PostMessage(pData->hwnd, WM_KERNEL, MSG_BUSY, 0)){
					ErrorMessage("send output failed");
				}
			}
			if (child_num > 0) delete[] childs;

			delete[] output;
			output = NULL;
			output_len = 0;
		}

		if (stopping) break;
		Sleep(10); //Sleep to free CPU from 100% usage
	}

	if (WAIT_OBJECT_0 != WaitForSingleObject(pi.hProcess, 3000)){
		TerminateProcess(pi.hProcess, 4);
	}

	CloseHandle(pi.hThread);
	CloseHandle(pi.hProcess);
	CloseHandle(newstdin);            //clean stuff up
	CloseHandle(newstdout);
	CloseHandle(read_stdout);
	CloseHandle(write_stdin);

	// Free the memory allocated by the caller for the thread data structure.

    HeapFree(GetProcessHeap(), 0, pData);

    return 0; 
} 

inline void Command_Kernel::start_kernel(){
	if (started) return;
	if (outputf == NULL) return;
	if (hwnd == NULL) return;

    PMYDATA pData; 

    // Create thread.
    // Allocate memory for thread data.

    pData = (PMYDATA) HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY,
            sizeof(MYDATA));

    if( pData == NULL )
        return;

    // Generate unique data for thread.

    pData->hwnd = this->hwnd;

    hThread = CreateThread( 
        NULL,              // default security attributes
        0,                 // use default stack size  
        ThreadProc,        // thread function 
        pData,             // argument to thread function 
        0,                 // use default creation flags 
        &dwThreadId);   // returns the thread identifier 
 
    // Check the return value for success. 

    if (hThread == NULL) 
    {
        return;
    }
	started = true;
	idle = false;
	return;
}

inline Command_Kernel::Command_Kernel(){
	started = false;
	idle = false;
	outputf = NULL;
	hwnd = NULL;
	hThread = NULL;
	command_buf = NULL;
	num_cmd = 0;
}

inline Command_Kernel::~Command_Kernel(){
	if (started) {
		stop_kernel();
		started = false;
	}
	for (int i=0; i<num_cmd; i++) delete[] command_buf[i];
	delete[] command_buf;
	command_buf = NULL;
	num_cmd = 0;
}

inline void Command_Kernel::set_callback(OUTPUT_FUNC output_func, HWND h_wnd){
	outputf = output_func;
	hwnd = h_wnd;
}

inline void Command_Kernel::stop_kernel(){
	if (!started) return;
	PostThreadMessage(dwThreadId, WM_KERNEL, MSG_STOP, 0);
	if (WAIT_OBJECT_0 != WaitForSingleObject(hThread, 5000)){
		TerminateThread(hThread, 4);
	}
    // Close thread handle upon completion.
    CloseHandle(hThread);
	hThread = NULL;
	started = false;
	idle = false;
}

inline void Command_Kernel::restart_kernel(){
	stop_kernel();
	start_kernel();
}

inline void Command_Kernel::dispatch_cmd(LPCTSTR cmd){
	//copy the cmd
	size_t input_len;
	if (FAILED(StringCchLength(cmd, 1024, &input_len))) { //input too long
		ErrorMessage("Input too long");
		return;
	}
	LPTSTR command = (LPTSTR) HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, input_len+1);
	memcpy(command, cmd, input_len+1);
	//send output
	if (!PostThreadMessage(dwThreadId, WM_KERNEL, MSG_INPUT, (LPARAM)(command))){
		ErrorMessage("send output failed");
	}
}

inline void Command_Kernel::process_one_cmd(){
#ifdef VERBOSE
	outputf("\r\nprocess_ond_cmd\r\n");
#endif

	if (!started) return;
	if (!idle) return;
	if (num_cmd == 0) return;
	idle = false;
	dispatch_cmd(command_buf[0]);
	delete[] command_buf[0];
	command_buf[0] = NULL;
	//romove one command from queue
	int new_num_cmd = num_cmd - 1;
	LPTSTR* new_cmd_buf;
	if (num_cmd > 1) {
		new_cmd_buf = new LPTSTR[new_num_cmd];
		memcpy(new_cmd_buf, command_buf+1, new_num_cmd * sizeof(LPTSTR));
	} else new_cmd_buf = NULL;
	delete[] command_buf;
	command_buf = new_cmd_buf;
	num_cmd = new_num_cmd;
}

inline void Command_Kernel::run_command(LPCTSTR command_line){
#ifdef VERBOSE
	outputf("\r\nrun_command ");
	outputf(command_line);
	outputf("\r\n");
#endif

	if (!started) return;
	// Allocate memory for output.
	size_t input_len;
	if (FAILED(StringCchLength(command_line, 1024, &input_len))) { //input too long
		ErrorMessage("Input too long");
		return;
	}
	TCHAR* cmd = new TCHAR[input_len+1];
	memcpy(cmd, command_line, input_len+1);
	//put cmd into queue
	int new_num_cmd = num_cmd + 1;
	LPTSTR* new_cmd_buf = new LPTSTR[new_num_cmd];
	if (num_cmd > 0) {
		memcpy(new_cmd_buf, command_buf, num_cmd * sizeof(LPTSTR));
		delete[] command_buf;
		command_buf = NULL;
	}
	command_buf = new_cmd_buf;
	new_cmd_buf[new_num_cmd-1] = cmd;
	num_cmd = new_num_cmd;
	//try to process one cmd
	if (idle) process_one_cmd();
}

inline bool Command_Kernel::is_idle(){
	return idle;
}

inline bool Command_Kernel::is_busy(){
	return !is_idle();
}

inline void Command_Kernel::dispatch_output(LPCTSTR output){
	outputf(output);
}

inline void Command_Kernel::process_message(UINT Msg,WPARAM wParam,LPARAM lParam){
	switch(Msg) 
	{ 
		case WM_KERNEL:
			if (wParam == MSG_OUTPUT) {
				LPTSTR output = (LPTSTR)lParam;
				dispatch_output(output);
				// Free the memory allocated by the caller for the input.
				HeapFree(GetProcessHeap(), 0, output);
			} else if (wParam == MSG_IDLE){
				idle = true;
#ifdef VERBOSE
	outputf("\r\ngot idle msg\r\n");
#endif
				process_one_cmd();
//				outputf("idle\r\n");
			} else if (wParam == MSG_BUSY){
				idle = false;
//				outputf("busy\r\n");
			} else {
				ErrorMessage("Invalid Message");
			}
			break;
		default:
			ErrorMessage("Invalid Message");
			break;
	} 
}

#endif //_COMMAND_KERNEL_H_
