EXECUTABLE_PATH=/Users/wonglab/workspace/browser/bin

cd $EXECUTABLE_PATH
./display_server_pi