function [ g ] = log_likelihood_i( A, T, X, k )

epsilon = 1e-10;

X_new = X + epsilon;

g = - sum(A(:, k)) + sum(T' .* A(:, k) ./ (A * X_new));