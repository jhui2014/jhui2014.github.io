function [CI, BOUND, MEAN] = weighted_hist2(X, Y, type, draw_plot)

BOUND = zeros(2);

for i=1:2
    [xx, I] = sort(X(i,:));
    yy = Y(I);
    temp_sum = 0;
    for j=1:length(Y)
        temp_sum = temp_sum + yy(j);
        yy(j) = temp_sum;
    end
    BOUND(i,:) = [xx(min(find(yy>.001))) - 1e-6, xx(min(find(yy>.999))) + 1e-6];
    len = BOUND(i,2) - BOUND(i,1);
    BOUND(i,1) = max(0,BOUND(i,1) - len / 10);
    BOUND(i,2) = BOUND(i,2) + len / 10;
end

if draw_plot
    
    N_MESH = 20;
    
    [XX, YY] = meshgrid(linspace(BOUND(1,1), BOUND(1,2), N_MESH + 1), linspace(BOUND(2,1), BOUND(2,2), N_MESH + 1));
    ZZ = zeros(N_MESH+1, N_MESH+1);
    for k=1:length(Y)
        index_X = round((X(1,k) - BOUND(1,1)) * N_MESH / (BOUND(1,2)-BOUND(1,1))) + 1;
        index_X = max(1, index_X);
        index_X = min(N_MESH+1, index_X);
        index_Y = round((X(2,k) - BOUND(2,1)) * N_MESH / (BOUND(2,2)-BOUND(2,1))) + 1;
        index_Y = max(1, index_Y);
        index_Y = min(N_MESH+1, index_Y);
        ZZ(index_X, index_Y) = ZZ(index_X, index_Y) + Y(k);
    end
    
    if type == 2
        pcolor(XX, YY, ZZ');
    else
        surf(XX, YY, ZZ);
        shading interp
    end
    
end