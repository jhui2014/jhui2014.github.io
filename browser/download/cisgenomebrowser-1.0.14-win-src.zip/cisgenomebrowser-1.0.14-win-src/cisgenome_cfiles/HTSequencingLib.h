/* ----------------------------------------------------------------------- */
/*                                 Macro                                   */
/* ----------------------------------------------------------------------- */

/* ----------------------------------------------------------------------- */ 
/*                                 Struct                                  */
/* ----------------------------------------------------------------------- */ 

/* HTS aln2window paramters */
struct tagHTSAln2WinParam
{
	/* project name */
	char strProjectName[MED_LINE_LENGTH];

	/* chromosome list */
	char strChrList[MED_LINE_LENGTH];

	/* chromosome length */
	char strChrLen[MED_LINE_LENGTH];

	/* data directory */
	char strDataFolder[MED_LINE_LENGTH];

	/* No. of Libraries, Samples, Arrays and Groups */
	int nSampleNum;
	int nGroupNum;
	
	/* Sample name */
	struct INTMATRIX *vGroupLabel;
	struct tagString **vSampleAlias;
	struct tagString **vSampleFile;

	/* scaling parameter */
	double dScaling;

	/* window size */
	int nW;

	/* step size */
	int nS;

	/* export folder */
	char strExportFolder[MED_LINE_LENGTH];
};

/* ----------------------------------------------------------------------- */
/*                              Declaration                                */
/* ----------------------------------------------------------------------- */

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Window_Main()                                                  */
/*  Convert high throughput sequencing alignment to windowed bar tiling    */
/*  data. Each sample will be scaled to have the same number of aligned    */
/*  reads if specified.                                                    */
/* ----------------------------------------------------------------------- */ 
int HTS_Aln2Window_Main(char strParamPath[]);

/* ----------------------------------------------------------------------- */ 
/*  HTSAln2WinParam_Create()                                               */
/*  Create hts_aln2window paramter.                                        */
/* ----------------------------------------------------------------------- */ 
struct tagHTSAln2WinParam *HTSAln2WinParam_Create();

/* ----------------------------------------------------------------------- */ 
/*  HTSAln2WinParam_Destroy()                                              */
/*  Destroy hts_aln2window paramter.                                       */
/* ----------------------------------------------------------------------- */ 
void HTSAln2WinParam_Destroy(struct tagHTSAln2WinParam **pParam);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Window_LoadParamter()                                          */
/*  Load hts_aln2window paramter.                                          */
/* ----------------------------------------------------------------------- */ 
struct tagHTSAln2WinParam *HTS_Aln2Window_LoadParamter(char strParamPath[]);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Window_PrepareBARData()                                        */
/*  Prepare the bar data object.                                           */
/* ----------------------------------------------------------------------- */ 
struct tagBARData * HTS_Aln2Window_PrepareBARData(struct tagHTSAln2WinParam *pParam, 
				struct INTMATRIX *pChrLen);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Window_PrepareBARData()                                        */
/*  Count hits in each window.                                             */
/* ----------------------------------------------------------------------- */ 
double HTS_Aln2Window_CountHits(struct tagBARData *pBARData, char strInFile[], int nW);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Window_Scaling()                                               */
/*  Scaling HTS data.                                                      */
/* ----------------------------------------------------------------------- */ 
int HTS_Aln2Window_Scaling(struct tagBARData *pBARData, double dScale);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Window_WriteCGW()                                              */
/*  Write to CGW file.                                                     */
/* ----------------------------------------------------------------------- */ 
int HTS_Aln2Window_WriteCGW(struct tagHTSAln2WinParam *pParam);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Window_WriteCGB()                                              */
/*  Write to CGB file.                                                     */
/* ----------------------------------------------------------------------- */
int HTS_Aln2Window_WriteCGB(struct tagHTSAln2WinParam *pParam);


/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Diff_Main()                                                    */
/*  Detect differentially aligned regions.                                 */
/* ----------------------------------------------------------------------- */ 
int HTS_Aln2Diff_Main(char strParamPath[]);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Diff_PrepareBARData()                                          */
/*  Prepare the bar data object.                                           */
/* ----------------------------------------------------------------------- */ 
struct tagBARData * HTS_Aln2Diff_PrepareBARData(struct tagHTSAln2WinParam *pParam, 
				struct INTMATRIX *pChrLen);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Diff_PrepareRecountingData()                                   */
/*  Prepare the bar data object.                                           */
/* ----------------------------------------------------------------------- */ 
struct tagBARData * HTS_Aln2Diff_PrepareRecountingData(struct tagHTSAln2WinParam *pParam, 
				struct INTMATRIX *pChrLen);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Diff_CountHits()                                               */
/*  Count hits in each window.                                             */
/* ----------------------------------------------------------------------- */ 
double HTS_Aln2Diff_CountHits(struct tagBARData *pBARData, char strInFile[], int nW, int nSampleID);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Diff_EstimateP()                                               */
/*  Estimate hyperparameter.                                               */
/* ----------------------------------------------------------------------- */ 
int HTS_Aln2Diff_EstimateP(struct tagBARData *pBARData, double *vP, int nSampleNum);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Diff_EstimatePrior2Col()                                       */
/*  Estimate prior probability of difference                               */
/* ----------------------------------------------------------------------- */ 
int HTS_Aln2Diff_EstimatePrior2Col(struct tagBARData *pBARData, int nSampleNum, 
								   double *vP, double *dPriorP);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Diff_EstimatePBinom()                                          */
/*  Estimate hyperparamter for mixture binominal                           */
/* ----------------------------------------------------------------------- */ 
int HTS_Aln2Diff_EstimatePBinom(struct tagBARData *pBARData, int nSampleNum, 
								   double *vP);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Diff_EstimateP3()                                              */
/*  Estimate hyperparamter for mixture binominal                           */
/* ----------------------------------------------------------------------- */ 
int HTS_Aln2Diff_EstimateP3(struct tagBARData *pBARData, int nSampleNum, 
								   double *vP);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Diff_CallRegion()                                              */
/*  Call differentially expressed regions.                                 */
/* ----------------------------------------------------------------------- */ 
int HTS_Aln2Diff_CallRegion(struct tagHTSAln2WinParam *pParam, double *vP);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Enrich_Main()                                                  */
/*  Detect enriched alignment regions.                                     */
/* ----------------------------------------------------------------------- */ 
int HTS_Aln2Enrich_Main(char strParamPath[]);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2Enrich_EstimateP()                                             */
/*  Estimate hyperparamter for mixture binominal                           */
/* ----------------------------------------------------------------------- */ 
int HTS_Aln2Enrich_EstimateP(struct tagBARData *pBARData, int nSampleNum, 
								   double *vP);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2BAR()                                                          */
/*  Convert high throughput sequencing alignment to bar file.              */
/* ----------------------------------------------------------------------- */ 
int HTS_Aln2BAR(char strTXTFile[], char strBARFile[]);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Aln2BARv2()                                                        */
/*  Convert high throughput sequencing alignment to bar file.              */
/* ----------------------------------------------------------------------- */ 
int HTS_Aln2BARv2(char strTXTFile[], char strBARFile[]);

/* ----------------------------------------------------------------------- */ 
/*  HTS_WindowSummary()                                                    */
/*  Summarize window counts.                                               */
/* ----------------------------------------------------------------------- */ 
int HTS_WindowSummary(char strBARFile[], char strChrList[], char strChrLen[], 
					  int nW, char strOutFile[]);

/* ----------------------------------------------------------------------- */ 
/*  HTS_WindowSummaryv2()                                                  */
/*  Summarize window counts.                                               */
/* ----------------------------------------------------------------------- */ 
int HTS_WindowSummaryv2(char strBARFile[], char strChrList[], char strChrLen[], 
					  int nW, char strOutFile[]);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_OneSample_Main()                                            */
/*  Find enriched region from a sequencing data set.                       */
/* ----------------------------------------------------------------------- */ 
int HTS_Enrich_OneSample_Main(char strBARFile[], int nW, int nS, int nCutoff,
					  int nMinLen, int nMaxGap,
					  char strExportFolder[], char strOutFileTitle[]);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_OneSamplev2_Main()                                          */
/*  Find enriched region from a sequencing data set.                       */
/* ----------------------------------------------------------------------- */ 
int HTS_Enrich_OneSamplev2_Main_Old(char strBARFile[], int nW, int nS, int nCutoff,
					  int nCutoffF, int nCutoffR, int nMinLen, int nMaxGap,
					  char strExportFolder[], char strOutFileTitle[]);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_OneSamplev2_Main()                                          */
/*  Find enriched region from a sequencing data set.                       */
/* ----------------------------------------------------------------------- */ 
int HTS_Enrich_OneSamplev2_Main(char strBARFile[], int nW, int nS, int nCutoff, 
					  int nCutoffF, int nCutoffR, int nMinLen, int nMaxGap, 
					  char strExportFolder[], char strOutFileTitle[],
					  int nBR, int nBRL, int nSSF);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_OneSample_CallRegion_Initial()                              */
/*  Search for enriched windows.                                           */
/* ----------------------------------------------------------------------- */ 
struct DOUBLEMATRIX *HTS_Enrich_OneSample_CallRegion_Initial(struct tagBARData *pBARData,
			int nW, int nS, int nCutoff, char strExportFolder[], char strOutFileTitle[]);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_OneSample_MergeRegion()                                     */
/*  Merge and filter regions.                                              */
/* ----------------------------------------------------------------------- */ 
struct DOUBLEMATRIX *HTS_Enrich_OneSample_MergeRegion(struct DOUBLEMATRIX *pRegion0, 
	int nMinLen, int nMaxGap);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_OneSample_MergeRegion()                                     */
/*  Merge and filter regions.                                              */
/* ----------------------------------------------------------------------- */ 
struct DOUBLEMATRIX *HTS_Enrich_OneSamplev2_MatchFRRegions(struct DOUBLEMATRIX *pRegion, 
		struct DOUBLEMATRIX *pRegionF, struct DOUBLEMATRIX *pRegionR);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_OneSamplev2_FindOverlap()                                   */
/*  Find overlap region.                                                   */
/* ----------------------------------------------------------------------- */ 
int HTS_Enrich_OneSamplev2_FindOverlap(struct DOUBLEMATRIX *pRegion, 
					int nChr, int nStart, int nEnd);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_OneSample_ExportResults()                                   */
/*  Export results.                                                        */
/* ----------------------------------------------------------------------- */ 
int	HTS_Enrich_OneSample_ExportResults(struct DOUBLEMATRIX *pRegion, 
							struct tagBARData *pBARData, char strFileName[]);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_OneSamplev2_ExportResults()                                 */
/*  Export results.                                                        */
/* ----------------------------------------------------------------------- */ 
int	HTS_Enrich_OneSamplev2_ExportResults_Old(struct DOUBLEMATRIX *pRegion, 
				struct tagBARData *pBARData, char strFileName[]);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_OneSamplev2_ExportResults()                                 */
/*  Export results.                                                        */
/* ----------------------------------------------------------------------- */ 
int	HTS_Enrich_OneSamplev2_ExportResults(struct DOUBLEMATRIX *pRegion, 
				struct tagBARData *pBARData, char strFileName[], int nBR, int nBRL,
				int nSSF, int nSSFF, int nSSFR);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_OneSample_RegionCollectInfo()                               */
/*  Collect reads number.                                                  */
/* ----------------------------------------------------------------------- */ 
int HTS_Enrich_OneSample_RegionCollectInfo(struct DOUBLEMATRIX *pRegion, struct tagBARData *pBARData);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_OneSamplev2_RegionCollectInfo()                             */
/*  Collect forward/reverse reads info                                     */
/* ----------------------------------------------------------------------- */ 
struct DOUBLEMATRIX *HTS_Enrich_OneSamplev2_RegionCollectInfo(struct DOUBLEMATRIX *pRegion, 
				struct tagBARData *pBARData, int nW);

/* ----------------------------------------------------------------------- */ 
/*  HTS_TwoSample_WindowSummary()                                          */
/*  Summarize window counts.                                               */
/* ----------------------------------------------------------------------- */ 
int HTS_TwoSample_WindowSummary(char strPosBARFile[], char strNegBARFile[],
					char strChrList[], char strChrLen[], 
					int nW, char strOutFile[]);

/* ----------------------------------------------------------------------- */ 
/*  HTS_TwoSample_WindowSummaryv2()                                        */
/*  Summarize window counts.                                               */
/* ----------------------------------------------------------------------- */ 
int HTS_TwoSample_WindowSummaryv2(char strPosBARFile[], char strNegBARFile[],
					char strChrList[], char strChrLen[], 
					int nW, char strOutFile[]);

/* ----------------------------------------------------------------------- */ 
/*  HTS_TwoSample_FDR()                                                    */
/*  Compute FDR for two sample comparison.                                 */
/* ----------------------------------------------------------------------- */ 
int HTS_TwoSample_FDR(struct DOUBLEMATRIX *pCount, struct DOUBLEMATRIX *pCount2D, 
					  int nMaxC, int nMaxCPos, struct DOUBLEMATRIX **pFDR, 
					  double *dP0);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_TwoSample_Main()                                            */
/*  Find enriched region from a sequencing data set.                       */
/* ----------------------------------------------------------------------- */ 
int HTS_Enrich_TwoSample_Main(char strPosBARFile[], char strNegBARFile[], 
					  int nOneSide, int nW, int nS, int nTCut, char strFDRFile[], double dFDRCut,
					  int nMinLen, int nMaxGap, double dP0,
					  char strExportFolder[], char strOutFileTitle[]);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_TwoSamplev2_Main()                                          */
/*  Find enriched region from a sequencing data set.                       */
/* ----------------------------------------------------------------------- */ 
int HTS_Enrich_TwoSamplev2_Main(char strPosBARFile[], char strNegBARFile[], 
					  int nOneSide, int nW, int nS, int nTCut, char strFDRFile[], double dFDRCut,
					  int nMinLen, int nMaxGap, double dP0,
					  char strExportFolder[], char strOutFileTitle[],
					  int nBR, int nBRL, int nSSF, int nSSFF, int nSSFR);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_TwoSample_CallRegion_Initial()                              */
/*  Search for differentially expressed windows.                           */
/* ----------------------------------------------------------------------- */ 
struct DOUBLEMATRIX *HTS_Enrich_TwoSample_CallRegion_Initial(struct tagBARData *pBARDataPos,
			struct tagBARData *pBARDataNeg, int nW, int nS, int nTCut,
			struct DOUBLEMATRIX *pFDR, double dFDRCut, double dP0, int nOneSide,
			char strExportFolder[], char strOutFileTitle[]);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_TwoSample_MergeRegion()                                     */
/*  Merge and filter regions.                                              */
/* ----------------------------------------------------------------------- */ 
struct DOUBLEMATRIX *HTS_Enrich_TwoSample_MergeRegion(struct DOUBLEMATRIX *pRegion0, 
	int nMinLen, int nMaxGap);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_TwoSample_ExportResults()                                   */
/*  Export results.                                                        */
/* ----------------------------------------------------------------------- */ 
int	HTS_Enrich_TwoSample_ExportResults(struct DOUBLEMATRIX *pRegion, 
			struct tagBARData *pBARDataPos, struct tagBARData *pBARDataNeg,
			char strFileName[]);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_TwoSamplev2_ExportResults()                                 */
/*  Export results.                                                        */
/* ----------------------------------------------------------------------- */ 
int	HTS_Enrich_TwoSamplev2_ExportResults(struct DOUBLEMATRIX *pRegion, 
			struct tagBARData *pBARDataPos, struct tagBARData *pBARDataNeg,
			char strFileName[], int nBR, int nBRL, int nSSF, int nSSFF, int nSSFR);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_TwoSample_RegionCollectInfo()                               */
/*  Collect reads number.                                                  */
/* ----------------------------------------------------------------------- */ 
int HTS_Enrich_TwoSample_RegionCollectInfo(struct DOUBLEMATRIX *pRegion, 
		struct tagBARData *pBARDataPos, struct tagBARData *pBARDataNeg);

/* ----------------------------------------------------------------------- */ 
/*  HTS_Enrich_TwoSamplev2_RegionCollectInfo()                             */
/*  Collect reads number.                                                  */
/* ----------------------------------------------------------------------- */ 
struct DOUBLEMATRIX *HTS_Enrich_TwoSamplev2_RegionCollectInfo(struct DOUBLEMATRIX *pRegion, 
		struct tagBARData *pBARDataPos, struct tagBARData *pBARDataNeg, int nW,
		struct DOUBLEMATRIX *pFDR, double dP0, int nOneSide);
