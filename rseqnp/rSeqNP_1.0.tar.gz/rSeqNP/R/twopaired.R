#paired two-group data
Twopaired=function(exp_object, outcome, nperm, seed, low.exp)
{

  #suppressMessages(library(exactRankTests))
  #library(exactRankTests)
  iso.exp=exp_object$iso.exp
  gene.exp=exp_object$gene.exp
  
  #get the name for genes and isoforms--long format
  gene_name=iso.exp[,1]
  isoform_name=iso.exp[,2]
  isoform_number=iso.exp[,3]
  
  #get the gene name--short format
  gene.name=gene.exp[,1]
  isoform.number=gene.exp[,2]
  
  n_sample=length(outcome) #total number of samples
  n_iso=nrow(iso.exp) #total number of isoforms(transcripts) in the dataframe  
  n_gene=nrow(gene.exp) #number of genes
  
  N.iso=apply(iso.exp[,4:(n_sample+3)],2,as.numeric)#this is the expression matrix for all isoforms, numeric  
  N.gene=apply(gene.exp[,3:(n_sample+2)],2,as.numeric)#this is the expression matrix for all genes, numeric
  
  #test 1: do the Wilcoxon signed-rank test for all isoforms, returns the WSR statistics and p-values
  isoform.res=t(apply(N.iso,1,calculate.twogroup.WSR.test))
  colnames(isoform.res)=c('WSR.stat','p.WSRtest')
  
  #calculate the FDR for all isoforms based on the Wilcoxon p value
  FDR.BH_i=p.adjust(isoform.res[,2], method="BH")
  
  #calculate the average log2 fold change for isoforms between the two groups
  avg_exp1_i=rowMeans(N.iso[,outcome == 1])  #average expression level for the first group
  avg_exp2_i=rowMeans(N.iso[,outcome == 2])  #average expression level for the second group
  if.low.i = (avg_exp1_i<low.exp) | (avg_exp2_i<low.exp) #add a tag indicate whether an isoform is lowly expressed in either of the one group, then the fold change is not so meaningful
  log.FC_i=log2(avg_exp1_i/avg_exp2_i) #log2 fold change
  
  isoform.result=data.frame(gene_name,isoform_name,isoform_number,isoform.res,fdr.BH=FDR.BH_i, log.FC=log.FC_i, if.low=if.low.i)
  isoform.result=isoform.result[order(isoform.result$fdr.BH,-abs(isoform.result$WSR.stat),-abs(isoform.result$log.FC),isoform.result$gene_name,isoform.result$isoform_name),]
  #gene_name, isoform_name, isoform_number, WSR.stat, p.WSRtest, fdr.BH, log.FC, if.low
    
  
  cat("Isoform differential expression test done!\n")
  
  #test 2: Do the Wilcoxon signed-rank test for all genes, returns the WSR statistics and p-values
  gene.res=t(apply(N.gene,1,calculate.twogroup.WSR.test))
  colnames(gene.res)=c('WSR.stat','p.WSRtest')
  FDR.BH_g=p.adjust(gene.res[,2], method="BH")
  
  #calculate the average log2 fold change for genes between the two groups
  avg_exp1_g=rowMeans(N.gene[,outcome == 1])  #average expression level for the first group
  avg_exp2_g=rowMeans(N.gene[,outcome == 2])  #average expression level for the second group
  if.low.g = (avg_exp1_g<low.exp) | (avg_exp2_g<low.exp) #add a tag indicate whether a gene is lowly expressed in either of the one group, then the fold change is not so meaningful
  log.FC_g=log2(avg_exp1_g/avg_exp2_g)  #log 2 fold change
  
  gene.result=data.frame(gene.name,gene.res,fdr.BH=FDR.BH_g,log.FC=log.FC_g, if.low=if.low.g)
  gene.result=gene.result[order(gene.result$fdr.BH,-abs(gene.result$WSR.stat),-abs(gene.result$log.FC),gene.result$gene.name),]
  #gene.name, WRS.stat, p.WRStest, fdr.BH, log.FC, if.low
  
  cat("Gene differential expression test done!\n")

  #test 3: Permutation test for differential expression and splicing of genes using GDS score
  
  GDS.result=GDS(isoform.info=data.frame(gene_name=isoform.result[,1], isoform_number=isoform.result[,3], Tj=isoform.result[,4]),
                 iso.exp=iso.exp, type='twopaired', outcome=outcome, nperm=nperm, seed=seed)
  #calculate the T.value that indicates the level of differential splicing
  theta_mat=data.frame(gene_name, avg_exp1_i, avg_exp2_i)
  gene.info=as.data.frame(table(gene_name))
  gene.info=gene.info[order(gene.info[,2],gene.info[,1]),]
  isoform.number.gds=gene.info[,2]
  gene.name=gene.info[,1]
  T.value=NA
  for (i in 1:length(gene.name))
  {
    if(isoform.number.gds[i]==1) { ##only one isoform
      T.value[i]=0
    } else {
      g_i_exp=theta_mat[theta_mat$gene_name==gene.name[i], 2:3]
      T.value[i] = 0.5*sum( abs( g_i_exp[,1]/(sum(g_i_exp[,1]))-g_i_exp[,2]/(sum(g_i_exp[,2])) ) )
    }
  }  
  T.value.mat=data.frame(gene.name, T.value) #T values with gene names
  GDS.result=join_all(list(GDS.result, T.value.mat), by='gene.name') #insert T value in the result dataframe 
  GDS.result=GDS.result[order(GDS.result$iso.num, GDS.result$p.plugin, -GDS.result$GDS, -GDS.result$T.value, GDS.result$gene.name),]
  
  cat("Permutation test based on GDS done!\n")
  
  return(list(isoform.DE.result=isoform.result, gene.DE.result=gene.result, GDS.result=GDS.result))
}

#this function calculate the Wilcoxon signed-rank statistic for two paired groups, 
#data is the data vector, outcomes is the sample tags for the two groups like c(1,2,1,2...,1,2)
#return the Wilcoxon statistic and the p_value
calculate.twogroup.WSR.test=function(data)
{  
  y1=data[c(T,F)]
  y2=data[c(F,T)]
  #print(y1)
  #print(y2)
  y=y1-y2
  n_p=sum(y!=0) #this is the number of positive ranks of the difference vector
  
  if(n_p==0)
  { 
    wsr_stat=0
    p_value=1
  } else  
  {
   test=wilcox.exact(y1,y2,alternative = "two.sided",paired=T,exact=T)
   wsr_stat=test$statistic - (n_p+1)*n_p/4
   p_value=test$p.value
  }
  if(is.na(p_value)){p_value=1}
  
  return(c(wsr_stat, p_value))
    
}
