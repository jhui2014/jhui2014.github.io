source("twoD.R")

#The following program requires packages "MASS", and "polynom".
library(MASS)
library(polynom)

#Each row of data contains coefficents of a convex quadratic function: AX^2+BXY+CY^2+DX+EY+F
#Note that when input the data, 
#data[i,1]=A
#data[i,2]=B/2   !!!
#data[i,3]=C
#data[i,4]=D
#data[i,5]=E
#data[i,6]=F


#call back function for TwoD
quadratic_shift = function(data, lambda) {
    data[, 6] = data[, 6] - lambda
    return(data)
}

#call back function for TwoD
quadratic_val = function(data, i, x) {
    return(data[i, 1] * x[1] ^ 2 + 2 * data[i, 2] * x[1] * x[2] + data[i, 3] * x[2] ^ 2 + data[i, 4] * x[1] + data[i, 5] * x[2] + data[i, 6])
}

#call back function for TwoD
quadratic_min = function(data_s, modifier, suff_stat = NULL) {
    if (is.null(suff_stat)) {
        suff_stat = rep(0, 6)
    }
    suff_stat = suff_stat + colSums(matrix(sign(modifier) * data_s[abs(modifier),], length(modifier), 6))
    A = matrix(c(suff_stat[1:2], suff_stat[2:3]), c(2, 2))
    B = c(suff_stat[4:5])
    if (abs(det(A)) < 1e-6) {
        argmin = c(0, 0)
    } else {
        argmin = -solve(A, B) / 2
    }
    m = t(argmin) %*% A %*% argmin + t(B) %*% argmin + suff_stat[6]
    return(list(par = argmin, value = m, suff_stat = suff_stat))
}

#call back function for TwoD
quadratic_radius = function(data_s, i, center, theta) {
    A = matrix(c(data_s[i, 1:2], data_s[i, 2:3]), c(2, 2))
    B = c(data_s[i, 4:5])
    v = c(cos(theta), sin(theta))
    a = t(v) %*% A %*% v
    b = 2 * t(v) %*% A %*% center + t(B) %*% v
    c = t(center) %*% A %*% center + t(B) %*% center + data_s[i, 6]
    r = (- b + sqrt(b ^ 2 - 4 * a * c)) / (2 * a)
    return(r)
}

#call back function for TwoD
quadratic_point = function(data_s, i) {
    return(quadratic_min(data_s, i)$par)
}

#call back function for TwoD
quadratic_intersect = function(data_s, i, j) {
    a00i = 1
    a01i = data_s[i, 2] / data_s[i, 1]
    a11i = data_s[i, 3] / data_s[i, 1]
    b0i = data_s[i, 4] / data_s[i, 1]
    b1i = data_s[i, 5] / data_s[i, 1]
    ci = data_s[i, 6] / data_s[i, 1]
    a00j = 1
    a01j = data_s[j, 2] / data_s[j, 1]
    a11j = data_s[j, 3] / data_s[j, 1]
    b0j = data_s[j, 4] / data_s[j, 1]
    b1j = data_s[j, 5] / data_s[j, 1]
    cj = data_s[j, 6] / data_s[j, 1]

    v0 = 2 * (a00i * a01j - a00j * a01i)
    v1 = a00i * a11j - a00j * a11i
    v2 = a00i * b0j - a00j * b0i
    v3 = a00i * b1j - a00j * b1i
    v4 = a00i * cj - a00j * ci
    v5 = 2 * (a01i * a11j - a01j * a11i)
    v6 = 2 * (a01i * b1j - a01j * b1i)
    v7 = 2 * (a01i * cj - a01j * ci)
    v8 = a11i * b0j - a11j * b0i
    v9 = b0i * b1j - b0j * b1i
    v10 = b0i * cj - b0j * ci

    u0 = v2 * v10 - v4 ^ 2
    u1 = v0 * v10 + v2 * (v7 + v9) - 2 * v3 * v4
    u2 = v0 * (v7 + v9) + v2 * (v6 - v8) - v3 ^ 2 - 2 * v1 * v4
    u3 = v0 * (v6 - v8) + v2 * v5 - 2 * v1 * v3
    u4 = v0 * v5 - v1 ^ 2
    py = as.polynomial(c(u0, u1, u2, u3, u4))
    z = solve(py)
    y = c()

    eps = 1e-6
    for (i in 1:length(z)) {
        if (abs(Im(z[i])) < eps) {
            y = c(y, Re(z[i])) #
        }
    }
    A = a00i
    points = c()
    points_final = c()
    if (is.null(y) == FALSE) {
        y = unique(y)
        if (length(y) != 1) {
            removelist = c()
            for (i in 1:(length(y) - 1)) {
                for (j in (i + 1):length(y)) {
                    if (abs(y[i] - y[j]) < eps) {
                        removelist = c(removelist, - j) #
                    }
                }
            }
            if (is.null(removelist) == FALSE) {
                y = y[removelist]
            }
        }
        for (i in 1:length(y)) {
            B = 2 * a01i * y[i] + b0i
            C = a11i * y[i] ^ 2 + b1i * y[i] + ci
            if (B ^ 2 - 4 * A * C >= 0) {
                D = sqrt(B ^ 2 - 4 * A * C)
                points = rbind(points, c(( - B + D) / (2 * A), y[i]), c(( - B - D) / (2 * A), y[i]))
            }
        }
        if (is.null(points) == FALSE) {
            for (i in 1:nrow(points)) {
                x = points[i, 1]
                y = points[i, 2]
                if (abs(a11j * y ^ 2 + b1j * y + cj + (2 * a01j * y + b0j) * x + a00j * x ^ 2) < eps) {
                    points_final = rbind(points_final, points[i,, drop = F]) #
                }
            }
            if (is.null(points_final) == F) {
                if (nrow(points_final) > 1) {
                    multi = c()
                    for (k in 1:(nrow(points_final) - 1)) {
                        for (l in (k + 1):nrow(points_final)) {
                            if (sum((points_final[k, ] - points_final[l, ]) ^ 2) < eps) {
                                multi = c(multi, l)
                            }
                        }
                    }
                    if (is.null(multi) == FALSE) {
                        return(points_final[ - multi,, drop = F])
                    } else {
                        return(points_final)
                    }
                }
            } else {
                return(points_final)
            }
        }
    }
}

#main function
quadratic.2D = function(data, lambda = 0) {
    twoD(data, lambda = lambda, g_shift = quadratic_shift, g_val = quadratic_val, g_min = quadratic_min, g_intersect = quadratic_intersect, g_radius = quadratic_radius, g_point = quadratic_point)
}
