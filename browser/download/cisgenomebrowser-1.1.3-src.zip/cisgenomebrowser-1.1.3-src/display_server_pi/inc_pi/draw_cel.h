#ifndef DRAW_CEL_H
#define DRAW_CEL_H

#include "draw_figure_support.h"
#include "colormap.h"

class draw_cel: public draw_figure_structure
{
public:
	vector<double> pdata;
	vector<char> masks;
	string cel_filename;
	colormap cm;

	draw_cel();
	virtual string print_usage();
	virtual bool get_params(const vector<string> &params);
	virtual bool load_data();
	virtual bool draw(wxMemoryDC* pdc, int x_off = 0, int y_off = 0);
};

#endif //DRAW_CEL_H
