// display_serverDlg.cpp : implementation file
//

#include "stdafx.h"
#include "display_server.h"
#include "display_serverDlg.h"
#include ".\display_serverdlg.h"

#include "main_thread.h"
#include "shared_data.h"
#include "stl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

void output_func(LPCTSTR output){
	if (output == NULL) return;
/*	FILE *file = fopen(log_filename.c_str(), "at");
	fprintf(file, "%s", output);
	fclose(file);*/
	cout << output;
}

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// Cdisplay_serverDlg dialog

const char* kpcTrayNotificationMsg_ = "TBHide tray notification";

Cdisplay_serverDlg::Cdisplay_serverDlg(CWnd* pParent /*=NULL*/)
	: CDialog(Cdisplay_serverDlg::IDD, pParent),
	bMinimized_(true),
	pTrayIcon_(0),
	nTrayNotificationMsg_(RegisterWindowMessage(kpcTrayNotificationMsg_))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

Cdisplay_serverDlg::~Cdisplay_serverDlg(){
	cleanup();
}

void Cdisplay_serverDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(Cdisplay_serverDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_COMMAND(ID_SYSTRAY_RESTORE, OnSystrayRestore)
	ON_COMMAND(ID_SYSTRAY_EXIT, OnSystrayExit)
	ON_BN_CLICKED(IDOK, OnBnClickedOk)
	ON_WM_WINDOWPOSCHANGING()
	ON_WM_CLOSE()
	ON_COMMAND(ID_SYSTRAY_BROWSE, OnSystrayBrowse)
	ON_COMMAND(ID_SYSTRAY_SETTING, OnSystraySetting)
	ON_COMMAND(ID_SYSTRAY_ABOUT, OnSystrayAbout)
	//ON_MESSAGE(WM_KERNEL, OnMyMessage)
END_MESSAGE_MAP()


// Cdisplay_serverDlg message handlers

BOOL Cdisplay_serverDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	SetupTrayIcon();
	SetupTaskBarButton();
    
/*	kernel = new MyKernel();
	kernel->set_callback(output_func, this->m_hWnd);
	kernel->start_kernel();*/

	startup();

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void Cdisplay_serverDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	bool bOldMin = bMinimized_;
	if (nID == SC_MINIMIZE) {
		bMinimized_ = true;
	}
	else if (nID == SC_RESTORE) {
		bMinimized_ = false;
	}

	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}

	if (bOldMin != bMinimized_) {
		// Minimize state changed.  Create the systray icon and do 
		// custom taskbar button handling.
		SetupTrayIcon();
		SetupTaskBarButton();
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void Cdisplay_serverDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR Cdisplay_serverDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void Cdisplay_serverDlg::SetupTaskBarButton()
{
	if (bMinimized_) {
		ShowWindow(SW_HIDE);
	}
	else {
		ShowWindow(SW_SHOW);
	}

}

void Cdisplay_serverDlg::SetupTrayIcon()
{
	if (bMinimized_ && (pTrayIcon_ == 0)) {
		pTrayIcon_ = new CSystemTray;
		pTrayIcon_->Create(0, nTrayNotificationMsg_, "CisGenome Browser",m_hIcon,IDR_TRAY);
	}
	else {
		delete pTrayIcon_;
		pTrayIcon_ = 0;
	}
}
void Cdisplay_serverDlg::OnSystrayRestore()
{
	// TODO: Add your command handler code here
	ShowWindow(SW_RESTORE);
	bMinimized_ = false;
	SetupTrayIcon();
	SetupTaskBarButton();
}

void Cdisplay_serverDlg::OnSystrayExit()
{
	// TODO: Add your command handler code here
	bMinimized_ = false;
	SetupTrayIcon();
	OnOK();
}

void Cdisplay_serverDlg::OnBnClickedOk()
{
	// TODO: Add your control notification handler code here
	OnOK();
}

void Cdisplay_serverDlg::OnWindowPosChanging(WINDOWPOS* lpwndpos)
{
  if(bMinimized_)
  {
    lpwndpos->flags &= ~SWP_SHOWWINDOW;
  }
	CDialog::OnWindowPosChanging(lpwndpos);

	// TODO: Add your message handler code here
}

void Cdisplay_serverDlg::OnClose()
{
	// TODO: Add your message handler code here and/or call default
	CDialog::OnClose();
}

void Cdisplay_serverDlg::OnSystrayBrowse()
{
	// TODO: Add your command handler code here
	ShellExecute(NULL, "open", local_host_name.c_str(), NULL, NULL, SW_SHOWNORMAL);
}

void Cdisplay_serverDlg::OnSystraySetting()
{
	// TODO: Add your command handler code here
	std::string url = local_host_name + "setting";
	ShellExecute(NULL, "open", url.c_str(), NULL, NULL, SW_SHOWNORMAL);
}

void Cdisplay_serverDlg::OnSystrayAbout()
{
	// TODO: Add your command handler code here
		//CAboutDlg dlgAbout;
		//dlgAbout.DoModal();
	std::string url = local_host_name + "about.html";
	ShellExecute(NULL, "open", url.c_str(), NULL, NULL, SW_SHOWNORMAL);
}


LRESULT Cdisplay_serverDlg::OnMyMessage(WPARAM wParam, LPARAM lParam)
{
//	if (NULL != kernel) kernel->process_message(WM_KERNEL, wParam, lParam);
	return 0;
}