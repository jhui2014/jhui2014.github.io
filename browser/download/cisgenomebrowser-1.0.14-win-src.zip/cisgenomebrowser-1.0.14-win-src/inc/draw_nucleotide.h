#ifndef DRAW_NUCLEOTIDE_H
#define DRAW_NUCLEOTIDE_H

#include "draw_axis.h"
#include "genefile.h"
#include "string_operation.h"
#include "file_operation.h"
#include "math_utils.h"
#include <atlimage.h>
#include "cisgenome.h"

class draw_nucleotide: public draw_axis
{
public:
	string nucleotides;

	string file_path;
	string chr;
	int startpos, endpos;

	draw_nucleotide();
	virtual string print_usage();
	virtual bool get_params(const vector<string> &params);
	virtual bool load_data();
	virtual bool prepare_data();
	virtual bool draw_contents(CDC *pdc, const CRect rect);
};

inline draw_nucleotide::draw_nucleotide(){
	top_axis = bottom_axis = true;
	left_space = right_space = true;

	nucleotides = "";
	file_path = "";
	chr = "";
	startpos = endpos = -1;
}

inline string draw_nucleotide::print_usage(){
	return "<sequence file path> </region:<chr>:<sequence start position>-<sequence end position>> [/width:<picture width>] [/axis:xxxx]\n";
}

inline bool draw_nucleotide::get_params(const vector<string> &params){
	if (params.size() == 0) return false;
	file_path = params[0];

	bool good_options = true;
	for (int i=1; i<(int)params.size(); i++) {
		string option = params[i];

		string command = "";
		string parameter = "";
		if (option[0] != '/') {
			good_options = false;
			break;
		}
		size_t index = option.find (":");
		if (index != string::npos ) {
			command = option.substr(1, index - 1);
			parameter = option.substr(index + 1);
		} else {
			command = option.substr(1);
		}
		if (command == "width"){
			sscanf(parameter.c_str(), "%d", &size.cx);
			if (size.cx <=0) {
				error_msg = "Invalid parameter. wrong picture width.\n";
				good_options = false;
				break;
			}
		} else if (command == "region"){
			if (!parse_region(parameter, chr, startpos, endpos)){
				error_msg = "Invalid parameter. wrong region.\n";
				good_options = false;
				break;
			}
		} else if (command == "axis"){
			int mask;
			sscanf(parameter.c_str(), "%d", &mask);
			top_axis = (mask >= 1000);
			mask %= 1000;
			bottom_axis = (mask >= 100);
			mask %= 100;
			left_axis = (mask >= 10);
			mask %= 10;
			right_axis = (mask >= 1);
		} else {
			good_options = false;
			break;
		}
	}
	return good_options;
}

inline bool draw_nucleotide::load_data(){
	if (error_msg != "") return false;
	if (startpos <=0 || endpos <=0 || chr == "") {
		error_msg = "Invalid parameter. no region information.\n";
		return false;
	}

	domainlow = startpos;
	domainhigh = endpos;

	if (endpos - startpos + 1 > 1000) return true; //skip too long sequence to save time

	struct tagSequence *pSeq = NULL;
	char filename[1024];
	sprintf(filename, "%s%s.sq", file_path.c_str(), chr.c_str());
	if (!file_exists(filename)) {
		error_msg = "error opening sequence file.\n";
		return false;
	}
	pSeq = Genome_Code_4bit_GetSeq(filename, startpos, endpos);
	if(pSeq == NULL) {
		error_msg = "error reading sequence file.\n";
		return false;
	}

	nucleotides = pSeq->m_pSequence->m_pString;

	if ((int)nucleotides.length() != endpos - startpos + 1) {
		error_msg = "error reading sequence file.\n";
		return false;
	}

	SequenceDelete(pSeq);

	return true;
}

inline bool draw_nucleotide::prepare_data(){
	if (error_msg != "") return false;

	left_space = left_axis;
	right_space = right_axis;
	left_axis = right_axis = false;

	draw_axis::prepare_data();

	CImage image1;
	image1.Create(100,100,24);
	CDC* pdc1 = CDC::FromHandle(image1.GetDC());
	CSize textsize= pdc1->GetTextExtent("W");
	size.cy = axis_top + axis_bottom + textsize.cy;

	image1.ReleaseDC();	

	draw_axis::prepare_data();

	return true;
}

inline bool draw_nucleotide::draw_contents(CDC *pdc, const CRect rect){
	if (error_msg != "") return false;

	CFont font;
	VERIFY(font.CreateFont(
	20,                       // nHeight
	8,                         // nWidth
	0,                         // nEscapement
	0,                         // nOrientation
	FW_NORMAL,                 // nWeight
	FALSE,                     // bItalic
	FALSE,                     // bUnderline
	0,                         // cStrikeOut
	ANSI_CHARSET,              // nCharSet
	OUT_DEFAULT_PRECIS,        // nOutPrecision
	CLIP_DEFAULT_PRECIS,       // nClipPrecision
	DEFAULT_QUALITY,           // nQuality
	DEFAULT_PITCH | FF_SWISS,  // nPitchAndFamily
	"Courier New"));                 // lpszFacename
	CFont* def_font = pdc->SelectObject(&font);

	CSize textsize= pdc->GetTextExtent("W");
	if (textsize.cx * (int)nucleotides.length() > rect.Width()) goto quit;
	if ((int)nucleotides.length() != endpos - startpos + 1) goto quit;
	if (do_folding) goto quit;

	for (int i = startpos; i <= endpos; i++) {
		string nt = nucleotides.substr(i - startpos, 1);
		textsize = pdc->GetTextExtent(nt.c_str());
		int pos = ((i - startpos) * rect.Width()) / (endpos - startpos) + rect.left;
		pdc->TextOut(pos - textsize.cx / 2, rect.top, nt.c_str());
	}

quit:
	pdc->SelectObject(def_font);
	// Done with the font.  Delete the font object.
	font.DeleteObject();
	return true;
}

#endif //DRAW_NUCLEOTIDE_H
