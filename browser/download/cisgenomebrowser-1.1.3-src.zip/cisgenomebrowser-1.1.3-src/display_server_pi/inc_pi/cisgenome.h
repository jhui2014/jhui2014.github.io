#ifndef _CISGENOME_H
#define _CISGENOME_H

#ifndef _MSC_VER
extern "C"
{
#endif
#include "../../cisgenome_cfiles/MicroarrayLib.h"
#include "../../cisgenome_cfiles/MatrixLib.h"
#include "../../cisgenome_cfiles/StringLib.h"
#include "../../cisgenome_cfiles/TilingArrayLib.h"
#include "../../cisgenome_cfiles/AffyLib.h"
#include "../../cisgenome_cfiles/GenomeLib.h"
#include "../../cisgenome_cfiles/SequenceLib.h"
#ifndef _MSC_VER
}
#endif

#endif // CISGENOME_H
