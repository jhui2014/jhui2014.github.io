#ifndef _DISPLAY_CEL_
#define _DISPLAY_CEL_

#include "display_type.h"

struct http_request;

class display_cel: public display_type
{
public:
	string src_filename;
	string pic_filename;
	display_cel(http_request* r);
	virtual bool load_from_file(string file_name);
	virtual bool update_params();
	virtual bool write_to_file(string file_name);
	virtual string get_html();
};

#endif