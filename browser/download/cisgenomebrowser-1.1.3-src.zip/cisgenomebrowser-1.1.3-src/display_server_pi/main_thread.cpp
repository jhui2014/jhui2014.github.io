#include "main_thread.h"
#include "webserver.h"
#include "session.h"
#include "inc_pi/html_formater.h"
#include "inc_pi/shared_func.h"
#include "shared_data.h"
#include "wx/stdpaths.h"
#include "wx/fileconf.h"
#include "wx/filename.h"
#include "wx/thread.h"
#include "wx/dir.h"
#include "wx/arrstr.h"
#include "wx/event.h"
#include "wx/filefn.h"
//#include "wxSocketHelper.h"
#include "wxDebugHelper.h"
#include "inc_pi/file_operation.h"
//#include "Server.h"

#include <iostream>
#include <string>
#include <boost/asio.hpp>
#include <boost/bind.hpp>
#include <boost/function.hpp>
#include <boost/lexical_cast.hpp>
#include "server/server.hpp"
#include <boost/thread.hpp>

#include <boost/thread/mutex.hpp>
#include <boost/thread/locks.hpp>

using boost::asio::ip::tcp;

#if !defined(_WIN32)
#include <pthread.h>
#include <signal.h>
#endif

vector<string> get_session_names()
{
	vector<string> session_names;
	session_names.clear();
	wxArrayString files;
	wxDir::GetAllFiles(wxS(session_path), &files);
	vector<string> file_names;
	for (size_t i = 0; i < files.size(); i++)
	{
		string fullpath = files[i].ToAscii();
		file_names.push_back(fullpath.substr(fullpath.find_last_of("/\\") + 1));
	}
	for (int i = 0; i < (int)file_names.size(); i++)
	{
		//hide all session beginning with '_'
		if (file_names[i].length() > 4 && tolower(file_names[i].substr(file_names[i].length()-4)) == ".ini" && file_names[i][0] != '_')
		{
			session_names.push_back(file_names[i].substr(0, file_names[i].length()-4));
		}
	}
	return session_names;
}

std::vector<std::string> get_local_ip() {
	boost::asio::io_service io_service;
	tcp::resolver resolver(io_service);
	tcp::resolver::query query(boost::asio::ip::host_name(),"");
	tcp::resolver::iterator it=resolver.resolve(query);

	std::vector<std::string> res;
	while(it != tcp::resolver::iterator()) {
		boost::asio::ip::address addr=(it++)->endpoint().address();
		if(addr.is_v4()) {
			res.push_back(addr.to_string());
		}
	}
	return res;
}

static boost::mutex gmutex;

void main_handler(http_request* r)
{
	int seed = (int)time(NULL);
	srand(seed);
	rand();
	rand();

	put2log(string("client from ") + r->client_ip_);

	boost::lock_guard<boost::mutex> lock(gmutex);
	server_ip = r->server_ip_;
	client_ip = "127.0.0.1";

	local_client = (server_ip == "127.0.0.1") || (server_ip == "localhost");
	std::vector<std::string> local_ips = get_local_ip();
	for (size_t i = 0; i < local_ips.size(); ++i) {
		local_client |= local_ips[i] == r->client_ip_;
	}

	host_name = string("http://") + server_ip + ":" + int2str(port_num) + "/";

	title = "";

	if (r->path_ == "/" || r->path_== "/index.html")
	{
		html_formater my_html_formater;
		my_html_formater.load_from_template_file(template_path+"index.html");
		vector<string> session_names = get_session_names();
		session_names.insert(session_names.begin(), "");
		my_html_formater.replace_keyword("$LOAD_SESSION$", drop_down_list_html("name", session_names, session_names));
		r->answer_ = my_html_formater.buf;
	}
	else if (r->path_ == "/session")
	{
		session mysession(r);
	}
	else if (r->path_ == "/dir")
	{
		if (local_client)
		{
			folder_to_be_opened = program_path;
			r->answer_ = redirect_html(host_name);
		}
		else
		{
			r->answer_ = error_html("Remote user can not do this.");
		}
	}
	else if (r->path_ == "/log")
	{
		if (local_client) {
			r->answer_ = redirect_html(host_name + "temp/" + log_filename);
		} else {
			r->answer_ = error_html("Remote user can not do this.");
		}
	}
	else if (r->path_ == "/setting")
	{
		if (local_client)
		{
			html_formater my_html_formater;
			my_html_formater.load_from_template_file(template_path+"setting.html");
			my_html_formater.replace_keyword("$PORT_NUM$", int2str(new_port_num));
			my_html_formater.replace_keyword("$LOCAL_ONLY$", new_local_only?" checked":"");
			r->answer_ = my_html_formater.buf;
		}
		else
		{
			r->answer_ = error_html("Remote user can not do this.");
		}
	}
	else if (r->path_ == "/update_setting")
	{
		if (local_client)
		{
			r->answer_ = redirect_html(host_name);
			if (r->params_.count("update_setting") > 0)
			{
				bool temp_local_only = (r->params_.count("local_only") > 0);
				int temp_port_num = str2int(r->params_["port_num"]);
				if (!is_int(r->params_["port_num"]) || temp_port_num < 1024 || temp_port_num > 65535) {
					r->answer_ = error_html("port number must be between 1024 and 65535.");
				}
				else
				{
					wxFileConfig ini(wxEmptyString,wxEmptyString,wxS(ini_filename),wxEmptyString, wxCONFIG_USE_LOCAL_FILE | wxCONFIG_USE_NO_ESCAPE_CHARACTERS);
					if (temp_port_num != new_port_num)
					{
						new_port_num = temp_port_num;
						if (new_port_num != default_port_num)
						{
							ini.Write(_T("browser/port_num"),new_port_num);
						}
						else
						{
							ini.DeleteEntry(_T("browser/port_num"));
						}
					}
					if (temp_local_only != new_local_only)
					{
						new_local_only = temp_local_only;
						if (new_local_only != default_local_only)
						{
							ini.Write(_T("browser/local_only"),new_local_only);
						}
						else
						{
							ini.DeleteEntry(_T("browser/local_only"));
						}
					}
				}
			}
		}
		else
		{
			r->answer_ = error_html("Remote user can not do this.");
		}
	}
	else if (r->path_ == "/clear")
	{
		if (local_client)
		{
			if (!wxDeleteAllFileInDir(session_path))
			{
				r->answer_ = error_html("Failed when clearing the session directory.");
			}
			if (!wxDeleteAllFileInDir(temp_path))
			{
				r->answer_ = error_html("Failed when clearing the temporary directory.");
			}
			r->answer_ = redirect_html(host_name);
		}
		else
		{
			r->answer_ = error_html("Remote user can not do this.");
		}
	}
	else
	{
		r->answer_ = error_html("Requested page does not exist.");
	}
	html_formater my_html_formater;
	my_html_formater.load_from_template_file(template_path+"template.html");
	my_html_formater.replace_keyword("$CONTENTS$", r->answer_);
	if (title == "") title = "CisGenome Browser";
	my_html_formater.replace_keyword("$TITLE$", title);
	r->answer_ = my_html_formater.buf;
}

class ServerThread : public wxThread
{
public:
	ServerThread(void * data1) : wxThread(wxTHREAD_JOINABLE) {
		Create();
		d1 = data1;
	}
	virtual void * Entry() {
		webserver server(port_num);
		return NULL;
	}
private:
	void *d1;
};

ServerThread *server_thread = NULL;

#if defined(_WIN32)
boost::function0<void> console_ctrl_function;

BOOL WINAPI console_ctrl_handler(DWORD ctrl_type)
{
	switch (ctrl_type)
	{
	case CTRL_C_EVENT:
	case CTRL_BREAK_EVENT:
	case CTRL_CLOSE_EVENT:
	case CTRL_SHUTDOWN_EVENT:
		console_ctrl_function();
		return TRUE;
	default:
		return FALSE;
	}
}

class server_main_thread {
public:
	server_main_thread(std::string ip, std::string port, std::string thread_n, std::string root) {
		ip_ = ip;
		port_ = port;
		thread_n_ = thread_n;
		root_ = root;
	}

	std::string ip_, port_, thread_n_, root_;

	void run() {
		try {
			// Initialise server.
			std::size_t num_threads = boost::lexical_cast<std::size_t>(thread_n_);
			http::server3::server s(ip_, port_, root_, num_threads);

			// Set console control handler to allow server to be stopped.
			console_ctrl_function = boost::bind(&http::server3::server::stop, &s);
			SetConsoleCtrlHandler(console_ctrl_handler, TRUE);

			// Run the server until stopped.
			s.run();
		} catch (std::exception& e) {
			std::cerr << "exception: " << e.what() << "\n";
		}
	}
};
#endif

#if defined(_WIN32)
static server_main_thread *gp_server_main_thread = NULL;
static boost::thread *gp_server_background_thread = NULL;
#else
static http::server3::server *gp_server = NULL;
static boost::thread *gp_server_background_thread = NULL;
#endif

void startup()
{
	int seed = (int)time(NULL);
	srand(seed);

	// Parse the ini file and read environment variables
	wxFileName exeFile(wxStandardPaths::Get().GetExecutablePath());
	program_path = exeFile.GetPath().ToAscii();
	program_path = substitute(program_path,"\\","/");
	ini_filename = program_path + "/cgb.ini";
	wxFileConfig ini(wxEmptyString,wxEmptyString,wxS(ini_filename),wxEmptyString, wxCONFIG_USE_LOCAL_FILE | wxCONFIG_USE_NO_ESCAPE_CHARACTERS);

	wwwroot = ini.Read(_T("browser/wwwroot"),wxS(program_path) + wxT("/wwwroot/")).ToAscii();
	module_path = ini.Read(_T("browser/module_path"),wxS(program_path)).ToAscii();
	template_path = ini.Read(_T("browser/template_path"),wxS(wwwroot+"templates/")).ToAscii();
	session_path = ini.Read(_T("browser/session_path"),wxS(wwwroot+"sessions/")).ToAscii();
	temp_path = wwwroot+"temp/";
	server_temp_path = "temp/";
	string defaultLogFileName = "log_" + get_time_string() + "_" + get_random_string() + ".txt";
	log_filename = ini.Read(_T("browser/log_filename"),wxS(defaultLogFileName)).ToAscii();
	port_num = (int)ini.Read(_T("browser/port_num"),(long)default_port_num);
	ini.Read(_T("browser/local_only"),&local_only,default_local_only);

	new_local_only = local_only;
	new_port_num = port_num;

	freopen((temp_path+log_filename).c_str(), "wt", stdout);

	put2log("start cisgenome browser");
	put2log("initialize random seed");
	put2log("initialize program parameters");
	put2log("program_path = " + program_path);
	put2log("ini_filename = " + ini_filename);
	put2log("wwwroot = " + wwwroot);
	put2log("module_path = " + module_path);
	put2log("template_path = " + template_path);
	put2log("session_path = " + session_path);
	put2log("temp_path = " + temp_path);
	put2log("server_temp_path = " + server_temp_path);
	put2log("log_filename = " + log_filename);
	put2log("local_only = " + int2str(local_only));

	server_ip = "127.0.0.1";
	client_ip = "";
	local_client = true;

	max_cache_size_MB = (int)ini.Read(_T("browser/max_cache_size"),256);
	put2log(string("max_cache_size_MB = ") + int2str(max_cache_size_MB));

	ini.Read(_T("browser/cache_genefiles"),&cache_genefiles,true);
	put2log(string("cache_genefiles = ") + int2str(cache_genefiles));
	genefile_cache.clear();
	genefile_time_cache.clear();

	// Start Old webserver
	//server_thread = new ServerThread(NULL);
	//server_thread->Run();

	std::string ip_string = "0.0.0.0";
	local_host_name = "http://127.0.0.1:" + int2str(port_num) + "/";

	// Start Asio Server
#if defined(_WIN32)
	gp_server_main_thread = new server_main_thread(ip_string, int2str(port_num), "20", "./wwwroot/");
	gp_server_background_thread = new boost::thread(boost::bind(&server_main_thread::run, gp_server_main_thread));
	boost::shared_ptr<boost::thread> thread(gp_server_background_thread);
#else
	gp_server = new http::server3::server(ip_string, int2str(port_num), "./wwwroot/", 20);
	gp_server_background_thread = new boost::thread(boost::bind(&http::server3::server::run, gp_server));
#endif
}

void cleanup()
{
	put2log("cleaning up");
	put2log("terminating web server thread");

	if (server_thread) {
		server_thread->Kill();
		delete server_thread;
		server_thread = NULL;
	}

#if defined(_WIN32)
	if (gp_server_main_thread) {
		delete gp_server_main_thread;
		gp_server_main_thread = NULL;
	}
	if (gp_server_background_thread) {
		//delete gp_server_background_thread;
		gp_server_background_thread = NULL;
	}
#else
	if (gp_server) {
		delete gp_server;
		gp_server = NULL;
	}
	if (gp_server_background_thread) {
		delete gp_server_background_thread;
		gp_server_background_thread = NULL;
	}
#endif

	put2log("close log file handle");
	fclose(stdout);
}

