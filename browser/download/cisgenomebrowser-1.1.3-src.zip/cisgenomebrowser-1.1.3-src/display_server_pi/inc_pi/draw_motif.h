#ifndef DRAW_MOTIF_H
#define DRAW_MOTIF_H

#include "draw_axis.h"

class draw_motif: public draw_axis
{
public:
	string motif_filename;
	vector<vector<pair<double, int> > > weights;
	int startpos, endpos;

	draw_motif();
	virtual string print_usage();
	virtual bool get_params(const vector<string> &params);
	virtual bool load_data();
	virtual bool prepare_data();
	virtual bool draw_contents(wxMemoryDC *pdc, const PIRect rect);
};


#endif //DRAW_MOTIF_H
