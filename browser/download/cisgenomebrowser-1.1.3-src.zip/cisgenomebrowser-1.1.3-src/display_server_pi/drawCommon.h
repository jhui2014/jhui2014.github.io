#ifndef _DRAWCOMMON_H_
#define _DRAWCOMMON_H_

#include "inc_pi/draw_data.h"
#include "inc_pi/draw_bar.h"
#include "inc_pi/draw_regbar.h"
#include "inc_pi/draw_conservation.h"
#include "inc_pi/draw_motif.h"
#include "inc_pi/draw_motif_html.h"
#include "inc_pi/draw_cel.h"
#include "inc_pi/draw_gene.h"
#include "inc_pi/draw_nucleotide.h"
#include "inc_pi/draw_junction.h"
#include "inc_pi/chr_region.h"
#include "inc_pi/file_operation.h"
#include "inc_pi/string_operation.h"
#include "inc_pi/math_utils.h"
#include "default_values.h"
#include "shared_data.h"
#include "wxFileConfigHelper.h"
#include "webserver.h"
#include "inc_pi/UserDefinedType.h"
#include "inc_pi/html_formater.h"

inline bool get_gene_file_name(const string filename, string &gene_filename,
							   string &error_msg)
{
	gene_filename = "";
	error_msg = "";
	if (!file_exists(filename))
	{
		error_msg = "ERROR: file does not exist.";
		return false;
	}
	else if (!is_genefile(filename))
	{
		if (file_exists(filename + ".genefile") && compare_file_time(filename,
			filename + ".genefile") <= 0)
		{
			if (!is_genefile(filename + ".genefile"))
			{
				error_msg
					= "ERROR: failed converting file to genefile format: file already exists and in wrong format.";
				return false;
			}
		}
		else
		{
			if (is_bamfile(filename)) {
				if (!convert_from_bam_to_gene(filename, filename + ".genefile"))
				{
					error_msg = "ERROR: failed converting bam file to genefile format.";
					return false;
				}
			} else { 
				if (!is_gene_text_file(filename))
				{
					error_msg
						= "ERROR: file is neither in genefile nor in correct text format.";
					return false;
				}
				if (!convert_from_text_to_gene(filename, filename + ".genefile"))
				{
					error_msg = "ERROR: failed converting file to genefile format.";
					return false;
				}
			}
		}
		gene_filename = filename + ".genefile";
	}
	else
	{
		gene_filename = filename;
	}
	return true;
}

inline bool get_genefile_from_cache(const string filename, string &error_msg,
									genefile* &mygenefile)
{
	error_msg = "";
	mygenefile = NULL;
	if (!cache_genefiles)
	{
		error_msg = "ERROR:caching is not allowed";
		return false;
	}
	else if (!file_exists(filename))
	{
		error_msg = "ERROR: file does not exist.";
		return false;
	}
	else if (genefile_time_cache.count(filename) == 0 || file_changed(filename,
		genefile_time_cache[filename]))
	{
		string gene_filename;
		if (!get_gene_file_name(filename, gene_filename, error_msg))
			return false;
		genefile tempgenefile;
		if (!tempgenefile.read_from_file(gene_filename))
		{
			error_msg = "ERROR: read genefile failed.";
			return false;
		}
		genefile_cache[filename] = tempgenefile;
		genefile_time_cache[filename] = get_file_modify_time(filename);
		mygenefile = &genefile_cache[filename];
		//check cache size and remove old ones if cache oversize
	}
	else
	{
		mygenefile = &genefile_cache[filename];
	}
	return true;
}


inline string get_random_session_name()
{
	string session_name = string("cgb_random_session_") + get_random_string();
	while (file_exists(session_path + session_name + ".ini"))
		session_name = string("cgb_random_session_") + get_random_string();
	return session_name;
}

inline string get_random_pic_file_name()
{
	string pic_file_name = string("cgb_random_pic_") + get_random_string()
		+ ".png";
	while (file_exists(temp_path + client_ip + pic_file_name))
		pic_file_name = string("cgb_random_pic_") + get_random_string()
		+ ".png";
	return pic_file_name;
}


extern string def_colors[8];
extern PICOLORREF def_colorrefs[8];

#endif
